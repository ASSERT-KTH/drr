import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(regularTimePeriod2, regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        try {
            timeSeries1.delete((int) 'a', (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(regularTimePeriod3, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries1.update(regularTimePeriod5, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        try {
            timeSeries1.delete(0, (int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            java.lang.Number number6 = timeSeries1.getValue(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        java.lang.Number number8 = null;
        try {
            timeSeries1.add(regularTimePeriod7, number8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        try {
            java.lang.Number number3 = timeSeries1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0f, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100.0]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100.0]"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) ' ', seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent7.getSummary();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo11);
        boolean boolean13 = timeSeries8.equals((java.lang.Object) seriesChangeInfo11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.next();
        long long19 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Number number23 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number23);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        try {
            timeSeries1.delete(1, (int) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str6 = seriesException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            timeSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries9.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        long long18 = fixedMillisecond14.getFirstMillisecond();
        java.lang.Number number19 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        boolean boolean21 = fixedMillisecond14.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond14.next();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 11);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month15.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str12 = fixedMillisecond6.toString();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str12.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        java.lang.Number number7 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (-9999), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond10.peg(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, regularTimePeriod19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.Object obj3 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.fireSeriesChanged();
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            java.lang.Number number4 = timeSeries1.getValue(regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        long long22 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1969L + "'", long22 == 1969L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond24.getMiddleMillisecond(calendar27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar30 = null;
        try {
            month22.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries2.getNotify();
        java.util.List list7 = timeSeries2.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 3, false);
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(0, year11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        java.util.List list8 = timeSeries1.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate(regularTimePeriod9, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        try {
            timeSeries1.delete(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        int int16 = month15.getMonth();
        java.lang.String str17 = month15.toString();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month15.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        boolean boolean21 = timeSeries16.equals((java.lang.Object) seriesChangeInfo19);
        java.lang.Comparable comparable22 = timeSeries16.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 0);
        java.util.Date date29 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond33.getMiddleMillisecond(calendar36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1L);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = month31.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) -1 + "'", comparable22.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 97L + "'", long35 == 97L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        int int31 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete((int) (byte) 100, 6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        int int16 = month15.getMonth();
        java.lang.String str17 = month15.toString();
        java.util.Calendar calendar18 = null;
        try {
            month15.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 11);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        timeSeries15.fireSeriesChanged();
        timeSeries15.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries15);
        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) timeSeries13);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean21);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.util.Date date2 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        timeSeries8.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 11);
        timeSeries8.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond26.getMiddleMillisecond(calendar29);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1969);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond19.getMiddleMillisecond();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        seriesChangeEvent28.setSummary(seriesChangeInfo29);
        boolean boolean31 = timeSeries26.equals((java.lang.Object) seriesChangeInfo29);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
        long long39 = fixedMillisecond35.getFirstMillisecond();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 1.0f);
        try {
            timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDescription("December 1969");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        boolean boolean11 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        try {
            timeSeries1.update(0, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries14.addAndOrUpdate(timeSeries16);
        boolean boolean22 = timeSeries10.equals((java.lang.Object) timeSeries16);
        int int23 = month7.compareTo((java.lang.Object) boolean22);
        long long24 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-26409600000L) + "'", long24 == (-26409600000L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year4.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        try {
            timeSeries1.delete((int) (byte) 100, (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.next();
        long long19 = fixedMillisecond15.getFirstMillisecond();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, regularTimePeriod22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("Value");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        try {
            timeSeries1.update((int) (short) 100, (java.lang.Number) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        java.util.List list8 = timeSeries1.getItems();
        int int9 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 11);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        timeSeriesDataItem5.setValue((java.lang.Number) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.util.Date date13 = year12.getEnd();
        int int14 = timeSeriesDataItem5.compareTo((java.lang.Object) year12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        int int11 = timeSeries1.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Date date21 = year3.getEnd();
        java.util.TimeZone timeZone22 = null;
        try {
            org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        long long7 = year3.getLastMillisecond();
        long long8 = year3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(regularTimePeriod8, (org.jfree.data.time.RegularTimePeriod) day12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25568L + "'", long13 == 25568L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        timeSeries1.setMaximumItemCount(12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) false);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        boolean boolean21 = timeSeries16.equals((java.lang.Object) seriesChangeInfo19);
        java.lang.Comparable comparable22 = timeSeries16.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 0);
        java.util.Date date29 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (double) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) -1 + "'", comparable22.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getLastMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        try {
            java.lang.Number number18 = timeSeries1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("31-December-1969");
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        java.lang.String str7 = year3.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean14 = year11.equals((java.lang.Object) 'a');
        java.lang.String str15 = year11.toString();
        int int16 = year3.compareTo((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        java.util.Calendar calendar6 = null;
        try {
            day3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.util.Collection collection5 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) -1, true);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond15.getFirstMillisecond(calendar21);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182986393L + "'", long16 == 1560182986393L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182986393L + "'", long17 == 1560182986393L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182986393L + "'", long22 == 1560182986393L);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        int int4 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        java.util.Calendar calendar21 = null;
        fixedMillisecond18.peg(calendar21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        int int17 = month16.getMonth();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month16.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        long long23 = year4.getFirstMillisecond();
        java.lang.Object obj24 = null;
        int int25 = year4.compareTo(obj24);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31507200000L) + "'", long23 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        timeSeries1.removeAgedItems(0L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond10.peg(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (short) 100);
        timeSeriesDataItem18.setValue((java.lang.Number) 100L);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        java.lang.Object obj22 = timeSeriesDataItem18.clone();
        timeSeries1.add(timeSeriesDataItem18);
        java.lang.String str24 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(class10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        long long15 = year10.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year10.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1969L + "'", long15 == 1969L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.lang.String str17 = month16.toString();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month16.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = year4.getSerialIndex();
        long long9 = year4.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        timeSeries8.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 11);
        timeSeries8.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21, true);
        timeSeries1.setDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2649600001L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond9.getFirstMillisecond(calendar14);
        java.lang.String str16 = fixedMillisecond9.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str16.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        int int9 = month7.getYearValue();
        int int10 = month7.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month7.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0L);
        long long14 = day11.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day11.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        try {
            timeSeries1.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
        java.lang.String str11 = seriesChangeEvent9.toString();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date8, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        java.lang.String str36 = month32.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "December 1969" + "'", str36.equals("December 1969"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        try {
            timeSeries1.delete(7, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo7);
        boolean boolean9 = timeSeries4.equals((java.lang.Object) seriesChangeInfo7);
        java.lang.Comparable comparable10 = timeSeries4.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) (short) 0);
        java.util.Date date17 = fixedMillisecond12.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(regularTimePeriod18, (java.lang.Number) 1560182981229L);
        try {
            timeSeries1.delete(8, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) -1 + "'", comparable10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        long long8 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        java.lang.String str31 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.delete(31, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        try {
            timeSeries1.update(11, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate(regularTimePeriod17, (double) 1560182987537L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2649600000L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        boolean boolean17 = month15.equals((java.lang.Object) (-25070400001L));
        int int18 = month15.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, 10);
        timeSeries21.setDescription("1969");
        boolean boolean24 = fixedMillisecond10.equals((java.lang.Object) timeSeries21);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries21.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        long long11 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        java.util.Calendar calendar18 = null;
        try {
            day15.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        long long10 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        timeSeries10.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.Class<?> wildcardClass17 = timeSeries16.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray9 = seriesException7.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException11.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException7.addSuppressed((java.lang.Throwable) seriesException16);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        long long36 = month32.getFirstMillisecond();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = month32.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2649600000L) + "'", long36 == (-2649600000L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        long long15 = fixedMillisecond9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 0L);
        java.lang.Number number14 = timeSeriesDataItem13.getValue();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0L + "'", number14.equals(0L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        long long10 = fixedMillisecond1.getLastMillisecond();
        long long11 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        boolean boolean8 = timeSeries1.getNotify();
        try {
            timeSeries1.delete(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        try {
            java.lang.Number number16 = timeSeries1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        boolean boolean4 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("March 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        long long7 = day3.getFirstMillisecond();
        int int8 = day3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        int int12 = day11.getMonth();
        long long13 = day11.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25568L + "'", long13 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection34 = timeSeries33.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries33.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo42 = null;
        seriesChangeEvent41.setSummary(seriesChangeInfo42);
        boolean boolean44 = timeSeries39.equals((java.lang.Object) seriesChangeInfo42);
        java.lang.Comparable comparable45 = timeSeries39.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getLastMillisecond(calendar48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (short) 0);
        java.util.Date date52 = fixedMillisecond47.getTime();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond56.getMiddleMillisecond(calendar59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month54, (java.lang.Number) 25568L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + (short) -1 + "'", comparable45.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 97L + "'", long60 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond24.getMiddleMillisecond(calendar27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = month22.getLastMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        java.util.Date date8 = day3.getStart();
        int int9 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        timeSeries1.setRangeDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.lang.String str9 = seriesChangeEvent7.toString();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent7.getSummary();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.getNotify();
        java.lang.String str11 = timeSeries1.getRangeDescription();
        timeSeries1.setRangeDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1560182976350L);
        long long11 = month7.getLastMillisecond();
        int int12 = month7.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-23731200001L) + "'", long11 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        boolean boolean32 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries34.removeChangeListener(seriesChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond39.next();
        long long43 = fixedMillisecond39.getFirstMillisecond();
        java.lang.Number number44 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        boolean boolean46 = fixedMillisecond39.equals((java.lang.Object) 8);
        timeSeries1.setKey((java.lang.Comparable) boolean46);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 97L + "'", long41 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 97L + "'", long43 == 97L);
        org.junit.Assert.assertNull(number44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        timeSeries2.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182996925L + "'", long1 == 1560182996925L);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        java.util.List list8 = timeSeries1.getItems();
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.removeChangeListener(seriesChangeListener13);
        timeSeries11.removeAgedItems(true);
        java.lang.Class class17 = timeSeries11.getTimePeriodClass();
        double double18 = timeSeries11.getMaxY();
        timeSeries11.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date22 = fixedMillisecond21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 11);
        java.lang.Number number26 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Number number27 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond1.getClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date14 = fixedMillisecond13.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        long long13 = year11.getFirstMillisecond();
        long long14 = year11.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries16.removeChangeListener(seriesChangeListener18);
        timeSeries16.setRangeDescription("hi!");
        java.util.Collection collection22 = timeSeries16.getTimePeriods();
        boolean boolean23 = year11.equals((java.lang.Object) timeSeries16);
        timeSeries16.setRangeDescription("");
        int int26 = fixedMillisecond1.compareTo((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31507200000L) + "'", long14 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.lang.String str17 = month16.toString();
        long long18 = month16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(10);
        long long9 = year8.getMiddleMillisecond();
        java.lang.String str10 = year8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61835976000001L) + "'", long9 == (-61835976000001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-25070400001L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        timeSeries8.setRangeDescription("hi!");
        java.util.Collection collection14 = timeSeries8.getTimePeriods();
        boolean boolean15 = year3.equals((java.lang.Object) timeSeries8);
        timeSeries8.setRangeDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries8.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year10.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass13 = seriesChangeEvent12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 100);
        timeSeries1.add(timeSeriesDataItem24);
        java.lang.String str26 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        long long13 = month12.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2649600000L) + "'", long13 == (-2649600000L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond24.getMiddleMillisecond(calendar27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries10.getItemCount();
        boolean boolean19 = timeSeries10.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent23.setSummary(seriesChangeInfo24);
        boolean boolean26 = timeSeries21.equals((java.lang.Object) seriesChangeInfo24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.next();
        long long32 = fixedMillisecond28.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond34.previous();
        timeSeries10.add(regularTimePeriod36, (double) 1560182972264L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate(regularTimePeriod36, (double) 9999);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo50 = null;
        seriesChangeEvent49.setSummary(seriesChangeInfo50);
        boolean boolean52 = timeSeries47.equals((java.lang.Object) seriesChangeInfo50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
        long long58 = fixedMillisecond54.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo66 = null;
        seriesChangeEvent65.setSummary(seriesChangeInfo66);
        boolean boolean68 = timeSeries63.equals((java.lang.Object) seriesChangeInfo66);
        java.lang.Comparable comparable69 = timeSeries63.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (double) (short) 0);
        java.util.Date date76 = fixedMillisecond71.getTime();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month78.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month78, (java.lang.Number) 0);
        long long82 = month78.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date85 = fixedMillisecond84.getStart();
        java.util.Calendar calendar86 = null;
        fixedMillisecond84.peg(calendar86);
        java.util.Calendar calendar88 = null;
        long long89 = fixedMillisecond84.getFirstMillisecond(calendar88);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month78, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        java.util.Calendar calendar91 = null;
        long long92 = fixedMillisecond84.getMiddleMillisecond(calendar91);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 97L + "'", long56 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + (short) -1 + "'", comparable69.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 97L + "'", long73 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-2649600000L) + "'", long82 == (-2649600000L));
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 97L + "'", long89 == 97L);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 97L + "'", long92 == 97L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date8, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        timeSeries8.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 11);
        timeSeries8.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.createCopy(1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        java.lang.Object obj11 = timeSeriesDataItem9.clone();
        java.lang.Number number12 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) wildcardClass7);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo11);
        boolean boolean13 = timeSeries8.equals((java.lang.Object) seriesChangeInfo11);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.next();
        long long21 = fixedMillisecond17.getFirstMillisecond();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(0, 10);
        timeSeries28.setDescription("1969");
        boolean boolean31 = fixedMillisecond17.equals((java.lang.Object) timeSeries28);
        java.util.Collection collection32 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        int int12 = day11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        long long14 = day11.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799999L + "'", long14 == 28799999L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1, false);
        boolean boolean16 = year1.equals((java.lang.Object) fixedMillisecond12);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year1.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        java.lang.String str35 = timeSeries15.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries15.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = year4.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            year4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        timeSeries17.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int29 = year12.compareTo((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(11, year12);
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        timeSeries1.setKey((java.lang.Comparable) month30);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month30.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.Object obj2 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 11);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (-23731200001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection2 = timeSeries1.getTimePeriods();
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setKey((java.lang.Comparable) (short) -1);
//        timeSeries1.removeAgedItems(0L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (short) 1);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        timeSeries1.add(timeSeriesDataItem13, true);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries18.setNotify(false);
//        timeSeries18.removeAgedItems(true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date27 = fixedMillisecond26.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo33 = null;
//        seriesChangeEvent32.setSummary(seriesChangeInfo33);
//        boolean boolean35 = timeSeries30.equals((java.lang.Object) seriesChangeInfo33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.next();
//        long long41 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        int int45 = year28.compareTo((java.lang.Object) fixedMillisecond43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year28.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries18.addOrUpdate(regularTimePeriod46, (java.lang.Number) 0.0d);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries49 = timeSeries1.addAndOrUpdate(timeSeries18);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183003522L + "'", long10 == 1560183003522L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183003522L + "'", long11 == 1560183003522L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 1 + "'", number14.equals((short) 1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 97L + "'", long41 == 97L);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        try {
            java.lang.Number number9 = timeSeries1.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        java.lang.Number number18 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        timeSeries22.fireSeriesChanged();
        timeSeries22.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean28 = fixedMillisecond13.equals((java.lang.Object) timeSeries20);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560182979730L);
        timeSeries1.setMaximumItemAge((long) (byte) 0);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Year year16 = month15.getYear();
        long long17 = month15.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(97, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        java.util.Date date27 = year26.getEnd();
        long long28 = year26.getFirstMillisecond();
        long long29 = year26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection32 = timeSeries31.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries31.removeChangeListener(seriesChangeListener33);
        timeSeries31.setRangeDescription("hi!");
        java.util.Collection collection37 = timeSeries31.getTimePeriods();
        boolean boolean38 = year26.equals((java.lang.Object) timeSeries31);
        java.lang.Object obj39 = timeSeries31.clone();
        boolean boolean40 = month22.equals((java.lang.Object) timeSeries31);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31507200000L) + "'", long28 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            day6.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        timeSeries8.setRangeDescription("hi!");
        java.util.Collection collection14 = timeSeries8.getTimePeriods();
        boolean boolean15 = year3.equals((java.lang.Object) timeSeries8);
        timeSeries8.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        java.util.List list8 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 11);
        java.lang.Number number16 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year13.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        timeSeries7.removeAgedItems(false);
        boolean boolean14 = timeSeries7.getNotify();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Wed Dec 31 16:00:00 PST 1969", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        try {
            timeSeries18.delete((int) (byte) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        java.util.Calendar calendar8 = null;
        try {
            year4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        timeSeriesDataItem9.setValue((java.lang.Number) 100L);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        boolean boolean13 = timeSeriesDataItem9.isSelected();
        boolean boolean14 = timeSeriesDataItem9.isSelected();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        boolean boolean14 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        long long5 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj6 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        java.util.List list10 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        boolean boolean6 = year3.equals((java.lang.Object) 12);
        java.lang.String str7 = year3.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        boolean boolean7 = timeSeries5.isEmpty();
        boolean boolean8 = timeSeries5.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.lang.Number number12 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems((long) '4', false);
        long long9 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        int int17 = month16.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 31, false);
        java.lang.String str21 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timeSeries15.getItemCount();
        boolean boolean24 = timeSeries15.getNotify();
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            timeSeries1.add(regularTimePeriod26, (java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        boolean boolean16 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries18.equals((java.lang.Object) seriesChangeInfo21);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) (short) 0);
        java.util.Date date31 = fixedMillisecond26.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond26.previous();
        try {
            timeSeries8.add(regularTimePeriod32, (double) 1560182982681L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) -1 + "'", comparable24.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        java.lang.Object obj16 = timeSeries7.clone();
        timeSeries7.setMaximumItemAge(1560182987537L);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            int int16 = timeSeries1.getIndex(regularTimePeriod15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        long long15 = year10.getSerialIndex();
        long long16 = year10.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1969L + "'", long15 == 1969L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Object obj7 = null;
        int int8 = day3.compareTo(obj7);
        java.lang.String str9 = day3.toString();
        int int10 = day3.getMonth();
        long long11 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        timeSeriesDataItem4.setValue((java.lang.Number) 10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183008493L + "'", long1 == 1560183008493L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183008493L + "'", long2 == 1560183008493L);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        long long13 = fixedMillisecond12.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.lang.String str9 = seriesChangeEvent7.toString();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent7);
        java.lang.String str11 = seriesChangeEvent7.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str11.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        try {
            timeSeries1.update(regularTimePeriod12, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) -1, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date24 = fixedMillisecond23.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        java.util.Date date26 = year25.getEnd();
//        long long27 = year25.getFirstMillisecond();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(3, year25);
//        long long29 = month28.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1560182976350L);
//        java.lang.Number number32 = timeSeriesDataItem31.getValue();
//        timeSeriesDataItem31.setSelected(true);
//        boolean boolean35 = timeSeriesDataItem31.isSelected();
//        try {
//            timeSeries7.add(timeSeriesDataItem31, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183009248L + "'", long16 == 1560183009248L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183009248L + "'", long17 == 1560183009248L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-25070400001L) + "'", long29 == (-25070400001L));
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 1560182976350L + "'", number32.equals(1560182976350L));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        long long6 = day3.getFirstMillisecond();
        int int7 = day3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Object obj7 = null;
        int int8 = day3.compareTo(obj7);
        java.lang.String str9 = day3.toString();
        int int10 = day3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.util.Collection collection30 = timeSeries1.getTimePeriods();
        java.lang.String str31 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection38 = timeSeries37.getTimePeriods();
        timeSeries37.fireSeriesChanged();
        timeSeries37.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries35.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 1, false);
        boolean boolean48 = year33.equals((java.lang.Object) fixedMillisecond44);
        long long49 = year33.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (short) 10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1L + "'", long49 == 1L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean7 = year4.equals((java.lang.Object) 'a');
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(97, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        boolean boolean10 = timeSeries5.equals((java.lang.Object) seriesChangeInfo8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        int int20 = year3.compareTo((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) ' ');
        java.lang.String str24 = year3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 31, false);
        int int21 = day15.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day15.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass25 = seriesChangeEvent24.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
        java.util.Date date31 = regularTimePeriod30.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        int int34 = day15.compareTo((java.lang.Object) timeZone32);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.String str5 = day3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-1969" + "'", str5.equals("31-December-1969"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        int int8 = month7.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        java.lang.String str17 = month16.toString();
        long long18 = month16.getLastMillisecond();
        long long19 = month16.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getMonth();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.fireSeriesChanged();
        timeSeries9.setMaximumItemAge((long) ' ');
        timeSeries9.removeAgedItems(false);
        timeSeries9.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 11);
        timeSeries9.add(timeSeriesDataItem22);
        boolean boolean24 = day6.equals((java.lang.Object) timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        boolean boolean16 = timeSeries8.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        timeSeries8.setRangeDescription("Time");
        boolean boolean21 = timeSeries8.getNotify();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1L);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183010642L + "'", long1 == 1560183010642L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date8, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.previous();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        timeSeries15.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=a]");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener38);
        java.lang.Comparable comparable40 = timeSeries15.getKey();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + (short) -1 + "'", comparable40.equals((short) -1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDescription("December 1969");
        java.util.List list7 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo50 = null;
        seriesChangeEvent49.setSummary(seriesChangeInfo50);
        boolean boolean52 = timeSeries47.equals((java.lang.Object) seriesChangeInfo50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
        long long58 = fixedMillisecond54.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo66 = null;
        seriesChangeEvent65.setSummary(seriesChangeInfo66);
        boolean boolean68 = timeSeries63.equals((java.lang.Object) seriesChangeInfo66);
        java.lang.Comparable comparable69 = timeSeries63.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (double) (short) 0);
        java.util.Date date76 = fixedMillisecond71.getTime();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month78.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month78, (java.lang.Number) 0);
        long long82 = month78.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date85 = fixedMillisecond84.getStart();
        java.util.Calendar calendar86 = null;
        fixedMillisecond84.peg(calendar86);
        java.util.Calendar calendar88 = null;
        long long89 = fixedMillisecond84.getFirstMillisecond(calendar88);
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month78, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        double double91 = timeSeries1.getMinY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 97L + "'", long56 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + (short) -1 + "'", comparable69.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 97L + "'", long73 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-2649600000L) + "'", long82 == (-2649600000L));
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 97L + "'", long89 == 97L);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.fireSeriesChanged();
        timeSeries16.setMaximumItemAge((long) ' ');
        timeSeries16.removeAgedItems(false);
        timeSeries16.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 11);
        timeSeries16.add(timeSeriesDataItem29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem29.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem29, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemAge((long) ' ');
        timeSeries8.removeAgedItems(false);
        timeSeries8.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 11);
        timeSeries8.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21, true);
        timeSeriesDataItem21.setSelected(false);
        timeSeriesDataItem21.setSelected(true);
        timeSeriesDataItem21.setValue((java.lang.Number) 1560182986783L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean5);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.delete(11, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        try {
            timeSeries1.update(9999, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date5 = fixedMillisecond4.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
//        long long11 = day9.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries1.delete((int) (short) -1, 31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        boolean boolean13 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.addAndOrUpdate(timeSeries5);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month14 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year15 = month14.getYear();
        java.lang.Number number16 = null;
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year15, number16);
        boolean boolean18 = timeSeries10.getNotify();
        int int19 = year1.compareTo((java.lang.Object) timeSeries10);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(month14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        java.lang.String str7 = year3.toString();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException9.addSuppressed((java.lang.Throwable) seriesException12);
        int int14 = year3.compareTo((java.lang.Object) seriesException12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year3.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        java.lang.Comparable comparable20 = timeSeries14.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (short) 0);
        java.util.Date date27 = fixedMillisecond22.getTime();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27);
        boolean boolean30 = day12.equals((java.lang.Object) date27);
        java.util.Calendar calendar31 = null;
        try {
            day12.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) -1 + "'", comparable20.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        java.util.List list8 = timeSeries1.getItems();
        try {
            java.lang.Number number10 = timeSeries1.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        int int8 = year3.getYear();
        long long9 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, "org.jfree.data.event.SeriesChangeEvent[source=a]", "1969");
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182979730L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        int int6 = day3.getDayOfMonth();
        long long7 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 31);
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        java.lang.Number number33 = timeSeries1.getValue(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date36 = fixedMillisecond35.getStart();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        long long38 = day37.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        java.lang.Number number41 = timeSeries1.getValue(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.560182972264E12d + "'", number33.equals(1.560182972264E12d));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 25568L + "'", long38 == 25568L);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1.560182972264E12d + "'", number41.equals(1.560182972264E12d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        java.lang.Object obj12 = null;
        boolean boolean13 = year11.equals(obj12);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135740800000L) + "'", long2 == (-62135740800000L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 11);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        timeSeriesDataItem5.setValue((java.lang.Number) (-1.0f));
        java.lang.Number number9 = null;
        timeSeriesDataItem5.setValue(number9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        try {
            java.lang.Number number5 = timeSeries1.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        long long7 = year3.getFirstMillisecond();
        long long8 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        timeSeries1.removeAgedItems(0L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        fixedMillisecond10.peg(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (short) 100);
        timeSeriesDataItem18.setValue((java.lang.Number) 100L);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        java.lang.Object obj22 = timeSeriesDataItem18.clone();
        timeSeries1.add(timeSeriesDataItem18);
        java.lang.String str24 = timeSeries1.getDomainDescription();
        java.lang.Object obj25 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries36.removeChangeListener(seriesChangeListener38);
        timeSeries36.removeAgedItems((long) 0, true);
        boolean boolean43 = timeSeries36.getNotify();
        int int44 = fixedMillisecond30.compareTo((java.lang.Object) boolean43);
        int int46 = fixedMillisecond30.compareTo((java.lang.Object) (-25070400001L));
        java.lang.Object obj47 = null;
        boolean boolean48 = fixedMillisecond30.equals(obj47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond30.next();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond30.getMiddleMillisecond(calendar50);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 97L + "'", long51 == 97L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        int int13 = fixedMillisecond6.compareTo((java.lang.Object) 1969);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond6.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Date date9 = year8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date9);
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 0, year15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries17.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond22.next();
        boolean boolean31 = year13.equals((java.lang.Object) regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean31);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        double double8 = timeSeries1.getMaxY();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.removeChangeListener(seriesChangeListener14);
        timeSeries12.setRangeDescription("hi!");
        java.util.Collection collection18 = timeSeries12.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries12);
        try {
            java.lang.Number number21 = timeSeries12.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183014860L + "'", long1 == 1560183014860L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        long long10 = fixedMillisecond6.getFirstMillisecond();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.Date date21 = year20.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date29 = fixedMillisecond28.getStart();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        long long31 = day30.getSerialIndex();
        int int32 = day30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        int int34 = day30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day30.previous();
        int int36 = fixedMillisecond24.compareTo((java.lang.Object) day30);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 25568L + "'", long31 == 25568L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) -1, true);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection23 = timeSeries22.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries22.removeChangeListener(seriesChangeListener24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.next();
//        long long31 = fixedMillisecond27.getFirstMillisecond();
//        java.lang.Number number32 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection37 = timeSeries36.getTimePeriods();
//        timeSeries36.fireSeriesChanged();
//        timeSeries36.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries34.addAndOrUpdate(timeSeries36);
//        boolean boolean42 = fixedMillisecond27.equals((java.lang.Object) timeSeries34);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.addAndOrUpdate(timeSeries34);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183015817L + "'", long16 == 1560183015817L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183015817L + "'", long17 == 1560183015817L);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 97L + "'", long29 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(timeSeries43);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond8.peg(calendar11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        boolean boolean21 = timeSeries14.getNotify();
        boolean boolean22 = fixedMillisecond8.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        long long27 = day26.getSerialIndex();
        int int28 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day26.next();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Object obj31 = null;
        boolean boolean32 = fixedMillisecond8.equals(obj31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        timeSeries34.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        boolean boolean41 = timeSeries34.equals((java.lang.Object) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo46 = null;
        seriesChangeEvent45.setSummary(seriesChangeInfo46);
        boolean boolean48 = timeSeries43.equals((java.lang.Object) seriesChangeInfo46);
        java.lang.Comparable comparable49 = timeSeries43.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getLastMillisecond(calendar52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (double) (short) 0);
        java.util.Date date56 = fixedMillisecond51.getTime();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date56, timeZone58);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo60 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) wildcardClass40, seriesChangeInfo60);
        int int62 = fixedMillisecond8.compareTo((java.lang.Object) seriesChangeEvent61);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond8.getFirstMillisecond(calendar63);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + (short) -1 + "'", comparable49.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 97L + "'", long53 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond8.peg(calendar11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        boolean boolean21 = timeSeries14.getNotify();
        boolean boolean22 = fixedMillisecond8.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        long long27 = day26.getSerialIndex();
        int int28 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day26.next();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day26);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("March 1969");
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183016971L + "'", long1 == 1560183016971L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183016971L + "'", long2 == 1560183016971L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560183016971L + "'", long6 == 1560183016971L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183016971L + "'", long8 == 1560183016971L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries36.removeChangeListener(seriesChangeListener38);
        timeSeries36.removeAgedItems((long) 0, true);
        boolean boolean43 = timeSeries36.getNotify();
        int int44 = fixedMillisecond30.compareTo((java.lang.Object) boolean43);
        int int46 = fixedMillisecond30.compareTo((java.lang.Object) (-25070400001L));
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo51 = null;
        seriesChangeEvent50.setSummary(seriesChangeInfo51);
        boolean boolean53 = timeSeries48.equals((java.lang.Object) seriesChangeInfo51);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries48.removePropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection58 = timeSeries57.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries57.removeChangeListener(seriesChangeListener59);
        java.util.Collection collection61 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries57);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection64 = timeSeries63.getTimePeriods();
        timeSeries63.fireSeriesChanged();
        timeSeries63.setMaximumItemAge((long) ' ');
        timeSeries63.removeAgedItems(false);
        timeSeries63.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date73 = fixedMillisecond72.getStart();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 11);
        timeSeries63.add(timeSeriesDataItem76);
        java.lang.Number number78 = timeSeriesDataItem76.getValue();
        timeSeries48.add(timeSeriesDataItem76);
        boolean boolean80 = fixedMillisecond30.equals((java.lang.Object) timeSeriesDataItem76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = fixedMillisecond30.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + 11 + "'", number78.equals(11));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        fixedMillisecond21.peg(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) (short) 100);
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        java.lang.Object obj31 = timeSeriesDataItem29.clone();
        timeSeries17.add(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100.0d + "'", number30.equals(100.0d));
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean6 = year3.equals((java.lang.Object) 'a');
        java.lang.String str7 = year3.toString();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException9.addSuppressed((java.lang.Throwable) seriesException12);
        int int14 = year3.compareTo((java.lang.Object) seriesException12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        boolean boolean21 = timeSeries16.equals((java.lang.Object) seriesChangeInfo19);
        java.lang.Comparable comparable22 = timeSeries16.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 0);
        java.util.Date date29 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond33.getMiddleMillisecond(calendar36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month31, (double) 1L);
        java.util.Calendar calendar41 = null;
        try {
            month31.peg(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) -1 + "'", comparable22.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 97L + "'", long35 == 97L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getYearValue();
        long long11 = month7.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month7.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-23731200001L) + "'", long11 == (-23731200001L));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 28799999L);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        java.lang.Number number18 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        timeSeries22.fireSeriesChanged();
        timeSeries22.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean28 = fixedMillisecond13.equals((java.lang.Object) timeSeries20);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560182979730L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries1.addChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setKey((java.lang.Comparable) 1L);
        timeSeries18.setKey((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection33 = timeSeries32.getTimePeriods();
        timeSeries32.fireSeriesChanged();
        timeSeries32.setMaximumItemAge((long) ' ');
        timeSeries32.removeAgedItems(false);
        timeSeries32.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date42 = fixedMillisecond41.getStart();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 11);
        timeSeries32.add(timeSeriesDataItem45);
        timeSeries25.add(timeSeriesDataItem45, true);
        timeSeriesDataItem45.setSelected(false);
        timeSeries18.setKey((java.lang.Comparable) timeSeriesDataItem45);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass54 = seriesChangeEvent53.getClass();
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date58 = fixedMillisecond57.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        java.util.Date date60 = year59.getEnd();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date60, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day63, (java.lang.Number) 0L);
        timeSeries18.add(timeSeriesDataItem65, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries15.addOrUpdate(timeSeriesDataItem65);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent70 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass71 = seriesChangeEvent70.getClass();
        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date75 = fixedMillisecond74.getStart();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        java.util.Date date77 = year76.getEnd();
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date77, timeZone78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond(date77);
        try {
            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, (java.lang.Number) (-62135740800000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(class72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date5 = fixedMillisecond4.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Date date13 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.previous();
//        java.lang.String str18 = day14.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.next();
//        int int20 = day9.compareTo((java.lang.Object) day14);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 25568L + "'", long15 == 25568L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 18058 + "'", int20 == 18058);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
//        int int9 = timeSeries1.getItemCount();
//        boolean boolean10 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
//        seriesChangeEvent14.setSummary(seriesChangeInfo15);
//        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
//        long long23 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
//        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
//        java.lang.Number number33 = timeSeries1.getValue(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        long long35 = fixedMillisecond34.getMiddleMillisecond();
//        long long36 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) (short) 1);
//        java.lang.Object obj39 = timeSeriesDataItem38.clone();
//        boolean boolean40 = timeSeriesDataItem38.isSelected();
//        boolean boolean42 = timeSeriesDataItem38.equals((java.lang.Object) (byte) 100);
//        timeSeries1.add(timeSeriesDataItem38, false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.560182972264E12d + "'", number33.equals(1.560182972264E12d));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560183018694L + "'", long35 == 1560183018694L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183018694L + "'", long36 == 1560183018694L);
//        org.junit.Assert.assertNotNull(obj39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (byte) -1, true);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection23 = timeSeries22.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries22.removeChangeListener(seriesChangeListener24);
//        timeSeries22.setRangeDescription("hi!");
//        java.util.Collection collection28 = timeSeries22.getTimePeriods();
//        int int29 = fixedMillisecond15.compareTo((java.lang.Object) collection28);
//        long long30 = fixedMillisecond15.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183018824L + "'", long16 == 1560183018824L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183018824L + "'", long17 == 1560183018824L);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560183018824L + "'", long30 == 1560183018824L);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timeSeries15.getItemCount();
        boolean boolean24 = timeSeries15.getNotify();
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries27.removePropertyChangeListener(propertyChangeListener33);
        int int35 = timeSeries27.getItemCount();
        boolean boolean36 = timeSeries27.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
        seriesChangeEvent40.setSummary(seriesChangeInfo41);
        boolean boolean43 = timeSeries38.equals((java.lang.Object) seriesChangeInfo41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getLastMillisecond(calendar46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.next();
        long long49 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond51.previous();
        timeSeries27.add(regularTimePeriod53, (double) 1560182972264L);
        java.util.Collection collection56 = timeSeries27.getTimePeriods();
        int int57 = timeSeries27.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries27.addChangeListener(seriesChangeListener58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
        long long64 = fixedMillisecond61.getMiddleMillisecond();
        timeSeries27.setKey((java.lang.Comparable) long64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries15.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str69 = timeSeries68.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo74 = null;
        seriesChangeEvent73.setSummary(seriesChangeInfo74);
        boolean boolean76 = timeSeries71.equals((java.lang.Object) seriesChangeInfo74);
        java.lang.Comparable comparable77 = timeSeries71.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar80 = null;
        long long81 = fixedMillisecond79.getLastMillisecond(calendar80);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79, (double) (short) 0);
        java.util.Date date84 = fixedMillisecond79.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = fixedMillisecond79.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries68.addOrUpdate(regularTimePeriod85, (java.lang.Number) 1560182981229L);
        java.util.Date date88 = regularTimePeriod85.getStart();
        try {
            timeSeries27.add(regularTimePeriod85, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Value" + "'", str69.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + comparable77 + "' != '" + (short) -1 + "'", comparable77.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 97L + "'", long81 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertNotNull(date88);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setKey((java.lang.Comparable) 1L);
        timeSeries5.setKey((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection20 = timeSeries19.getTimePeriods();
        timeSeries19.fireSeriesChanged();
        timeSeries19.setMaximumItemAge((long) ' ');
        timeSeries19.removeAgedItems(false);
        timeSeries19.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date29 = fixedMillisecond28.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 11);
        timeSeries19.add(timeSeriesDataItem32);
        timeSeries12.add(timeSeriesDataItem32, true);
        timeSeriesDataItem32.setSelected(false);
        timeSeries5.setKey((java.lang.Comparable) timeSeriesDataItem32);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass41 = seriesChangeEvent40.getClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date45 = fixedMillisecond44.getStart();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        java.util.Date date47 = year46.getEnd();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 0L);
        timeSeries5.add(timeSeriesDataItem52, true);
        timeSeries1.add(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.previous();
        long long19 = month16.getLastMillisecond();
        int int20 = month16.getMonth();
        java.util.Calendar calendar21 = null;
        try {
            month16.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setRangeDescription("hi!");
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        timeSeries4.setDescription("1969");
        int int7 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        double double11 = timeSeries8.getMaxY();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 11);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        timeSeriesDataItem18.setValue((java.lang.Number) (-1.0f));
        timeSeries8.add(timeSeriesDataItem18, true);
        timeSeries1.add(timeSeriesDataItem18, false);
        boolean boolean26 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem18.getPeriod();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date8, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 0, false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries36.removeChangeListener(seriesChangeListener38);
        timeSeries36.removeAgedItems((long) 0, true);
        boolean boolean43 = timeSeries36.getNotify();
        int int44 = fixedMillisecond30.compareTo((java.lang.Object) boolean43);
        int int46 = fixedMillisecond30.compareTo((java.lang.Object) (-25070400001L));
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo51 = null;
        seriesChangeEvent50.setSummary(seriesChangeInfo51);
        boolean boolean53 = timeSeries48.equals((java.lang.Object) seriesChangeInfo51);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries48.removePropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection58 = timeSeries57.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries57.removeChangeListener(seriesChangeListener59);
        java.util.Collection collection61 = timeSeries48.getTimePeriodsUniqueToOtherSeries(timeSeries57);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection64 = timeSeries63.getTimePeriods();
        timeSeries63.fireSeriesChanged();
        timeSeries63.setMaximumItemAge((long) ' ');
        timeSeries63.removeAgedItems(false);
        timeSeries63.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date73 = fixedMillisecond72.getStart();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 11);
        timeSeries63.add(timeSeriesDataItem76);
        java.lang.Number number78 = timeSeriesDataItem76.getValue();
        timeSeries48.add(timeSeriesDataItem76);
        boolean boolean80 = fixedMillisecond30.equals((java.lang.Object) timeSeriesDataItem76);
        timeSeriesDataItem76.setValue((java.lang.Number) 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + 11 + "'", number78.equals(11));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
        long long17 = fixedMillisecond14.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        long long23 = month22.getLastMillisecond();
        java.util.Calendar calendar24 = null;
        try {
            month22.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2649600001L) + "'", long23 == (-2649600001L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray12 = seriesException3.getSuppressed();
        java.lang.String str13 = seriesException3.toString();
        java.lang.Throwable[] throwableArray14 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        java.lang.Comparable comparable12 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) (short) 0);
        java.util.Date date19 = fixedMillisecond14.getTime();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1560182979766L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (short) -1 + "'", comparable12.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 31);
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getMiddleMillisecond(calendar11);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31L + "'", long12 == 31L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.util.Date date2 = fixedMillisecond0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, "June 2019", "10");
        timeSeries15.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        boolean boolean7 = year4.equals((java.lang.Object) 12);
        java.lang.String str8 = year4.toString();
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(100, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        java.util.Date date8 = day3.getStart();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) 0.0f);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        timeSeries8.fireSeriesChanged();
        double double11 = timeSeries8.getMaxY();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 11);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        timeSeriesDataItem18.setValue((java.lang.Number) (-1.0f));
        timeSeries8.add(timeSeriesDataItem18, true);
        timeSeries1.add(timeSeriesDataItem18, false);
        java.lang.Number number26 = timeSeriesDataItem18.getValue();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0f) + "'", number26.equals((-1.0f)));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries7.add(regularTimePeriod17, (double) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries9.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        int int12 = day11.getMonth();
        long long13 = day11.getSerialIndex();
        java.util.Calendar calendar14 = null;
        try {
            day11.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25568L + "'", long13 == 25568L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo21);
        boolean boolean23 = timeSeries18.equals((java.lang.Object) seriesChangeInfo21);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) (short) 0);
        java.util.Date date31 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        fixedMillisecond35.peg(calendar40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date44 = fixedMillisecond43.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean48 = year45.equals((java.lang.Object) 'a');
        java.lang.String str49 = year45.toString();
        java.lang.String str50 = year45.toString();
        int int51 = fixedMillisecond35.compareTo((java.lang.Object) year45);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day32.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) -1 + "'", comparable24.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 97L + "'", long37 == 97L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1969" + "'", str50.equals("1969"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        try {
            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month32, (double) 1L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        int int10 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.update(0, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        long long11 = day10.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        timeSeries4.setKey((java.lang.Comparable) serialDate12);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent14.setSummary(seriesChangeInfo15);
        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        boolean boolean32 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries1.addChangeListener(seriesChangeListener33);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean12 = year9.equals((java.lang.Object) 'a');
        java.lang.String str13 = year9.toString();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        seriesException15.addSuppressed((java.lang.Throwable) seriesException18);
        int int20 = year9.compareTo((java.lang.Object) seriesException18);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException18);
        java.lang.Throwable[] throwableArray22 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date12 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month15);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month15.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 18058, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        double double6 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond8.peg(calendar11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection15 = timeSeries14.getTimePeriods();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemAge((long) ' ');
        timeSeries14.removeAgedItems(false);
        boolean boolean21 = timeSeries14.getNotify();
        boolean boolean22 = fixedMillisecond8.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        long long27 = day26.getSerialIndex();
        int int28 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day26.next();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day26);
        timeSeries30.clear();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 0L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) (-31507200000L));
        try {
            timeSeries1.add(timeSeriesDataItem22, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection9 = timeSeries8.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        timeSeries8.setRangeDescription("hi!");
        java.util.Collection collection14 = timeSeries8.getTimePeriods();
        boolean boolean15 = year3.equals((java.lang.Object) timeSeries8);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        java.lang.String str12 = day11.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day11.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        java.lang.Object obj11 = timeSeriesDataItem9.clone();
        timeSeriesDataItem9.setValue((java.lang.Number) 97L);
        timeSeriesDataItem9.setValue((java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond24.getMiddleMillisecond(calendar27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
        try {
            java.lang.Number number31 = timeSeries1.getValue(regularTimePeriod30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries9.setMaximumItemCount((int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        long long18 = day17.getSerialIndex();
        int int19 = day17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
        int int26 = day17.compareTo((java.lang.Object) regularTimePeriod25);
        timeSeries9.delete(regularTimePeriod25);
        try {
            timeSeries1.update(regularTimePeriod25, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 25568L + "'", long18 == 25568L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("December 1969");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        timeSeries7.fireSeriesChanged();
//        timeSeries7.setMaximumItemAge((long) ' ');
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        java.util.List list14 = timeSeries7.getItems();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183018824L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        long long25 = fixedMillisecond23.getMiddleMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond23.getLastMillisecond(calendar26);
//        boolean boolean28 = year19.equals((java.lang.Object) calendar26);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183023940L + "'", long24 == 1560183023940L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560183023940L + "'", long25 == 1560183023940L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183023940L + "'", long27 == 1560183023940L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int29 = year12.compareTo((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(11, year12);
        long long31 = year12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
        long long33 = year12.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31507200000L) + "'", long33 == (-31507200000L));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        int int14 = day13.getYear();
        int int15 = day13.getYear();
        timeSeries1.setKey((java.lang.Comparable) int15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = year4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = month1.getLastMillisecond();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28799999L + "'", long3 == 28799999L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1.0f);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        int int6 = year1.compareTo((java.lang.Object) "org.jfree.data.general.SeriesException: ");
        long long7 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61835976000001L) + "'", long2 == (-61835976000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        java.util.Date date8 = day3.getStart();
        long long9 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        seriesChangeEvent35.setSummary(seriesChangeInfo36);
        boolean boolean38 = timeSeries33.equals((java.lang.Object) seriesChangeInfo36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        long long44 = fixedMillisecond40.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 0, false);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        long long52 = fixedMillisecond46.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 97L + "'", long42 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 97L + "'", long52 == 97L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond19.getMiddleMillisecond();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond15.getFirstMillisecond(calendar25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.util.Calendar calendar7 = null;
        try {
            day3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        java.lang.String str7 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo14);
        boolean boolean16 = timeSeries11.equals((java.lang.Object) seriesChangeInfo14);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener17);
        int int19 = timeSeries11.getItemCount();
        boolean boolean20 = timeSeries11.isEmpty();
        timeSeries11.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener31);
        int int33 = timeSeries25.getItemCount();
        boolean boolean34 = timeSeries25.getNotify();
        java.util.Collection collection35 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond37.getMiddleMillisecond(calendar40);
        java.util.Calendar calendar42 = null;
        fixedMillisecond37.peg(calendar42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (short) 100);
        java.lang.Number number46 = timeSeriesDataItem45.getValue();
        int int48 = timeSeriesDataItem45.compareTo((java.lang.Object) 31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries25.addOrUpdate(timeSeriesDataItem45);
        try {
            timeSeries1.add(timeSeriesDataItem49, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 97L + "'", long39 == 97L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 97L + "'", long41 == 97L);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 100.0d + "'", number46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Number number14 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year13, number14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries17.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
        long long26 = fixedMillisecond22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond22.next();
        boolean boolean31 = year13.equals((java.lang.Object) regularTimePeriod30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year13.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day3.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection12 = timeSeries11.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.removeChangeListener(seriesChangeListener13);
        boolean boolean15 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond34.getMiddleMillisecond(calendar37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        int int40 = day3.compareTo((java.lang.Object) month32);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        timeSeries15.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=a]");
        timeSeries15.setRangeDescription("org.jfree.data.general.SeriesException: December 1969");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getSerialIndex();
        int int11 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 28799999L);
        long long14 = day9.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
        seriesChangeEvent24.setSummary(seriesChangeInfo25);
        boolean boolean27 = timeSeries22.equals((java.lang.Object) seriesChangeInfo25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getLastMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
        long long33 = fixedMillisecond29.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        int int37 = year20.compareTo((java.lang.Object) fixedMillisecond35);
        java.util.Date date38 = year20.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        int int40 = day9.compareTo((java.lang.Object) date38);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
        long long22 = fixedMillisecond19.getMiddleMillisecond();
        long long23 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries27.setNotify(false);
        timeSeries27.removeAgedItems(true);
        java.lang.String str32 = timeSeries27.getDomainDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass35 = seriesChangeEvent34.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date38 = fixedMillisecond37.getStart();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date38);
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo47 = null;
        seriesChangeEvent46.setSummary(seriesChangeInfo47);
        boolean boolean49 = timeSeries44.equals((java.lang.Object) seriesChangeInfo47);
        java.lang.Comparable comparable50 = timeSeries44.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) (short) 0);
        java.util.Date date57 = fixedMillisecond52.getTime();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
        java.util.Calendar calendar64 = null;
        long long65 = fixedMillisecond61.getMiddleMillisecond(calendar64);
        java.util.Calendar calendar66 = null;
        fixedMillisecond61.peg(calendar66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date70 = fixedMillisecond69.getStart();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        boolean boolean74 = year71.equals((java.lang.Object) 'a');
        java.lang.String str75 = year71.toString();
        java.lang.String str76 = year71.toString();
        int int77 = fixedMillisecond61.compareTo((java.lang.Object) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day58, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        long long79 = day58.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) long79);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + (short) -1 + "'", comparable50.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 97L + "'", long54 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 97L + "'", long65 == 97L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1969" + "'", str75.equals("1969"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "1969" + "'", str76.equals("1969"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 28799999L + "'", long79 == 28799999L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        long long2 = year1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        int int6 = year1.compareTo((java.lang.Object) "org.jfree.data.general.SeriesException: ");
        int int7 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61835976000001L) + "'", long2 == (-61835976000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5);
        int int9 = month8.getMonth();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month8.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.String str7 = timeSeries1.getDescription();
        try {
            java.lang.Number number9 = timeSeries1.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.previous();
        long long19 = month16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month16.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date8, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getFirstMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183026296L + "'", long1 == 1560183026296L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183026296L + "'", long2 == 1560183026296L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183026296L + "'", long4 == 1560183026296L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560183026296L + "'", long6 == 1560183026296L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        double double4 = timeSeries1.getMaxY();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date8 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 11);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        timeSeriesDataItem11.setValue((java.lang.Number) (-1.0f));
        timeSeries1.add(timeSeriesDataItem11, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getSerialIndex();
        int int22 = day20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
        int int24 = day20.getYear();
        java.util.Date date25 = day20.getStart();
        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
        int int27 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25568L + "'", long21 == 25568L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        boolean boolean11 = timeSeries6.equals((java.lang.Object) seriesChangeInfo9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        long long17 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int21 = year4.compareTo((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(11, year4);
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "org.jfree.data.event.SeriesChangeEvent[source=a]", "org.jfree.data.general.SeriesException: December 1969");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.String str7 = timeSeries1.getDescription();
        boolean boolean8 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.lang.Object obj7 = null;
        int int8 = day3.compareTo(obj7);
        java.lang.String str9 = day3.toString();
        int int10 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day3.previous();
        long long12 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) 'a');
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = month2.compareTo((java.lang.Object) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        boolean boolean8 = timeSeries1.getNotify();
        double double9 = timeSeries1.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) 'a');
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.setKey((java.lang.Comparable) 1L);
        timeSeries7.setKey((java.lang.Comparable) ' ');
        java.lang.String str13 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date16 = year15.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        int int18 = timeSeries7.getIndex(regularTimePeriod17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem(regularTimePeriod17);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException16);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("December 1969");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException19);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("March 1969");
        try {
            java.lang.Number number10 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getYearValue();
        long long11 = month7.getLastMillisecond();
        int int12 = month7.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-23731200001L) + "'", long11 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemAge(0L);
        java.lang.Object obj16 = timeSeries7.clone();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass19 = seriesChangeEvent18.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.Date date25 = year24.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date25);
        timeSeries7.setKey((java.lang.Comparable) date25);
        timeSeries7.setNotify(false);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: December 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        long long5 = timeSeries1.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.removeChangeListener(seriesChangeListener12);
        timeSeries10.removeAgedItems(true);
        java.lang.Class class16 = timeSeries10.getTimePeriodClass();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        seriesChangeEvent21.setSummary(seriesChangeInfo22);
        boolean boolean24 = timeSeries19.equals((java.lang.Object) seriesChangeInfo22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        long long30 = fixedMillisecond26.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.previous();
        try {
            timeSeries1.update(regularTimePeriod35, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 97L + "'", long30 == 97L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        boolean boolean6 = timeSeries1.getNotify();
        java.lang.Number number8 = null;
        try {
            timeSeries1.update((int) (short) -1, number8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        long long5 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge(1560183008493L);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        java.util.Collection collection2 = timeSeries1.getTimePeriods();
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setKey((java.lang.Comparable) (short) -1);
//        timeSeries1.removeAgedItems(0L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        long long11 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (short) 1);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        timeSeries1.add(timeSeriesDataItem13, true);
//        boolean boolean17 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent21.setSummary(seriesChangeInfo22);
//        boolean boolean24 = timeSeries19.equals((java.lang.Object) seriesChangeInfo22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
//        long long29 = fixedMillisecond26.getMiddleMillisecond();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond26.peg(calendar30);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond26.getMiddleMillisecond(calendar32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.junit.Assert.assertNotNull(collection2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560183028224L + "'", long10 == 1560183028224L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183028224L + "'", long11 == 1560183028224L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 1 + "'", number14.equals((short) 1));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 97L + "'", long28 == 97L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 97L + "'", long29 == 97L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 97L + "'", long33 == 97L);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 11);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.removeChangeListener(seriesChangeListener18);
        int int20 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        long long18 = day15.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-57600000L) + "'", long18 == (-57600000L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.getNotify();
        java.lang.String str11 = timeSeries1.getRangeDescription();
        double double12 = timeSeries1.getMaxY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        int int8 = year3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 1560182986783L);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem10, "hi!", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.lang.Comparable comparable21 = timeSeries15.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 0);
        java.util.Date date28 = fixedMillisecond23.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond23.previous();
        boolean boolean31 = fixedMillisecond23.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1560183016971L);
        timeSeries13.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) -1 + "'", comparable21.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        try {
            timeSeries7.delete(31, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
//        int int9 = timeSeries1.getItemCount();
//        boolean boolean10 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
//        seriesChangeEvent14.setSummary(seriesChangeInfo15);
//        boolean boolean17 = timeSeries12.equals((java.lang.Object) seriesChangeInfo15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
//        long long23 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
//        timeSeries1.add(regularTimePeriod27, (double) 1560182972264L);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        long long33 = fixedMillisecond32.getMiddleMillisecond();
//        long long34 = fixedMillisecond32.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (short) 1);
//        java.lang.Object obj37 = timeSeriesDataItem36.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries1.addOrUpdate(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560183029244L + "'", long33 == 1560183029244L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560183029244L + "'", long34 == 1560183029244L);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-62135740800000L));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date5 = fixedMillisecond4.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        int int9 = day8.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date13 = fixedMillisecond12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.Date date15 = year14.getEnd();
        long long16 = year14.getFirstMillisecond();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year14);
        long long18 = month17.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 1560182976350L);
        long long21 = month17.getLastMillisecond();
        int int22 = day8.compareTo((java.lang.Object) long21);
        long long23 = day8.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-25070400001L) + "'", long18 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-23731200001L) + "'", long21 == (-23731200001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28799999L + "'", long23 == 28799999L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: December 1969");
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setKey((java.lang.Comparable) 1L);
        timeSeries1.setDomainDescription("");
        java.lang.Class<?> wildcardClass7 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 31);
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getTime();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        boolean boolean5 = timeSeries1.getNotify();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Date date11 = year10.getEnd();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 3, false);
        java.lang.Comparable comparable15 = timeSeries1.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries1.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) -1 + "'", comparable15.equals((short) -1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getSerialIndex();
        int int10 = day8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        int int17 = day8.compareTo((java.lang.Object) regularTimePeriod16);
        timeSeries1.setKey((java.lang.Comparable) day8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        double double8 = timeSeries1.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass13 = seriesChangeEvent12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 100);
        timeSeries1.add(timeSeriesDataItem24);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries1.addChangeListener(seriesChangeListener26);
        try {
            timeSeries1.delete(6, (int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date4 = fixedMillisecond3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getSerialIndex();
        int int7 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) 28799999L);
        long long10 = day5.getSerialIndex();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) long10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 25568L + "'", long6 == 25568L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        long long6 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year4);
        long long8 = month7.getMiddleMillisecond();
        int int9 = month7.getYearValue();
        int int10 = month7.getYearValue();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass13 = seriesChangeEvent12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        boolean boolean23 = month7.equals((java.lang.Object) date19);
        java.util.Calendar calendar24 = null;
        try {
            month7.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-25070400001L) + "'", long8 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.String str2 = regularTimePeriod1.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mon Jun 10 09:10:29 PDT 2019" + "'", str2.equals("Mon Jun 10 09:10:29 PDT 2019"));
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        timeSeries4.setDescription("1969");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date13 = fixedMillisecond12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.Date date15 = year14.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate(regularTimePeriod20, (java.lang.Number) (-2649600000L));
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection25 = timeSeries24.getTimePeriods();
        timeSeries24.fireSeriesChanged();
        timeSeries24.setMaximumItemAge((long) ' ');
        timeSeries24.removeAgedItems(false);
        boolean boolean31 = timeSeries24.getNotify();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection34 = timeSeries33.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeries33.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo42 = null;
        seriesChangeEvent41.setSummary(seriesChangeInfo42);
        boolean boolean44 = timeSeries39.equals((java.lang.Object) seriesChangeInfo42);
        java.lang.Comparable comparable45 = timeSeries39.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getLastMillisecond(calendar48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (short) 0);
        java.util.Date date52 = fixedMillisecond47.getTime();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond56.getMiddleMillisecond(calendar59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) month54, (double) 1L);
        java.util.Collection collection64 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = timeSeries4.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + (short) -1 + "'", comparable45.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 97L + "'", long60 == 97L);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(collection64);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        boolean boolean12 = timeSeries7.equals((java.lang.Object) seriesChangeInfo10);
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        java.util.Date date20 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        long long25 = month22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.next();
        timeSeries1.setKey((java.lang.Comparable) month22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        int int33 = month22.compareTo((java.lang.Object) day31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97L + "'", long17 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        seriesChangeEvent27.setSummary(seriesChangeInfo28);
        boolean boolean30 = timeSeries25.equals((java.lang.Object) seriesChangeInfo28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        long long36 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 0, false);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d, true);
        java.util.Calendar calendar46 = null;
        fixedMillisecond38.peg(calendar46);
        java.util.Date date48 = fixedMillisecond38.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond38.previous();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setKey((java.lang.Comparable) (short) -1);
        timeSeries1.setDomainDescription("Time");
        try {
            timeSeries1.delete(11, 31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183030238L + "'", long2 == 1560183030238L);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timeSeries15.getItemCount();
        boolean boolean24 = timeSeries15.getNotify();
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries27.removePropertyChangeListener(propertyChangeListener33);
        int int35 = timeSeries27.getItemCount();
        boolean boolean36 = timeSeries27.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
        seriesChangeEvent40.setSummary(seriesChangeInfo41);
        boolean boolean43 = timeSeries38.equals((java.lang.Object) seriesChangeInfo41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getLastMillisecond(calendar46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.next();
        long long49 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond51.previous();
        timeSeries27.add(regularTimePeriod53, (double) 1560182972264L);
        java.util.Collection collection56 = timeSeries27.getTimePeriods();
        int int57 = timeSeries27.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries27.addChangeListener(seriesChangeListener58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
        long long64 = fixedMillisecond61.getMiddleMillisecond();
        timeSeries27.setKey((java.lang.Comparable) long64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries15.addAndOrUpdate(timeSeries27);
        try {
            timeSeries27.delete(97, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
        org.junit.Assert.assertNotNull(timeSeries66);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=a]");
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        int int7 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '4');
        java.util.Date date20 = year19.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) 1560183018824L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        boolean boolean25 = timeSeries24.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) day32);
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        try {
            timeSeries7.delete(12, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(collection34);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setRangeDescription("");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        boolean boolean15 = timeSeries10.equals((java.lang.Object) seriesChangeInfo13);
        java.lang.Comparable comparable16 = timeSeries10.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 0);
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection30 = timeSeries29.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
        long long38 = fixedMillisecond34.getFirstMillisecond();
        java.lang.Number number39 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection44 = timeSeries43.getTimePeriods();
        timeSeries43.fireSeriesChanged();
        timeSeries43.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries41.addAndOrUpdate(timeSeries43);
        boolean boolean49 = fixedMillisecond34.equals((java.lang.Object) timeSeries41);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection52 = timeSeries51.getTimePeriods();
        timeSeries51.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond56.getMiddleMillisecond(calendar59);
        java.util.Calendar calendar61 = null;
        fixedMillisecond56.peg(calendar61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) (short) 100);
        timeSeries51.add(timeSeriesDataItem64);
        timeSeries41.add(timeSeriesDataItem64, true);
        int int68 = month27.compareTo((java.lang.Object) timeSeries41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) -1 + "'", comparable16.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 97L + "'", long20 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 97L + "'", long36 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 97L + "'", long38 == 97L);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 97L + "'", long58 == 97L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 97L + "'", long60 == 97L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25568L + "'", long4 == 25568L);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getItemCount();
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        boolean boolean20 = timeSeries15.equals((java.lang.Object) seriesChangeInfo18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timeSeries15.getItemCount();
        boolean boolean24 = timeSeries15.getNotify();
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo30);
        boolean boolean32 = timeSeries27.equals((java.lang.Object) seriesChangeInfo30);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries27.removePropertyChangeListener(propertyChangeListener33);
        int int35 = timeSeries27.getItemCount();
        boolean boolean36 = timeSeries27.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
        seriesChangeEvent40.setSummary(seriesChangeInfo41);
        boolean boolean43 = timeSeries38.equals((java.lang.Object) seriesChangeInfo41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getLastMillisecond(calendar46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.next();
        long long49 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond51.previous();
        timeSeries27.add(regularTimePeriod53, (double) 1560182972264L);
        java.util.Collection collection56 = timeSeries27.getTimePeriods();
        int int57 = timeSeries27.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries27.addChangeListener(seriesChangeListener58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
        long long64 = fixedMillisecond61.getMiddleMillisecond();
        timeSeries27.setKey((java.lang.Comparable) long64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries15.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries68.setNotify(false);
        timeSeries68.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100.0]");
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo77 = null;
        seriesChangeEvent76.setSummary(seriesChangeInfo77);
        boolean boolean79 = timeSeries74.equals((java.lang.Object) seriesChangeInfo77);
        java.lang.Comparable comparable80 = timeSeries74.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar83 = null;
        long long84 = fixedMillisecond82.getLastMillisecond(calendar83);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82, (double) (short) 0);
        java.util.Date date87 = fixedMillisecond82.getTime();
        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date87);
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = month89.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = month89.previous();
        long long92 = month89.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month89.next();
        timeSeries68.setKey((java.lang.Comparable) month89);
        java.lang.Number number95 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) month89);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 97L + "'", long47 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 97L + "'", long49 == 97L);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 97L + "'", long64 == 97L);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + comparable80 + "' != '" + (short) -1 + "'", comparable80.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 97L + "'", long84 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 28799999L + "'", long92 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertTrue("'" + number95 + "' != '" + 1.560182972264E12d + "'", number95.equals(1.560182972264E12d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(0, 10);
        double double5 = timeSeries4.getMaxY();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        int int17 = month16.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.Date date23 = year22.getEnd();
        long long24 = year22.getFirstMillisecond();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(3, year22);
        long long26 = month25.getMiddleMillisecond();
        int int27 = month25.getYearValue();
        int int28 = month25.getYearValue();
        int int29 = month16.compareTo((java.lang.Object) month25);
        java.lang.String str30 = month25.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-25070400001L) + "'", long26 == (-25070400001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "March 1969" + "'", str30.equals("March 1969"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        long long12 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo20);
        boolean boolean22 = timeSeries17.equals((java.lang.Object) seriesChangeInfo20);
        java.lang.Comparable comparable23 = timeSeries17.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (short) 0);
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 0);
        int int36 = month32.getMonth();
        long long37 = month32.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) -1 + "'", comparable23.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 23640L + "'", long37 == 23640L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) (short) 0);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems(true);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo17);
        boolean boolean19 = timeSeries14.equals((java.lang.Object) seriesChangeInfo17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int29 = year12.compareTo((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(11, year12);
        long long31 = year12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date36 = fixedMillisecond35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.Date date38 = year37.getEnd();
        long long39 = year37.getFirstMillisecond();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(3, year37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date43 = fixedMillisecond42.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 11);
        java.lang.Object obj47 = timeSeriesDataItem46.clone();
        timeSeriesDataItem46.setValue((java.lang.Number) (-1.0f));
        int int50 = month40.compareTo((java.lang.Object) (-1.0f));
        long long51 = month40.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, Double.NaN);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 97L + "'", long23 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 97L + "'", long25 == 97L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-31507200000L) + "'", long39 == (-31507200000L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-23731200001L) + "'", long51 == (-23731200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem53);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        timeSeries1.removeAgedItems((long) 0, true);
        boolean boolean8 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        try {
            timeSeries1.update(10, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (-61851744000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemAge((long) ' ');
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeries7);
        java.util.List list14 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy(4, (int) ' ');
        timeSeries7.clear();
        timeSeries7.removeAgedItems(false);
        java.lang.String str21 = timeSeries7.getDescription();
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo7);
        boolean boolean9 = timeSeries4.equals((java.lang.Object) seriesChangeInfo7);
        java.lang.Comparable comparable10 = timeSeries4.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) (short) 0);
        java.util.Date date17 = fixedMillisecond12.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(regularTimePeriod18, (java.lang.Number) 1560182981229L);
        timeSeries1.setMaximumItemCount(11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) -1 + "'", comparable10.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Date date4 = year3.getEnd();
        long long5 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        long long7 = year3.getFirstMillisecond();
        int int8 = year3.getYear();
        long long9 = year3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-15739200001L) + "'", long9 == (-15739200001L));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 11);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        java.lang.String str18 = timeSeries1.getDescription();
        long long19 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
        java.lang.String str12 = day11.toString();
        int int13 = day11.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.next();
        long long15 = day11.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57600000L) + "'", long15 == (-57600000L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeInfo4);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 'a');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        boolean boolean14 = timeSeries9.equals((java.lang.Object) seriesChangeInfo12);
        java.lang.Comparable comparable15 = timeSeries9.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) (short) 0);
        java.util.Date date22 = fixedMillisecond17.getTime();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        int int24 = month23.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) -1);
        java.lang.Class class27 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) -1 + "'", comparable7.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) -1 + "'", comparable15.equals((short) -1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 97L + "'", long19 == 97L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 100);
        timeSeriesDataItem9.setValue((java.lang.Number) 100L);
        timeSeriesDataItem9.setSelected(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
    }
}

