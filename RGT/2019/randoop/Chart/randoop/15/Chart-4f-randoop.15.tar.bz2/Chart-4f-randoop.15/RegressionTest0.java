import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, 0, (double) ' ', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        try {
            xYAreaRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (byte) 100, (java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 10L, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            xYAreaRenderer0.fillDomainGridBand(graphics2D2, xYPlot3, valueAxis4, rectangle2D5, (double) (byte) -1, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        java.awt.Font font8 = null;
        try {
            categoryAxis3D0.setLabelFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray2 = new float[] { 31 };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateBottomInset((double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            categoryAxis3D1.setLabelInsets(rectangleInsets11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        java.lang.String str8 = categoryAxis3D0.getLabel();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Layer.BACKGROUND", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        xYAreaRenderer0.setUseFillPaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        try {
            xYAreaRenderer0.setSeriesItemLabelFont((int) (short) -1, font6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 10, (double) 0L, (double) (-1.0f), (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean5 = xYAreaRenderer0.getSeriesVisibleInLegend(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYAreaRenderer0.setSeriesURLGenerator(12, xYURLGenerator7, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.lang.String str11 = axisEntity10.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) -1, range1, lengthConstraintType2, (double) (byte) 0, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color2 = java.awt.Color.getColor("poly", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBaseOutlinePaint();
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("NO_CHANGE", font1, paint3, (float) (-1), textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        try {
            boolean boolean5 = segmentedTimeline0.containsDomainRange((long) 12, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (-1) < domainValueStart (12)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.axis.Axis axis11 = axisEntity10.getAxis();
        java.lang.String str12 = axisEntity10.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(axis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisEntity: tooltip = null" + "'", str12.equals("AxisEntity: tooltip = null"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        org.jfree.data.RangeType rangeType4 = numberAxis3D1.getRangeType();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean6 = rangeType4.equals((java.lang.Object) paint5);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.lang.Comparable comparable9 = null;
        java.awt.Color color10 = java.awt.Color.black;
        try {
            categoryAxis3D0.setTickLabelPaint(comparable9, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        piePlot0.setAutoPopulateSectionOutlinePaint(true);
        boolean boolean7 = piePlot0.getSectionOutlinesVisible();
        piePlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean5 = xYAreaRenderer0.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("AxisEntity: tooltip = null", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) (short) 10, 100.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        segment5.dec((long) '4');
        segment5.dec((long) 1969);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        categoryAxis3D0.clearCategoryLabelToolTips();
        java.lang.Class class9 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date12 = segmentedTimeline10.getDate(0L);
        java.lang.Object obj13 = segmentedTimeline10.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date16 = segmentedTimeline14.getDate(0L);
        segmentedTimeline10.addException(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date16, timeZone18);
        try {
            categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) regularTimePeriod19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(segmentedTimeline10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        double double9 = categoryAxis3D1.getUpperMargin();
        java.awt.Font font10 = categoryAxis3D1.getTickLabelFont();
        float float11 = categoryAxis3D1.getMinorTickMarkInsideLength();
        categoryAxis3D1.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean14 = booleanList0.equals((java.lang.Object) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = null;
        try {
            xYAreaRenderer0.setBaseItemLabelPaint(paint2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.2d, (double) 100.0f, 100, (java.lang.Comparable) 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = null;
        piePlot0.setDrawingSupplier(drawingSupplier1, true);
        piePlot0.setMinimumArcAngleToDraw((double) 1L);
        piePlot0.clearSectionOutlinePaints(false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 1969, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = centerArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", graphics2D1, 0.0f, (float) 31, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "hi!", "", "");
        java.lang.String str5 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = numberAxis3D2.draw(graphics2D8, 100.0d, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        java.lang.String str6 = axisEntity3.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D11.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, rectangle2D14, (double) (byte) -1);
        numberAxis3D11.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Comparable comparable2 = defaultPieDataset0.getKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint8 = xYAreaRenderer0.getItemPaint((int) (byte) 100, 0, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.getAutoPopulateSeriesOutlinePaint();
        boolean boolean13 = xYAreaRenderer11.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = xYAreaRenderer11.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer11);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean17 = xYAreaRenderer16.getAutoPopulateSeriesOutlinePaint();
        boolean boolean18 = xYAreaRenderer16.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = xYAreaRenderer16.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle20.setLegendItemGraphicEdge(rectangleEdge21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle20.getPosition();
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge23);
        try {
            double double25 = categoryAxis3D0.getCategoryMiddle((int) (short) 10, 12, rectangle2D10, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect(0.2d, 100.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setRangeAboutValue(0.0d, (double) (byte) 100);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        categoryAxis3D1.setMinorTickMarksVisible(false);
        categoryAxis3D1.setTickMarksVisible(false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean15 = xYAreaRenderer14.getAutoPopulateSeriesOutlinePaint();
        boolean boolean16 = xYAreaRenderer14.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYAreaRenderer14.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle18.setLegendItemGraphicEdge(rectangleEdge19);
        try {
            double double21 = categoryAxis3D1.getCategorySeriesMiddle(0, (int) (short) 100, (int) (short) 0, (int) ' ', (double) '4', rectangle2D13, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYAreaRenderer0.setBaseURLGenerator(xYURLGenerator1, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D7.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3D7.getTickLabelInsets();
        java.awt.Shape shape10 = numberAxis3D7.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            xYAreaRenderer0.fillDomainGridBand(graphics2D4, xYPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, rectangle2D11, (double) (short) 1, (double) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBasePaint();
        piePlot0.setBaseSectionOutlinePaint(paint4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = new org.jfree.chart.plot.CrosshairState();
        int int9 = crosshairState8.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        crosshairState8.setAnchor(point2D12);
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            piePlot0.draw(graphics2D6, rectangle2D7, point2D12, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("Layer.BACKGROUND", font1, (java.awt.Paint) color2, (float) (-1), (int) '4', textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        try {
            timeSeries1.delete(12, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        try {
            xYStepAreaRenderer1.setLegendItemLabelGenerator(xYSeriesLabelGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYItemRendererState7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.getAutoPopulateSeriesOutlinePaint();
        boolean boolean9 = xYAreaRenderer7.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = xYAreaRenderer7.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean13 = xYAreaRenderer12.getAutoPopulateSeriesOutlinePaint();
        boolean boolean14 = xYAreaRenderer12.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = xYAreaRenderer12.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle16.setLegendItemGraphicEdge(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle16.getPosition();
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge19);
        try {
            gradientXYBarPainter0.paintBarShadow(graphics2D1, xYBarRenderer2, 0, 500, true, rectangularShape6, rectangleEdge19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = xYStepAreaRenderer4.initialise(graphics2D5, rectangle2D6, xYPlot7, xYDataset8, plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D19.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis3D19.getTickLabelInsets();
        org.jfree.data.RangeType rangeType22 = numberAxis3D19.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        try {
            xYStepAreaRenderer1.drawItem(graphics2D2, xYItemRendererState10, rectangle2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, xYDataset23, 1969, 2, true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(xYItemRendererState10);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rangeType22);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0L, (java.lang.Object) categoryAxis3D4);
        java.lang.String str15 = categoryAxis3D4.getLabel();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        try {
            xYAreaRenderer0.setSeriesItemLabelsVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color1 = java.awt.Color.getColor("Layer.BACKGROUND");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        piePlot0.setLabelGap((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        polarPlot10.setRadiusGridlinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "series", "series", image3, "AxisEntity: tooltip = null", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "Pie Plot");
        projectInfo7.setLicenceName("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendGraphic2.setFillPaint((java.awt.Paint) color3);
        boolean boolean5 = legendGraphic2.isShapeVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        int int2 = crosshairState0.getDomainAxisIndex();
        int int3 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        java.awt.Paint paint3 = xYAreaRenderer0.getBasePaint();
        xYAreaRenderer0.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean2 = tickType0.equals((java.lang.Object) paintArray1);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) (-2208927599948L), 10.0d, (int) '4', (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("AxisLocation.TOP_OR_RIGHT");
        float float2 = categoryAxis3D1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.lang.Object obj5 = logFormat4.clone();
        logFormat4.setMaximumIntegerDigits(0);
        logFormat4.setMaximumIntegerDigits(6);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.lang.Object obj5 = logFormat4.clone();
        logFormat4.setMaximumIntegerDigits(0);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        java.lang.StringBuffer stringBuffer11 = logFormat4.format((double) 1969L, stringBuffer9, fieldPosition10);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stringBuffer11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.util.Collection collection2 = xYAreaRenderer0.getAnnotations();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYAreaRenderer0.getURLGenerator(4, (int) (byte) 0, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNull(xYURLGenerator6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str2.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        piePlot3.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font2, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D12.configure();
        numberAxis3D12.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, polarItemRenderer16);
        java.awt.Paint paint18 = numberAxis3D12.getAxisLinePaint();
        org.jfree.chart.text.TextMeasurer textMeasurer20 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("series", font2, paint18, (float) 1L, textMeasurer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        xYAreaRenderer0.setPlot(xYPlot14);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CrosshairState crosshairState3 = new org.jfree.chart.plot.CrosshairState();
        int int4 = crosshairState3.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        crosshairState3.setAnchor(point2D7);
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            waferMapPlot0.draw(graphics2D1, rectangle2D2, point2D7, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5, "");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint9 = xYAreaRenderer8.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer8);
        java.awt.Paint paint11 = xYAreaRenderer8.getBasePaint();
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "", "poly", "Pie Plot", shape4, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int3 = java.awt.Color.HSBtoRGB((float) 1969L, (float) (short) 100, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-668) + "'", int3 == (-668));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "series", "series", image3, "AxisEntity: tooltip = null", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "Pie Plot");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getLibraries();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20561) + "'", int1 == (-20561));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart8.createBufferedImage((int) (byte) 1, (int) (byte) 0, 2, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape6 = xYAreaRenderer0.lookupSeriesShape((int) (byte) 1);
        java.awt.Stroke stroke8 = xYAreaRenderer0.lookupSeriesStroke(4);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYStepAreaRenderer11.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState18 = null;
        xYItemRendererState17.setSelectionState(xYDatasetSelectionState18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D23.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis3D23.getTickLabelInsets();
        org.jfree.data.RangeType rangeType26 = numberAxis3D23.getRangeType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D28.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = numberAxis3D28.getTickLabelInsets();
        java.awt.Shape shape31 = numberAxis3D28.getDownArrow();
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        int int35 = piePlot34.getBackgroundImageAlignment();
        java.awt.Stroke stroke36 = piePlot34.getOutlineStroke();
        piePlot34.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font33, (org.jfree.chart.plot.Plot) piePlot34, false);
        numberAxis3D28.setTickLabelFont(font33);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        try {
            xYAreaRenderer0.drawItem(graphics2D9, xYItemRendererState17, rectangle2D20, xYPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, xYDataset42, 500, (int) (short) 1, false, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.renderer.xy.XYItemRendererState cannot be cast to org.jfree.chart.renderer.xy.XYAreaRenderer$XYAreaRendererState");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (int) (byte) 10);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Paint paint36 = null;
        try {
            xYPlot35.setRangeCrosshairPaint(paint36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = segmentedTimeline0.getBaseTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(7, (int) (short) 100, (int) (short) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", font1, (java.awt.Paint) color2, (float) (byte) 0, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.05d, 0.0d, (double) (byte) -1, 0.2d, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Shape shape2 = null;
        try {
            xYAreaRenderer0.setBaseShape(shape2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = centerArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color9.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Number number7 = logFormat4.parse("Layer.BACKGROUND", parsePosition6);
        java.math.RoundingMode roundingMode8 = null;
        try {
            logFormat4.setRoundingMode(roundingMode8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot0.setLabelOutlineStroke(stroke1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        java.awt.Paint paint4 = piePlot0.getNoDataMessagePaint();
        piePlot0.setMinimumArcAngleToDraw((double) 1);
        org.jfree.data.general.PieDataset pieDataset7 = piePlot0.getDataset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint7 = xYAreaRenderer6.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer6);
        java.awt.Paint paint9 = xYAreaRenderer6.getBasePaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D13.configure();
        numberAxis3D13.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, polarItemRenderer17);
        java.awt.Paint paint19 = numberAxis3D13.getAxisLinePaint();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean24 = segmentedTimeline22.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment26 = segmentedTimeline22.getSegment((long) (short) 0);
        categoryAxis3D21.addCategoryLabelToolTip((java.lang.Comparable) segment26, "");
        categoryAxis3D21.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape20, (org.jfree.chart.axis.Axis) categoryAxis3D21);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape20, "NO_CHANGE");
        numberAxis3D13.setDownArrow(shape20);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer35.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape41 = xYAreaRenderer35.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot42 = xYAreaRenderer35.getPlot();
        java.lang.Boolean boolean44 = xYAreaRenderer35.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, valueAxis34, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer35);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot45.setRangeZeroBaselineStroke(stroke46);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 2.0d, paint2, stroke5, paint9, stroke46, (float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(segment26);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNull(xYPlot42);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        boolean boolean14 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        xYAreaRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        org.jfree.chart.plot.Marker marker48 = null;
        try {
            xYPlot35.addDomainMarker(marker48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str3.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        categoryAxis3D3.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D3);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer15.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle17);
        boolean boolean20 = blockContainer0.equals((java.lang.Object) titleEntity19);
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (-20561));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        legendGraphic2.setID("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = axisEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape14, (java.awt.Paint) color15);
        java.awt.Shape shape17 = legendGraphic16.getShape();
        axisEntity10.setArea(shape17);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        org.jfree.data.Range range3 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange0, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Number number7 = logFormat4.parse("Layer.BACKGROUND", parsePosition6);
        boolean boolean8 = logFormat4.isGroupingUsed();
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean20 = segmentedTimeline18.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment22 = segmentedTimeline18.getSegment((long) (short) 0);
        categoryAxis3D17.addCategoryLabelToolTip((java.lang.Comparable) segment22, "");
        boolean boolean27 = segment22.contained((long) (short) 0, (long) ' ');
        boolean boolean28 = segment22.inExcludeSegments();
        boolean boolean31 = segment22.contained((long) 6, (long) ' ');
        boolean boolean32 = segment16.after(segment22);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean37 = xYAreaRenderer36.getAutoPopulateSeriesOutlinePaint();
        boolean boolean38 = xYAreaRenderer36.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator39 = xYAreaRenderer36.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer36);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle40.setLegendItemGraphicEdge(rectangleEdge41);
        try {
            double double43 = categoryAxis3D1.getCategorySeriesMiddle((java.lang.Comparable) (byte) -1, (java.lang.Comparable) segment22, categoryDataset33, (double) (byte) 0, rectangle2D35, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(segmentedTimeline18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segment22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = null;
        java.awt.geom.Point2D point2D50 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor49);
        try {
            xYPlot35.zoomDomainAxes((double) (-1L), plotRenderingInfo47, point2D50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("NO_CHANGE");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        numberAxis3D2.setAxisLineVisible(false);
        numberAxis3D2.setInverted(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Paint paint4 = null;
        try {
            xYAreaRenderer0.setBaseFillPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj6 = numberAxis3D2.clone();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        numberAxis3D2.setRangeWithMargins((org.jfree.data.Range) dateRange7, true, false);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend11 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        try {
            java.lang.Number number4 = xYSeries2.getY((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        int int14 = month8.compareTo((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = xYItemRendererState7.getInfo();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNull(plotRenderingInfo8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        double double2 = crosshairState0.getCrosshairX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        categoryAxis3D3.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D3);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer15.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle17);
        boolean boolean20 = blockContainer0.equals((java.lang.Object) titleEntity19);
        org.jfree.chart.block.BlockBorder blockBorder21 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        java.lang.String str23 = rectangleInsets22.toString();
        double double25 = rectangleInsets22.calculateLeftInset((double) 15);
        blockContainer0.setMargin(rectangleInsets22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(blockBorder21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str23.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        java.lang.String str4 = axisEntity3.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AxisEntity: tooltip = " + "'", str4.equals("AxisEntity: tooltip = "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.util.Collection collection2 = xYAreaRenderer0.getAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        try {
            xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        boolean boolean8 = legendTitle4.isVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.PiePlotState piePlotState8 = piePlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 15, plotRenderingInfo7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot0.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        org.jfree.data.xy.XYDataItem xYDataItem3 = null;
        try {
            xYSeries2.add(xYDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape6 = xYAreaRenderer0.lookupSeriesShape((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape6, "item", "series", categoryDataset9, (java.lang.Comparable) (-20561), (java.lang.Comparable) "AxisEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        org.jfree.chart.util.SortOrder sortOrder4 = null;
        try {
            defaultPieDataset0.sortByValues(sortOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            jFreeChart8.handleClick(2, 100, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 10.0f, "DateTickUnit[DateTickUnitType.DAY, 1]", textAnchor2, textAnchor3, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str41 = layer40.toString();
        try {
            boolean boolean42 = xYPlot35.removeRangeMarker(marker39, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.BACKGROUND" + "'", str41.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        long long5 = month3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1310400001L) + "'", long5 == (-1310400001L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot0.setLabelOutlineStroke(stroke1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        java.awt.Paint paint4 = piePlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        int int6 = piePlot5.getBackgroundImageAlignment();
        java.awt.Stroke stroke7 = piePlot5.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot5.getSimpleLabelOffset();
        piePlot0.setInsets(rectangleInsets8, false);
        piePlot0.setBackgroundImageAlpha((float) 0L);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        polarPlot10.rendererChanged(rendererChangeEvent18);
        double double20 = polarPlot10.getMaxRadius();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.5d + "'", double20 == 3.5d);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setDomainMinorGridlineStroke(stroke39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getRangeAxis();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str44 = layer43.toString();
        try {
            xYPlot35.addRangeMarker(marker42, layer43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.BACKGROUND" + "'", str44.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke36);
        xYPlot35.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D42.configure();
        numberAxis3D42.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, polarItemRenderer46);
        numberAxis3D42.setLowerBound((double) (short) 0);
        xYPlot35.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        java.lang.Number number4 = null;
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries2.addOrUpdate(number4, (java.lang.Number) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date9 = segmentedTimeline7.getDate(0L);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline6.getSegment(date9);
        java.util.Date date12 = null;
        try {
            boolean boolean13 = segmentedTimeline0.containsDomainRange(date9, date12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment11);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        categoryAxis3D0.clearCategoryLabelToolTips();
        float float9 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean15 = xYAreaRenderer14.getAutoPopulateSeriesOutlinePaint();
        boolean boolean16 = xYAreaRenderer14.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYAreaRenderer14.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle18.setLegendItemGraphicEdge(rectangleEdge19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis3D0.draw(graphics2D10, (double) 2.0f, rectangle2D12, rectangle2D13, rectangleEdge19, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseOutlinePaint();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity3 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "AxisEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        java.lang.String str2 = standardXYToolTipGenerator0.getFormatString();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = axisEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape14, (org.jfree.chart.axis.Axis) categoryAxis3D15, "");
        axisEntity10.setArea(shape14);
        axisEntity10.setToolTipText("series");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        legendTitle2.setWidth((double) (byte) -1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "gray" + "'", str1.equals("gray"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D51.configure();
        numberAxis3D51.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, polarItemRenderer55);
        java.awt.Paint paint57 = numberAxis3D51.getAxisLinePaint();
        java.awt.Shape shape58 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D59 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline60 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean62 = segmentedTimeline60.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment64 = segmentedTimeline60.getSegment((long) (short) 0);
        categoryAxis3D59.addCategoryLabelToolTip((java.lang.Comparable) segment64, "");
        categoryAxis3D59.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity68 = new org.jfree.chart.entity.AxisEntity(shape58, (org.jfree.chart.axis.Axis) categoryAxis3D59);
        org.jfree.chart.entity.ChartEntity chartEntity70 = new org.jfree.chart.entity.ChartEntity(shape58, "NO_CHANGE");
        numberAxis3D51.setDownArrow(shape58);
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer73 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer73.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape79 = xYAreaRenderer73.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot80 = xYAreaRenderer73.getPlot();
        java.lang.Boolean boolean82 = xYAreaRenderer73.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, valueAxis72, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer73);
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline85 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date87 = segmentedTimeline85.getDate(0L);
        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date87);
        int int89 = month88.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month88, (double) '#');
        boolean boolean92 = axisLocation84.equals((java.lang.Object) timeSeriesDataItem91);
        xYPlot83.setRangeAxisLocation(axisLocation84);
        try {
            xYPlot35.setDomainAxisLocation((-1), axisLocation84, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(segmentedTimeline60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(segment64);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNull(xYPlot80);
        org.junit.Assert.assertNull(boolean82);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(segmentedTimeline85);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1969 + "'", int89 == 1969);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        java.awt.Font font2 = piePlot0.getNoDataMessageFont();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        double double10 = numberAxis3D2.getUpperMargin();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D2.setLabelFont(font11);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        boolean boolean15 = segment10.contained((long) (short) 0, (long) ' ');
        boolean boolean16 = segment10.inExcludeSegments();
        boolean boolean19 = segment10.contained((long) 6, (long) ' ');
        boolean boolean20 = segment4.after(segment10);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries22.setMaximumItemCount(12);
        java.lang.Comparable comparable25 = timeSeries22.getKey();
        timeSeries22.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.Object obj28 = timeSeries22.clone();
        try {
            int int29 = segment10.compareTo((java.lang.Object) timeSeries22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 0 + "'", comparable25.equals((byte) 0));
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date13 = segmentedTimeline11.getDate(0L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        java.awt.Paint paint15 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) date13);
        categoryAxis3D1.clearCategoryLabelToolTips();
        java.awt.Paint paint18 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        java.lang.String str46 = axisLocation36.toString();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str46.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        java.awt.Font font2 = piePlot0.getNoDataMessageFont();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator3);
        double double5 = piePlot0.getStartAngle();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle2.getLegendItemGraphicPadding();
        java.awt.Font font4 = legendTitle2.getItemFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.remove((java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        java.util.Collection collection13 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries12.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke36);
        xYPlot35.setDomainGridlinesVisible(false);
        xYPlot35.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            xYPlot35.addRangeMarker(marker36, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(layer37);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        xYAreaRenderer0.setUseFillPaint(true);
        xYAreaRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition(4, itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (double) (byte) 10);
        size2D2.height = 500;
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 0, (double) 0);
        double double3 = xYDataItem2.getYValue();
        java.lang.Object obj4 = xYDataItem2.clone();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepAreaRenderer6.initialise(graphics2D7, rectangle2D8, xYPlot9, xYDataset10, plotRenderingInfo11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.data.Range range14 = xYStepAreaRenderer6.findRangeBounds(xYDataset13);
        int int15 = xYDataItem2.compareTo((java.lang.Object) range14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot5.setLabelOutlineStroke(stroke6);
        java.awt.Font font8 = piePlot5.getLabelFont();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        piePlot5.setMinimumArcAngleToDraw((double) 1);
        defaultPieDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot5);
        org.jfree.data.general.DatasetGroup datasetGroup13 = null;
        try {
            defaultPieDataset0.setGroup(datasetGroup13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.lang.Object obj39 = xYPlot35.clone();
        xYPlot35.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.CrosshairState crosshairState43 = new org.jfree.chart.plot.CrosshairState();
        int int44 = crosshairState43.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        crosshairState43.setAnchor(point2D47);
        try {
            xYPlot35.zoomDomainAxes(10.0d, plotRenderingInfo42, point2D47, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) 0, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.PiePlotState piePlotState8 = piePlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 15, plotRenderingInfo7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            piePlot3.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Paint paint13 = xYAreaRenderer0.getLegendTextPaint(500);
        java.awt.Paint paint17 = xYAreaRenderer0.getItemFillPaint((int) (byte) 100, (int) (byte) 0, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = numberAxis3D2.draw(graphics2D12, (double) 15, rectangle2D14, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        piePlot0.setAutoPopulateSectionOutlinePaint(true);
        piePlot0.setStartAngle((double) 1546329600000L);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean10 = xYAreaRenderer9.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer9.setBaseStroke(stroke11, true);
        piePlot0.setLabelLinkStroke(stroke11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        try {
            timeSeries1.setMaximumItemAge((long) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date16 = segmentedTimeline14.getDate(0L);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.awt.Paint paint18 = categoryAxis3D4.getTickLabelPaint((java.lang.Comparable) date16);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date21 = segmentedTimeline19.getDate(0L);
        java.lang.Object obj22 = segmentedTimeline19.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date25 = segmentedTimeline23.getDate(0L);
        segmentedTimeline19.addException(date25);
        boolean boolean27 = segmentedTimeline0.containsDomainRange(date16, date25);
        java.util.Date date28 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline0.getSegment(date28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(segmentedTimeline19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        int int12 = piePlot11.getBackgroundImageAlignment();
        java.awt.Stroke stroke13 = piePlot11.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = piePlot8.initialise(graphics2D9, rectangle2D10, piePlot11, (java.lang.Integer) 15, plotRenderingInfo15);
        categoryAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot11);
        java.awt.Paint paint18 = piePlot11.getBaseSectionPaint();
        float float19 = piePlot11.getForegroundAlpha();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(piePlotState16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "Pie Plot", (java.lang.Number) 192);
        try {
            defaultKeyedValues0.removeValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str1 = dateTickUnit0.toString();
        java.lang.Class class2 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date5 = segmentedTimeline3.getDate(0L);
        java.lang.Object obj6 = segmentedTimeline3.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date9 = segmentedTimeline7.getDate(0L);
        segmentedTimeline3.addException(date9);
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date9, timeZone11);
        java.util.TimeZone timeZone13 = null;
        try {
            java.util.Date date14 = dateTickUnit0.addToDate(date9, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str1.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendGraphic2.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendGraphic2.getPadding();
        double double6 = rectangleInsets4.extendWidth((double) 1969);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1973.0d + "'", double6 == 1973.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = xYPlot35.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker37 = null;
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str39 = layer38.toString();
        java.lang.String str40 = layer38.toString();
        try {
            xYPlot35.addRangeMarker(marker37, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.BACKGROUND" + "'", str39.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Layer.BACKGROUND" + "'", str40.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Paint paint9 = piePlot2.getLabelBackgroundPaint();
        piePlot2.setLabelLinkMargin((double) (byte) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        java.awt.Paint paint5 = null;
        piePlot2.setLabelShadowPaint(paint5);
        piePlot2.setAutoPopulateSectionOutlinePaint(true);
        boolean boolean9 = timePeriodAnchor0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean13 = segmentedTimeline11.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segmentedTimeline11.getSegment((long) (short) 0);
        categoryAxis3D10.addCategoryLabelToolTip((java.lang.Comparable) segment15, "");
        segment15.dec((long) '4');
        long long20 = segment15.getSegmentNumber();
        java.awt.Paint paint21 = piePlot2.getSectionPaint((java.lang.Comparable) long20);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(segment15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2454312L + "'", long20 == 2454312L);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        boolean boolean6 = legendGraphic2.isShapeFilled();
        boolean boolean8 = legendGraphic2.equals((java.lang.Object) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendGraphic2.getPadding();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = timePeriodAnchor0.equals(obj2);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (short) -1, "TimePeriodAnchor.END", "", true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        boolean boolean14 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        try {
            xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-9999), (float) '#');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D11.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, rectangle2D14, (double) (byte) -1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator17 = xYStepAreaRenderer1.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(xYItemLabelGenerator17);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        boolean boolean36 = legendItem35.isShapeVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        java.awt.Stroke stroke2 = piePlot0.getLabelLinkStroke();
        double double3 = piePlot0.getLabelGap();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        defaultPieDataset0.clear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        piePlot0.setShadowYOffset((double) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieURLGenerator9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart12.createBufferedImage((int) (byte) 1, 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        try {
            jFreeChart12.plotChanged(plotChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        org.jfree.data.xy.XYDataItem xYDataItem6 = new org.jfree.data.xy.XYDataItem((double) 0, (double) 0);
        double double7 = xYDataItem6.getYValue();
        xYSeries2.add(xYDataItem6, true);
        boolean boolean10 = xYDataItem6.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer1.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer1);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D6.configure();
        numberAxis3D6.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, polarItemRenderer10);
        xYAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Paint paint13 = xYAreaRenderer1.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer1.getBaseNegativeItemLabelPosition();
        double double15 = itemLabelPosition14.getAngle();
        boolean boolean16 = textAnchor0.equals((java.lang.Object) itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.clear();
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        int int2 = crosshairState0.getDomainAxisIndex();
        double double3 = crosshairState0.getCrosshairX();
        double double4 = crosshairState0.getCrosshairY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date8 = segmentedTimeline6.getDate(0L);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline5.getSegment(date8);
        try {
            defaultKeyedValues0.insertValue(6, (java.lang.Comparable) date8, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(segment10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str50 = axisLocation49.toString();
        xYPlot35.setRangeAxisLocation(7, axisLocation49, true);
        double double53 = xYPlot35.getDomainCrosshairValue();
        boolean boolean54 = xYPlot35.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str50.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 7.0d + "'", double53 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setUseYInterval(true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        try {
            double double16 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor11, (int) (short) 100, (-20561), rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = null;
        try {
            xYPlot35.setAxisOffset(rectangleInsets39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot0.getLegendItems();
        piePlot0.setShadowXOffset((double) (-668));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        try {
            java.lang.Number number5 = defaultPieDataset0.getValue((java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 3.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape3, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint17 = xYAreaRenderer16.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle18.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity20 = new org.jfree.chart.entity.TitleEntity(shape3, (org.jfree.chart.title.Title) legendTitle18);
        boolean boolean21 = blockContainer1.equals((java.lang.Object) titleEntity20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D25 = centerArrangement0.arrange(blockContainer1, graphics2D22, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardXYToolTipGenerator0.getXFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        boolean boolean3 = legendTitle2.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean5 = xYAreaRenderer4.getAutoPopulateSeriesOutlinePaint();
        boolean boolean6 = xYAreaRenderer4.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYAreaRenderer4.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge9);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge9);
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "Pie Plot", (java.lang.Number) 192);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries5.setMaximumItemCount(12);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        timeSeries5.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint13 = xYAreaRenderer12.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer12);
        xYAreaRenderer12.setUseFillPaint(true);
        boolean boolean17 = day11.equals((java.lang.Object) true);
        int int18 = day11.getMonth();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, number19);
        try {
            defaultKeyedValues0.setValue((java.lang.Comparable) timeSeriesDataItem20, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 0 + "'", comparable8.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendGraphic2.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendGraphic2.getPadding();
        legendGraphic2.setShapeFilled(true);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            legendGraphic2.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = null;
        boolean boolean3 = textFragment1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYAreaRenderer0.drawDomainGridLine(graphics2D12, xYPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, rectangle2D16, (double) (-2208927599948L));
        boolean boolean19 = xYAreaRenderer0.getBaseSeriesVisible();
        xYAreaRenderer0.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year11 = month8.getYear();
        java.lang.String str12 = month8.toString();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 1969" + "'", str12.equals("December 1969"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYAreaRenderer0.setBaseShape(shape3, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.getAutoPopulateSeriesOutlinePaint();
        boolean boolean7 = xYAreaRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer5.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle9.getPosition();
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge12);
        double double14 = legendTitle4.getHeight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = xYItemRendererState7.getSelectionState();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNull(xYDatasetSelectionState8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        try {
            java.lang.Number number4 = xYSeries2.getY(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            java.lang.Number number52 = timeSeriesCollection49.getEndY(15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        java.awt.Paint paint3 = xYAreaRenderer0.getBasePaint();
        boolean boolean5 = xYAreaRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Font font7 = null;
        xYAreaRenderer0.setSeriesItemLabelFont((int) '4', font7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        xYAreaRenderer0.setUseFillPaint(true);
        xYAreaRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset37 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset37.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        legendItem35.setDataset((org.jfree.data.general.Dataset) defaultPieDataset37);
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset37);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        xYAreaRenderer0.setSeriesVisibleInLegend(5, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            java.lang.Comparable comparable51 = timeSeriesCollection49.getSeriesKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (500).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        categoryAxis3D3.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D3);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer15.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle17);
        boolean boolean20 = blockContainer0.equals((java.lang.Object) titleEntity19);
        java.lang.String str21 = blockContainer0.getID();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries2.setMaximumItemCount(12);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        timeSeries2.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.Object obj8 = timeSeries2.clone();
        boolean boolean9 = lengthConstraintType0.equals((java.lang.Object) timeSeries2);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        java.awt.Stroke stroke48 = xYPlot35.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace49);
        org.jfree.chart.plot.Marker marker52 = null;
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str54 = layer53.toString();
        java.lang.String str55 = layer53.toString();
        try {
            xYPlot35.addDomainMarker((int) (byte) 1, marker52, layer53, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Layer.BACKGROUND" + "'", str54.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Layer.BACKGROUND" + "'", str55.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        xYAreaRenderer0.setUseFillPaint(true);
        xYAreaRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYAreaRenderer0.getBaseURLGenerator();
        boolean boolean10 = xYAreaRenderer0.getUseFillPaint();
        xYAreaRenderer0.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        int int19 = piePlot18.getBackgroundImageAlignment();
        java.awt.Stroke stroke20 = piePlot18.getOutlineStroke();
        java.awt.Paint paint21 = piePlot18.getLabelPaint();
        int int22 = piePlot18.getBackgroundImageAlignment();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot18.setLabelLinkStroke(stroke23);
        polarPlot10.setRadiusGridlineStroke(stroke23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj5 = numberAxis3D1.clone();
        double double6 = numberAxis3D1.getLowerBound();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-50.0d) + "'", double6 == (-50.0d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int4 = color3.getBlue();
        float[] floatArray8 = new float[] { 0, 1.0f, 0.0f };
        float[] floatArray9 = color3.getColorComponents(floatArray8);
        float[] floatArray10 = java.awt.Color.RGBtoHSB((-668), 15, 9999, floatArray9);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date17 = segmentedTimeline15.getDate(0L);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        int int19 = month18.getYearValue();
        boolean boolean20 = legendItemEntity14.equals((java.lang.Object) int19);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        java.awt.Paint paint5 = null;
        piePlot2.setLabelShadowPaint(paint5);
        piePlot2.setAutoPopulateSectionOutlinePaint(true);
        boolean boolean9 = timePeriodAnchor0.equals((java.lang.Object) piePlot2);
        java.awt.Stroke stroke10 = piePlot2.getOutlineStroke();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState8 = ringPlot1.initialise(graphics2D2, rectangle2D3, piePlot5, (java.lang.Integer) 1, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle2.getLegendItemGraphicPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D10.configure();
        numberAxis3D10.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer14);
        xYAreaRenderer5.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot15);
        polarPlot15.setForegroundAlpha(0.0f);
        polarPlot15.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot15.setDataset(xYDataset21);
        boolean boolean23 = defaultPieDataset0.equals((java.lang.Object) polarPlot15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        boolean boolean9 = jFreeChart8.isNotify();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean11 = xYAreaRenderer10.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer10.setBaseStroke(stroke12, true);
        jFreeChart8.setBorderStroke(stroke12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Shape shape3 = legendGraphic2.getShape();
        double double4 = legendGraphic2.getHeight();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj5 = numberAxis3D1.clone();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange6, true, false);
        numberAxis3D1.resizeRange((double) 2.0f, (double) 1560409200000L);
        boolean boolean13 = numberAxis3D1.isVisible();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj5 = numberAxis3D1.clone();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange6, true, false);
        numberAxis3D1.resizeRange((double) 2.0f, (double) 1560409200000L);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape14 = defaultDrawingSupplier13.getNextShape();
        numberAxis3D1.setRightArrow(shape14);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        xYSeries2.add((java.lang.Number) 31, (java.lang.Number) (byte) 100);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries2.remove((java.lang.Number) (-668));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        double double4 = xYSeries2.getMinY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean16 = xYAreaRenderer15.getAutoPopulateSeriesOutlinePaint();
        boolean boolean17 = xYAreaRenderer15.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator18 = xYAreaRenderer15.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle19.setLegendItemGraphicEdge(rectangleEdge20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis3D1.draw(graphics2D11, (double) 192, rectangle2D13, rectangle2D14, rectangleEdge20, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getRollMultiple();
        java.lang.String str2 = dateTickUnit0.toString();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str2.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        java.awt.Stroke stroke48 = xYPlot35.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.CrosshairState crosshairState53 = new org.jfree.chart.plot.CrosshairState();
        int int54 = crosshairState53.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D55, rectangleAnchor56);
        crosshairState53.setAnchor(point2D57);
        xYPlot35.panDomainAxes((double) 2, plotRenderingInfo52, point2D57);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        try {
            double double53 = timeSeriesCollection49.getEndXValue((-20561), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        java.awt.Stroke stroke2 = piePlot0.getLabelLinkStroke();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot0.getDataset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset1);
        boolean boolean3 = objectList0.equals((java.lang.Object) defaultPieDataset1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        int int1 = crosshairState0.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        crosshairState0.setAnchor(point2D4);
        crosshairState0.updateCrosshairY((double) 100L, (int) (byte) 100);
        crosshairState0.updateCrosshairX((double) 1546329600000L, (int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(point2D4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        piePlot0.setShadowYOffset((double) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        java.lang.Object obj12 = null;
        boolean boolean13 = standardPieSectionLabelGenerator10.equals(obj12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYAreaRenderer0.notifyListeners(rendererChangeEvent2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        xYStepAreaRenderer1.setRangeBase((double) 100);
        boolean boolean10 = xYStepAreaRenderer1.getPlotArea();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = null;
        xYAreaRenderer0.setSeriesPaint(0, paint3, false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        boolean boolean3 = legendTitle2.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean5 = xYAreaRenderer4.getAutoPopulateSeriesOutlinePaint();
        boolean boolean6 = xYAreaRenderer4.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYAreaRenderer4.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge9);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            legendTitle2.setPosition(rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        java.awt.Paint paint6 = null;
        legendGraphic2.setLinePaint(paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D11 = legendGraphic2.arrange(graphics2D8, rectangleConstraint10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(size2D11);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset37 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset37.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        legendItem35.setDataset((org.jfree.data.general.Dataset) defaultPieDataset37);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer42 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem35.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer42);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType44 = standardGradientPaintTransformer42.getType();
        java.lang.String str45 = gradientPaintTransformType44.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(gradientPaintTransformType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str45.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.getAutoPopulateSeriesOutlinePaint();
        boolean boolean9 = xYAreaRenderer7.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = xYAreaRenderer7.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle11.getPosition();
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, 6, 31, true, rectangularShape6, rectangleEdge14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        legendTitle4.setHeight((double) 100.0f);
        java.awt.Font font10 = legendTitle4.getItemFont();
        legendTitle4.setWidth(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Paint paint9 = piePlot2.getLabelBackgroundPaint();
        boolean boolean10 = piePlot2.getSimpleLabels();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean15 = segmentedTimeline13.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline13.getSegment((long) (short) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) segment17, "");
        categoryAxis3D12.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis3D12);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator22 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator23 = null;
        java.lang.String str24 = axisEntity21.getImageMapAreaTag(toolTipTagFragmentGenerator22, uRLTagFragmentGenerator23);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape25, (org.jfree.chart.axis.Axis) categoryAxis3D26, "");
        axisEntity21.setArea(shape25);
        piePlot2.setLegendItemShape(shape25);
        piePlot2.zoom((-50.0d));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", dateFormat1, (java.text.NumberFormat) logFormat6);
        logFormat6.setMinimumFractionDigits(15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        try {
            java.lang.Number number2 = numberFormat0.parse("series");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"series\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesItemLabelPaint(10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYAreaRenderer3.setBaseURLGenerator(xYURLGenerator4, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYAreaRenderer3.getSeriesPositiveItemLabelPosition((-668));
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str37 = seriesRenderingOrder36.toString();
        xYPlot35.setSeriesRenderingOrder(seriesRenderingOrder36);
        java.awt.Paint paint39 = xYPlot35.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str37.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        try {
            boolean boolean53 = timeSeriesCollection49.isSelected(10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        int int1 = dateTickUnitType0.getCalendarField();
        java.lang.String str2 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickUnitType.DAY" + "'", str2.equals("DateTickUnitType.DAY"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Paint paint60 = xYPlot40.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        boolean boolean6 = legendGraphic2.isShapeVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setBaseStroke(stroke2, true);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint8 = xYAreaRenderer7.getBasePaint();
        java.util.Collection collection9 = xYAreaRenderer7.getAnnotations();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYAreaRenderer7.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        xYAreaRenderer7.setBasePaint((java.awt.Paint) color14, true);
        xYAreaRenderer0.setBaseFillPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint9 = xYAreaRenderer8.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer8);
        xYAreaRenderer8.setUseFillPaint(true);
        boolean boolean13 = day7.equals((java.lang.Object) true);
        int int14 = day7.getMonth();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, number15);
        org.jfree.data.time.TimeSeries timeSeries17 = null;
        try {
            java.util.Collection collection18 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color4 = java.awt.Color.black;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 2019, (double) 8, 0.0d, (double) (-1L), (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockBorder5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateBottomInset((double) 100.0f);
        legendTitle4.setMargin(rectangleInsets9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle4.setHorizontalAlignment(horizontalAlignment13);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint29 = xYAreaRenderer28.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer28);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle30.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity32 = new org.jfree.chart.entity.TitleEntity(shape15, (org.jfree.chart.title.Title) legendTitle30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle30.setLegendItemGraphicLocation(rectangleAnchor33);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray35 = legendTitle30.getSources();
        legendTitle4.setSources(legendItemSourceArray35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(blockBorder8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(legendItemSourceArray35);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateBottomInset((double) 100.0f);
        legendTitle4.setMargin(rectangleInsets9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle4.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment15, 0.0d, (double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(blockBorder8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10.0f, (double) 1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        piePlot7.clearSectionOutlineStrokes(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYStepAreaRenderer18.initialise(graphics2D19, rectangle2D20, xYPlot21, xYDataset22, plotRenderingInfo23);
        int int25 = xYItemRendererState24.getLastItemIndex();
        boolean boolean26 = xYItemRendererState24.getProcessVisibleItemsOnly();
        boolean boolean27 = piePlot7.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        xYSeries2.add((java.lang.Number) 31, (java.lang.Number) (byte) 100);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries2.remove((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        try {
            double double54 = timeSeriesCollection49.getEndXValue((int) ' ', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        boolean boolean3 = legendTitle2.visible;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.clear();
        legendTitle2.setWrapper(blockContainer6);
        org.jfree.chart.block.BlockFrame blockFrame9 = null;
        try {
            legendTitle2.setFrame(blockFrame9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer2);
        xYAreaRenderer2.setUseFillPaint(true);
        boolean boolean7 = day1.equals((java.lang.Object) true);
        int int8 = day1.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = day1.getSerialDate();
        serialDate9.setDescription("TimePeriodAnchor.END");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(1969, serialDate9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.getAutoPopulateSeriesOutlinePaint();
        boolean boolean13 = xYAreaRenderer11.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = xYAreaRenderer11.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer11);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle15);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean19 = xYAreaRenderer18.getAutoPopulateSeriesOutlinePaint();
        boolean boolean20 = xYAreaRenderer18.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = xYAreaRenderer18.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle22.setLegendItemGraphicEdge(rectangleEdge23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = legendTitle22.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder26 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        double double29 = rectangleInsets27.calculateBottomInset((double) 100.0f);
        legendTitle22.setMargin(rectangleInsets27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle22.setHorizontalAlignment(horizontalAlignment31);
        try {
            jFreeChart8.addSubtitle((-1), (org.jfree.chart.title.Title) legendTitle22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(blockBorder26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setBaseStroke(stroke2, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D10.configure();
        numberAxis3D10.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer14);
        xYAreaRenderer5.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot15);
        polarPlot15.setForegroundAlpha(0.0f);
        polarPlot15.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot15.setDataset(xYDataset21);
        polarPlot15.clearCornerTextItems();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("NO_CHANGE");
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setDrawBarOutline(false);
        xYBarRenderer0.setDrawBarOutline(true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        categoryAxis3D3.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D3);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer15.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle17);
        boolean boolean20 = blockContainer0.equals((java.lang.Object) titleEntity19);
        java.lang.Object obj21 = titleEntity19.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        categoryAxis3D1.setMinorTickMarksVisible(false);
        categoryAxis3D1.setLabel("poly");
        double double8 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        try {
            segmentedTimeline3.addException((long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        java.lang.String str46 = xYPlot35.getNoDataMessage();
        boolean boolean47 = xYPlot35.isDomainPannable();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "Pie Plot", (java.lang.Number) 192);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue((java.lang.Comparable) year4);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D11.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, rectangle2D14, (double) (byte) -1);
        java.awt.Paint paint18 = xYStepAreaRenderer1.getSeriesItemLabelPaint(0);
        boolean boolean20 = xYStepAreaRenderer1.isSeriesItemLabelsVisible((int) (short) 0);
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        try {
            timeSeries1.delete((int) (short) 10, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        try {
            timeSeriesCollection49.setSelected((int) '#', 1969, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (35).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str50 = axisLocation49.toString();
        xYPlot35.setRangeAxisLocation(7, axisLocation49, true);
        double double53 = xYPlot35.getDomainCrosshairValue();
        int int54 = xYPlot35.getWeight();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str50.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 7.0d + "'", double53 == 7.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("NO_CHANGE", graphics2D1, 0.0f, (float) 8, textAnchor4, (double) (short) 0, (float) 100L, (float) (-20561));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0L, (java.lang.Object) categoryAxis3D4);
        java.lang.Object obj15 = categoryAxis3D4.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.lang.Comparable comparable15 = legendItemEntity14.getSeriesKey();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(comparable15);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = new org.jfree.chart.plot.CrosshairState();
        int int50 = crosshairState49.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        crosshairState49.setAnchor(point2D53);
        xYPlot35.zoomDomainAxes((double) 12, plotRenderingInfo48, point2D53);
        org.jfree.chart.plot.Marker marker56 = null;
        try {
            boolean boolean57 = xYPlot35.removeRangeMarker(marker56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState();
        int int2 = crosshairState1.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        crosshairState1.setAnchor(point2D5);
        crosshairState1.setDatasetIndex((int) 'a');
        boolean boolean9 = itemLabelAnchor0.equals((java.lang.Object) crosshairState1);
        int int10 = crosshairState1.getDatasetIndex();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        boolean boolean6 = segment4.contains((long) 'a');
        segment4.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = null;
        try {
            boolean boolean9 = segment4.before(segment8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        java.lang.String str2 = numberFormat0.format((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "$3.00" + "'", str2.equals("$3.00"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("poly", graphics2D1, (float) (-1L), (float) 10, 0.2d, (float) (byte) 1, (float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        try {
            gradientBarPainter0.paintBar(graphics2D1, barRenderer2, (int) (short) 0, 1, true, rectangularShape6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        java.lang.String str46 = xYPlot35.getNoDataMessage();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.RenderingSource renderingSource50 = null;
        xYPlot35.select((double) (byte) 0, (double) '4', rectangle2D49, renderingSource50);
        org.jfree.chart.plot.Marker marker52 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer53 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint54 = xYAreaRenderer53.getBasePaint();
        java.awt.Paint paint56 = xYAreaRenderer53.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean58 = xYAreaRenderer53.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D62.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = numberAxis3D62.getTickLabelInsets();
        org.jfree.data.RangeType rangeType65 = numberAxis3D62.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D68 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D68.configure();
        numberAxis3D68.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer72 = null;
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot(xYDataset66, (org.jfree.chart.axis.ValueAxis) numberAxis3D68, polarItemRenderer72);
        java.awt.Paint paint74 = numberAxis3D68.getAxisLinePaint();
        numberAxis3D68.setPositiveArrowVisible(true);
        numberAxis3D68.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str80 = layer79.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        xYAreaRenderer53.drawAnnotations(graphics2D59, rectangle2D60, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, (org.jfree.chart.axis.ValueAxis) numberAxis3D68, layer79, plotRenderingInfo81);
        try {
            xYPlot35.addRangeMarker(marker52, layer79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(rangeType65);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Layer.BACKGROUND" + "'", str80.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) 2019, (float) 100, (double) 0L, (float) (short) 10, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset2.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset2);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot7.setLabelOutlineStroke(stroke8);
        java.awt.Font font10 = piePlot7.getLabelFont();
        java.awt.Paint paint11 = piePlot7.getNoDataMessagePaint();
        piePlot7.setMinimumArcAngleToDraw((double) 1);
        defaultPieDataset2.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        java.lang.Comparable comparable15 = null;
        try {
            java.text.AttributedString attributedString16 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, comparable15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "Pie Plot", (java.lang.Number) 192);
        java.lang.Comparable comparable5 = defaultKeyedValues0.getKey((int) (byte) 0);
        defaultKeyedValues0.clear();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Pie Plot" + "'", comparable5.equals("Pie Plot"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke36);
        xYPlot35.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot35.getDomainAxisLocation();
        xYPlot35.setRangeMinorGridlinesVisible(true);
        java.awt.Paint paint43 = xYPlot35.getDomainGridlinePaint();
        java.awt.Stroke stroke44 = xYPlot35.getRangeMinorGridlineStroke();
        java.awt.Paint paint45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot35.setDomainMinorGridlinePaint(paint45);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DateTickUnitType.DAY");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DateTickUnitType.DAY\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        xYSeries2.add((java.lang.Number) 31, (java.lang.Number) (byte) 100);
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (-2208927599948L), (java.lang.Number) 0.5f);
        xYSeries2.add(xYDataItem8, false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        boolean boolean37 = legendItem35.isLineVisible();
        java.awt.Shape shape38 = legendItem35.getShape();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(9999);
        java.lang.Boolean boolean4 = booleanList0.getBoolean((-20561));
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (-1310400001L), textAnchor4, (double) '#', (float) (byte) 10, (float) '4');
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        labelBlock1.setHeight((double) (-2208927599948L));
        java.lang.Object obj6 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        try {
            defaultPieDataset0.insertValue(192, (java.lang.Comparable) "ThreadContext", (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesOutlineStroke((int) 'a', stroke9, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str5 = dateTickUnit4.toString();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        long long7 = dateRange6.getLowerMillis();
        java.util.Date date8 = dateRange6.getLowerDate();
        java.util.Date date9 = dateTickUnit4.rollDate(date8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str11 = dateTickUnit10.toString();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
        long long13 = dateRange12.getLowerMillis();
        java.util.Date date14 = dateRange12.getLowerDate();
        java.util.Date date15 = dateTickUnit10.rollDate(date14);
        try {
            boolean boolean16 = segmentedTimeline3.containsDomainRange(date8, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str5.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str11.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        long long1 = dateRange0.getLowerMillis();
        java.util.Date date2 = dateRange0.getLowerDate();
        double double3 = dateRange0.getCentralValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        org.jfree.chart.event.ChartChangeListener chartChangeListener15 = null;
        try {
            jFreeChart12.addChangeListener(chartChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (double) (byte) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        int int15 = piePlot14.getBackgroundImageAlignment();
        java.awt.Stroke stroke16 = piePlot14.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = piePlot11.initialise(graphics2D12, rectangle2D13, piePlot14, (java.lang.Integer) 15, plotRenderingInfo18);
        categoryAxis3D3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot14);
        java.awt.Paint paint21 = piePlot14.getBaseSectionPaint();
        boolean boolean22 = size2D2.equals((java.lang.Object) piePlot14);
        java.awt.Stroke stroke23 = piePlot14.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.lang.Object obj39 = xYPlot35.clone();
        xYPlot35.configureRangeAxes();
        java.awt.Paint paint41 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot35.setDomainTickBandPaint(paint41);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.String str2 = rectangleInsets1.toString();
        double double4 = rectangleInsets1.calculateLeftInset((double) 15);
        double double6 = rectangleInsets1.calculateRightInset((double) (short) 10);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean18 = segmentedTimeline16.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment20 = segmentedTimeline16.getSegment((long) (short) 0);
        categoryAxis3D15.addCategoryLabelToolTip((java.lang.Comparable) segment20, "");
        long long23 = segment20.getMillisecond();
        piePlot0.setExplodePercent((java.lang.Comparable) long23, (double) (-1310400001L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(segment20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }
}

