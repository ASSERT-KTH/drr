import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        boolean boolean6 = segment4.contains((long) 'a');
        segment4.moveIndexToEnd();
        long long8 = segment4.getSegmentEnd();
        segment4.dec(100L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 899999L + "'", long8 == 899999L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.lang.Object obj3 = segmentedTimeline0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date6 = segmentedTimeline4.getDate(0L);
        segmentedTimeline0.addException(date6);
        java.lang.Object obj8 = null;
        boolean boolean9 = segmentedTimeline0.equals(obj8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str37 = seriesRenderingOrder36.toString();
        xYPlot35.setSeriesRenderingOrder(seriesRenderingOrder36);
        xYPlot35.configureRangeAxes();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str37.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        piePlot3.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font2, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart9, "NO_CHANGE", "December 1969");
        org.jfree.chart.JFreeChart jFreeChart14 = jFreeChartEntity13.getChart();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(jFreeChart14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year11 = month8.getYear();
        int int12 = month8.getMonth();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month8.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtBottom();
        projectInfo0.setContributors(list2);
        java.util.Collection collection4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list2);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        boolean boolean11 = categoryAxis3D0.isMinorTickMarksVisible();
        categoryAxis3D0.setTickMarksVisible(true);
        org.jfree.chart.block.BlockBorder blockBorder14 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        java.lang.String str16 = rectangleInsets15.toString();
        categoryAxis3D0.setLabelInsets(rectangleInsets15, false);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(blockBorder14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str16.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.String str2 = rectangleInsets1.toString();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries1 = null;
        try {
            xYSeriesCollection0.removeSeries(xYSeries1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("NO_CHANGE");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 10, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        boolean boolean15 = piePlot0.getSimpleLabels();
        piePlot0.setAutoPopulateSectionOutlineStroke(false);
        java.awt.Paint paint18 = piePlot0.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        java.awt.Paint paint61 = xYPlot40.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        int int62 = xYSeriesCollection61.getSeriesCount();
        int int63 = xYPlot40.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        try {
            xYSeriesCollection61.setIntervalPositionFactor((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 0.0f, numberFormat1, (int) (short) 10);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        java.lang.Number number53 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        try {
            timeSeriesCollection49.setSelected((int) '4', 8, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (52).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNull(number53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            org.jfree.data.xy.XYSeries xYSeries2 = xYSeriesCollection0.getSeries((java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        piePlot0.setMaximumLabelWidth((double) 10.0f);
        piePlot0.setLabelGap((double) (short) -1);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot0.getToolTipGenerator();
        java.awt.Stroke stroke10 = piePlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.lang.Object obj3 = segmentedTimeline0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date6 = segmentedTimeline4.getDate(0L);
        segmentedTimeline0.addException(date6);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date10 = segmentedTimeline8.getDate(0L);
        java.lang.Object obj11 = segmentedTimeline8.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date14 = segmentedTimeline12.getDate(0L);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.lang.Class class16 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date19 = segmentedTimeline17.getDate(0L);
        java.lang.Object obj20 = segmentedTimeline17.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date23 = segmentedTimeline21.getDate(0L);
        segmentedTimeline17.addException(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date23, timeZone25);
        boolean boolean27 = segmentedTimeline8.containsDomainRange(date14, date23);
        long long28 = segmentedTimeline0.getTime(date14);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date31 = segmentedTimeline29.getDate(0L);
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean36 = segmentedTimeline34.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment38 = segmentedTimeline34.getSegment((long) (short) 0);
        categoryAxis3D33.addCategoryLabelToolTip((java.lang.Comparable) segment38, "");
        categoryAxis3D33.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity42 = new org.jfree.chart.entity.AxisEntity(shape32, (org.jfree.chart.axis.Axis) categoryAxis3D33);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline43 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date45 = segmentedTimeline43.getDate(0L);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
        java.awt.Paint paint47 = categoryAxis3D33.getTickLabelPaint((java.lang.Comparable) date45);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline48 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date50 = segmentedTimeline48.getDate(0L);
        java.lang.Object obj51 = segmentedTimeline48.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date54 = segmentedTimeline52.getDate(0L);
        segmentedTimeline48.addException(date54);
        boolean boolean56 = segmentedTimeline29.containsDomainRange(date45, date54);
        long long57 = segmentedTimeline0.toTimelineValue(date45);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(segmentedTimeline21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(segmentedTimeline34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(segment38);
        org.junit.Assert.assertNotNull(segmentedTimeline43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(segmentedTimeline48);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(segmentedTimeline52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 644288400000L + "'", long57 == 644288400000L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot0.getSimpleLabelOffset();
        boolean boolean16 = piePlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.util.Collection collection2 = xYAreaRenderer0.getAnnotations();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYAreaRenderer0.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, true);
        java.lang.String str7 = standardXYToolTipGenerator4.getNullYString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null" + "'", str7.equals("null"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (double) (byte) 10);
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Paint paint9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean11 = xYAreaRenderer10.getAutoPopulateSeriesOutlinePaint();
        boolean boolean12 = xYAreaRenderer10.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke13 = xYAreaRenderer10.getBaseStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer15.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer15.setBaseCreateEntities(false, true);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        xYAreaRenderer15.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color24);
        java.awt.Shape shape28 = xYAreaRenderer15.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D32.configure();
        numberAxis3D32.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, polarItemRenderer36);
        java.awt.Paint paint38 = numberAxis3D32.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity41 = new org.jfree.chart.entity.AxisEntity(shape28, (org.jfree.chart.axis.Axis) numberAxis3D32, "1.65", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer42 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint44 = xYAreaRenderer42.getSeriesItemLabelPaint(10);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer42.setSeriesOutlineStroke(0, stroke46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("", "AxisLocation.TOP_OR_RIGHT", "", "AxisEntity: tooltip = ", true, shape5, true, paint7, false, paint9, stroke13, true, shape28, stroke46, (java.awt.Paint) color48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toMillisecond((long) '4');
        segmentedTimeline0.addException(1L, (long) 3);
        try {
            boolean boolean8 = segmentedTimeline0.containsDomainRange((long) 6, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (0) < domainValueStart (6)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927599948L) + "'", long2 == (-2208927599948L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        numberAxis3D2.setAxisLineVisible(false);
        numberAxis3D2.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart12.draw(graphics2D15, rectangle2D16, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 1969L, 0.0d, paint2);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setBaseStroke(stroke2, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYAreaRenderer0.notifyListeners(rendererChangeEvent5);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendGraphic9.setFillPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int13 = color12.getBlue();
        legendGraphic9.setLinePaint((java.awt.Paint) color12);
        xYAreaRenderer0.setBaseLegendTextPaint((java.awt.Paint) color12);
        java.awt.Shape shape16 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (byte) 10, (double) 86400000L, (double) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            gradientBarPainter3.paintBar(graphics2D4, barRenderer5, (int) (byte) 1, (int) (short) 10, false, rectangularShape9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        int int9 = jFreeChart8.getSubtitleCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart8.createBufferedImage(5, (int) (short) 0, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (5) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 31;
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", dateFormat1, (java.text.NumberFormat) logFormat6);
        int int8 = logFormat6.getMaximumIntegerDigits();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 40 + "'", int8 == 40);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.String str2 = rectangleInsets1.toString();
        double double4 = rectangleInsets1.calculateRightInset((double) 10L);
        double double5 = rectangleInsets1.getLeft();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets1.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str37 = seriesRenderingOrder36.toString();
        xYPlot35.setSeriesRenderingOrder(seriesRenderingOrder36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D41.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D41.getTickLabelInsets();
        float float44 = numberAxis3D41.getMinorTickMarkInsideLength();
        xYPlot35.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, false);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = xYPlot35.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str37.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNull(legendItemCollection47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit1.toString();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        long long4 = dateRange3.getLowerMillis();
        java.util.Date date5 = dateRange3.getLowerDate();
        java.util.Date date6 = dateTickUnit1.rollDate(date5);
        dateAxis0.setTickUnit(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str2.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = null;
        piePlot0.setLabelShadowPaint(paint3);
        piePlot0.setMaximumLabelWidth((double) 10.0f);
        java.awt.Paint paint7 = piePlot0.getLabelBackgroundPaint();
        java.lang.String str8 = piePlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        piePlot0.setIgnoreNullValues(true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape7 = xYAreaRenderer1.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot8 = xYAreaRenderer1.getPlot();
        java.lang.Boolean boolean10 = xYAreaRenderer1.getSeriesItemLabelsVisible(2);
        java.awt.Paint paint14 = xYAreaRenderer1.getItemPaint(1, (int) 'a', false);
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("NO_CHANGE", paint14);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(xYPlot8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        boolean boolean9 = jFreeChart8.isNotify();
        int int10 = jFreeChart8.getSubtitleCount();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = xYPlot35.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot35.getAxisOffset();
        boolean boolean38 = xYPlot35.isRangePannable();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        java.lang.Number number53 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent54 = null;
        timeSeriesCollection49.seriesChanged(seriesChangeEvent54);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNull(number53);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "series");
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int1 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, polarItemRenderer4);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint7 = xYAreaRenderer6.getBasePaint();
        java.awt.Paint paint9 = xYAreaRenderer6.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean11 = xYAreaRenderer6.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D15.getTickLabelInsets();
        org.jfree.data.RangeType rangeType18 = numberAxis3D15.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D21.configure();
        numberAxis3D21.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer25);
        java.awt.Paint paint27 = numberAxis3D21.getAxisLinePaint();
        numberAxis3D21.setPositiveArrowVisible(true);
        numberAxis3D21.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str33 = layer32.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYAreaRenderer6.drawAnnotations(graphics2D12, rectangle2D13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, layer32, plotRenderingInfo34);
        boolean boolean36 = numberAxis3D21.isAxisLineVisible();
        polarPlot5.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rangeType18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.BACKGROUND" + "'", str33.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) 500, (double) 1969L);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(range0);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Paint paint12 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYAreaRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition13.getTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape4 = numberAxis3D1.getDownArrow();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        piePlot7.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font6, (org.jfree.chart.plot.Plot) piePlot7, false);
        numberAxis3D1.setTickLabelFont(font6);
        numberAxis3D1.setMinorTickMarkInsideLength(10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot1.setSectionDepth((double) 'a');
        ringPlot1.setOuterSeparatorExtension(0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        boolean boolean7 = legendTitle6.visible;
        boolean boolean8 = periodAxis1.equals((java.lang.Object) boolean7);
        java.awt.Stroke stroke9 = periodAxis1.getMinorTickMarkStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setShadowYOffset((double) 500);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        java.awt.Paint paint11 = numberAxis3D5.getAxisLinePaint();
        numberAxis3D5.setPositiveArrowVisible(true);
        numberAxis3D5.setAxisLineVisible(false);
        java.awt.Font font16 = numberAxis3D5.getLabelFont();
        xYBarRenderer0.setBaseItemLabelFont(font16, false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYAreaRenderer0.drawDomainGridLine(graphics2D12, xYPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, rectangle2D16, (double) (-2208927599948L));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYAreaRenderer0.notifyListeners(rendererChangeEvent19);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = xYAreaRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator21);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int1 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, polarItemRenderer4);
        try {
            double double8 = xYSeriesCollection0.getYValue(100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle2.getLegendItemGraphicPadding();
        java.lang.String str4 = legendTitle2.getID();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        java.awt.Stroke stroke37 = legendItem35.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendGraphic2.setFillPaint((java.awt.Paint) color3);
        legendGraphic2.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int1 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, polarItemRenderer4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = null;
        xYSeriesCollection0.seriesChanged(seriesChangeEvent6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49, false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number52, Double.NaN, 0);
        org.junit.Assert.assertNull(range54);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        boolean boolean6 = segment4.contains((long) 'a');
        segment4.moveIndexToEnd();
        long long8 = segment4.getSegmentEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segment4.copy();
        long long10 = segment4.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 899999L + "'", long8 == 899999L);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2454364L + "'", long10 == 2454364L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        int int62 = xYSeriesCollection61.getSeriesCount();
        int int63 = xYPlot40.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        int int64 = xYSeriesCollection61.getSeriesCount();
        double double66 = xYSeriesCollection61.getRangeUpperBound(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesItemLabelPaint(10);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        java.util.Collection collection13 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        boolean boolean11 = categoryAxis3D0.isMinorTickMarksVisible();
        categoryAxis3D0.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection17 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list18 = axisCollection17.getAxesAtBottom();
        axisState16.setTicks(list18);
        axisState16.setCursor(0.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list24 = categoryAxis3D0.refreshTicks(graphics2D14, axisState16, rectangle2D22, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        xYStepAreaRenderer1.setPlotArea(false);
        boolean boolean7 = xYStepAreaRenderer1.getItemCreateEntity(15, (int) 'a', false);
        boolean boolean8 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYStepAreaRenderer1.getSeriesItemLabelGenerator(192);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        org.jfree.data.xy.XYDataItem xYDataItem6 = new org.jfree.data.xy.XYDataItem((double) 0, (double) 0);
        double double7 = xYDataItem6.getYValue();
        xYSeries2.add(xYDataItem6, true);
        int int10 = xYSeries2.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        boolean boolean49 = xYPlot46.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        double double48 = xYPlot35.getRangeCrosshairValue();
        boolean boolean49 = xYPlot35.isDomainMinorGridlinesVisible();
        boolean boolean50 = xYPlot35.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setShadowYOffset((double) 500);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset3 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset3);
        java.awt.Paint paint5 = ringPlot4.getSeparatorPaint();
        xYBarRenderer0.setBasePaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        boolean boolean15 = piePlot0.getSimpleLabels();
        boolean boolean16 = piePlot0.getSectionOutlinesVisible();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        piePlot0.markerChanged(markerChangeEvent17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLowerMargin(0.2d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        xYStepAreaRenderer1.setPlotArea(false);
        boolean boolean4 = xYStepAreaRenderer1.getBaseCreateEntities();
        xYStepAreaRenderer1.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        xYAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYAreaRenderer0.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj2 = piePlot1.clone();
        java.awt.Font font3 = piePlot1.getNoDataMessageFont();
        boolean boolean4 = verticalAlignment0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (double) (byte) 10);
        size2D2.setWidth((double) (short) 10);
        size2D2.height = (byte) 0;
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        java.awt.Paint paint4 = labelBlock1.getPaint();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean7 = xYSeries6.getAllowDuplicateXValues();
        boolean boolean8 = axisEntity3.equals((java.lang.Object) xYSeries6);
        try {
            xYSeries6.delete(0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = combinedDomainXYPlot0.getRangeAxis(7);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D10.configure();
        numberAxis3D10.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, polarItemRenderer14);
        java.awt.Paint paint16 = numberAxis3D10.getAxisLinePaint();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean21 = segmentedTimeline19.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline19.getSegment((long) (short) 0);
        categoryAxis3D18.addCategoryLabelToolTip((java.lang.Comparable) segment23, "");
        categoryAxis3D18.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape17, (org.jfree.chart.axis.Axis) categoryAxis3D18);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape17, "NO_CHANGE");
        numberAxis3D10.setDownArrow(shape17);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer32.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape38 = xYAreaRenderer32.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot39 = xYAreaRenderer32.getPlot();
        java.lang.Boolean boolean41 = xYAreaRenderer32.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, valueAxis31, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer32);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot42.setRangeZeroBaselineStroke(stroke43);
        xYPlot42.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.Marker marker48 = null;
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean51 = xYPlot42.removeDomainMarker(10, marker48, layer49, true);
        boolean boolean53 = combinedDomainXYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker6, layer49, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(segmentedTimeline19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(segment23);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(xYPlot39);
        org.junit.Assert.assertNull(boolean41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str37 = seriesRenderingOrder36.toString();
        xYPlot35.setSeriesRenderingOrder(seriesRenderingOrder36);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D41.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D41.getTickLabelInsets();
        float float44 = numberAxis3D41.getMinorTickMarkInsideLength();
        xYPlot35.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, false);
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot35.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str37.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1);
        java.awt.Stroke stroke2 = xYStepAreaRenderer1.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        numberAxis3D2.setAxisLineVisible(false);
        double double12 = numberAxis3D2.getFixedAutoRange();
        numberAxis3D2.setNegativeArrowVisible(true);
        boolean boolean15 = numberAxis3D2.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot2.setSectionOutlineStroke((java.lang.Comparable) 1, stroke10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendGraphic5.getFrame();
        legendGraphic2.setFrame(blockFrame6);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(blockFrame6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", graphics2D1, (float) (byte) 10, (float) (-2208927599948L), (double) 0L, (float) (byte) 0, (float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 192, (double) (short) 10, (double) (byte) 10, 2.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Shape shape3 = legendGraphic2.getShape();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape4, "NO_CHANGE");
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        int int18 = piePlot17.getBackgroundImageAlignment();
        java.awt.Stroke stroke19 = piePlot17.getOutlineStroke();
        java.awt.Paint paint20 = null;
        piePlot17.setLabelShadowPaint(paint20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) piePlot17, "AxisEntity: tooltip = null");
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.equal(shape3, shape4);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart12.createBufferedImage((int) (byte) 1, 10);
        jFreeChart12.setBackgroundImageAlignment(1900);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart12.createBufferedImage(4, 0, chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (4) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("DateTickUnitType.DAY", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0L, (java.lang.Object) categoryAxis3D4);
        double double15 = categoryAxis3D4.getLowerMargin();
        int int16 = categoryAxis3D4.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        categoryAxis3D0.setLowerMargin((double) (byte) 0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem48 = legendItemCollection46.get(40);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 40, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        xYPlot35.clearRangeMarkers(100);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D9.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D9.getTickLabelInsets();
        org.jfree.data.RangeType rangeType12 = numberAxis3D9.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.configure();
        numberAxis3D15.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer19);
        java.awt.Paint paint21 = numberAxis3D15.getAxisLinePaint();
        numberAxis3D15.setPositiveArrowVisible(true);
        numberAxis3D15.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str27 = layer26.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYAreaRenderer0.drawAnnotations(graphics2D6, rectangle2D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, layer26, plotRenderingInfo28);
        numberAxis3D9.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.BACKGROUND" + "'", str27.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = polarPlot10.getAxis();
        boolean boolean13 = polarPlot10.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.LegendItem legendItem4 = xYAreaRenderer0.getLegendItem(1900, 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        numberAxis3D3.setPositiveArrowVisible(true);
        numberAxis3D3.setAxisLineVisible(false);
        java.awt.Font font14 = numberAxis3D3.getLabelFont();
        java.awt.Paint paint15 = null;
        org.jfree.chart.axis.AxisCollection axisCollection16 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list17 = axisCollection16.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D19.configure();
        double double21 = numberAxis3D19.getLowerMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection16.add((org.jfree.chart.axis.Axis) numberAxis3D19, rectangleEdge22);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean25 = xYAreaRenderer24.getAutoPopulateSeriesOutlinePaint();
        boolean boolean26 = xYAreaRenderer24.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = xYAreaRenderer24.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle28.setLegendItemGraphicEdge(rectangleEdge29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle28.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder32 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.calculateBottomInset((double) 100.0f);
        legendTitle28.setMargin(rectangleInsets33);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle28.setHorizontalAlignment(horizontalAlignment37);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.BlockBorder blockBorder40 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = blockBorder40.getInsets();
        java.lang.String str42 = rectangleInsets41.toString();
        boolean boolean44 = rectangleInsets41.equals((java.lang.Object) 10.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, paint15, rectangleEdge22, horizontalAlignment37, verticalAlignment39, rectangleInsets41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'paint' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(blockBorder32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(blockBorder40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        legendGraphic2.setOutlineStroke(stroke6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        int int9 = piePlot8.getBackgroundImageAlignment();
        java.awt.Stroke stroke10 = piePlot8.getOutlineStroke();
        java.awt.Paint paint11 = piePlot8.getLabelPaint();
        int int12 = piePlot8.getBackgroundImageAlignment();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot8.setLabelLinkStroke(stroke13);
        java.awt.Paint paint15 = piePlot8.getLabelLinkPaint();
        legendGraphic2.setLinePaint(paint15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean6 = segmentedTimeline4.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline4.getSegment((long) (short) 0);
        categoryAxis3D3.addCategoryLabelToolTip((java.lang.Comparable) segment8, "");
        categoryAxis3D3.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape2, (org.jfree.chart.axis.Axis) categoryAxis3D3);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer15.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle17);
        boolean boolean20 = blockContainer0.equals((java.lang.Object) titleEntity19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint22.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D24 = blockContainer0.arrange(graphics2D21, rectangleConstraint22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(size2D24);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        try {
            double double16 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) 0.025d, (java.lang.Comparable) 90.0d, categoryDataset10, 0.0d, rectangle2D12, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = null;
        xYItemRendererState7.setSelectionState(xYDatasetSelectionState8);
        int int10 = xYItemRendererState7.getFirstItemIndex();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries12.setMaximumItemCount(12);
        java.lang.Comparable comparable15 = timeSeries12.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date18 = segmentedTimeline16.getDate(0L);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        int int20 = month19.getYearValue();
        int int21 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D25.configure();
        numberAxis3D25.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, polarItemRenderer29);
        java.awt.Paint paint31 = numberAxis3D25.getAxisLinePaint();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean36 = segmentedTimeline34.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment38 = segmentedTimeline34.getSegment((long) (short) 0);
        categoryAxis3D33.addCategoryLabelToolTip((java.lang.Comparable) segment38, "");
        categoryAxis3D33.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity42 = new org.jfree.chart.entity.AxisEntity(shape32, (org.jfree.chart.axis.Axis) categoryAxis3D33);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape32, "NO_CHANGE");
        numberAxis3D25.setDownArrow(shape32);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer47 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer47.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape53 = xYAreaRenderer47.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot54 = xYAreaRenderer47.getPlot();
        java.lang.Boolean boolean56 = xYAreaRenderer47.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, valueAxis46, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer47);
        java.awt.Stroke stroke58 = xYPlot57.getDomainGridlineStroke();
        boolean boolean59 = timeSeries12.equals((java.lang.Object) xYPlot57);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        double double62 = timeSeriesCollection60.getDomainLowerBound(false);
        org.jfree.data.DomainOrder domainOrder63 = timeSeriesCollection60.getDomainOrder();
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        xYItemRendererState7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection60);
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (byte) 0 + "'", comparable15.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(segmentedTimeline34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(segment38);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNull(xYPlot54);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder63);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource1 = chartRenderingInfo0.getRenderingSource();
        java.lang.Object obj2 = chartRenderingInfo0.clone();
        org.junit.Assert.assertNull(renderingSource1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        polarPlot10.handleClick(15, 8, plotRenderingInfo20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = polarPlot10.getDataRange(valueAxis22);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year11 = month8.getYear();
        int int12 = year11.getYear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        xYPlot35.setRangeZeroBaselineVisible(true);
        xYPlot35.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke36);
        xYPlot35.clearDomainAxes();
        java.awt.Paint paint39 = xYPlot35.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setBaseStroke(stroke2, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYAreaRenderer0.getSeriesToolTipGenerator((int) (short) 1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint8 = xYAreaRenderer7.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D12.configure();
        numberAxis3D12.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, polarItemRenderer16);
        xYAreaRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot17);
        java.awt.Paint paint19 = xYAreaRenderer7.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYAreaRenderer7.getBaseNegativeItemLabelPosition();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot0.setLabelOutlineStroke(stroke1);
        java.awt.Font font3 = piePlot0.getLabelFont();
        java.awt.Paint paint4 = piePlot0.getNoDataMessagePaint();
        piePlot0.setMinimumArcAngleToDraw((double) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        piePlot0.handleClick((int) (byte) 10, (-20561), plotRenderingInfo9);
        boolean boolean11 = piePlot0.getIgnoreNullValues();
        java.awt.Paint paint13 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) 0.5d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list2 = axisCollection1.getAxesAtBottom();
        projectInfo0.setContributors(list2);
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("1.65");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        double double3 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        ringPlot1.setSeparatorPaint(paint4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendGraphic2.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendGraphic2.getPadding();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset37 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset37.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        legendItem35.setDataset((org.jfree.data.general.Dataset) defaultPieDataset37);
        java.lang.String str42 = legendItem35.getLabel();
        java.awt.Font font43 = legendItem35.getLabelFont();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries45.setMaximumItemCount(12);
        int int48 = timeSeries45.getMaximumItemCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline49 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date51 = segmentedTimeline49.getDate(0L);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        int int53 = month52.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month52, (double) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries45.addOrUpdate(timeSeriesDataItem55);
        legendItem35.setSeriesKey((java.lang.Comparable) timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNull(font43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertNotNull(segmentedTimeline49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1969 + "'", int53 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean7 = xYSeries6.getAllowDuplicateXValues();
        boolean boolean8 = axisEntity3.equals((java.lang.Object) xYSeries6);
        double double9 = xYSeries6.getMinY();
        boolean boolean10 = xYSeries6.getAllowDuplicateXValues();
        boolean boolean11 = xYSeries6.getAutoSort();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        xYStepAreaRenderer1.setPlotArea(false);
        boolean boolean7 = xYStepAreaRenderer1.getItemCreateEntity(15, (int) 'a', false);
        boolean boolean8 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        double double9 = xYStepAreaRenderer1.getRangeBase();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline0.getBaseTimeline();
        long long7 = segmentedTimeline5.getTimeFromLong((long) 1969);
        segmentedTimeline5.addException((long) 8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1969L + "'", long7 == 1969L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.Object obj7 = timeSeries1.clone();
        try {
            timeSeries1.delete(192, 12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color1 = java.awt.Color.getColor("TimePeriodAnchor.END");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Paint paint13 = xYAreaRenderer0.getSeriesFillPaint(10);
        xYAreaRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        int int4 = xYSeries2.indexOf((java.lang.Number) 8);
        try {
            java.lang.Number number6 = xYSeries2.getY(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = null;
        xYItemRendererState7.setSelectionState(xYDatasetSelectionState8);
        int int10 = xYItemRendererState7.getLastItemIndex();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset11 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset11.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset11);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D19.configure();
        numberAxis3D19.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, polarItemRenderer23);
        java.awt.Paint paint25 = numberAxis3D19.getAxisLinePaint();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean30 = segmentedTimeline28.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment32 = segmentedTimeline28.getSegment((long) (short) 0);
        categoryAxis3D27.addCategoryLabelToolTip((java.lang.Comparable) segment32, "");
        categoryAxis3D27.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity36 = new org.jfree.chart.entity.AxisEntity(shape26, (org.jfree.chart.axis.Axis) categoryAxis3D27);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape26, "NO_CHANGE");
        numberAxis3D19.setDownArrow(shape26);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer41 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer41.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape47 = xYAreaRenderer41.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot48 = xYAreaRenderer41.getPlot();
        java.lang.Boolean boolean50 = xYAreaRenderer41.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, valueAxis40, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline53 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date55 = segmentedTimeline53.getDate(0L);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        int int57 = month56.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month56, (double) '#');
        boolean boolean60 = axisLocation52.equals((java.lang.Object) timeSeriesDataItem59);
        xYPlot51.setRangeAxisLocation(axisLocation52);
        xYPlot51.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str66 = axisLocation65.toString();
        xYPlot51.setRangeAxisLocation(7, axisLocation65, true);
        double double69 = xYPlot51.getDomainCrosshairValue();
        boolean boolean70 = defaultPieDataset11.equals((java.lang.Object) xYPlot51);
        java.awt.Stroke stroke71 = xYPlot51.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection72 = new org.jfree.data.xy.XYSeriesCollection();
        int int73 = xYSeriesCollection72.getSeriesCount();
        int int74 = xYPlot51.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection72);
        double double76 = xYSeriesCollection72.getDomainUpperBound(false);
        xYItemRendererState7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection72);
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(segmentedTimeline28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(segment32);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNull(xYPlot48);
        org.junit.Assert.assertNull(boolean50);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(segmentedTimeline53);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1969 + "'", int57 == 1969);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str66.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 7.0d + "'", double69 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        categoryAxis3D0.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D0.setAxisLineVisible(true);
        java.awt.Font font16 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis21.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj24 = periodAxis21.clone();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState27 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection28 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list29 = axisCollection28.getAxesAtBottom();
        axisState27.setTicks(list29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list33 = periodAxis21.refreshTicks(graphics2D25, axisState27, rectangle2D31, rectangleEdge32);
        try {
            double double34 = categoryAxis3D0.getCategoryMiddle((int) (byte) -1, (int) (short) 0, rectangle2D19, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesItemLabelPaint(10);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesOutlineStroke(0, stroke4);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj2 = piePlot1.clone();
        java.awt.Font font3 = piePlot1.getNoDataMessageFont();
        boolean boolean4 = verticalAlignment0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        piePlot1.setIgnoreNullValues(true);
        java.awt.Stroke stroke8 = piePlot1.getLabelLinkStroke();
        double double9 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str2 = timePeriodAnchor1.toString();
        boolean boolean3 = itemLabelPosition0.equals((java.lang.Object) timePeriodAnchor1);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TimePeriodAnchor.END" + "'", str2.equals("TimePeriodAnchor.END"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateBottomInset((double) 100.0f);
        legendTitle4.setMargin(rectangleInsets9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle4.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean17 = verticalAlignment15.equals((java.lang.Object) textAnchor16);
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment15, (double) 97, (double) 2454364L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(blockBorder8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.util.Collection collection2 = xYAreaRenderer0.getAnnotations();
        java.awt.Paint paint3 = xYAreaRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        categoryAxis3D0.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D0.setAxisLineVisible(true);
        java.awt.Font font16 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double21 = categoryAxis3D0.getCategoryEnd(15, 4, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape4 = numberAxis3D1.getDownArrow();
        numberAxis3D1.setFixedDimension((double) 100L);
        numberAxis3D1.centerRange((double) '4');
        java.awt.Paint paint9 = numberAxis3D1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(97, 1969, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int1 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, polarItemRenderer4);
        boolean boolean6 = polarPlot5.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        numberAxis3D2.setPositiveArrowVisible(true);
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font13 = numberAxis3D2.getLabelFont();
        java.awt.Shape shape14 = numberAxis3D2.getUpArrow();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", dateFormat1, (java.text.NumberFormat) logFormat6);
        boolean boolean8 = logFormat6.isParseIntegerOnly();
        logFormat6.setParseIntegerOnly(false);
        logFormat6.setMaximumFractionDigits(6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setDrawBarOutline(true);
        xYBarRenderer0.setBarAlignmentFactor(0.0d);
        double double5 = xYBarRenderer0.getBase();
        boolean boolean6 = xYBarRenderer0.getShadowsVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateTickUnitType2, (int) 'a', dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.lang.String str11 = axisEntity10.getShapeCoords();
        java.lang.Object obj12 = axisEntity10.clone();
        org.jfree.chart.axis.Axis axis13 = axisEntity10.getAxis();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str11.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(axis13);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        java.lang.String str2 = dateRange1.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 4, (org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str2.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = intervalMarker2.getLabelOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.lang.Object obj39 = xYPlot35.clone();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder40 = null;
        try {
            xYPlot35.setDatasetRenderingOrder(datasetRenderingOrder40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(40);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list3 = axisCollection2.getAxesAtBottom();
        axisState1.setTicks(list3);
        axisState1.setCursor(0.0d);
        axisState1.cursorRight((double) (short) 100);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        piePlot0.setShadowYOffset((double) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) categoryAxis3D13, "");
        categoryAxis3D13.setMinorTickMarksVisible(false);
        categoryAxis3D13.setTickMarksVisible(false);
        boolean boolean20 = standardPieSectionLabelGenerator10.equals((java.lang.Object) false);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset21 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset21.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        int int26 = defaultPieDataset21.getIndex((java.lang.Comparable) (-20561));
        java.text.AttributedString attributedString28 = standardPieSectionLabelGenerator10.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset21, (java.lang.Comparable) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(attributedString28);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        int int62 = xYSeriesCollection61.getSeriesCount();
        int int63 = xYPlot40.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        double double65 = xYSeriesCollection61.getDomainUpperBound(false);
        xYSeriesCollection61.setIntervalWidth((double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("MINOR", dateFormat1, dateFormat2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setBaseStroke(stroke2, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYAreaRenderer0.notifyListeners(rendererChangeEvent5);
        boolean boolean7 = xYAreaRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D9.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D9.getTickLabelInsets();
        org.jfree.data.RangeType rangeType12 = numberAxis3D9.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.configure();
        numberAxis3D15.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer19);
        java.awt.Paint paint21 = numberAxis3D15.getAxisLinePaint();
        numberAxis3D15.setPositiveArrowVisible(true);
        numberAxis3D15.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str27 = layer26.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYAreaRenderer0.drawAnnotations(graphics2D6, rectangle2D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, layer26, plotRenderingInfo28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape31 = defaultDrawingSupplier30.getNextShape();
        numberAxis3D9.setRightArrow(shape31);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = numberAxis3D9.getTickUnit();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.BACKGROUND" + "'", str27.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(numberTickUnit33);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        java.lang.String str3 = numberFormat1.format((long) 0);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape0, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint14 = xYAreaRenderer13.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle15.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray20 = legendTitle15.getSources();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            legendTitle15.draw(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(legendItemSourceArray20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        axisEntity3.setArea(shape4);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj7 = standardXYToolTipGenerator6.clone();
        boolean boolean8 = axisEntity3.equals(obj7);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setDomainMinorGridlineStroke(stroke39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getRangeAxis();
        java.awt.Stroke stroke42 = xYPlot35.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setGap((double) (-2208960000000L));
        combinedDomainXYPlot0.setGap((double) 0.5f);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            boolean boolean6 = combinedDomainXYPlot0.removeAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        axisEntity3.setArea(shape4);
        axisEntity3.setToolTipText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color1.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D11.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, rectangle2D14, (double) (byte) -1);
        java.lang.Boolean boolean18 = xYStepAreaRenderer1.getSeriesVisibleInLegend((-668));
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset37 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset37.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        legendItem35.setDataset((org.jfree.data.general.Dataset) defaultPieDataset37);
        java.lang.String str42 = legendItem35.getLabel();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        legendItem35.setShape(shape43);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        xYStepAreaRenderer1.setPlotArea(false);
        boolean boolean7 = xYStepAreaRenderer1.getItemCreateEntity(15, (int) 'a', false);
        boolean boolean8 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        xYStepAreaRenderer1.setSeriesItemLabelsVisible((int) 'a', (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.axis.Axis axis11 = axisEntity10.getAxis();
        java.lang.String str12 = axisEntity10.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(axis11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        java.lang.String str3 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.BACKGROUND" + "'", str1.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.BACKGROUND" + "'", str2.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Layer.BACKGROUND" + "'", str3.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.PiePlotState piePlotState8 = piePlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 15, plotRenderingInfo7);
        boolean boolean9 = piePlot0.getIgnoreNullValues();
        double double10 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) ' ');
        java.util.List list2 = axisState1.getTicks();
        double double3 = axisState1.getMax();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        java.awt.Paint paint11 = numberAxis3D5.getAxisLinePaint();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean16 = segmentedTimeline14.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline14.getSegment((long) (short) 0);
        categoryAxis3D13.addCategoryLabelToolTip((java.lang.Comparable) segment18, "");
        categoryAxis3D13.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) categoryAxis3D13);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape12, "NO_CHANGE");
        numberAxis3D5.setDownArrow(shape12);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer27.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape33 = xYAreaRenderer27.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot34 = xYAreaRenderer27.getPlot();
        java.lang.Boolean boolean36 = xYAreaRenderer27.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, valueAxis26, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline39 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date41 = segmentedTimeline39.getDate(0L);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        int int43 = month42.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (double) '#');
        boolean boolean46 = axisLocation38.equals((java.lang.Object) timeSeriesDataItem45);
        xYPlot37.setRangeAxisLocation(axisLocation38);
        xYPlot37.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str52 = axisLocation51.toString();
        xYPlot37.setRangeAxisLocation(7, axisLocation51, true);
        double double55 = xYPlot37.getDomainCrosshairValue();
        java.awt.Paint paint56 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot37.setRangeMinorGridlinePaint(paint56);
        boolean boolean58 = blockContainer0.equals((java.lang.Object) xYPlot37);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection59 = new org.jfree.data.xy.XYSeriesCollection();
        int int60 = xYSeriesCollection59.getSeriesCount();
        xYPlot37.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection59);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(xYPlot34);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(segmentedTimeline39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1969 + "'", int43 == 1969);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str52.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 7.0d + "'", double55 == 7.0d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("poly");
        java.awt.Font font2 = categoryAxis3D1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean7 = xYSeries6.getAllowDuplicateXValues();
        boolean boolean8 = axisEntity3.equals((java.lang.Object) xYSeries6);
        double double9 = xYSeries6.getMinY();
        boolean boolean10 = xYSeries6.getAllowDuplicateXValues();
        org.jfree.data.xy.XYDataItem xYDataItem13 = xYSeries6.addOrUpdate((double) (byte) 0, (double) (-20561));
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(xYDataItem13);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        boolean boolean46 = xYPlot35.isDomainCrosshairVisible();
        java.awt.Stroke stroke47 = xYPlot35.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        double double10 = numberAxis3D2.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double14 = numberAxis3D2.lengthToJava2D((double) (-1), rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        int int5 = defaultPieDataset0.getIndex((java.lang.Comparable) (-20561));
        int int6 = defaultPieDataset0.getItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = null;
        xYItemRendererState7.setSelectionState(xYDatasetSelectionState8);
        org.jfree.chart.entity.EntityCollection entityCollection10 = xYItemRendererState7.getEntityCollection();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNull(entityCollection10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        boolean boolean3 = legendTitle2.visible;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.clear();
        legendTitle2.setWrapper(blockContainer6);
        boolean boolean9 = blockContainer6.isEmpty();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = rectangleConstraint1.getWidthConstraintType();
        org.jfree.data.Range range3 = rectangleConstraint1.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("December 1969", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = java.awt.Color.lightGray;
        xYAreaRenderer0.setSeriesFillPaint(9999, (java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.getAutoPopulateSeriesOutlinePaint();
        boolean boolean7 = xYAreaRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer5.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle9.getPosition();
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge12);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        int int17 = piePlot16.getBackgroundImageAlignment();
        java.awt.Stroke stroke18 = piePlot16.getOutlineStroke();
        piePlot16.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font15, (org.jfree.chart.plot.Plot) piePlot16, false);
        legendTitle4.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        java.awt.Paint paint24 = jFreeChart22.getBackgroundPaint();
        jFreeChart22.setAntiAlias(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.lang.Object obj5 = logFormat4.clone();
        logFormat4.setMaximumIntegerDigits(0);
        logFormat4.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        boolean boolean46 = xYPlot35.isDomainCrosshairVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent47 = null;
        xYPlot35.notifyListeners(plotChangeEvent47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot35.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot35.setRangeAxisLocation((int) '4', axisLocation52);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer2.setShadowYOffset((double) 500);
        java.awt.geom.RectangularShape rectangularShape8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean10 = xYAreaRenderer9.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = xYAreaRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYAreaRenderer9.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        try {
            gradientXYBarPainter0.paintBar(graphics2D1, xYBarRenderer2, 7, 1969, true, rectangularShape8, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 97, number2);
        java.lang.Number number5 = defaultKeyedValues0.getValue(0);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.configure();
        numberAxis3D4.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer8);
        java.awt.Paint paint10 = numberAxis3D4.getAxisLinePaint();
        ringPlot1.setBaseSectionOutlinePaint(paint10);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj5 = numberAxis3D1.clone();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange6, true, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis3D1.setStandardTickUnits(tickUnitSource10);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.Object obj3 = chartChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.Range range7 = xYAreaRenderer0.findDomainBounds(xYDataset6);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYAreaRenderer0.getSeriesItemLabelGenerator(0);
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = xYAreaRenderer0.hasListener(eventListener10);
        java.awt.Stroke stroke12 = xYAreaRenderer0.getBaseOutlineStroke();
        java.awt.Color color13 = java.awt.Color.pink;
        java.awt.Color color14 = color13.darker();
        xYAreaRenderer0.setBaseItemLabelPaint((java.awt.Paint) color14, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        java.util.Iterator iterator47 = legendItemCollection46.iterator();
        java.util.Iterator iterator48 = legendItemCollection46.iterator();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(iterator47);
        org.junit.Assert.assertNotNull(iterator48);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        java.awt.Paint paint13 = xYAreaRenderer0.getLegendTextPaint(500);
        java.awt.Shape shape14 = xYAreaRenderer0.getLegendArea();
        java.awt.Font font16 = xYAreaRenderer0.lookupLegendTextFont(100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(font16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        double double9 = numberAxis3D2.getUpperMargin();
        numberAxis3D2.setAxisLineVisible(false);
        double double12 = numberAxis3D2.getFixedAutoRange();
        numberAxis3D2.setNegativeArrowVisible(true);
        boolean boolean15 = numberAxis3D2.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        boolean boolean10 = segment5.contained((long) (short) 0, (long) ' ');
        boolean boolean11 = segment5.inExcludeSegments();
        long long12 = segment5.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2454364L + "'", long12 == 2454364L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 15, (float) 31);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list3 = axisCollection2.getAxesAtBottom();
        axisState1.setTicks(list3);
        double double5 = axisState1.getCursor();
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        xYAreaRenderer0.setBaseURLGenerator(xYURLGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer0.getSeriesPositiveItemLabelPosition((-668));
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYAreaRenderer0.getURLGenerator(1900, 7, true);
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        xYAreaRenderer0.setBaseOutlinePaint(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(xYURLGenerator9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        int int8 = xYItemRendererState7.getLastItemIndex();
        boolean boolean9 = xYItemRendererState7.getProcessVisibleItemsOnly();
        int int10 = xYItemRendererState7.getLastItemIndex();
        int int11 = xYItemRendererState7.getLastItemIndex();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) stroke1);
        java.lang.Object obj3 = null;
        boolean boolean4 = gradientPaintTransformType0.equals(obj3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        int int8 = xYItemRendererState7.getLastItemIndex();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState9 = xYItemRendererState7.getCrosshairState();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(xYCrosshairState9);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot35.setRangeZeroBaselineStroke(stroke36);
        xYPlot35.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean44 = xYPlot35.removeDomainMarker(10, marker41, layer42, true);
        xYPlot35.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100.0f, "item", "DateTickMarkPosition.END", true);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        segment5.dec((long) '4');
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = null;
        try {
            boolean boolean11 = segment5.contains(segment10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.getAutoPopulateSeriesOutlinePaint();
        boolean boolean8 = xYAreaRenderer6.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYAreaRenderer6.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle10.setLegendItemGraphicEdge(rectangleEdge11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle10.getPosition();
        legendTitle10.setHeight((double) 100.0f);
        java.awt.Font font16 = legendTitle10.getItemFont();
        legendTitle10.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle10.getBounds();
        org.jfree.chart.util.PaintList paintList20 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean22 = xYAreaRenderer21.getAutoPopulateSeriesOutlinePaint();
        boolean boolean23 = xYAreaRenderer21.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = xYAreaRenderer21.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer21);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean27 = xYAreaRenderer26.getAutoPopulateSeriesOutlinePaint();
        boolean boolean28 = xYAreaRenderer26.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator29 = xYAreaRenderer26.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle30.setLegendItemGraphicEdge(rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle30.getPosition();
        legendTitle25.setLegendItemGraphicEdge(rectangleEdge33);
        boolean boolean35 = paintList20.equals((java.lang.Object) rectangleEdge33);
        try {
            gradientXYBarPainter0.paintBarShadow(graphics2D1, xYBarRenderer2, 2, 1969, true, (java.awt.geom.RectangularShape) rectangle2D19, rectangleEdge33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        boolean boolean3 = legendTitle2.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean5 = xYAreaRenderer4.getAutoPopulateSeriesOutlinePaint();
        boolean boolean6 = xYAreaRenderer4.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = xYAreaRenderer4.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge9);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint15 = xYAreaRenderer14.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer14);
        boolean boolean17 = legendTitle16.visible;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle16.setLegendItemGraphicAnchor(rectangleAnchor18);
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("DateTickUnit[DateTickUnitType.DAY, 1]", "", "DateTickUnitType.DAY", image3, "item", "December 1969", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        projectInfo7.setName("gray");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        numberAxis3D1.zoomRange(0.0d, (double) (short) 100);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) 100.0f, "item", "DateTickMarkPosition.END", true);
        numberAxis3D1.setNumberFormatOverride((java.text.NumberFormat) logFormat11);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range2 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) (short) 100);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot1.setSectionDepth((double) 'a');
        double double4 = ringPlot1.getStartAngle();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        ringPlot1.setLabelPaint(paint5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        int int9 = jFreeChart8.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        boolean boolean2 = logAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.Range range7 = xYAreaRenderer0.findDomainBounds(xYDataset6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        numberAxis3D11.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, polarItemRenderer15);
        java.awt.Paint paint17 = numberAxis3D11.getAxisLinePaint();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean22 = segmentedTimeline20.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segmentedTimeline20.getSegment((long) (short) 0);
        categoryAxis3D19.addCategoryLabelToolTip((java.lang.Comparable) segment24, "");
        categoryAxis3D19.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape18, "NO_CHANGE");
        numberAxis3D11.setDownArrow(shape18);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer33.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape39 = xYAreaRenderer33.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot40 = xYAreaRenderer33.getPlot();
        java.lang.Boolean boolean42 = xYAreaRenderer33.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, valueAxis32, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer33);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot43.setRangeZeroBaselineStroke(stroke44);
        xYPlot43.setRangeCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D50.configure();
        numberAxis3D50.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, polarItemRenderer54);
        numberAxis3D50.setVerticalTickLabels(true);
        xYPlot43.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        int int59 = xYPlot43.getSeriesCount();
        boolean boolean60 = xYAreaRenderer0.equals((java.lang.Object) int59);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(segmentedTimeline20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(segment24);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(xYPlot40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        int int8 = piePlot7.getBackgroundImageAlignment();
        java.awt.Stroke stroke9 = piePlot7.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBasePaint();
        piePlot7.setBaseSectionOutlinePaint(paint11);
        java.lang.String str13 = piePlot7.getPlotType();
        piePlot0.setParent((org.jfree.chart.plot.Plot) piePlot7);
        boolean boolean15 = piePlot0.getSimpleLabels();
        piePlot0.setShadowYOffset((double) (short) 100);
        double double18 = piePlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = new org.jfree.chart.plot.CrosshairState();
        int int50 = crosshairState49.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        crosshairState49.setAnchor(point2D53);
        xYPlot35.zoomDomainAxes((double) 12, plotRenderingInfo48, point2D53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = null;
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor59);
        xYPlot35.panRangeAxes((-1.0d), plotRenderingInfo57, point2D60);
        java.io.ObjectOutputStream objectOutputStream62 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D60, objectOutputStream62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        piePlot0.axisChanged(axisChangeEvent5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        boolean boolean61 = xYPlot40.canSelectByRegion();
        int int62 = xYPlot40.getWeight();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DateTickMarkPosition.END");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone7 = periodAxis4.getTimeZone();
        dateAxis2.setTimeZone(timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("gray", timeZone7);
        java.util.Locale locale10 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone7, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        xYPlot35.setDomainCrosshairValue((double) 7);
        double double48 = xYPlot35.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D53 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D53.configure();
        numberAxis3D53.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, polarItemRenderer57);
        java.awt.Paint paint59 = numberAxis3D53.getAxisLinePaint();
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline62 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean64 = segmentedTimeline62.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment66 = segmentedTimeline62.getSegment((long) (short) 0);
        categoryAxis3D61.addCategoryLabelToolTip((java.lang.Comparable) segment66, "");
        categoryAxis3D61.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape60, (org.jfree.chart.axis.Axis) categoryAxis3D61);
        org.jfree.chart.entity.ChartEntity chartEntity72 = new org.jfree.chart.entity.ChartEntity(shape60, "NO_CHANGE");
        numberAxis3D53.setDownArrow(shape60);
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer75 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer75.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape81 = xYAreaRenderer75.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot82 = xYAreaRenderer75.getPlot();
        java.lang.Boolean boolean84 = xYAreaRenderer75.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot85 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) numberAxis3D53, valueAxis74, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer75);
        org.jfree.chart.axis.AxisLocation axisLocation86 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline87 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date89 = segmentedTimeline87.getDate(0L);
        org.jfree.data.time.Month month90 = new org.jfree.data.time.Month(date89);
        int int91 = month90.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month90, (double) '#');
        boolean boolean94 = axisLocation86.equals((java.lang.Object) timeSeriesDataItem93);
        xYPlot85.setRangeAxisLocation(axisLocation86);
        try {
            xYPlot35.setDomainAxisLocation((-9999), axisLocation86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(segmentedTimeline62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(segment66);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertNull(xYPlot82);
        org.junit.Assert.assertNull(boolean84);
        org.junit.Assert.assertNotNull(axisLocation86);
        org.junit.Assert.assertNotNull(segmentedTimeline87);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1969 + "'", int91 == 1969);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.lang.Object obj7 = logFormat6.clone();
        int int8 = logFormat6.getMaximumFractionDigits();
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        logAxis1.pan((double) 500);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        java.awt.Shape shape4 = numberAxis3D1.getDownArrow();
        numberAxis3D1.setFixedDimension((double) 100L);
        numberAxis3D1.centerRange((double) '4');
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DateTickMarkPosition.END");
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis12.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone15 = periodAxis12.getTimeZone();
        dateAxis10.setTimeZone(timeZone15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone15);
        numberAxis3D1.setStandardTickUnits(tickUnitSource17);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        boolean boolean39 = xYPlot35.canSelectByPoint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer0.getSeriesPositiveItemLabelPosition(15);
        double double6 = itemLabelPosition5.getAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long3 = segmentedTimeline0.toMillisecond((long) ' ');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208927599968L) + "'", long3 == (-2208927599968L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint39 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.text.TextFragment textFragment40 = new org.jfree.chart.text.TextFragment("TimePeriodAnchor.END", font38, paint39);
        legendItem35.setLabelPaint(paint39);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100.0f, "item", "DateTickMarkPosition.END", true);
        logFormat4.setMaximumFractionDigits((int) 'a');
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart12.createBufferedImage((int) (byte) 1, 10);
        jFreeChart12.setBackgroundImageAlignment(1900);
        org.jfree.chart.plot.Plot plot20 = jFreeChart12.getPlot();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(plot20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        boolean boolean61 = xYPlot40.canSelectByRegion();
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot40.setRangeCrosshairStroke(stroke62);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-9999), (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = xYStepAreaRenderer6.initialise(graphics2D7, rectangle2D8, xYPlot9, xYDataset10, plotRenderingInfo11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D16.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis3D16.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepAreaRenderer6.drawDomainGridLine(graphics2D13, xYPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, rectangle2D19, (double) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator22 = new org.jfree.chart.urls.StandardXYURLGenerator();
        boolean boolean23 = numberAxis3D16.equals((java.lang.Object) standardXYURLGenerator22);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer24 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator22);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState33 = xYStepAreaRenderer27.initialise(graphics2D28, rectangle2D29, xYPlot30, xYDataset31, plotRenderingInfo32);
        int int34 = xYItemRendererState33.getLastItemIndex();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean36 = xYAreaRenderer35.getAutoPopulateSeriesOutlinePaint();
        boolean boolean37 = xYAreaRenderer35.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator38 = xYAreaRenderer35.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle39.setLegendItemGraphicEdge(rectangleEdge40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = legendTitle39.getPosition();
        legendTitle39.setHeight((double) 100.0f);
        java.awt.Font font45 = legendTitle39.getItemFont();
        legendTitle39.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle39.getBounds();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        combinedDomainXYPlot49.setRangeAxis(0, valueAxis51);
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D54 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline55 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean57 = segmentedTimeline55.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment59 = segmentedTimeline55.getSegment((long) (short) 0);
        categoryAxis3D54.addCategoryLabelToolTip((java.lang.Comparable) segment59, "");
        categoryAxis3D54.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity63 = new org.jfree.chart.entity.AxisEntity(shape53, (org.jfree.chart.axis.Axis) categoryAxis3D54);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator64 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator65 = null;
        java.lang.String str66 = axisEntity63.getImageMapAreaTag(toolTipTagFragmentGenerator64, uRLTagFragmentGenerator65);
        java.awt.Shape shape67 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity70 = new org.jfree.chart.entity.AxisEntity(shape67, (org.jfree.chart.axis.Axis) categoryAxis3D68, "");
        axisEntity63.setArea(shape67);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D73 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D73.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = numberAxis3D73.getTickLabelInsets();
        java.awt.Shape shape76 = numberAxis3D73.getDownArrow();
        org.jfree.chart.entity.AxisEntity axisEntity77 = new org.jfree.chart.entity.AxisEntity(shape67, (org.jfree.chart.axis.Axis) numberAxis3D73);
        java.text.NumberFormat numberFormat78 = numberAxis3D73.getNumberFormatOverride();
        java.awt.Shape shape79 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color80 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic81 = new org.jfree.chart.title.LegendGraphic(shape79, (java.awt.Paint) color80);
        numberAxis3D73.setUpArrow(shape79);
        org.jfree.chart.axis.PeriodAxis periodAxis84 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis84.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj87 = periodAxis84.clone();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection88 = new org.jfree.data.xy.XYSeriesCollection();
        int int89 = xYSeriesCollection88.getSeriesCount();
        xYSeriesCollection88.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis91 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer92 = null;
        org.jfree.chart.plot.PolarPlot polarPlot93 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection88, valueAxis91, polarItemRenderer92);
        try {
            xYStepRenderer24.drawItem(graphics2D25, xYItemRendererState33, rectangle2D48, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot49, (org.jfree.chart.axis.ValueAxis) numberAxis3D73, (org.jfree.chart.axis.ValueAxis) periodAxis84, (org.jfree.data.xy.XYDataset) xYSeriesCollection88, 5, 9999, true, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(xYItemRendererState12);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(xYItemRendererState33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(segmentedTimeline55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(segment59);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNull(numberFormat78);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(obj87);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        piePlot0.setShadowYOffset((double) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        piePlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity15 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) categoryAxis3D13, "");
        categoryAxis3D13.setMinorTickMarksVisible(false);
        categoryAxis3D13.setTickMarksVisible(false);
        boolean boolean20 = standardPieSectionLabelGenerator10.equals((java.lang.Object) false);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset21 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset21.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean25 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset21);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D29.configure();
        numberAxis3D29.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, polarItemRenderer33);
        java.awt.Paint paint35 = numberAxis3D29.getAxisLinePaint();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline38 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean40 = segmentedTimeline38.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment42 = segmentedTimeline38.getSegment((long) (short) 0);
        categoryAxis3D37.addCategoryLabelToolTip((java.lang.Comparable) segment42, "");
        categoryAxis3D37.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity46 = new org.jfree.chart.entity.AxisEntity(shape36, (org.jfree.chart.axis.Axis) categoryAxis3D37);
        org.jfree.chart.entity.ChartEntity chartEntity48 = new org.jfree.chart.entity.ChartEntity(shape36, "NO_CHANGE");
        numberAxis3D29.setDownArrow(shape36);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer51.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape57 = xYAreaRenderer51.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot58 = xYAreaRenderer51.getPlot();
        java.lang.Boolean boolean60 = xYAreaRenderer51.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, valueAxis50, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer51);
        org.jfree.chart.axis.AxisLocation axisLocation62 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date65 = segmentedTimeline63.getDate(0L);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date65);
        int int67 = month66.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, (double) '#');
        boolean boolean70 = axisLocation62.equals((java.lang.Object) timeSeriesDataItem69);
        xYPlot61.setRangeAxisLocation(axisLocation62);
        xYPlot61.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation75 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str76 = axisLocation75.toString();
        xYPlot61.setRangeAxisLocation(7, axisLocation75, true);
        double double79 = xYPlot61.getDomainCrosshairValue();
        boolean boolean80 = defaultPieDataset21.equals((java.lang.Object) xYPlot61);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline81 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date83 = segmentedTimeline81.getDate(0L);
        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date83);
        int int85 = month84.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month84, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = timeSeriesDataItem87.getPeriod();
        java.text.AttributedString attributedString89 = standardPieSectionLabelGenerator10.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset21, (java.lang.Comparable) regularTimePeriod88);
        java.lang.Number number91 = defaultPieDataset21.getValue(40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(segmentedTimeline38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(segment42);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNull(xYPlot58);
        org.junit.Assert.assertNull(boolean60);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(segmentedTimeline63);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1969 + "'", int67 == 1969);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str76.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 7.0d + "'", double79 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline81);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1969 + "'", int85 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNull(attributedString89);
        org.junit.Assert.assertNull(number91);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.lang.Object obj39 = xYPlot35.clone();
        xYPlot35.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace41);
        java.awt.Paint paint43 = xYPlot35.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 2.0d, (java.lang.Number) 3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        boolean boolean6 = segment4.contains((long) 'a');
        segment4.moveIndexToEnd();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource9 = chartRenderingInfo8.getRenderingSource();
        try {
            int int10 = segment4.compareTo((java.lang.Object) renderingSource9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(renderingSource9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        crosshairState0.updateCrosshairPoint((double) (short) 100, (double) 1.0f, (double) ' ', (-1.0d), plotOrientation5);
        crosshairState0.setCrosshairY((double) 1546329600000L);
        crosshairState0.updateCrosshairY(2.0d);
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.configure();
        numberAxis3D4.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, polarItemRenderer8);
        java.awt.Paint paint10 = numberAxis3D4.getAxisLinePaint();
        numberAxis3D4.setPositiveArrowVisible(true);
        org.jfree.data.Range range13 = numberAxis3D4.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint0.toRangeHeight(range13);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        java.awt.Paint paint3 = xYAreaRenderer0.getBasePaint();
        java.awt.Shape shape4 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis3D11.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, rectangle2D14, (double) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator17 = new org.jfree.chart.urls.StandardXYURLGenerator();
        boolean boolean18 = numberAxis3D11.equals((java.lang.Object) standardXYURLGenerator17);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean20 = xYAreaRenderer19.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer19.setBaseStroke(stroke21, true);
        boolean boolean24 = standardXYURLGenerator17.equals((java.lang.Object) xYAreaRenderer19);
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        java.awt.Paint paint2 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        int int7 = piePlot6.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot6.getOutlineStroke();
        piePlot6.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font5, (org.jfree.chart.plot.Plot) piePlot6, false);
        boolean boolean13 = jFreeChart12.isNotify();
        chartChangeEvent2.setChart(jFreeChart12);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart12.createBufferedImage((int) (byte) 1, 10);
        jFreeChart12.setBackgroundImageAlignment(1900);
        org.jfree.chart.event.ChartProgressListener chartProgressListener20 = null;
        jFreeChart12.removeProgressListener(chartProgressListener20);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=PlotOrientation.HORIZONTAL]"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint2 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline0.getBaseTimeline();
        long long6 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 61200000L + "'", long6 == 61200000L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.getShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        int int4 = piePlot3.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = piePlot3.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.PiePlotState piePlotState8 = piePlot0.initialise(graphics2D1, rectangle2D2, piePlot3, (java.lang.Integer) 15, plotRenderingInfo7);
        piePlot3.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100L, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!", false);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Number number7 = logFormat4.parse("Layer.BACKGROUND", parsePosition6);
        java.lang.String str9 = logFormat4.format((double) 1969L);
        logFormat4.setGroupingUsed(false);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.65" + "'", str9.equals("1.65"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        org.jfree.data.Range range5 = numberAxis3D3.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint1.toRangeWidth(range5);
        boolean boolean8 = range5.contains((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        double double9 = categoryAxis3D1.getUpperMargin();
        java.awt.Font font10 = categoryAxis3D1.getTickLabelFont();
        float float11 = categoryAxis3D1.getMinorTickMarkInsideLength();
        categoryAxis3D1.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D1.setAxisLineVisible(true);
        java.awt.Font font17 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("[size=1]", font17);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint12 = xYAreaRenderer11.getBasePaint();
        boolean boolean13 = axisEntity10.equals((java.lang.Object) paint12);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        java.awt.Stroke stroke36 = xYPlot35.getDomainGridlineStroke();
        xYPlot35.setDomainGridlinesVisible(true);
        java.awt.Image image39 = xYPlot35.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        org.jfree.data.DomainOrder domainOrder52 = timeSeriesCollection49.getDomainOrder();
        try {
            java.lang.Number number55 = timeSeriesCollection49.getX(12, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder52);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        boolean boolean9 = jFreeChart8.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart8.getLegend((-668));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        try {
            jFreeChart8.plotChanged(plotChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(legendTitle11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        xYSeries2.add((java.lang.Number) 31, (java.lang.Number) (byte) 100);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset7 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset7.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        defaultPieDataset7.validateObject();
        java.lang.Number number13 = defaultPieDataset7.getValue((int) (short) 0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str15 = dateTickUnit14.toString();
        int int16 = dateTickUnit14.getMultiple();
        java.lang.Class class17 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date20 = segmentedTimeline18.getDate(0L);
        java.lang.Object obj21 = segmentedTimeline18.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date24 = segmentedTimeline22.getDate(0L);
        segmentedTimeline18.addException(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date24, timeZone26);
        java.lang.String str28 = dateTickUnit14.dateToString(date24);
        org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset7, (java.lang.Comparable) date24, (double) ' ', (-668));
        boolean boolean32 = xYSeries2.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str15.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(segmentedTimeline18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "12/31/69 4:00 PM" + "'", str28.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(pieDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        long long7 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date10 = segmentedTimeline8.getDate(0L);
        java.lang.Object obj11 = segmentedTimeline8.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date14 = segmentedTimeline12.getDate(0L);
        segmentedTimeline8.addException(date14);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline0.getSegment(date14);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(segment16);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 0);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.clear();
        pieLabelDistributor1.clear();
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        boolean boolean61 = xYPlot40.isDomainMinorGridlinesVisible();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer63 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean64 = xYAreaRenderer63.getAutoPopulateSeriesOutlinePaint();
        boolean boolean65 = xYAreaRenderer63.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator66 = xYAreaRenderer63.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer63);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle67.setLegendItemGraphicEdge(rectangleEdge68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = legendTitle67.getPosition();
        legendTitle67.setHeight((double) 100.0f);
        java.awt.Font font73 = legendTitle67.getItemFont();
        legendTitle67.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D76 = legendTitle67.getBounds();
        try {
            xYPlot40.drawBackground(graphics2D62, rectangle2D76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(rectangle2D76);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        org.jfree.data.Range range5 = numberAxis3D3.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint1.toRangeWidth(range5);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.block.BlockBorder blockBorder2 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder2.getInsets();
        java.lang.String str4 = rectangleInsets3.toString();
        double double6 = rectangleInsets3.calculateLeftOutset((double) '#');
        numberAxis3D1.setLabelInsets(rectangleInsets3);
        org.junit.Assert.assertNotNull(blockBorder2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str4.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list3 = axisCollection2.getAxesAtBottom();
        axisState1.setTicks(list3);
        axisState1.cursorDown(0.0d);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = xYAreaRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle4.getPosition();
        org.jfree.chart.block.BlockBorder blockBorder8 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateBottomInset((double) 100.0f);
        legendTitle4.setMargin(rectangleInsets9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle4.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendTitle4.setItemLabelPadding(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(blockBorder8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        java.util.Date date2 = dateRange0.getLowerDate();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 0);
        pieLabelDistributor1.sort();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.distributeLabels((double) 15, (double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        java.util.Collection collection13 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setMaximumItemCount(15);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset17 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset17.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean21 = year16.equals((java.lang.Object) 1L);
        try {
            timeSeries12.update((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesItemLabelsVisible(3, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        double double5 = numberAxis3D3.getLowerMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis3D3, rectangleEdge6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis3D3.getTickUnit();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean3 = segmentedTimeline1.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline1.getSegment((long) (short) 0);
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) segment5, "");
        double double8 = categoryAxis3D0.getUpperMargin();
        java.awt.Font font9 = categoryAxis3D0.getTickLabelFont();
        float float10 = categoryAxis3D0.getMinorTickMarkInsideLength();
        categoryAxis3D0.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D0.setAxisLineVisible(true);
        java.awt.Font font16 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean18 = categoryAxis3D0.equals((java.lang.Object) gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer1.setBaseCreateEntities(false, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        xYAreaRenderer1.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color10);
        java.awt.Shape shape14 = xYAreaRenderer1.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.configure();
        numberAxis3D18.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, polarItemRenderer22);
        java.awt.Paint paint24 = numberAxis3D18.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape14, (org.jfree.chart.axis.Axis) numberAxis3D18, "1.65", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape14, (double) (-2208927599968L), (float) (short) 1, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        segmentedTimeline3.setStartTime((long) 4);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        long long13 = segmentedTimeline6.getExceptionSegmentCount((long) (short) 10, (long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date16 = segmentedTimeline14.getDate(0L);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        long long18 = segmentedTimeline6.toTimelineValue(date16);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date21 = segmentedTimeline19.getDate(0L);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean26 = segmentedTimeline24.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment28 = segmentedTimeline24.getSegment((long) (short) 0);
        categoryAxis3D23.addCategoryLabelToolTip((java.lang.Comparable) segment28, "");
        categoryAxis3D23.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity32 = new org.jfree.chart.entity.AxisEntity(shape22, (org.jfree.chart.axis.Axis) categoryAxis3D23);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date35 = segmentedTimeline33.getDate(0L);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        java.awt.Paint paint37 = categoryAxis3D23.getTickLabelPaint((java.lang.Comparable) date35);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline38 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date40 = segmentedTimeline38.getDate(0L);
        java.lang.Object obj41 = segmentedTimeline38.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        segmentedTimeline38.addException(date44);
        boolean boolean46 = segmentedTimeline19.containsDomainRange(date35, date44);
        try {
            boolean boolean47 = segmentedTimeline3.containsDomainRange(date16, date44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 644288400000L + "'", long18 == 644288400000L);
        org.junit.Assert.assertNotNull(segmentedTimeline19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(segment28);
        org.junit.Assert.assertNotNull(segmentedTimeline33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(segmentedTimeline38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        java.awt.Paint paint5 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        periodAxis1.setMinorTickMarkPaint(paint5);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("null");
        boolean boolean2 = numberAxis3D1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#008080" + "'", str1.equals("#008080"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape36, (double) 9999, (float) 97, 10.0f);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset41 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset41.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity50 = new org.jfree.chart.entity.PieSectionEntity(shape36, (org.jfree.data.general.PieDataset) defaultPieDataset41, 2, (int) ' ', (java.lang.Comparable) 15, "", "item");
        int int51 = pieSectionEntity50.getPieIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        boolean boolean61 = xYPlot40.isDomainMinorGridlinesVisible();
        xYPlot40.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace63 = null;
        xYPlot40.setFixedRangeAxisSpace(axisSpace63);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(8, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer4.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer4.setBaseCreateEntities(false, true);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        xYAreaRenderer4.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape17 = xYAreaRenderer4.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        int int23 = piePlot22.getBackgroundImageAlignment();
        java.awt.Stroke stroke24 = piePlot22.getOutlineStroke();
        piePlot22.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font21, (org.jfree.chart.plot.Plot) piePlot22, false);
        java.awt.Color color30 = java.awt.Color.gray;
        piePlot22.setSectionPaint((java.lang.Comparable) "Pie Plot", (java.awt.Paint) color30);
        java.lang.String str32 = org.jfree.chart.util.PaintUtilities.colorToString(color30);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "$3.00", "Layer.BACKGROUND", "0", shape17, stroke19, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "gray" + "'", str32.equals("gray"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setDrawBarOutline(false);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape4, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint18 = xYAreaRenderer17.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) legendTitle19);
        xYBarRenderer0.setSeriesShape(2, shape4);
        double double23 = xYBarRenderer0.getBarAlignmentFactor();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        org.jfree.chart.block.BlockBorder blockBorder39 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockBorder39.getInsets();
        java.lang.String str41 = rectangleInsets40.toString();
        double double43 = rectangleInsets40.calculateLeftInset((double) 15);
        xYPlot35.setInsets(rectangleInsets40);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(blockBorder39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str41.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setText("AxisEntity: tooltip = ");
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toMillisecond((long) '4');
        segmentedTimeline0.addException(1L, (long) 3);
        long long6 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927599948L) + "'", long2 == (-2208927599948L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 25200000L + "'", long6 == 25200000L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        int int62 = xYSeriesCollection61.getSeriesCount();
        int int63 = xYPlot40.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        try {
            java.lang.Number number66 = xYSeriesCollection61.getY(5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.lang.Object obj3 = segmentedTimeline0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date6 = segmentedTimeline4.getDate(0L);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        java.lang.Class class8 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date11 = segmentedTimeline9.getDate(0L);
        java.lang.Object obj12 = segmentedTimeline9.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date15 = segmentedTimeline13.getDate(0L);
        segmentedTimeline9.addException(date15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date15, timeZone17);
        boolean boolean19 = segmentedTimeline0.containsDomainRange(date6, date15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("DateTickMarkPosition.END");
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis24.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone27 = periodAxis24.getTimeZone();
        dateAxis22.setTimeZone(timeZone27);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("gray", timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date15, timeZone27);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        double double5 = numberAxis3D3.getLowerMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis3D3, rectangleEdge6);
        numberAxis3D3.resizeRange2((double) (short) 0, (double) 10);
        boolean boolean11 = numberAxis3D3.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate(timeSeriesDataItem11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries14.setMaximumItemCount(12);
        java.lang.Comparable comparable17 = timeSeries14.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date20 = segmentedTimeline18.getDate(0L);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        int int22 = month21.getYearValue();
        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.Year year24 = month21.getYear();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year24);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (byte) 0 + "'", comparable17.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        java.awt.Shape shape15 = null;
        xYAreaRenderer0.setSeriesShape(0, shape15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        xYAreaRenderer0.setSeriesPositiveItemLabelPosition(40, itemLabelPosition19);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj4 = periodAxis1.clone();
        java.lang.Class class5 = periodAxis1.getMajorTickTimePeriodClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate(timeSeriesDataItem11);
        timeSeriesDataItem11.setSelected(true);
        java.lang.Object obj15 = timeSeriesDataItem11.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean15 = segmentedTimeline13.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline13.getSegment((long) (short) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) segment17, "");
        double double20 = categoryAxis3D12.getUpperMargin();
        java.awt.Font font21 = categoryAxis3D12.getTickLabelFont();
        float float22 = categoryAxis3D12.getMinorTickMarkInsideLength();
        categoryAxis3D12.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D12.setAxisLineVisible(true);
        java.awt.Font font28 = categoryAxis3D12.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        xYAreaRenderer0.setBaseLegendTextFont(font28);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D9.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D9.getTickLabelInsets();
        org.jfree.data.RangeType rangeType12 = numberAxis3D9.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.configure();
        numberAxis3D15.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer19);
        java.awt.Paint paint21 = numberAxis3D15.getAxisLinePaint();
        numberAxis3D15.setPositiveArrowVisible(true);
        numberAxis3D15.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str27 = layer26.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYAreaRenderer0.drawAnnotations(graphics2D6, rectangle2D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, layer26, plotRenderingInfo28);
        float float30 = numberAxis3D15.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.BACKGROUND" + "'", str27.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        java.lang.String str46 = xYPlot35.getNoDataMessage();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        int int48 = xYPlot35.getIndexOf(xYItemRenderer47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot35.setFixedDomainAxisSpace(axisSpace49, false);
        int int52 = xYPlot35.getRendererCount();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getAutoPopulateSectionOutlinePaint();
        java.awt.Stroke stroke3 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj4 = periodAxis1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection8 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list9 = axisCollection8.getAxesAtBottom();
        axisState7.setTicks(list9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list13 = periodAxis1.refreshTicks(graphics2D5, axisState7, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.setRangeAboutValue(0.0d, (double) (byte) 100);
        java.lang.Object obj19 = numberAxis3D15.clone();
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange();
        numberAxis3D15.setRangeWithMargins((org.jfree.data.Range) dateRange20, true, false);
        double double24 = dateRange20.getLength();
        periodAxis1.setRange((org.jfree.data.Range) dateRange20, false, false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint17 = xYAreaRenderer16.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D21.configure();
        numberAxis3D21.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer25);
        xYAreaRenderer16.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot26);
        polarPlot26.setForegroundAlpha(0.0f);
        polarPlot26.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        polarPlot26.setDataset(xYDataset32);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        polarPlot26.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.axis.TickUnit tickUnit36 = polarPlot26.getAngleTickUnit();
        polarPlot10.setAngleTickUnit(tickUnit36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        polarPlot10.zoomRangeAxes((double) 100L, plotRenderingInfo39, point2D42, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(tickUnit36);
        org.junit.Assert.assertNotNull(point2D42);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj4 = periodAxis1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection8 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list9 = axisCollection8.getAxesAtBottom();
        axisState7.setTicks(list9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list13 = periodAxis1.refreshTicks(graphics2D5, axisState7, rectangle2D11, rectangleEdge12);
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean5 = xYAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDescription("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint9 = xYAreaRenderer8.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer8);
        xYAreaRenderer8.setUseFillPaint(true);
        boolean boolean13 = day7.equals((java.lang.Object) true);
        int int14 = day7.getMonth();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, number15);
        org.jfree.data.time.SerialDate serialDate17 = day7.getSerialDate();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.configure();
        numberAxis3D2.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, polarItemRenderer6);
        java.awt.Paint paint8 = numberAxis3D2.getAxisLinePaint();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean13 = segmentedTimeline11.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segmentedTimeline11.getSegment((long) (short) 0);
        categoryAxis3D10.addCategoryLabelToolTip((java.lang.Comparable) segment15, "");
        categoryAxis3D10.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity19 = new org.jfree.chart.entity.AxisEntity(shape9, (org.jfree.chart.axis.Axis) categoryAxis3D10);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape9, "NO_CHANGE");
        numberAxis3D2.setDownArrow(shape9);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D2.getLabelInsets();
        numberAxis3D2.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(segment15);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        categoryAxis3D1.setMinorTickMarksVisible(false);
        categoryAxis3D1.setTickMarksVisible(false);
        java.awt.Paint paint8 = categoryAxis3D1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        java.awt.Image image7 = null;
        piePlot0.setBackgroundImage(image7);
        piePlot0.setAutoPopulateSectionPaint(false);
        piePlot0.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Shape shape1 = multiplePiePlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        java.lang.String str1 = combinedDomainXYPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        org.jfree.data.DomainOrder domainOrder52 = timeSeriesCollection49.getDomainOrder();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        int[] intArray56 = timeSeriesCollection49.getSurroundingItems(0, (-2208927599948L));
        try {
            timeSeriesCollection49.setSelected((int) (short) -1, 97, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder52);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.lang.Object obj39 = xYPlot35.clone();
        xYPlot35.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace41);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        java.awt.Stroke stroke47 = intervalMarker46.getOutlineStroke();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str49 = layer48.toString();
        xYPlot35.addDomainMarker(8, (org.jfree.chart.plot.Marker) intervalMarker46, layer48, true);
        float float52 = intervalMarker46.getAlpha();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Layer.BACKGROUND" + "'", str49.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.8f + "'", float52 == 0.8f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 0);
        pieLabelDistributor1.sort();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer2);
        boolean boolean5 = legendTitle4.visible;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = legendTitle4.getHorizontalAlignment();
        textTitle0.setHorizontalAlignment(horizontalAlignment6);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date8 = segmentedTimeline6.getDate(0L);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        int int10 = month9.getYearValue();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (double) 100L, true);
        boolean boolean14 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        float float13 = categoryAxis3D4.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis3D4.setTickLabelFont((java.lang.Comparable) false, font15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int19 = color18.getBlue();
        categoryAxis3D4.setTickLabelPaint((java.lang.Comparable) "SeriesRenderingOrder.REVERSE", (java.awt.Paint) color18);
        xYAreaRenderer0.setBasePaint((java.awt.Paint) color18, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 192 + "'", int19 == 192);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-9999), (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        int int9 = piePlot8.getBackgroundImageAlignment();
        java.awt.Stroke stroke10 = piePlot8.getOutlineStroke();
        piePlot8.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font7, (org.jfree.chart.plot.Plot) piePlot8, false);
        int int15 = jFreeChart14.getSubtitleCount();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity18 = new org.jfree.chart.entity.JFreeChartEntity(shape5, jFreeChart14, "NO_CHANGE", "December 1969");
        boolean boolean19 = standardXYURLGenerator3.equals((java.lang.Object) "December 1969");
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DateTickMarkPosition.END");
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis4.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone7 = periodAxis4.getTimeZone();
        dateAxis2.setTimeZone(timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("gray", timeZone7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        dateAxis9.setRange(0.05d, 10.0d);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toUnconstrainedHeight();
        double double3 = rectangleConstraint0.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str1 = dateTickUnit0.toString();
        int int2 = dateTickUnit0.getMultiple();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues3 = new org.jfree.data.DefaultKeyedValues();
        int int4 = dateTickUnit0.compareTo((java.lang.Object) defaultKeyedValues3);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str1.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1);
        xYStepAreaRenderer1.setOutline(false);
        java.awt.Paint paint7 = xYStepAreaRenderer1.getItemPaint((int) (short) -1, (int) (short) 10, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYStepAreaRenderer1.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape0, "NO_CHANGE");
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        int int14 = piePlot13.getBackgroundImageAlignment();
        java.awt.Stroke stroke15 = piePlot13.getOutlineStroke();
        java.awt.Paint paint16 = null;
        piePlot13.setLabelShadowPaint(paint16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) piePlot13, "AxisEntity: tooltip = null");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        xYStepAreaRenderer21.setPlotArea(false);
        boolean boolean27 = xYStepAreaRenderer21.getItemCreateEntity(15, (int) 'a', false);
        boolean boolean28 = xYStepAreaRenderer21.getAutoPopulateSeriesFillPaint();
        boolean boolean29 = xYStepAreaRenderer21.isShapesFilled();
        boolean boolean30 = plotEntity19.equals((java.lang.Object) boolean29);
        java.lang.String str31 = plotEntity19.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PlotEntity: tooltip = AxisEntity: tooltip = null" + "'", str31.equals("PlotEntity: tooltip = AxisEntity: tooltip = null"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.awt.Paint paint2 = logAxis1.getTickLabelPaint();
        float float3 = logAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 100.0f, "item", "DateTickMarkPosition.END", true);
        boolean boolean5 = logFormat4.isGroupingUsed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        polarPlot10.handleClick(15, 8, plotRenderingInfo20);
        double double22 = polarPlot10.getMaxRadius();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.5d + "'", double22 == 3.5d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(100.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.configure();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        boolean boolean7 = legendTitle6.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean9 = xYAreaRenderer8.getAutoPopulateSeriesOutlinePaint();
        boolean boolean10 = xYAreaRenderer8.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = xYAreaRenderer8.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle12.setLegendItemGraphicEdge(rectangleEdge13);
        legendTitle6.setLegendItemGraphicEdge(rectangleEdge13);
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis2, rectangleEdge13);
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = dateAxis2.hasListener(eventListener17);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot35.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = new org.jfree.chart.plot.CrosshairState();
        int int50 = crosshairState49.getDomainAxisIndex();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        crosshairState49.setAnchor(point2D53);
        xYPlot35.zoomDomainAxes((double) 12, plotRenderingInfo48, point2D53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = null;
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor59);
        xYPlot35.panRangeAxes((-1.0d), plotRenderingInfo57, point2D60);
        int int62 = xYPlot35.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 15 + "'", int62 == 15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot1.setSectionDepth((double) 'a');
        ringPlot1.setInnerSeparatorExtension((double) (-668));
        java.awt.Stroke stroke6 = ringPlot1.getSeparatorStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        long long7 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date10 = segmentedTimeline8.getDate(0L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        long long12 = segmentedTimeline0.toTimelineValue(date10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date15 = segmentedTimeline13.getDate(0L);
        java.lang.Object obj16 = segmentedTimeline13.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date19 = segmentedTimeline17.getDate(0L);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        java.lang.Class class21 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date24 = segmentedTimeline22.getDate(0L);
        java.lang.Object obj25 = segmentedTimeline22.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date28 = segmentedTimeline26.getDate(0L);
        segmentedTimeline22.addException(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date28, timeZone30);
        boolean boolean32 = segmentedTimeline13.containsDomainRange(date19, date28);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment33 = segmentedTimeline0.getSegment(date28);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 644288400000L + "'", long12 == 644288400000L);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(segment33);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        java.awt.Paint paint6 = null;
        legendGraphic2.setLinePaint(paint6);
        java.awt.Paint paint8 = legendGraphic2.getOutlinePaint();
        java.lang.Object obj9 = legendGraphic2.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.lang.Object obj3 = segmentedTimeline0.clone();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot0.setLabelOutlineStroke(stroke1);
        java.awt.Stroke stroke3 = piePlot0.getOutlineStroke();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries5.setMaximumItemCount(12);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date11 = segmentedTimeline9.getDate(0L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        int int13 = month12.getYearValue();
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Year year15 = month12.getYear();
        int int16 = month12.getMonth();
        double double17 = piePlot0.getExplodePercent((java.lang.Comparable) month12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 0 + "'", comparable8.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        int int62 = xYSeriesCollection61.getSeriesCount();
        int int63 = xYPlot40.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState64 = xYSeriesCollection61.getSelectionState();
        java.lang.Number number65 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(xYDatasetSelectionState64);
        org.junit.Assert.assertEquals((double) number65, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, xYPlot4, xYDataset5, plotRenderingInfo6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = null;
        xYItemRendererState7.setSelectionState(xYDatasetSelectionState8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = xYItemRendererState7.getInfo();
        org.junit.Assert.assertNotNull(xYItemRendererState7);
        org.junit.Assert.assertNull(plotRenderingInfo10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date3 = segmentedTimeline1.getDate(0L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) '#');
        boolean boolean8 = axisLocation0.equals((java.lang.Object) timeSeriesDataItem7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation9, plotOrientation10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation10);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        int int4 = defaultPieDataset0.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline0.getBaseTimeline();
        int int6 = segmentedTimeline5.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1, "");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D9.configure();
        numberAxis3D9.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, polarItemRenderer13);
        xYAreaRenderer4.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot14);
        polarPlot14.setForegroundAlpha(0.0f);
        polarPlot14.setAngleGridlinesVisible(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int21 = dateTickUnit20.getRollMultiple();
        polarPlot14.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit20);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot14);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date2 = segmentedTimeline0.getDate(0L);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean7 = segmentedTimeline5.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline5.getSegment((long) (short) 0);
        categoryAxis3D4.addCategoryLabelToolTip((java.lang.Comparable) segment9, "");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity13 = new org.jfree.chart.entity.AxisEntity(shape3, (org.jfree.chart.axis.Axis) categoryAxis3D4);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date16 = segmentedTimeline14.getDate(0L);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        java.awt.Paint paint18 = categoryAxis3D4.getTickLabelPaint((java.lang.Comparable) date16);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date21 = segmentedTimeline19.getDate(0L);
        java.lang.Object obj22 = segmentedTimeline19.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date25 = segmentedTimeline23.getDate(0L);
        segmentedTimeline19.addException(date25);
        boolean boolean27 = segmentedTimeline0.containsDomainRange(date16, date25);
        java.lang.Object obj28 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(segmentedTimeline19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("PlotEntity: tooltip = AxisEntity: tooltip = null", "", "Layer.BACKGROUND");
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        double double5 = numberAxis3D3.getLowerMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis3D3, rectangleEdge6);
        java.util.List list8 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickMarkPosition.END");
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis3.setMinorTickMarkOutsideLength((float) (short) 100);
        java.util.TimeZone timeZone6 = periodAxis3.getTimeZone();
        dateAxis1.setTimeZone(timeZone6);
        java.awt.Shape shape8 = dateAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        boolean boolean5 = xYAreaRenderer0.isSeriesVisible(3);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D9.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis3D9.getTickLabelInsets();
        org.jfree.data.RangeType rangeType12 = numberAxis3D9.getRangeType();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.configure();
        numberAxis3D15.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, polarItemRenderer19);
        java.awt.Paint paint21 = numberAxis3D15.getAxisLinePaint();
        numberAxis3D15.setPositiveArrowVisible(true);
        numberAxis3D15.setTickMarkInsideLength((float) 1);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str27 = layer26.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYAreaRenderer0.drawAnnotations(graphics2D6, rectangle2D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, layer26, plotRenderingInfo28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline35 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean37 = segmentedTimeline35.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment39 = segmentedTimeline35.getSegment((long) (short) 0);
        categoryAxis3D34.addCategoryLabelToolTip((java.lang.Comparable) segment39, "");
        double double42 = categoryAxis3D34.getUpperMargin();
        java.awt.Font font43 = categoryAxis3D34.getTickLabelFont();
        float float44 = categoryAxis3D34.getMinorTickMarkInsideLength();
        categoryAxis3D34.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D34.setAxisLineVisible(true);
        java.awt.Font font50 = categoryAxis3D34.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D9, (double) (-1), (double) (-2208960000000L), 0.0d, 0.0d, font50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer53 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean54 = xYAreaRenderer53.getAutoPopulateSeriesOutlinePaint();
        boolean boolean55 = xYAreaRenderer53.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = xYAreaRenderer53.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer53);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle57.setLegendItemGraphicEdge(rectangleEdge58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = legendTitle57.getPosition();
        legendTitle57.setHeight((double) 100.0f);
        java.awt.Font font63 = legendTitle57.getItemFont();
        legendTitle57.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D66 = legendTitle57.getBounds();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer67 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean68 = xYAreaRenderer67.getAutoPopulateSeriesOutlinePaint();
        boolean boolean69 = xYAreaRenderer67.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator70 = xYAreaRenderer67.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer67);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle71.setLegendItemGraphicEdge(rectangleEdge72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = legendTitle71.getPosition();
        legendTitle71.setHeight((double) 100.0f);
        java.awt.Font font77 = legendTitle71.getItemFont();
        legendTitle71.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D80 = legendTitle71.getBounds();
        markerAxisBand51.draw(graphics2D52, rectangle2D66, rectangle2D80, (double) (short) 1, (double) (-668));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rangeType12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.BACKGROUND" + "'", str27.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(segmentedTimeline35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(segment39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator70);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Object obj0 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.getAutoPopulateSeriesOutlinePaint();
        boolean boolean3 = xYAreaRenderer1.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYAreaRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.getAutoPopulateSeriesOutlinePaint();
        boolean boolean8 = xYAreaRenderer6.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYAreaRenderer6.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle10.setLegendItemGraphicEdge(rectangleEdge11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle10.getPosition();
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge13);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        int int18 = piePlot17.getBackgroundImageAlignment();
        java.awt.Stroke stroke19 = piePlot17.getOutlineStroke();
        piePlot17.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font16, (org.jfree.chart.plot.Plot) piePlot17, false);
        legendTitle5.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (byte) 10, (double) 86400000L, (double) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean10 = xYAreaRenderer9.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = xYAreaRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYAreaRenderer9.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle13.getPosition();
        legendTitle13.setHeight((double) 100.0f);
        java.awt.Font font19 = legendTitle13.getItemFont();
        legendTitle13.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle13.getBounds();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean24 = xYAreaRenderer23.getAutoPopulateSeriesOutlinePaint();
        boolean boolean25 = xYAreaRenderer23.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator26 = xYAreaRenderer23.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle27.setLegendItemGraphicEdge(rectangleEdge28);
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, (int) ' ', 2147483647, false, (java.awt.geom.RectangularShape) rectangle2D22, rectangleEdge28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 31);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D39.configure();
        numberAxis3D39.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer43 = null;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, polarItemRenderer43);
        java.awt.Paint paint45 = numberAxis3D39.getAxisLinePaint();
        numberAxis3D39.setPositiveArrowVisible(true);
        numberAxis3D39.setAxisLineVisible(false);
        java.awt.Font font50 = numberAxis3D39.getLabelFont();
        legendItem35.setLabelFont(font50);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.configure();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        boolean boolean7 = legendTitle6.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean9 = xYAreaRenderer8.getAutoPopulateSeriesOutlinePaint();
        boolean boolean10 = xYAreaRenderer8.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = xYAreaRenderer8.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle12.setLegendItemGraphicEdge(rectangleEdge13);
        legendTitle6.setLegendItemGraphicEdge(rectangleEdge13);
        axisCollection0.add((org.jfree.chart.axis.Axis) dateAxis2, rectangleEdge13);
        java.awt.Font font17 = dateAxis2.getLabelFont();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset18 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset18.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        defaultPieDataset18.validateObject();
        java.lang.Number number24 = defaultPieDataset18.getValue((int) (short) 0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str26 = dateTickUnit25.toString();
        int int27 = dateTickUnit25.getMultiple();
        java.lang.Class class28 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date31 = segmentedTimeline29.getDate(0L);
        java.lang.Object obj32 = segmentedTimeline29.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date35 = segmentedTimeline33.getDate(0L);
        segmentedTimeline29.addException(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date35, timeZone37);
        java.lang.String str39 = dateTickUnit25.dateToString(date35);
        org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset18, (java.lang.Comparable) date35, (double) ' ', (-668));
        dateAxis2.setMaximumDate(date35);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1L + "'", number24.equals(1L));
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str26.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(segmentedTimeline33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "12/31/69 4:00 PM" + "'", str39.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(pieDataset42);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setDrawBarOutline(true);
        xYBarRenderer0.setBarAlignmentFactor(0.0d);
        double double5 = xYBarRenderer0.getBase();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean11 = segmentedTimeline9.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline9.getSegment((long) (short) 0);
        categoryAxis3D8.addCategoryLabelToolTip((java.lang.Comparable) segment13, "");
        double double16 = categoryAxis3D8.getUpperMargin();
        java.awt.Font font17 = categoryAxis3D8.getTickLabelFont();
        float float18 = categoryAxis3D8.getMinorTickMarkInsideLength();
        categoryAxis3D8.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D8.setAxisLineVisible(true);
        java.awt.Font font24 = categoryAxis3D8.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("item", font24);
        try {
            xYBarRenderer0.setSeriesItemLabelFont(2147483647, font24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D8 = labelBlock1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis3D1);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = axisEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape14, (org.jfree.chart.axis.Axis) categoryAxis3D15, "");
        axisEntity10.setArea(shape14);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.entity.XYItemEntity xYItemEntity24 = new org.jfree.chart.entity.XYItemEntity(shape14, xYDataset19, 15, (-9999), "hi!", "AxisEntity: tooltip = null");
        java.lang.Object obj25 = null;
        boolean boolean26 = xYItemEntity24.equals(obj25);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        boolean boolean46 = xYPlot35.isDomainCrosshairVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent47 = null;
        xYPlot35.notifyListeners(plotChangeEvent47);
        org.jfree.data.xy.XYDataset xYDataset50 = xYPlot35.getDataset((int) (byte) 1);
        xYPlot35.setRangeZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot35.getRangeAxisEdge((int) (short) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        xYPlot35.datasetChanged(datasetChangeEvent55);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(xYDataset50);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        int int1 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke2 = piePlot0.getOutlineStroke();
        java.awt.Paint paint3 = piePlot0.getLabelPaint();
        int int4 = piePlot0.getBackgroundImageAlignment();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot0.setLabelLinkStroke(stroke5);
        java.awt.Image image7 = null;
        piePlot0.setBackgroundImage(image7);
        piePlot0.setCircular(false, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        java.lang.Object obj4 = periodAxis1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) ' ');
        org.jfree.chart.axis.AxisCollection axisCollection8 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list9 = axisCollection8.getAxesAtBottom();
        axisState7.setTicks(list9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list13 = periodAxis1.refreshTicks(graphics2D5, axisState7, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray14 = null;
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray14);
        java.lang.Class class16 = periodAxis1.getAutoRangeTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries18.setMaximumItemCount(12);
        java.lang.Comparable comparable21 = timeSeries18.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date24 = segmentedTimeline22.getDate(0L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        int int26 = month25.getYearValue();
        int int27 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Year year28 = month25.getYear();
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) month25);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (byte) 0 + "'", comparable21.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(year28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setUpperBound((double) 899999L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D8.configure();
        numberAxis3D8.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, polarItemRenderer12);
        java.awt.Paint paint14 = numberAxis3D8.getAxisLinePaint();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean19 = segmentedTimeline17.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline17.getSegment((long) (short) 0);
        categoryAxis3D16.addCategoryLabelToolTip((java.lang.Comparable) segment21, "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) categoryAxis3D16);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape15, "NO_CHANGE");
        numberAxis3D8.setDownArrow(shape15);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape36 = xYAreaRenderer30.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot37 = xYAreaRenderer30.getPlot();
        java.lang.Boolean boolean39 = xYAreaRenderer30.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D8, valueAxis29, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date44 = segmentedTimeline42.getDate(0L);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        int int46 = month45.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) '#');
        boolean boolean49 = axisLocation41.equals((java.lang.Object) timeSeriesDataItem48);
        xYPlot40.setRangeAxisLocation(axisLocation41);
        xYPlot40.setDomainCrosshairValue((double) 7);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str55 = axisLocation54.toString();
        xYPlot40.setRangeAxisLocation(7, axisLocation54, true);
        double double58 = xYPlot40.getDomainCrosshairValue();
        boolean boolean59 = defaultPieDataset0.equals((java.lang.Object) xYPlot40);
        java.awt.Stroke stroke60 = xYPlot40.getDomainGridlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        xYPlot40.markerChanged(markerChangeEvent61);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(segment21);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(xYPlot37);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1969 + "'", int46 == 1969);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str55.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 7.0d + "'", double58 == 7.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.lang.String str2 = rectangleInsets1.toString();
        double double4 = rectangleInsets1.calculateLeftOutset((double) '#');
        double double6 = rectangleInsets1.extendWidth((double) 2);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.getAutoPopulateSeriesOutlinePaint();
        boolean boolean9 = xYAreaRenderer7.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = xYAreaRenderer7.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle11.getPosition();
        legendTitle11.setHeight((double) 100.0f);
        java.awt.Font font17 = legendTitle11.getItemFont();
        legendTitle11.setID("Layer.BACKGROUND");
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle11.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets1.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType21, lengthAdjustmentType23);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NO_CHANGE" + "'", str22.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        org.jfree.data.DomainOrder domainOrder52 = timeSeriesCollection49.getDomainOrder();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        timeSeriesCollection49.validateObject();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder52);
        org.junit.Assert.assertNull(range53);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        org.jfree.data.Range range5 = numberAxis3D3.getDefaultAutoRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range5, (double) 3);
        double double8 = range7.getCentralValue();
        dateAxis1.setRange(range7);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.5d + "'", double8 == 3.5d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        polarPlot10.handleClick(15, 8, plotRenderingInfo20);
        polarPlot10.setAngleLabelsVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis24 = polarPlot10.getAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(valueAxis24);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setDrawBarOutline(false);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape4, "NO_CHANGE");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint18 = xYAreaRenderer17.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape4, (org.jfree.chart.title.Title) legendTitle19);
        xYBarRenderer0.setSeriesShape(2, shape4);
        boolean boolean25 = xYBarRenderer0.getItemVisible(9999, 9);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer3);
        xYAreaRenderer3.setUseFillPaint(true);
        xYAreaRenderer3.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        boolean boolean12 = plotOrientation0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date39 = segmentedTimeline37.getDate(0L);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        int int41 = month40.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) '#');
        boolean boolean44 = axisLocation36.equals((java.lang.Object) timeSeriesDataItem43);
        xYPlot35.setRangeAxisLocation(axisLocation36);
        boolean boolean46 = xYPlot35.isDomainCrosshairVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent47 = null;
        xYPlot35.notifyListeners(plotChangeEvent47);
        org.jfree.data.xy.XYDataset xYDataset50 = xYPlot35.getDataset((int) (byte) 1);
        xYPlot35.setRangeZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot35.getRangeAxisEdge((int) (short) 1);
        int int55 = xYPlot35.getRendererCount();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(segmentedTimeline37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(xYDataset50);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) (byte) -1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        java.lang.String str3 = textTitle0.getToolTipText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D7.configure();
        numberAxis3D7.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, polarItemRenderer11);
        xYAreaRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot12);
        java.awt.Paint paint15 = xYAreaRenderer2.getLegendTextPaint(500);
        boolean boolean16 = seriesRenderingOrder0.equals((java.lang.Object) xYAreaRenderer2);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYAreaRenderer2.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean3 = xYSeries2.getAllowDuplicateXValues();
        java.lang.String str4 = xYSeries2.getDescription();
        double[][] doubleArray5 = xYSeries2.toArray();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator21 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator22 = null;
        java.lang.String str23 = axisEntity20.getImageMapAreaTag(toolTipTagFragmentGenerator21, uRLTagFragmentGenerator22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity27 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis3D25, "");
        axisEntity20.setArea(shape24);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer29.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer29.setBaseCreateEntities(false, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color38);
        xYAreaRenderer29.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color38);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape24, (java.awt.Paint) color38);
        java.awt.Shape shape42 = legendItem41.getShape();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape42, (double) 9999, (float) 97, 10.0f);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset47 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset47.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity56 = new org.jfree.chart.entity.PieSectionEntity(shape42, (org.jfree.data.general.PieDataset) defaultPieDataset47, 2, (int) ' ', (java.lang.Comparable) 15, "", "item");
        org.jfree.data.xy.XYSeries xYSeries59 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        boolean boolean60 = xYSeries59.getAllowDuplicateXValues();
        org.jfree.data.xy.XYDataItem xYDataItem63 = new org.jfree.data.xy.XYDataItem((double) 0, (double) 0);
        double double64 = xYDataItem63.getYValue();
        xYSeries59.add(xYDataItem63, true);
        org.jfree.data.general.PieDataset pieDataset68 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset47, (java.lang.Comparable) xYDataItem63, 0.0d);
        xYSeries2.add(xYDataItem63);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(pieDataset68);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.RenderingHints renderingHints11 = jFreeChart8.getRenderingHints();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(renderingHints11);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.configure();
        numberAxis3D14.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, polarItemRenderer18);
        java.awt.Paint paint20 = numberAxis3D14.getAxisLinePaint();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean25 = segmentedTimeline23.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment27 = segmentedTimeline23.getSegment((long) (short) 0);
        categoryAxis3D22.addCategoryLabelToolTip((java.lang.Comparable) segment27, "");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape21, (org.jfree.chart.axis.Axis) categoryAxis3D22);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape21, "NO_CHANGE");
        numberAxis3D14.setDownArrow(shape21);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer36.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape42 = xYAreaRenderer36.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot43 = xYAreaRenderer36.getPlot();
        java.lang.Boolean boolean45 = xYAreaRenderer36.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis35, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer36);
        java.awt.Stroke stroke47 = xYPlot46.getDomainGridlineStroke();
        boolean boolean48 = timeSeries1.equals((java.lang.Object) xYPlot46);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double51 = timeSeriesCollection49.getDomainLowerBound(false);
        org.jfree.data.DomainOrder domainOrder52 = timeSeriesCollection49.getDomainOrder();
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        int[] intArray56 = timeSeriesCollection49.getSurroundingItems(0, (-2208927599948L));
        org.jfree.data.Range range58 = timeSeriesCollection49.getDomainBounds(false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(segmentedTimeline23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(segment27);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(domainOrder52);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNull(range58);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 12, 0, (int) (byte) 0);
        try {
            segmentedTimeline3.addException((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendGraphic2.getOutlinePaint();
        legendGraphic2.setWidth((double) (short) 0);
        double double6 = legendGraphic2.getHeight();
        boolean boolean7 = legendGraphic2.isShapeOutlineVisible();
        boolean boolean8 = legendGraphic2.isShapeOutlineVisible();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer9.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer9);
        boolean boolean12 = legendTitle11.visible;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean14 = xYAreaRenderer13.getAutoPopulateSeriesOutlinePaint();
        boolean boolean15 = xYAreaRenderer13.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = xYAreaRenderer13.getLegendItemToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.RIGHT;
        legendTitle17.setLegendItemGraphicEdge(rectangleEdge18);
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor21);
        legendGraphic2.setShapeAnchor(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean5 = segmentedTimeline3.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) (short) 0);
        categoryAxis3D2.addCategoryLabelToolTip((java.lang.Comparable) segment7, "");
        double double10 = categoryAxis3D2.getUpperMargin();
        java.awt.Font font11 = categoryAxis3D2.getTickLabelFont();
        float float12 = categoryAxis3D2.getMinorTickMarkInsideLength();
        categoryAxis3D2.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis3D2.setAxisLineVisible(true);
        java.awt.Font font18 = categoryAxis3D2.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("item", font18);
        textBlock0.addLine(textLine19);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("SeriesRenderingOrder.REVERSE");
        java.awt.Font font23 = textFragment22.getFont();
        textLine19.removeFragment(textFragment22);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean4 = segmentedTimeline2.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline2.getSegment((long) (short) 0);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) segment6, "");
        double double9 = categoryAxis3D1.getUpperMargin();
        java.awt.Font font10 = categoryAxis3D1.getTickLabelFont();
        float float11 = categoryAxis3D1.getMinorTickMarkInsideLength();
        java.awt.Paint paint12 = categoryAxis3D1.getTickMarkPaint();
        boolean boolean13 = booleanList0.equals((java.lang.Object) categoryAxis3D1);
        java.lang.Object obj14 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Shape shape13 = xYAreaRenderer0.lookupSeriesShape(15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.lang.Object obj15 = null;
        boolean boolean16 = legendItemEntity14.equals(obj15);
        java.lang.Comparable comparable17 = legendItemEntity14.getSeriesKey();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(comparable17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        legendGraphic2.setShapeOutlineVisible(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint13 = xYAreaRenderer12.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer12);
        xYAreaRenderer12.setUseFillPaint(true);
        boolean boolean17 = day11.equals((java.lang.Object) true);
        int int18 = day11.getMonth();
        int int19 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        timeSeries1.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-9999), (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1969);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYStepAreaRenderer8.initialise(graphics2D9, rectangle2D10, xYPlot11, xYDataset12, plotRenderingInfo13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = numberAxis3D18.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        xYStepAreaRenderer8.drawDomainGridLine(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, rectangle2D21, (double) (byte) -1);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator24 = new org.jfree.chart.urls.StandardXYURLGenerator();
        boolean boolean25 = numberAxis3D18.equals((java.lang.Object) standardXYURLGenerator24);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) (short) 0);
        long long7 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date10 = segmentedTimeline8.getDate(0L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        long long12 = segmentedTimeline0.toTimelineValue(date10);
        try {
            boolean boolean15 = segmentedTimeline0.containsDomainRange((long) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (0) < domainValueStart (1)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 644288400000L + "'", long12 == 644288400000L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D3.configure();
        numberAxis3D3.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, polarItemRenderer7);
        java.awt.Paint paint9 = numberAxis3D3.getAxisLinePaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean14 = segmentedTimeline12.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline12.getSegment((long) (short) 0);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) segment16, "");
        categoryAxis3D11.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity20 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D11);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape10, "NO_CHANGE");
        numberAxis3D3.setDownArrow(shape10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer25.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        java.awt.Shape shape31 = xYAreaRenderer25.lookupSeriesShape((int) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot32 = xYAreaRenderer25.getPlot();
        java.lang.Boolean boolean34 = xYAreaRenderer25.getSeriesItemLabelsVisible(2);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot35.getDomainMarkers((int) 'a', layer37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot35.setDomainMinorGridlineStroke(stroke39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot35.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            xYPlot35.handleClick((int) '#', 9999, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment16);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(xYPlot32);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(valueAxis41);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesOutlineStroke((int) 'a', stroke9, false);
        boolean boolean12 = xYAreaRenderer0.getBaseSeriesVisibleInLegend();
        boolean boolean15 = xYAreaRenderer0.getItemVisible(10, 9);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis3D1.getTickLabelInsets();
        float float4 = numberAxis3D1.getMinorTickMarkInsideLength();
        numberAxis3D1.setTickMarkInsideLength((float) 1969);
        try {
            numberAxis3D1.setRangeWithMargins((double) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean8 = segmentedTimeline6.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment((long) (short) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) segment10, "");
        categoryAxis3D5.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity14 = new org.jfree.chart.entity.AxisEntity(shape4, (org.jfree.chart.axis.Axis) categoryAxis3D5);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = axisEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) categoryAxis3D19, "");
        axisEntity14.setArea(shape18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer23.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer23.setBaseCreateEntities(false, true);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color32);
        xYAreaRenderer23.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "ThreadContext", "[size=1]", shape18, (java.awt.Paint) color32);
        java.awt.Shape shape36 = legendItem35.getShape();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape36, (double) 9999, (float) 97, 10.0f);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset41 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset41.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 1L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity50 = new org.jfree.chart.entity.PieSectionEntity(shape36, (org.jfree.data.general.PieDataset) defaultPieDataset41, 2, (int) ' ', (java.lang.Comparable) 15, "", "item");
        org.jfree.data.general.PieDataset pieDataset51 = pieSectionEntity50.getDataset();
        org.jfree.data.general.PieDataset pieDataset52 = pieSectionEntity50.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertNotNull(pieDataset52);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.configure();
        numberAxis3D5.centerRange((double) 3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, polarItemRenderer9);
        xYAreaRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot10);
        polarPlot10.setForegroundAlpha(0.0f);
        polarPlot10.setAngleGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        polarPlot10.setDataset(xYDataset16);
        polarPlot10.clearCornerTextItems();
        java.awt.Paint paint19 = polarPlot10.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        timeSeries1.setMaximumItemCount(12);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate(0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        int int9 = month8.getYearValue();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0);
        java.util.Collection collection13 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setMaximumItemCount(15);
        int int16 = timeSeries12.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        int int3 = piePlot2.getBackgroundImageAlignment();
        java.awt.Stroke stroke4 = piePlot2.getOutlineStroke();
        piePlot2.setIgnoreNullValues(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("AxisLocation.TOP_OR_RIGHT", font1, (org.jfree.chart.plot.Plot) piePlot2, false);
        java.awt.Paint paint9 = piePlot2.getLabelBackgroundPaint();
        boolean boolean10 = piePlot2.getSimpleLabels();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean15 = segmentedTimeline13.containsDomainValue((long) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline13.getSegment((long) (short) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) segment17, "");
        categoryAxis3D12.clearCategoryLabelToolTips();
        org.jfree.chart.entity.AxisEntity axisEntity21 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis3D12);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator22 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator23 = null;
        java.lang.String str24 = axisEntity21.getImageMapAreaTag(toolTipTagFragmentGenerator22, uRLTagFragmentGenerator23);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape25, (org.jfree.chart.axis.Axis) categoryAxis3D26, "");
        axisEntity21.setArea(shape25);
        piePlot2.setLegendItemShape(shape25);
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape25, (double) 15, (float) 1577865599999L, (float) 1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint36 = xYAreaRenderer35.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer35);
        boolean boolean38 = legendTitle37.visible;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle37.setLegendItemGraphicAnchor(rectangleAnchor39);
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        blockContainer41.clear();
        legendTitle37.setWrapper(blockContainer41);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        piePlot44.setLabelOutlineStroke(stroke45);
        java.awt.Font font47 = piePlot44.getLabelFont();
        java.awt.Paint paint48 = piePlot44.getNoDataMessagePaint();
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot();
        int int50 = piePlot49.getBackgroundImageAlignment();
        java.awt.Stroke stroke51 = piePlot49.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = piePlot49.getSimpleLabelOffset();
        piePlot44.setInsets(rectangleInsets52, false);
        legendTitle37.setLegendItemGraphicPadding(rectangleInsets52);
        org.jfree.chart.entity.TitleEntity titleEntity58 = new org.jfree.chart.entity.TitleEntity(shape25, (org.jfree.chart.title.Title) legendTitle37, "Layer.BACKGROUND", "AxisEntity: tooltip = ");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 15 + "'", int50 == 15);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 0, (double) 0);
        double double6 = xYDataItem5.getYValue();
        java.lang.Object obj7 = xYDataItem5.clone();
        boolean boolean8 = xYDataItem5.isSelected();
        xYDataItem5.setY((double) ' ');
        xYSeries2.add(xYDataItem5, false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj2 = piePlot1.clone();
        java.awt.Font font3 = piePlot1.getNoDataMessageFont();
        boolean boolean4 = verticalAlignment0.equals((java.lang.Object) piePlot1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBasePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYAreaRenderer4);
        boolean boolean7 = legendTitle6.visible;
        boolean boolean8 = periodAxis1.equals((java.lang.Object) boolean7);
        java.lang.Class class9 = periodAxis1.getMajorTickTimePeriodClass();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "poly", false);
        xYSeries2.add((java.lang.Number) 1.0f, (java.lang.Number) 644288400000L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        xYAreaRenderer0.setBaseCreateEntities(false, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        xYAreaRenderer0.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color9);
        java.awt.Color color12 = color9.brighter();
        int int13 = color12.getRed();
        java.awt.Color color16 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (int) (byte) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int21 = color20.getBlue();
        float[] floatArray25 = new float[] { 0, 1.0f, 0.0f };
        float[] floatArray26 = color20.getColorComponents(floatArray25);
        float[] floatArray27 = java.awt.Color.RGBtoHSB((-668), 500, 3, floatArray26);
        float[] floatArray28 = color16.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color12.getColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 192 + "'", int21 == 192);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        float float1 = dateAxis0.getTickMarkInsideLength();
        java.lang.Object obj2 = dateAxis0.clone();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}

