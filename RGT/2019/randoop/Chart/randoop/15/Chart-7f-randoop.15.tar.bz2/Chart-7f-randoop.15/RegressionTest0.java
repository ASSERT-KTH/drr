import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues3.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.delete((int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar6 = null;
        try {
            day5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        try {
            java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 2019, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.delete(6, 0);
        timePeriodValues3.setDescription("1-January-2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        java.lang.Object obj8 = timePeriodValue7.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100, "2019", "");
        try {
            timePeriodValues3.delete((int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        try {
            timePeriodValues3.add(timePeriod10, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        java.util.Calendar calendar17 = null;
        try {
            year10.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        boolean boolean7 = year0.equals((java.lang.Object) true);
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = null;
        try {
            timePeriodValues3.add(timePeriodValue10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0d);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            day5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        java.util.Calendar calendar8 = null;
        try {
            year0.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "1-January-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        java.lang.Object obj14 = null;
        try {
            int int15 = simpleTimePeriod12.compareTo(obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day5.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560452399999L, 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = day4.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        boolean boolean5 = year1.equals((java.lang.Object) 1);
        java.util.Date date6 = year1.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(date0, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        long long27 = day4.getFirstMillisecond();
//        int int28 = day4.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.String str2 = year1.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day4.equals(obj31);
//        long long33 = day4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 4);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year14.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        int int14 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!");
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.delete((int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day4.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date11, date28);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date11);
        boolean boolean33 = year0.equals((java.lang.Object) day32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getSerialIndex();
//        java.util.Date date10 = year8.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day12, 0.0d);
//        long long15 = day12.getSerialIndex();
//        boolean boolean17 = day12.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getSerialIndex();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
//        java.util.Date date27 = simpleTimePeriod26.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getSerialIndex();
//        java.util.Date date30 = year28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = timePeriodValues31.createCopy((int) '#', 1);
//        boolean boolean36 = simpleTimePeriod26.equals((java.lang.Object) timePeriodValues31);
//        int int37 = timePeriodValues31.getMinEndIndex();
//        int int38 = day12.compareTo((java.lang.Object) int37);
//        java.lang.Object obj39 = null;
//        boolean boolean40 = day12.equals(obj39);
//        java.lang.Number number41 = null;
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, number41);
//        int int43 = timePeriodValues3.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(timePeriodValues35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        long long19 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1546329600000L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 4);
        try {
            java.lang.Object obj24 = timePeriodValues3.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.lang.String str13 = year7.toString();
        java.lang.String str14 = year7.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long2);
//        java.lang.Object obj4 = seriesChangeEvent3.getSource();
//        java.lang.Object obj5 = seriesChangeEvent3.getSource();
//        java.lang.String str6 = seriesChangeEvent3.toString();
//        java.lang.Object obj7 = seriesChangeEvent3.getSource();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560452399999L + "'", obj4.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 1560452399999L + "'", obj5.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560452399999]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]"));
//        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + 1560452399999L + "'", obj7.equals(1560452399999L));
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            day4.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        java.util.Date date6 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]" + "'", str3.equals("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) 10);
        java.util.Date date9 = year0.getStart();
        java.util.Calendar calendar10 = null;
        try {
            year0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getSerialIndex();
//        java.util.Date date10 = year8.getStart();
//        int int11 = year8.getYear();
//        long long12 = year8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 100);
//        boolean boolean16 = day4.equals((java.lang.Object) 100);
//        java.util.Calendar calendar17 = null;
//        try {
//            day4.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        long long8 = day5.getFirstMillisecond();
        java.lang.String str9 = day5.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day5.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-2019" + "'", str9.equals("1-January-2019"));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getSerialIndex();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getSerialIndex();
//        java.util.Date date11 = year9.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date7, date11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date4, date11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 43629L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date21, date28);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        java.util.Date date38 = year36.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date34, date38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date21, date38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date21);
        boolean boolean43 = timePeriodValue18.equals((java.lang.Object) date21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        int int27 = day4.getMonth();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getSerialIndex();
//        java.util.Date date30 = year28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) day32, 0.0d);
//        int int35 = day4.compareTo((java.lang.Object) 0.0d);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable10 = null;
        try {
            timePeriodValues3.setKey(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100, "2019", "");
        try {
            java.lang.Number number5 = timePeriodValues3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        java.util.Calendar calendar8 = null;
        try {
            day5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        int int14 = timePeriodValues3.getMaxEndIndex();
        int int15 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        java.lang.String str8 = day4.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            day4.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        int int7 = year4.getYear();
        int int8 = year4.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10.0d);
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDomainDescription("Time");
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        long long8 = day5.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str16 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,100.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 1560452399999L);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Object obj5 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1560452399999L + "'", number4.equals(1560452399999L));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        long long13 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "13-June-2019");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year9.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("13-June-2019");
        boolean boolean17 = timePeriodValues3.equals((java.lang.Object) 9);
        try {
            timePeriodValues3.delete((int) (byte) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0d);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        int int17 = year14.getYear();
        long long18 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100);
        int int22 = simpleTimePeriod11.compareTo((java.lang.Object) year14);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        int int26 = year23.getYear();
        long long27 = year23.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year23, "", "13-June-2019");
        int int31 = year14.compareTo((java.lang.Object) "13-June-2019");
        int int32 = year14.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = null;
        try {
            timePeriodValues3.add(timePeriodValue17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10.0d);
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        long long14 = simpleTimePeriod11.getStartMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getSerialIndex();
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        java.util.Date date12 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        java.lang.String str17 = timePeriodValues16.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues16.createCopy((int) '#', 1);
//        boolean boolean21 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues16);
//        boolean boolean23 = simpleTimePeriod11.equals((java.lang.Object) 1.0d);
//        int int24 = day0.compareTo((java.lang.Object) 1.0d);
//        java.lang.Class<?> wildcardClass25 = day0.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("13-June-2019");
        boolean boolean17 = timePeriodValues3.equals((java.lang.Object) 9);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        java.lang.String str22 = timePeriodValues21.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues21.createCopy((int) '#', 1);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date28, date32);
        java.util.Date date35 = simpleTimePeriod34.getStart();
        timePeriodValues21.setKey((java.lang.Comparable) simpleTimePeriod34);
        java.util.Date date37 = simpleTimePeriod34.getEnd();
        long long38 = simpleTimePeriod34.getEndMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (double) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener41);
        try {
            timePeriodValues3.update((int) ' ', (java.lang.Number) (-163));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1-January-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues7.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        java.lang.String str27 = timePeriodValues26.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy((int) '#', 1);
        boolean boolean31 = simpleTimePeriod21.equals((java.lang.Object) timePeriodValues26);
        boolean boolean32 = timePeriodValues26.isEmpty();
        boolean boolean33 = simpleTimePeriod12.equals((java.lang.Object) boolean32);
        java.util.Date date34 = simpleTimePeriod12.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        int int31 = day4.getMonth();
//        long long32 = day4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 1560452399999L);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Number number5 = timePeriodValue3.getValue();
        java.lang.Number number6 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1560452399999L + "'", number4.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1560452399999L + "'", number5.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1560452399999L + "'", number6.equals(1560452399999L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues3.getMinEndIndex();
        int int12 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues7.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.String str15 = timePeriodValues14.getDescription();
        boolean boolean17 = timePeriodValues14.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable18 = timePeriodValues14.getKey();
        timePeriodValues7.setKey(comparable18);
        try {
            org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues7.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(comparable18);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        try {
            timePeriodValues3.update(4, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.delete(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.String str15 = timePeriodValues14.getDescription();
        boolean boolean17 = timePeriodValues14.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year18, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 12);
        int int26 = simpleTimePeriod8.compareTo((java.lang.Object) year18);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year18.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        try {
            timePeriodValues3.delete((int) (short) 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        long long9 = day4.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day4.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        int int31 = day4.getMonth();
//        java.util.Calendar calendar32 = null;
//        try {
//            long long33 = day4.getLastMillisecond(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        try {
            java.lang.Number number13 = timePeriodValues3.getValue(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 1560452399999L);
        java.lang.Object obj4 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        java.lang.Class<?> wildcardClass10 = date8.getClass();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date8, timeZone11);
        java.util.Date date13 = regularTimePeriod12.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod12);
        java.lang.Object obj15 = seriesChangeEvent14.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Date date6 = day0.getStart();
//        long long7 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day4.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day11, 0.0d);
        timePeriodValues10.fireSeriesChanged();
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMinMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        long long21 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.next();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (java.lang.Number) 5);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        int int28 = year25.getYear();
        int int29 = year25.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 10.0d);
        timePeriodValues10.setKey((java.lang.Comparable) 10.0d);
        timePeriodValues10.setRangeDescription("");
        boolean boolean35 = year0.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        long long13 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "13-June-2019");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (short) 1);
        long long19 = year9.getSerialIndex();
        long long20 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        boolean boolean7 = year0.equals((java.lang.Object) true);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        timePeriodValues3.setRangeDescription("");
        java.lang.Number number29 = null;
        try {
            timePeriodValues3.update((int) ' ', number29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100.0f);
        java.lang.Object obj15 = timePeriodValue14.clone();
        java.lang.Number number16 = timePeriodValue14.getValue();
        timePeriodValues3.add(timePeriodValue14);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("Time");
        int int11 = timePeriodValues3.getItemCount();
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
        java.util.Date date27 = simpleTimePeriod26.getStart();
        timePeriodValues13.setKey((java.lang.Comparable) simpleTimePeriod26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long32 = simpleTimePeriod31.getStartMillis();
        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) simpleTimePeriod31);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 3);
        java.util.Date date36 = simpleTimePeriod31.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.getNotify();
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        int int27 = year24.getYear();
        long long28 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue33.getPeriod();
        boolean boolean35 = day23.equals((java.lang.Object) timePeriodValue33);
        org.jfree.data.time.SerialDate serialDate36 = day23.getSerialDate();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day23.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(7, 0);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener13);
        java.lang.String str15 = timePeriodValues10.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNull(str15);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getSerialIndex();
//        java.util.Date date10 = year8.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day12, 0.0d);
//        long long15 = day12.getSerialIndex();
//        boolean boolean17 = day12.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getSerialIndex();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
//        java.util.Date date27 = simpleTimePeriod26.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getSerialIndex();
//        java.util.Date date30 = year28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = timePeriodValues31.createCopy((int) '#', 1);
//        boolean boolean36 = simpleTimePeriod26.equals((java.lang.Object) timePeriodValues31);
//        int int37 = timePeriodValues31.getMinEndIndex();
//        int int38 = day12.compareTo((java.lang.Object) int37);
//        java.lang.Object obj39 = null;
//        boolean boolean40 = day12.equals(obj39);
//        java.lang.Number number41 = null;
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, number41);
//        java.util.Calendar calendar43 = null;
//        try {
//            day12.peg(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(timePeriodValues35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        timePeriodValues3.delete((int) '#', 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getItemCount();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        boolean boolean16 = timePeriodValues13.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year17, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year17.previous();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year17, (double) 100);
        java.lang.String str28 = timePeriodValues7.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        try {
            java.lang.Number number16 = timePeriodValues3.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        long long5 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 2);
        timePeriodValue2.setValue((java.lang.Number) 3);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getSerialIndex();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 4);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year14.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        int int4 = year1.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 100.0f);
        long long7 = year1.getFirstMillisecond();
        int int9 = year1.compareTo((java.lang.Object) 10);
        java.util.Date date10 = year1.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        boolean boolean15 = year11.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
        java.lang.Class<?> wildcardClass23 = date21.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date27);
        java.lang.Class<?> wildcardClass29 = date27.getClass();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date27, timeZone30);
        boolean boolean32 = timePeriodValue18.equals((java.lang.Object) timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date10, timeZone30);
        try {
            org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date0, timeZone30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43629L);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 43629L);
        boolean boolean20 = year0.equals((java.lang.Object) 43629L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        java.lang.Class<?> wildcardClass10 = date8.getClass();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date8, timeZone11);
        java.util.Date date13 = regularTimePeriod12.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        int int17 = year14.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 100.0f);
        long long20 = year14.getFirstMillisecond();
        int int22 = year14.compareTo((java.lang.Object) 10);
        java.util.Date date23 = year14.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        boolean boolean28 = year24.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 0);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date34);
        java.lang.Class<?> wildcardClass36 = date34.getClass();
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getSerialIndex();
        java.util.Date date40 = year38.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date40);
        java.lang.Class<?> wildcardClass42 = date40.getClass();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date40, timeZone43);
        boolean boolean45 = timePeriodValue31.equals((java.lang.Object) timeZone43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date23, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date13, date23);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        java.util.Date date4 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100.0f);
        timePeriodValues3.add(timePeriodValue14);
        timePeriodValues3.setRangeDescription("");
        int int18 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDomainDescription("Time");
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.delete(11, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        java.lang.Object obj6 = timePeriodValue5.clone();
        java.lang.String str7 = timePeriodValue5.toString();
        java.lang.String str8 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str7.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str8.equals("TimePeriodValue[2019,100.0]"));
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 43629L);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year10.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        timePeriodValues3.fireSeriesChanged();
//        int int8 = timePeriodValues3.getMinEndIndex();
//        java.lang.String str9 = timePeriodValues3.getDomainDescription();
//        java.lang.String str10 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.setDescription("");
//        boolean boolean13 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDomainDescription("13-June-2019");
//        boolean boolean17 = timePeriodValues3.equals((java.lang.Object) 9);
//        boolean boolean18 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day23, 0.0d);
//        long long26 = day23.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, (double) 1560495599999L);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        long long31 = year30.getSerialIndex();
//        java.util.Date date32 = year30.getStart();
//        int int33 = year30.getYear();
//        long long34 = year30.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year30.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (double) 100);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (double) 43629L);
//        org.jfree.data.time.TimePeriod timePeriod40 = timePeriodValue39.getPeriod();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getSerialIndex();
//        java.util.Date date43 = year41.getStart();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getSerialIndex();
//        java.util.Date date46 = year44.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        long long49 = year48.getSerialIndex();
//        java.util.Date date50 = year48.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date46, date50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date43, date50);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        long long55 = year54.getSerialIndex();
//        java.util.Date date56 = year54.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        long long59 = year58.getSerialIndex();
//        java.util.Date date60 = year58.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date56, date60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date43, date60);
//        boolean boolean64 = timePeriodValue39.equals((java.lang.Object) date60);
//        timePeriodValues3.add(timePeriodValue39);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timePeriod40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, 0.0d);
//        java.lang.String str7 = timePeriodValue6.toString();
//        java.lang.String str8 = timePeriodValue6.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[14-June-2019,0.0]" + "'", str7.equals("TimePeriodValue[14-June-2019,0.0]"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[14-June-2019,0.0]" + "'", str8.equals("TimePeriodValue[14-June-2019,0.0]"));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 12);
        java.lang.Object obj15 = null;
        int int16 = year7.compareTo(obj15);
        long long17 = year7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        java.util.Calendar calendar11 = null;
//        try {
//            day4.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 6);
//        java.lang.Number number33 = timePeriodValue32.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 6.0d + "'", number33.equals(6.0d));
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        int int27 = day4.getMonth();
//        long long28 = day4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560452399999L + "'", long28 == 1560452399999L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        try {
            timePeriodValues3.update(4, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day4.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxStartIndex();
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("Time");
        int int11 = timePeriodValues3.getItemCount();
        int int12 = timePeriodValues3.getMinEndIndex();
        int int13 = timePeriodValues3.getMaxEndIndex();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        long long9 = day5.getFirstMillisecond();
        int int10 = day5.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day5.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day4.equals(obj31);
//        java.util.Date date33 = day4.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        long long9 = day5.getFirstMillisecond();
        boolean boolean11 = day5.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        java.lang.Object obj13 = timePeriodValues3.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        int int17 = year14.getYear();
        long long18 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 43629L);
        java.lang.String str24 = timePeriodValue23.toString();
        timePeriodValues3.add(timePeriodValue23);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[2019,43629.0]" + "'", str24.equals("TimePeriodValue[2019,43629.0]"));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getSerialIndex();
//        java.util.Date date6 = year4.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
//        java.util.Date date9 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        java.lang.String str14 = timePeriodValues13.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
//        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day23, 0.0d);
//        long long26 = day23.getSerialIndex();
//        boolean boolean28 = day23.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getSerialIndex();
//        java.util.Date date31 = year29.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) day33, 0.0d);
//        timePeriodValues32.setDescription("");
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getSerialIndex();
//        java.util.Date date40 = year38.getStart();
//        int int41 = year38.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 100.0f);
//        timePeriodValues32.add(timePeriodValue43);
//        boolean boolean45 = day23.equals((java.lang.Object) timePeriodValue43);
//        long long46 = day23.getFirstMillisecond();
//        try {
//            int int47 = simpleTimePeriod8.compareTo((java.lang.Object) long46);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(timePeriodValues17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560409200000L + "'", long46 == 1560409200000L);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getSerialIndex();
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getSerialIndex();
//        java.util.Date date19 = year17.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        long long26 = day24.getMiddleMillisecond();
//        long long27 = day24.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day24.next();
//        int int29 = day23.compareTo((java.lang.Object) day24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day23.previous();
//        java.util.Date date31 = regularTimePeriod30.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
//        java.util.Date date35 = simpleTimePeriod34.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date31, date35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560452399999L + "'", long26 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-163) + "'", int29 == (-163));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date35);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Date date6 = day0.getStart();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getSerialIndex();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
//        java.lang.String str9 = timePeriodValues8.getDescription();
//        boolean boolean11 = timePeriodValues8.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getSerialIndex();
//        java.util.Date date14 = year12.getStart();
//        int int15 = year12.getYear();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year12, (double) 1.0f);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues8.removePropertyChangeListener(propertyChangeListener18);
//        int int20 = timePeriodValues8.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues8.removePropertyChangeListener(propertyChangeListener21);
//        boolean boolean23 = timePeriodValues8.isEmpty();
//        int int24 = timePeriodValues8.getMinStartIndex();
//        int int25 = day0.compareTo((java.lang.Object) int24);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(7, 0);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues10.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        int int17 = year14.getYear();
        long long18 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100);
        int int22 = simpleTimePeriod11.compareTo((java.lang.Object) year14);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year14.getMiddleMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 4);
        java.lang.String str24 = year14.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        long long9 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues7.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        java.util.Date date23 = simpleTimePeriod22.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getStart();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 1560452399999L);
        java.lang.Number number4 = timePeriodValue3.getValue();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        java.util.Date date7 = year5.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        boolean boolean10 = timePeriodValue3.equals((java.lang.Object) wildcardClass9);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValue3.equals(obj11);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1560452399999L + "'", number4.equals(1560452399999L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        java.util.Date date7 = year5.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
        java.lang.Class<?> wildcardClass9 = date7.getClass();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) 10);
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        int int11 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date18);
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date2, date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date22);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        long long9 = day4.getFirstMillisecond();
//        int int10 = day4.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getSerialIndex();
//        java.util.Date date31 = year29.getStart();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        java.util.Date date34 = year32.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        long long37 = year36.getSerialIndex();
//        java.util.Date date38 = year36.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date34, date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date31, date38);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getSerialIndex();
//        java.util.Date date44 = year42.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getSerialIndex();
//        java.util.Date date48 = year46.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date44, date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date31, date48);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.String str54 = day53.toString();
//        long long55 = day53.getMiddleMillisecond();
//        long long56 = day53.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day53.next();
//        int int58 = day52.compareTo((java.lang.Object) day53);
//        boolean boolean59 = timePeriodValue28.equals((java.lang.Object) day53);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        long long61 = year60.getSerialIndex();
//        java.util.Date date62 = year60.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        timePeriodValues63.add((org.jfree.data.time.TimePeriod) day64, 0.0d);
//        long long67 = day64.getSerialIndex();
//        long long68 = day64.getSerialIndex();
//        boolean boolean69 = timePeriodValue28.equals((java.lang.Object) long68);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "13-June-2019" + "'", str54.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560452399999L + "'", long55 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560409200000L + "'", long56 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-163) + "'", int58 == (-163));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 43629L + "'", long67 == 43629L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 43629L + "'", long68 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        java.lang.String str28 = timePeriodValues27.getDescription();
        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        java.util.Date date33 = year31.getStart();
        int int34 = year31.getYear();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year31, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 12);
        int int39 = simpleTimePeriod21.compareTo((java.lang.Object) year31);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getSerialIndex();
        java.util.Date date42 = year40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) day44, 0.0d);
        timePeriodValues43.fireSeriesChanged();
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getSerialIndex();
        java.util.Date date52 = year50.getStart();
        java.lang.String str53 = year50.toString();
        java.lang.String str54 = year50.toString();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 4);
        boolean boolean57 = simpleTimePeriod21.equals((java.lang.Object) year50);
        timePeriodValues3.setKey((java.lang.Comparable) year50);
        java.lang.String str59 = year50.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getSerialIndex();
        long long7 = year0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        timePeriodValues3.setRangeDescription("");
        boolean boolean17 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,43629.0]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]"));
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        java.util.Date date4 = year2.getStart();
//        int int5 = year2.getYear();
//        int int6 = year2.getYear();
//        boolean boolean7 = day0.equals((java.lang.Object) year2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year2.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
        java.util.Date date27 = simpleTimePeriod26.getStart();
        timePeriodValues13.setKey((java.lang.Comparable) simpleTimePeriod26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long32 = simpleTimePeriod31.getStartMillis();
        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) simpleTimePeriod31);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 3);
        long long36 = simpleTimePeriod31.getStartMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getSerialIndex();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
//        java.lang.String str9 = timePeriodValues8.getDescription();
//        boolean boolean11 = timePeriodValues8.equals((java.lang.Object) (byte) 10);
//        java.lang.String str12 = timePeriodValues8.getDescription();
//        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
//        int int14 = day0.compareTo((java.lang.Object) timePeriodValues8);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.SerialDate serialDate16 = day0.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        int int16 = year13.getYear();
//        long long17 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
//        int int19 = day11.compareTo((java.lang.Object) regularTimePeriod18);
//        int int20 = day11.getYear();
//        int int21 = day4.compareTo((java.lang.Object) day11);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        long long27 = year26.getSerialIndex();
//        java.util.Date date28 = year26.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
//        java.util.Date date31 = simpleTimePeriod30.getStart();
//        boolean boolean32 = day11.equals((java.lang.Object) simpleTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        timePeriodValues7.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues7.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        java.lang.Class<?> wildcardClass16 = date14.getClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
        java.lang.String str18 = day17.toString();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        timePeriodValues3.setKey((java.lang.Comparable) serialDate19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1-January-2019" + "'", str18.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        boolean boolean20 = simpleTimePeriod8.equals((java.lang.Object) 1.0d);
        long long21 = simpleTimePeriod8.getEndMillis();
        java.util.Date date22 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "org.jfree.data.general.SeriesChangeEvent[source=1560452399999]", "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues25.removeChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        try {
            timePeriodValues3.update(4, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        int int27 = day4.getMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day4.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(serialDate28);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getMinEndIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        java.util.Date date22 = year20.getEnd();
        long long23 = year20.getSerialIndex();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 10.0d);
        long long26 = year20.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        int int8 = day5.getMonth();
        java.util.Date date9 = day5.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 100);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean6 = day0.equals((java.lang.Object) year5);
//        long long7 = year5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100, "2019", "");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getSerialIndex();
//        java.util.Date date8 = year6.getStart();
//        int int9 = year6.getYear();
//        int int10 = year6.getYear();
//        boolean boolean11 = day4.equals((java.lang.Object) year6);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, (double) 13);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day23.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        java.util.Date date7 = year5.getEnd();
        boolean boolean8 = year0.equals((java.lang.Object) year5);
        java.util.Date date9 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 100);
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getItemCount();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        boolean boolean16 = timePeriodValues13.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year17, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year17.previous();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year17, (double) 100);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year17.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        java.util.Date date17 = year15.getStart();
        int int18 = year15.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 100.0f);
        long long21 = year15.getFirstMillisecond();
        int int23 = year15.compareTo((java.lang.Object) 10);
        java.util.Date date24 = year15.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        boolean boolean29 = year25.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 0);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getSerialIndex();
        java.util.Date date35 = year33.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date35);
        java.lang.Class<?> wildcardClass37 = date35.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
        java.lang.Class<?> wildcardClass43 = date41.getClass();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone44);
        boolean boolean46 = timePeriodValue32.equals((java.lang.Object) timeZone44);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date24, timeZone44);
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (java.lang.Number) (short) 10);
        timePeriodValues3.add(timePeriodValue49);
        int int51 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day4.equals(obj31);
//        java.util.Calendar calendar33 = null;
//        try {
//            day4.peg(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getItemCount();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date28, date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date25, date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date19, date25);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getSerialIndex();
        java.util.Date date39 = year37.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getSerialIndex();
        java.util.Date date42 = year40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getSerialIndex();
        java.util.Date date46 = year44.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date46);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date39, date46);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getSerialIndex();
        java.util.Date date52 = year50.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        java.util.Date date56 = year54.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date56);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date52, date56);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date39, date56);
        java.util.Date date60 = simpleTimePeriod59.getEnd();
        java.util.Date date61 = simpleTimePeriod59.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date19, date61);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        java.lang.Object obj5 = null;
        int int6 = year0.compareTo(obj5);
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue21 = timePeriodValues13.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
        int int24 = day23.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMinEndIndex();
        boolean boolean11 = timePeriodValues3.isEmpty();
        try {
            java.lang.Number number13 = timePeriodValues3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        long long27 = day4.getFirstMillisecond();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day4.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        timePeriodValue7.setValue((java.lang.Number) 0);
        timePeriodValue7.setValue((java.lang.Number) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,43629.0]");
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        java.lang.String str10 = timePeriodValues9.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues9.createCopy((int) '#', 1);
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues9.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        java.util.Date date13 = year11.getStart();
//        int int14 = year11.getYear();
//        long long15 = year11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.next();
//        int int17 = day9.compareTo((java.lang.Object) regularTimePeriod16);
//        int int18 = day9.getYear();
//        int int19 = day4.compareTo((java.lang.Object) day9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        long long9 = day4.getSerialIndex();
//        java.util.Date date10 = day4.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        java.lang.Class<?> wildcardClass4 = date2.getClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
//        java.lang.String str6 = day5.toString();
//        int int7 = day5.getMonth();
//        int int8 = day5.getDayOfMonth();
//        long long9 = day5.getFirstMillisecond();
//        int int10 = day5.getMonth();
//        long long11 = day5.getFirstMillisecond();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getSerialIndex();
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day16, 0.0d);
//        long long19 = day16.getSerialIndex();
//        boolean boolean21 = day16.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day26, 0.0d);
//        timePeriodValues25.setDescription("");
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getSerialIndex();
//        java.util.Date date33 = year31.getStart();
//        int int34 = year31.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 100.0f);
//        timePeriodValues25.add(timePeriodValue36);
//        boolean boolean38 = day16.equals((java.lang.Object) timePeriodValue36);
//        timePeriodValue36.setValue((java.lang.Number) (byte) 0);
//        org.jfree.data.time.TimePeriod timePeriod41 = timePeriodValue36.getPeriod();
//        org.jfree.data.time.TimePeriod timePeriod42 = timePeriodValue36.getPeriod();
//        boolean boolean43 = day5.equals((java.lang.Object) timePeriod42);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(timePeriod41);
//        org.junit.Assert.assertNotNull(timePeriod42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        boolean boolean20 = simpleTimePeriod8.equals((java.lang.Object) 1.0d);
        long long21 = simpleTimePeriod8.getEndMillis();
        long long22 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getMiddleMillisecond();
        java.lang.String str7 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        int int17 = year14.getYear();
        long long18 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100);
        int int22 = simpleTimePeriod11.compareTo((java.lang.Object) year14);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        int int26 = year23.getYear();
        long long27 = year23.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year23, "", "13-June-2019");
        int int31 = year14.compareTo((java.lang.Object) "13-June-2019");
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year14.getMiddleMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        int int8 = day5.getYear();
        int int9 = day5.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        int int27 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.delete((int) (byte) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues3.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) false, "TimePeriodValue[2019,43629.0]", "1-January-2019");
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
        int int24 = day23.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        int int16 = year13.getYear();
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue22.getPeriod();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day28, 0.0d);
        timePeriodValues27.setDescription("");
        boolean boolean33 = timePeriodValues27.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timePeriodValue22.equals((java.lang.Object) propertyChangeListener34);
        timePeriodValue22.setValue((java.lang.Number) 0.0f);
        java.lang.Number number39 = timePeriodValue22.getValue();
        timePeriodValues3.add(timePeriodValue22);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.0f + "'", number39.equals(0.0f));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        boolean boolean14 = timePeriodValues3.isEmpty();
        java.lang.String str15 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
        java.lang.String str25 = timePeriodValues24.getDescription();
        boolean boolean27 = timePeriodValues24.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        int int31 = year28.getYear();
        timePeriodValues24.add((org.jfree.data.time.TimePeriod) year28, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 12);
        boolean boolean36 = simpleTimePeriod16.equals((java.lang.Object) 12);
        java.util.Date date37 = simpleTimePeriod16.getStart();
        java.util.Date date38 = simpleTimePeriod16.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getSerialIndex();
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        java.util.Date date12 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        java.lang.String str17 = timePeriodValues16.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues16.createCopy((int) '#', 1);
//        boolean boolean21 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues16);
//        boolean boolean23 = simpleTimePeriod11.equals((java.lang.Object) 1.0d);
//        int int24 = day0.compareTo((java.lang.Object) 1.0d);
//        java.lang.Class<?> wildcardClass25 = day0.getClass();
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day0.getFirstMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date23, date30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        java.util.Date date36 = year34.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getSerialIndex();
        java.util.Date date40 = year38.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date36, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date23, date40);
        boolean boolean44 = simpleTimePeriod16.equals((java.lang.Object) date40);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getSerialIndex();
        java.util.Date date47 = year45.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date47);
        java.lang.String str49 = timePeriodValues48.getDescription();
        boolean boolean51 = timePeriodValues48.equals((java.lang.Object) (byte) 10);
        java.lang.String str52 = timePeriodValues48.getDescription();
        java.lang.Comparable comparable53 = timePeriodValues48.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, (double) (byte) -1);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getSerialIndex();
        java.util.Date date61 = year59.getStart();
        int int62 = year59.getYear();
        long long63 = year59.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year59.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, (double) 100);
        int int67 = simpleTimePeriod56.compareTo((java.lang.Object) year59);
        boolean boolean68 = simpleTimePeriod16.equals((java.lang.Object) year59);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(comparable53);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        long long13 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "13-June-2019");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year9.previous();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
        java.lang.Class<?> wildcardClass25 = date23.getClass();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
        java.lang.String str27 = day26.toString();
        int int28 = day26.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
        java.util.Date date31 = day30.getStart();
        boolean boolean32 = year9.equals((java.lang.Object) date31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1-January-2019" + "'", str27.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        java.lang.Object obj8 = null;
        int int9 = day5.compareTo(obj8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        boolean boolean19 = timePeriodValues13.isEmpty();
        timePeriodValues13.setDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        try {
            timePeriodValues13.delete(5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[14-June-2019,0.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("1-January-2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        java.lang.Object obj8 = null;
        boolean boolean9 = day5.equals(obj8);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (double) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, 0.0d);
//        java.lang.Object obj7 = timePeriodValue6.clone();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getSerialIndex();
//        java.util.Date date10 = year8.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date10);
//        java.lang.String str13 = seriesChangeEvent12.toString();
//        boolean boolean14 = timePeriodValue6.equals((java.lang.Object) str13);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year7.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year7, "Value", "1-January-2019");
        long long19 = year7.getFirstMillisecond();
        long long20 = year7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 100);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean6 = day0.equals((java.lang.Object) year5);
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getEnd();
        long long10 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) day17, 0.0d);
        timePeriodValues16.setDescription("");
        boolean boolean22 = timePeriodValues16.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener23);
        timePeriodValues16.fireSeriesChanged();
        boolean boolean26 = year7.equals((java.lang.Object) timePeriodValues16);
        boolean boolean27 = day5.equals((java.lang.Object) year7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        int int14 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = null;
        try {
            timePeriodValues3.add(timePeriodValue15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        java.lang.String str8 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        java.lang.Number number11 = null;
        timePeriodValue9.setValue(number11);
        java.lang.String str13 = timePeriodValue9.toString();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
        java.lang.String str18 = timePeriodValues17.getDescription();
        boolean boolean20 = timePeriodValues17.equals((java.lang.Object) (byte) 10);
        int int21 = timePeriodValues17.getMinStartIndex();
        int int22 = timePeriodValues17.getMaxStartIndex();
        timePeriodValues17.setRangeDescription("");
        boolean boolean25 = timePeriodValue9.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,null]" + "'", str13.equals("TimePeriodValue[2019,null]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        int int26 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,43629.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        int int27 = timePeriodValues3.getMinStartIndex();
        java.lang.String str28 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        int int27 = year24.getYear();
        long long28 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue33.getPeriod();
        boolean boolean35 = day23.equals((java.lang.Object) timePeriodValue33);
        java.lang.Number number36 = timePeriodValue33.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 43629.0d + "'", number36.equals(43629.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getSerialIndex();
        java.lang.String str7 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        long long13 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "13-June-2019");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        long long20 = regularTimePeriod19.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod19);
        try {
            java.lang.Number number23 = timePeriodValues21.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1530561599999L + "'", long20 == 1530561599999L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("13-June-2019");
        timePeriodValues3.setRangeDescription("");
        int int18 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        int int15 = year12.getYear();
        long long16 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 100);
        java.lang.Number number22 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, number22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year12.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        boolean boolean16 = timePeriodValues13.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year17, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year17.previous();
        boolean boolean26 = timePeriodValues7.equals((java.lang.Object) year17);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        java.lang.String str13 = timePeriodValues12.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues12.createCopy((int) '#', 1);
        int int17 = timePeriodValues12.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass18 = timePeriodValues12.getClass();
        boolean boolean19 = year0.equals((java.lang.Object) wildcardClass18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        java.util.Date date22 = year20.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
        java.lang.Class<?> wildcardClass24 = date22.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
        java.lang.Class<?> wildcardClass30 = date28.getClass();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date28, timeZone31);
        java.util.Date date33 = regularTimePeriod32.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod32);
        boolean boolean35 = year0.equals((java.lang.Object) seriesChangeEvent34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        java.lang.Object obj5 = null;
        int int6 = year0.compareTo(obj5);
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getSerialIndex();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(12, 11);
        java.lang.String str16 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: 1-January-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        boolean boolean15 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        long long13 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "13-June-2019");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) (short) 1);
        long long19 = year9.getSerialIndex();
        java.lang.Object obj20 = null;
        boolean boolean21 = year9.equals(obj20);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 100);
        java.lang.Class<?> wildcardClass10 = timePeriodValue9.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "Time", "TimePeriodValue[14-June-2019,0.0]");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        int int4 = year0.getYear();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        long long8 = day5.getFirstMillisecond();
        java.lang.String str9 = day5.toString();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
        timePeriodValues13.fireSeriesChanged();
        int int18 = timePeriodValues13.getMinEndIndex();
        java.lang.String str19 = timePeriodValues13.getDomainDescription();
        java.lang.String str20 = timePeriodValues13.getDomainDescription();
        timePeriodValues13.setDescription("");
        boolean boolean23 = timePeriodValues13.getNotify();
        timePeriodValues13.setDomainDescription("13-June-2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.Object obj28 = new java.lang.Object();
        boolean boolean29 = timePeriodValues13.equals(obj28);
        boolean boolean30 = day5.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-2019" + "'", str9.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getSerialIndex();
        long long7 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        long long9 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        long long9 = day5.getFirstMillisecond();
        int int10 = day5.getMonth();
        long long11 = day5.getFirstMillisecond();
        int int12 = day5.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getSerialIndex();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
//        java.lang.String str9 = timePeriodValues8.getDescription();
//        boolean boolean11 = timePeriodValues8.equals((java.lang.Object) (byte) 10);
//        java.lang.String str12 = timePeriodValues8.getDescription();
//        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
//        int int14 = day0.compareTo((java.lang.Object) timePeriodValues8);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.util.Date date16 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date16);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        boolean boolean11 = timePeriodValues3.isEmpty();
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        long long21 = year17.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues24.addChangeListener(seriesChangeListener25);
        java.lang.Object obj27 = timePeriodValues24.clone();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
        java.lang.String str32 = timePeriodValues31.getDescription();
        boolean boolean34 = timePeriodValues31.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable35 = timePeriodValues31.getKey();
        timePeriodValues24.setKey(comparable35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getSerialIndex();
        java.util.Date date39 = year37.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day41, 0.0d);
        timePeriodValues40.setDescription("");
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getSerialIndex();
        java.util.Date date48 = year46.getStart();
        int int49 = year46.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) 100.0f);
        timePeriodValues40.add(timePeriodValue51);
        org.jfree.data.time.TimePeriod timePeriod53 = timePeriodValue51.getPeriod();
        timePeriodValues24.add(timePeriodValue51);
        timePeriodValues3.add(timePeriodValue51);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(comparable35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertNotNull(timePeriod53);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues7.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date13, date20);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date13, date30);
        boolean boolean34 = timePeriodValue9.equals((java.lang.Object) date30);
        java.lang.Object obj35 = timePeriodValue9.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.Class<?> wildcardClass15 = date13.getClass();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        java.lang.String str17 = day16.toString();
        int int18 = day16.getMonth();
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) day16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        java.lang.Class<?> wildcardClass26 = date24.getClass();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24);
        java.lang.String str28 = day27.toString();
        int int29 = day27.getMonth();
        int int30 = day27.getDayOfMonth();
        long long31 = day27.getFirstMillisecond();
        int int32 = day27.getMonth();
        long long33 = day27.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day27, (double) 1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1-January-2019" + "'", str17.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1-January-2019" + "'", str28.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        timePeriodValues3.fireSeriesChanged();
//        int int8 = timePeriodValues3.getItemCount();
//        int int9 = timePeriodValues3.getMinMiddleIndex();
//        int int10 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        java.util.Date date13 = year11.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, 0.0d);
//        long long18 = day15.getSerialIndex();
//        boolean boolean20 = day15.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getSerialIndex();
//        java.util.Date date23 = year21.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day25, 0.0d);
//        timePeriodValues24.setDescription("");
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        long long31 = year30.getSerialIndex();
//        java.util.Date date32 = year30.getStart();
//        int int33 = year30.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) 100.0f);
//        timePeriodValues24.add(timePeriodValue35);
//        boolean boolean37 = day15.equals((java.lang.Object) timePeriodValue35);
//        timePeriodValues3.add(timePeriodValue35);
//        timePeriodValue35.setValue((java.lang.Number) 0);
//        java.lang.String str41 = timePeriodValue35.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TimePeriodValue[2019,0]" + "'", str41.equals("TimePeriodValue[2019,0]"));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        java.lang.String str8 = year0.toString();
        java.lang.String str9 = year0.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        java.lang.String str28 = timePeriodValues27.getDescription();
        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        java.util.Date date33 = year31.getStart();
        int int34 = year31.getYear();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year31, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 12);
        int int39 = simpleTimePeriod21.compareTo((java.lang.Object) year31);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getSerialIndex();
        java.util.Date date42 = year40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) day44, 0.0d);
        timePeriodValues43.fireSeriesChanged();
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getSerialIndex();
        java.util.Date date52 = year50.getStart();
        java.lang.String str53 = year50.toString();
        java.lang.String str54 = year50.toString();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 4);
        boolean boolean57 = simpleTimePeriod21.equals((java.lang.Object) year50);
        timePeriodValues3.setKey((java.lang.Comparable) year50);
        boolean boolean59 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long2);
//        java.lang.Object obj4 = seriesChangeEvent3.getSource();
//        java.lang.String str5 = seriesChangeEvent3.toString();
//        java.lang.Object obj6 = seriesChangeEvent3.getSource();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560452399999L + "'", obj4.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560452399999]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]"));
//        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 1560452399999L + "'", obj6.equals(1560452399999L));
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        long long8 = day5.getFirstMillisecond();
        boolean boolean10 = day5.equals((java.lang.Object) 'a');
        java.util.Date date11 = day5.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getSerialIndex();
//        java.util.Date date3 = year1.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
//        java.lang.Class<?> wildcardClass5 = date3.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getSerialIndex();
//        java.util.Date date8 = year6.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
//        java.lang.Class<?> wildcardClass10 = date8.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getSerialIndex();
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
//        java.lang.Class<?> wildcardClass16 = date14.getClass();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getDayOfMonth();
//        java.lang.String str23 = day21.toString();
//        java.util.Date date24 = day21.getStart();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date3, date24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getSerialIndex();
//        java.util.Date date30 = year28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
//        java.lang.Class<?> wildcardClass32 = date30.getClass();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        long long34 = year33.getSerialIndex();
//        java.util.Date date35 = year33.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date35);
//        java.lang.Class<?> wildcardClass37 = date35.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getSerialIndex();
//        java.util.Date date41 = year39.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
//        java.lang.Class<?> wildcardClass43 = date41.getClass();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date30, timeZone44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date24, timeZone44);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        int int16 = year13.getYear();
//        long long17 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
//        int int19 = day11.compareTo((java.lang.Object) regularTimePeriod18);
//        int int20 = day11.getYear();
//        int int21 = day4.compareTo((java.lang.Object) day11);
//        java.util.Date date22 = day11.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getDayOfMonth();
//        java.lang.String str25 = day23.toString();
//        java.util.Date date26 = day23.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date22, date26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date26);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getDayOfMonth();
//        java.util.Date date6 = day0.getStart();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        int int13 = year10.getYear();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        int int22 = year18.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) 10.0d);
        boolean boolean26 = timePeriodValues3.getNotify();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date25, date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date12, date29);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date6, date29);
        java.lang.Number number35 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, number35);
        java.util.Date date37 = simpleTimePeriod34.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        java.util.Date date3 = year1.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        java.lang.Class<?> wildcardClass5 = date3.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        java.lang.Class<?> wildcardClass10 = date8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        java.lang.Class<?> wildcardClass16 = date14.getClass();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year20.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        java.util.Date date10 = day9.getStart();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day9.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues7.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.String str15 = timePeriodValues14.getDescription();
        boolean boolean17 = timePeriodValues14.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable18 = timePeriodValues14.getKey();
        timePeriodValues7.setKey(comparable18);
        java.lang.Comparable comparable20 = timePeriodValues7.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues7.createCopy(13, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(comparable18);
        org.junit.Assert.assertNotNull(comparable20);
        org.junit.Assert.assertNotNull(timePeriodValues23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(7, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) 4);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day4.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues23.createCopy((int) '#', 1);
//        boolean boolean28 = simpleTimePeriod18.equals((java.lang.Object) timePeriodValues23);
//        int int29 = timePeriodValues23.getMinEndIndex();
//        int int30 = day4.compareTo((java.lang.Object) int29);
//        java.util.Date date31 = day4.getEnd();
//        java.util.TimeZone timeZone32 = null;
//        try {
//            org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31, timeZone32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(timePeriodValues27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(date31);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(12, 11);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, 0.0d);
        timePeriodValues19.setDescription("");
        boolean boolean25 = timePeriodValues19.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener26);
        int int28 = timePeriodValues19.getMinStartIndex();
        boolean boolean29 = timePeriodValues3.equals((java.lang.Object) int28);
        java.lang.String str30 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100.0f);
        timePeriodValues3.add(timePeriodValue14);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 1562097599999L);
        timePeriodValue14.setValue((java.lang.Number) 1546329600000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(timePeriod16);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) 10);
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        boolean boolean14 = year10.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 0);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        java.lang.Class<?> wildcardClass22 = date20.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        java.lang.Class<?> wildcardClass28 = date26.getClass();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date26, timeZone29);
        boolean boolean31 = timePeriodValue17.equals((java.lang.Object) timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date9, timeZone29);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) (short) 10);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year32.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        int int9 = day8.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener17);
        try {
            timePeriodValues3.delete(2, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        int int10 = year7.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getSerialIndex();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day22, 0.0d);
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        long long27 = year26.getSerialIndex();
//        java.util.Date date28 = year26.getStart();
//        int int29 = year26.getYear();
//        long long30 = year26.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year26.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (double) 100);
//        boolean boolean34 = day22.equals((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day22.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        int int27 = year24.getYear();
        long long28 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 43629L);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue33.getPeriod();
        boolean boolean35 = day23.equals((java.lang.Object) timePeriodValue33);
        long long36 = day23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546415999999L + "'", long36 == 1546415999999L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        int int8 = day5.getDayOfMonth();
        long long9 = day5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43466L + "'", long9 == 43466L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date2);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        java.lang.String str7 = seriesChangeEvent4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        long long8 = day5.getFirstMillisecond();
        java.lang.String str9 = day5.toString();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
        timePeriodValues13.fireSeriesChanged();
        int int18 = timePeriodValues13.getMinEndIndex();
        java.lang.String str19 = timePeriodValues13.getDomainDescription();
        java.lang.String str20 = timePeriodValues13.getDomainDescription();
        timePeriodValues13.setDescription("");
        boolean boolean23 = timePeriodValues13.getNotify();
        timePeriodValues13.setDomainDescription("13-June-2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.Object obj28 = new java.lang.Object();
        boolean boolean29 = timePeriodValues13.equals(obj28);
        boolean boolean30 = day5.equals((java.lang.Object) timePeriodValues13);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues13.createCopy(10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-2019" + "'", str9.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        int int8 = day5.getYear();
        long long9 = day5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.delete(6, 0);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(12, 11);
        int int16 = timePeriodValues15.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(12, 11);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, 0.0d);
        timePeriodValues19.setDescription("");
        boolean boolean25 = timePeriodValues19.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener26);
        int int28 = timePeriodValues19.getMinStartIndex();
        boolean boolean29 = timePeriodValues3.equals((java.lang.Object) int28);
        timePeriodValues3.setDescription("TimePeriodValue[2019,43629.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date11, date18);
        java.util.Date date22 = simpleTimePeriod21.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date2, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        boolean boolean28 = year24.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.next();
        int int30 = simpleTimePeriod23.compareTo((java.lang.Object) regularTimePeriod29);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        try {
            int int33 = simpleTimePeriod23.compareTo((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 8, (long) 13);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 1.0d);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        long long6 = year5.getSerialIndex();
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day9, 0.0d);
//        timePeriodValues8.fireSeriesChanged();
//        int int13 = timePeriodValues8.getItemCount();
//        int int14 = timePeriodValues8.getMinMiddleIndex();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getSerialIndex();
//        java.util.Date date17 = year15.getStart();
//        int int18 = year15.getYear();
//        long long19 = year15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year15.next();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 5);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getSerialIndex();
//        java.util.Date date25 = year23.getStart();
//        int int26 = year23.getYear();
//        int int27 = year23.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10.0d);
//        timePeriodValues8.setKey((java.lang.Comparable) 10.0d);
//        timePeriodValues8.setRangeDescription("");
//        boolean boolean33 = timePeriodValue4.equals((java.lang.Object) timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
        java.lang.Class<?> wildcardClass23 = date21.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        java.lang.String str25 = day24.toString();
        int int26 = day24.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        java.util.Date date29 = day28.getStart();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day28, (double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1-January-2019" + "'", str25.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.Class<?> wildcardClass15 = date13.getClass();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        java.lang.String str17 = day16.toString();
        int int18 = day16.getMonth();
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) day16);
        timePeriodValues3.setDescription("Time");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener22);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1-January-2019" + "'", str17.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getSerialIndex();
//        java.util.Date date6 = year4.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, 0.0d);
//        timePeriodValues7.setDescription("");
//        boolean boolean13 = timePeriodValues7.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener14);
//        timePeriodValues7.fireSeriesChanged();
//        boolean boolean17 = day0.equals((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date2, date9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date2, date19);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        java.util.Date date24 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        int int27 = day25.compareTo((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.delete(6, 0);
        int int12 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        java.util.Date date22 = simpleTimePeriod21.getStart();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        java.lang.String str28 = timePeriodValues27.getDescription();
        boolean boolean30 = timePeriodValues27.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        java.util.Date date33 = year31.getStart();
        int int34 = year31.getYear();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year31, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 12);
        int int39 = simpleTimePeriod21.compareTo((java.lang.Object) year31);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getSerialIndex();
        java.util.Date date42 = year40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) day44, 0.0d);
        timePeriodValues43.fireSeriesChanged();
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getSerialIndex();
        java.util.Date date52 = year50.getStart();
        java.lang.String str53 = year50.toString();
        java.lang.String str54 = year50.toString();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 4);
        boolean boolean57 = simpleTimePeriod21.equals((java.lang.Object) year50);
        timePeriodValues3.setKey((java.lang.Comparable) year50);
        java.util.Calendar calendar59 = null;
        try {
            year50.peg(calendar59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.Class<?> wildcardClass15 = date13.getClass();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
        java.lang.String str17 = day16.toString();
        int int18 = day16.getMonth();
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) day16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues3.createCopy((int) '4', (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1-January-2019" + "'", str17.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timePeriodValues24);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        java.util.Date date4 = year2.getStart();
//        int int5 = year2.getYear();
//        long long6 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year2.next();
//        int int8 = day0.compareTo((java.lang.Object) regularTimePeriod7);
//        int int9 = day0.getYear();
//        long long10 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43629L);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Date date7 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 100);
        timePeriodValue9.setValue((java.lang.Number) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,null]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxStartIndex();
        try {
            timePeriodValues3.delete(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        timePeriodValues3.setKey((java.lang.Comparable) date16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long22 = simpleTimePeriod21.getStartMillis();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        java.lang.Class<?> wildcardClass28 = date26.getClass();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
        java.lang.String str30 = day29.toString();
        int int31 = day29.getDayOfMonth();
        int int32 = day29.getYear();
        java.lang.Number number33 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day29, number33);
        int int35 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.delete(1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1-January-2019" + "'", str30.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getSerialIndex();
//        java.util.Date date6 = year4.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, 0.0d);
//        long long11 = day8.getSerialIndex();
//        long long12 = day8.getSerialIndex();
//        long long13 = day8.getFirstMillisecond();
//        long long14 = day8.getLastMillisecond();
//        int int15 = simpleTimePeriod2.compareTo((java.lang.Object) day8);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getSerialIndex();
//        java.util.Date date18 = year16.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues19.createCopy((int) '#', 1);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getSerialIndex();
//        java.util.Date date26 = year24.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getSerialIndex();
//        java.util.Date date30 = year28.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
//        java.util.Date date33 = simpleTimePeriod32.getStart();
//        timePeriodValues19.setKey((java.lang.Comparable) simpleTimePeriod32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
//        long long38 = simpleTimePeriod37.getStartMillis();
//        boolean boolean39 = timePeriodValues19.equals((java.lang.Object) simpleTimePeriod37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getSerialIndex();
//        java.util.Date date42 = year40.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date42);
//        java.lang.Class<?> wildcardClass44 = date42.getClass();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date42);
//        java.lang.String str46 = day45.toString();
//        int int47 = day45.getDayOfMonth();
//        int int48 = day45.getYear();
//        java.lang.Number number49 = null;
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day45, number49);
//        boolean boolean51 = simpleTimePeriod2.equals((java.lang.Object) day45);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(timePeriodValues23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1-January-2019" + "'", str46.equals("1-January-2019"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        int int3 = year0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues6.createCopy(0, (int) (byte) -1);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        long long17 = day14.getSerialIndex();
//        boolean boolean19 = day14.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day24, 0.0d);
//        timePeriodValues23.setDescription("");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getSerialIndex();
//        java.util.Date date31 = year29.getStart();
//        int int32 = year29.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 100.0f);
//        timePeriodValues23.add(timePeriodValue34);
//        boolean boolean36 = day14.equals((java.lang.Object) timePeriodValue34);
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (double) 10L);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getSerialIndex();
//        java.util.Date date41 = year39.getStart();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getSerialIndex();
//        java.util.Date date44 = year42.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getSerialIndex();
//        java.util.Date date48 = year46.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date44, date48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date41, date48);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getSerialIndex();
//        java.util.Date date54 = year52.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        long long57 = year56.getSerialIndex();
//        java.util.Date date58 = year56.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date58);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date54, date58);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date41, date58);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date41);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        long long65 = day63.getMiddleMillisecond();
//        long long66 = day63.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day63.next();
//        int int68 = day62.compareTo((java.lang.Object) day63);
//        boolean boolean69 = timePeriodValue38.equals((java.lang.Object) day63);
//        timePeriodValues6.add(timePeriodValue38);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "13-June-2019" + "'", str64.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560452399999L + "'", long65 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560409200000L + "'", long66 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-163) + "'", int68 == (-163));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.lang.String str13 = year7.toString();
        int int14 = year7.getYear();
        long long15 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        int int15 = year12.getYear();
        long long16 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 100);
        java.lang.Number number22 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, number22);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues3.createCopy((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues7.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.String str15 = timePeriodValues14.getDescription();
        boolean boolean17 = timePeriodValues14.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable18 = timePeriodValues14.getKey();
        timePeriodValues7.setKey(comparable18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        java.util.Date date22 = year20.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day24, 0.0d);
        timePeriodValues23.setDescription("");
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getSerialIndex();
        java.util.Date date31 = year29.getStart();
        int int32 = year29.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 100.0f);
        timePeriodValues23.add(timePeriodValue34);
        org.jfree.data.time.TimePeriod timePeriod36 = timePeriodValue34.getPeriod();
        timePeriodValues7.add(timePeriodValue34);
        java.lang.Number number38 = null;
        timePeriodValue34.setValue(number38);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(comparable18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(timePeriod36);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Value", "Time", "1-January-2019");
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        long long9 = day4.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day4.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getDayOfMonth();
//        java.util.Calendar calendar12 = null;
//        try {
//            day4.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        boolean boolean12 = year8.equals((java.lang.Object) 1);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getEnd();
        boolean boolean16 = year8.equals((java.lang.Object) year13);
        java.lang.String str17 = year13.toString();
        timePeriodValues3.setKey((java.lang.Comparable) year13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getSerialIndex();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long22 = simpleTimePeriod21.getStartMillis();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod21);
        timePeriodValues3.setDescription("1-January-2019");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.lang.Class<?> wildcardClass9 = date6.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        boolean boolean21 = year17.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 0);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        int int7 = year4.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 100.0f);
        long long10 = year4.getFirstMillisecond();
        int int12 = year4.compareTo((java.lang.Object) 10);
        java.util.Date date13 = year4.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
        java.lang.Class<?> wildcardClass26 = date24.getClass();
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
        java.lang.Class<?> wildcardClass32 = date30.getClass();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date30, timeZone33);
        boolean boolean35 = timePeriodValue21.equals((java.lang.Object) timeZone33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date13, timeZone33);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date3, timeZone33);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100);
        java.lang.String str8 = year0.toString();
        java.lang.String str9 = year0.toString();
        long long10 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) 10);
        long long9 = year0.getLastMillisecond();
        int int10 = year0.getYear();
        java.lang.String str11 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getDayOfMonth();
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        timePeriodValues3.fireSeriesChanged();
//        int int8 = timePeriodValues3.getItemCount();
//        int int9 = timePeriodValues3.getMinMiddleIndex();
//        int int10 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        java.util.Date date13 = year11.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, 0.0d);
//        long long18 = day15.getSerialIndex();
//        boolean boolean20 = day15.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getSerialIndex();
//        java.util.Date date23 = year21.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day25, 0.0d);
//        timePeriodValues24.setDescription("");
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        long long31 = year30.getSerialIndex();
//        java.util.Date date32 = year30.getStart();
//        int int33 = year30.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) 100.0f);
//        timePeriodValues24.add(timePeriodValue35);
//        boolean boolean37 = day15.equals((java.lang.Object) timePeriodValue35);
//        timePeriodValues3.add(timePeriodValue35);
//        java.lang.String str39 = timePeriodValue35.toString();
//        java.lang.Number number40 = timePeriodValue35.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str39.equals("TimePeriodValue[2019,100.0]"));
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 100.0f + "'", number40.equals(100.0f));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 100);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.getNotify();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        java.lang.Object obj6 = timePeriodValue5.clone();
        java.lang.Number number7 = timePeriodValue5.getValue();
        java.lang.String str8 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str8.equals("TimePeriodValue[2019,100.0]"));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        java.util.Date date9 = day4.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        boolean boolean4 = year0.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.lang.String str6 = year0.toString();
        java.lang.String str7 = year0.toString();
        long long8 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update(100, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getFirstMillisecond();
        int int8 = year0.compareTo((java.lang.Object) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 43629L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getSerialIndex();
//        java.util.Date date31 = year29.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date31);
//        java.lang.String str33 = timePeriodValues32.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues32.createCopy((int) '#', 1);
//        timePeriodValues36.fireSeriesChanged();
//        int int38 = timePeriodValues36.getItemCount();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getSerialIndex();
//        java.util.Date date41 = year39.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
//        java.lang.String str43 = timePeriodValues42.getDescription();
//        boolean boolean45 = timePeriodValues42.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getSerialIndex();
//        java.util.Date date48 = year46.getStart();
//        int int49 = year46.getYear();
//        timePeriodValues42.add((org.jfree.data.time.TimePeriod) year46, (double) 1.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year46.previous();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year46, (double) 100);
//        boolean boolean57 = day4.equals((java.lang.Object) timePeriodValues36);
//        long long58 = day4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560495599999L + "'", long58 == 1560495599999L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        int int10 = year7.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
//        java.lang.String str13 = timePeriodValues3.getDomainDescription();
//        java.lang.String str14 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getSerialIndex();
//        java.util.Date date19 = year17.getStart();
//        int int20 = year17.getYear();
//        long long21 = year17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.next();
//        int int23 = day15.compareTo((java.lang.Object) regularTimePeriod22);
//        int int24 = day15.getYear();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, 0.0d);
//        try {
//            java.lang.Number number28 = timePeriodValues3.getValue((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        java.util.Date date17 = year15.getStart();
        int int18 = year15.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues21.createCopy(0, (int) (byte) -1);
        boolean boolean25 = timePeriodValue14.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparable10);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) 4);
//        int int10 = day4.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13);
        java.lang.String str15 = timePeriodValues14.getDescription();
        boolean boolean17 = timePeriodValues14.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        int int21 = year18.getYear();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year18, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 12);
        int int26 = simpleTimePeriod8.compareTo((java.lang.Object) year18);
        java.util.Date date27 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues3.isEmpty();
        int int19 = timePeriodValues3.getMinStartIndex();
        boolean boolean20 = timePeriodValues3.isEmpty();
        try {
            timePeriodValues3.update((int) (short) 10, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1530561599999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        java.lang.Object obj6 = timePeriodValue5.clone();
        java.lang.Number number7 = timePeriodValue5.getValue();
        java.lang.Object obj8 = timePeriodValue5.clone();
        java.lang.String str9 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str9.equals("TimePeriodValue[2019,100.0]"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,0]");
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        int int8 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
        java.lang.String str10 = day5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1-January-2019" + "'", str10.equals("1-January-2019"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        java.lang.String str13 = year10.toString();
        java.lang.String str14 = year10.toString();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year10.next();
        long long20 = year10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        java.lang.Object obj14 = null;
        try {
            int int15 = simpleTimePeriod11.compareTo(obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        java.lang.Object obj14 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) (byte) -1);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues3.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        java.util.Date date13 = year7.getStart();
        java.util.Date date14 = year7.getEnd();
        long long15 = year7.getSerialIndex();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year7.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues13.createCopy((int) (short) -1, 100);
        try {
            timePeriodValues21.delete(9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timePeriodValues21);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) '4', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getMinEndIndex();
        java.lang.String str20 = timePeriodValues13.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        timePeriodValues3.setDescription("");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getSerialIndex();
//        java.util.Date date11 = year9.getStart();
//        int int12 = year9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100.0f);
//        timePeriodValues3.add(timePeriodValue14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getSerialIndex();
//        java.util.Date date18 = year16.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day20, 0.0d);
//        long long23 = day20.getSerialIndex();
//        boolean boolean25 = day20.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        long long27 = year26.getSerialIndex();
//        java.util.Date date28 = year26.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day30, 0.0d);
//        timePeriodValues29.setDescription("");
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getSerialIndex();
//        java.util.Date date37 = year35.getStart();
//        int int38 = year35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 100.0f);
//        timePeriodValues29.add(timePeriodValue40);
//        boolean boolean42 = day20.equals((java.lang.Object) timePeriodValue40);
//        int int43 = day20.getMonth();
//        long long44 = day20.getFirstMillisecond();
//        timePeriodValues3.setKey((java.lang.Comparable) day20);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 100);
//        java.lang.Number number5 = timePeriodValue4.getValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long2);
//        java.lang.Object obj4 = seriesChangeEvent3.getSource();
//        java.lang.String str5 = seriesChangeEvent3.toString();
//        java.lang.String str6 = seriesChangeEvent3.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560452399999L + "'", obj4.equals(1560452399999L));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560452399999]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560452399999]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]"));
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        int int10 = year7.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year7.previous();
        long long16 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year7.next();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20);
        java.lang.String str22 = timePeriodValues21.getDescription();
        boolean boolean24 = timePeriodValues21.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        int int28 = year25.getYear();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year25, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year25, "Value", "1-January-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year25.previous();
        boolean boolean38 = year7.equals((java.lang.Object) year25);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long22 = simpleTimePeriod21.getStartMillis();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod21);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener24);
        java.lang.Comparable comparable26 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,43629.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(comparable26);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getSerialIndex();
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        java.util.Date date12 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
//        java.lang.String str17 = timePeriodValues16.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues16.createCopy((int) '#', 1);
//        boolean boolean21 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues16);
//        boolean boolean23 = simpleTimePeriod11.equals((java.lang.Object) 1.0d);
//        int int24 = day0.compareTo((java.lang.Object) 1.0d);
//        java.lang.Class<?> wildcardClass25 = day0.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', (long) 100);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) (-1));
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        long long8 = day4.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) 100, 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getSerialIndex();
//        java.util.Date date12 = year10.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day14, 0.0d);
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getSerialIndex();
//        java.util.Date date21 = year19.getStart();
//        int int22 = year19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100.0f);
//        timePeriodValues13.add(timePeriodValue24);
//        boolean boolean26 = day4.equals((java.lang.Object) timePeriodValue24);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (double) 10L);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = day4.compareTo((java.lang.Object) day29);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        int int8 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        timePeriodValues3.delete((int) '4', (int) (byte) 10);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 01 00:00:00 PST 2019]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.lang.String str6 = day5.toString();
        int int7 = day5.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            day5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        java.lang.Class<?> wildcardClass11 = date9.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 10);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        int int20 = year17.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100.0f);
        long long23 = year17.getFirstMillisecond();
        int int25 = year17.compareTo((java.lang.Object) 10);
        java.util.Date date26 = year17.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        boolean boolean31 = year27.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year27.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 0);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date37);
        java.lang.Class<?> wildcardClass39 = date37.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getSerialIndex();
        java.util.Date date43 = year41.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date43);
        java.lang.Class<?> wildcardClass45 = date43.getClass();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date43, timeZone46);
        boolean boolean48 = timePeriodValue34.equals((java.lang.Object) timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date26, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone46);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date6, timeZone46);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues13.createCopy((int) '#', 1);
        boolean boolean18 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getMinEndIndex();
        timePeriodValues13.setNotify(false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        java.util.Date date16 = year14.getStart();
        boolean boolean18 = year14.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year14.next();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date27);
        java.lang.String str29 = timePeriodValues28.getDescription();
        boolean boolean31 = timePeriodValues28.equals((java.lang.Object) (byte) 10);
        java.lang.String str32 = timePeriodValues28.getDescription();
        java.lang.String str33 = timePeriodValues28.getRangeDescription();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        java.util.Date date36 = year34.getStart();
        int int37 = year34.getYear();
        long long38 = year34.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34, "", "13-June-2019");
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) (short) 1);
        java.lang.Object obj44 = timePeriodValues28.clone();
        boolean boolean45 = year14.equals((java.lang.Object) timePeriodValues28);
        java.lang.Comparable comparable46 = timePeriodValues28.getKey();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(comparable46);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1560452399999]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        java.lang.String str11 = timePeriodValues10.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues10.createCopy((int) '#', 1);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date17, date21);
        java.util.Date date24 = simpleTimePeriod23.getStart();
        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long29 = simpleTimePeriod28.getStartMillis();
        boolean boolean30 = timePeriodValues10.equals((java.lang.Object) simpleTimePeriod28);
        int int31 = year0.compareTo((java.lang.Object) simpleTimePeriod28);
        java.util.Date date32 = simpleTimePeriod28.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        long long8 = day4.getSerialIndex();
//        int int9 = day4.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.util.Date date11 = year9.getStart();
        int int12 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100.0f);
        timePeriodValues3.add(timePeriodValue14);
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,43629.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        java.lang.String str12 = timePeriodValues3.getDescription();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day4.previous();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day4.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        java.util.Date date30 = year28.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date23, date30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        java.util.Date date36 = year34.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getSerialIndex();
        java.util.Date date40 = year38.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date36, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date23, date40);
        boolean boolean44 = simpleTimePeriod16.equals((java.lang.Object) date40);
        java.util.Date date45 = simpleTimePeriod16.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100.0f);
        long long6 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date2, date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date25, date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date12, date29);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date6, date29);
        java.lang.Number number35 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, number35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getSerialIndex();
        java.util.Date date39 = year37.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day41, 0.0d);
        timePeriodValues40.setDescription("");
        boolean boolean46 = timePeriodValues40.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues40.addPropertyChangeListener(propertyChangeListener47);
        int int49 = timePeriodValues40.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener50);
        boolean boolean52 = simpleTimePeriod34.equals((java.lang.Object) timePeriodValues40);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (byte) 10);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparable7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        int int16 = year13.getYear();
//        long long17 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
//        int int19 = day11.compareTo((java.lang.Object) regularTimePeriod18);
//        int int20 = day11.getYear();
//        int int21 = day4.compareTo((java.lang.Object) day11);
//        java.util.Date date22 = day11.getEnd();
//        java.lang.Class<?> wildcardClass23 = date22.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        int int3 = year0.getYear();
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "13-June-2019");
//        int int8 = timePeriodValues7.getMinMiddleIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getSerialIndex();
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getSerialIndex();
//        java.util.Date date18 = year16.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date14, date18);
//        java.util.Date date21 = simpleTimePeriod20.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24);
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = timePeriodValues25.createCopy((int) '#', 1);
//        boolean boolean30 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues25);
//        boolean boolean32 = simpleTimePeriod20.equals((java.lang.Object) 1.0d);
//        int int33 = day9.compareTo((java.lang.Object) 1.0d);
//        java.lang.Class<?> wildcardClass34 = day9.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day9.next();
//        timePeriodValues7.setKey((java.lang.Comparable) day9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(timePeriodValues29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
//        long long7 = day4.getSerialIndex();
//        boolean boolean9 = day4.equals((java.lang.Object) "2019");
//        java.lang.String str10 = day4.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getSerialIndex();
//        java.util.Date date15 = year13.getStart();
//        int int16 = year13.getYear();
//        long long17 = year13.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
//        int int19 = day11.compareTo((java.lang.Object) regularTimePeriod18);
//        int int20 = day11.getYear();
//        int int21 = day4.compareTo((java.lang.Object) day11);
//        java.util.Date date22 = day11.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.String str4 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((int) '#', 1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date14);
        java.util.Date date17 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod16);
        long long19 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        java.util.Date date22 = year20.getStart();
        java.lang.String str23 = year20.toString();
        java.util.Date date24 = year20.getEnd();
        java.lang.String str25 = year20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year20.previous();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date29);
        java.lang.String str31 = timePeriodValues30.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues30.createCopy((int) '#', 1);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        java.util.Date date44 = simpleTimePeriod43.getStart();
        timePeriodValues30.setKey((java.lang.Comparable) simpleTimePeriod43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(1L, 2019L);
        long long49 = simpleTimePeriod48.getStartMillis();
        boolean boolean50 = timePeriodValues30.equals((java.lang.Object) simpleTimePeriod48);
        int int51 = year20.compareTo((java.lang.Object) simpleTimePeriod48);
        boolean boolean52 = simpleTimePeriod16.equals((java.lang.Object) int51);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(timePeriodValues34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1L + "'", long49 == 1L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        java.lang.Class<?> wildcardClass4 = date2.getClass();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        long long6 = day5.getSerialIndex();
        java.lang.String str7 = day5.toString();
        int int8 = day5.getMonth();
        int int9 = day5.getMonth();
        long long10 = day5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        java.util.Date date17 = year15.getStart();
        int int18 = year15.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 100.0f);
        long long21 = year15.getFirstMillisecond();
        int int23 = year15.compareTo((java.lang.Object) 10);
        java.util.Date date24 = year15.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        boolean boolean29 = year25.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 0);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getSerialIndex();
        java.util.Date date35 = year33.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date35);
        java.lang.Class<?> wildcardClass37 = date35.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
        java.lang.Class<?> wildcardClass43 = date41.getClass();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date41, timeZone44);
        boolean boolean46 = timePeriodValue32.equals((java.lang.Object) timeZone44);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date24, timeZone44);
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (java.lang.Number) (short) 10);
        timePeriodValues3.add(timePeriodValue49);
        timePeriodValues3.setDomainDescription("TimePeriodValue[14-June-2019,0.0]");
        boolean boolean53 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day4, 0.0d);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }
}

