import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Stroke stroke6 = null;
        java.awt.Color color7 = java.awt.Color.GRAY;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.red;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "hi!", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color9 = java.awt.Color.GRAY;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = java.awt.Color.red;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", false, shape5, false, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        try {
            categoryPlot0.setRenderer((-1), categoryItemRenderer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 0, categoryMarker5, layer6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        try {
            int int5 = categoryPlot0.getRangeAxisIndex(valueAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis(0, categoryAxis3);
        java.awt.Paint paint5 = categoryPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot1.getRenderer();
        java.awt.Stroke stroke7 = null;
        categoryPlot1.setOutlineStroke(stroke7);
        try {
            org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) 100, true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 100, categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.util.SortOrder sortOrder8 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        try {
            lineAndShapeRenderer0.setItemMargin((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        try {
            int int8 = categoryPlot0.getRangeAxisIndex(valueAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            categoryPlot0.addRangeMarker((int) (byte) 100, marker6, layer7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke14 = lineAndShapeRenderer10.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color15 = java.awt.Color.red;
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, paint9, stroke14, (java.awt.Paint) color15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        legendItem1.setLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        categoryPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = null;
        try {
            java.awt.Shape shape23 = lineAndShapeRenderer0.createHotSpotShape(graphics2D9, rectangle2D10, categoryPlot11, categoryAxis16, valueAxis17, categoryDataset18, (int) ' ', (int) (byte) 1, false, categoryItemRendererState22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "", categoryDataset3, (java.lang.Comparable) 1L, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 10L, (double) 3, (double) (byte) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot9.setFixedRangeAxisSpace(axisSpace13, true);
        boolean boolean16 = categoryPlot9.canSelectByPoint();
        lineAndShapeRenderer4.setPlot(categoryPlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getRangeAxisEdge(10);
        try {
            double double20 = categoryAxis0.getCategoryMiddle((int) 'a', 0, rectangle2D3, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke11 = lineAndShapeRenderer7.getItemStroke((int) (short) 1, (int) (short) 100, true);
        try {
            lineAndShapeRenderer0.setSeriesOutlineStroke((-1), stroke11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke22 = lineAndShapeRenderer18.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis(0, categoryAxis25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot23.setFixedRangeAxisSpace(axisSpace27, true);
        boolean boolean30 = categoryPlot23.canSelectByPoint();
        lineAndShapeRenderer18.setPlot(categoryPlot23);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot23.getRangeAxisEdge(10);
        try {
            double double34 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) (short) 10, (int) (byte) 10, (int) (byte) 1, (double) 0, rectangle2D17, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Paint paint10 = lineAndShapeRenderer0.getSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addRangeMarker((int) '#', marker5, layer6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        try {
            lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            categoryPlot0.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer5.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace14, true);
        boolean boolean17 = categoryPlot10.canSelectByPoint();
        lineAndShapeRenderer5.setPlot(categoryPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getRangeAxisEdge(10);
        try {
            java.util.List list21 = categoryAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint12 = lineAndShapeRenderer0.lookupSeriesFillPaint((-1));
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot0.setDomainGridlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot0.addDomainMarker(192, categoryMarker15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int2 = color1.getGreen();
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color1);
        java.lang.String str4 = color3.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 192 + "'", int2 == 192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str4.equals("java.awt.Color[r=0,g=192,b=192]"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 100);
        java.util.List list9 = categoryPlot6.getAnnotations();
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) (byte) 1, list9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        categoryPlot0.setCrosshairDatasetIndex((int) '4');
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("java.awt.Color[r=0,g=192,b=192]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            categoryPlot3.addDomainMarker((int) (short) 0, categoryMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) 0, categoryMarker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Category Plot", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryDataset3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int13 = color12.getGreen();
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color12);
        categoryPlot0.setDomainAxis(10, categoryAxis10, false);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer22.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis(0, categoryAxis29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace31, true);
        boolean boolean34 = categoryPlot27.canSelectByPoint();
        lineAndShapeRenderer22.setPlot(categoryPlot27);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot27.getRangeAxisEdge(10);
        try {
            double double38 = categoryAxis10.getCategorySeriesMiddle((java.lang.Comparable) (-1.0d), (java.lang.Comparable) false, categoryDataset19, (double) 0.0f, rectangle2D21, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) 10, true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, 0.0d, (double) 0.0f, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean6 = lineAndShapeRenderer4.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape8 = lineAndShapeRenderer4.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke13 = lineAndShapeRenderer9.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color14 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape8, stroke13, (java.awt.Paint) color14);
        int int16 = legendItem15.getDatasetIndex();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        try {
            categoryPlot15.setBackgroundImageAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        java.awt.Paint paint10 = null;
        lineAndShapeRenderer0.setLegendTextPaint(0, paint10);
        java.awt.Paint paint13 = lineAndShapeRenderer0.getSeriesOutlinePaint((int) ' ');
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        try {
            lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart4);
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 10.0d, "CategoryAnchor.MIDDLE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace21, true);
        boolean boolean24 = categoryPlot17.canSelectByPoint();
        lineAndShapeRenderer12.setPlot(categoryPlot17);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot17.getRangeAxisEdge(10);
        try {
            java.util.List list28 = categoryAxis0.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        org.jfree.chart.util.ShadowGenerator shadowGenerator8 = null;
        categoryPlot0.setShadowGenerator(shadowGenerator8);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot0.handleClick(0, (int) '4', plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis(0, categoryAxis3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot1.setFixedRangeAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot1.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 3, 0.0d, (double) 1L, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.lang.String str3 = legendItem1.getToolTipText();
        java.awt.Paint paint4 = null;
        try {
            legendItem1.setLinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Font font13 = categoryAxis10.getTickLabelFont((java.lang.Comparable) 1L);
        lineAndShapeRenderer0.setSeriesItemLabelFont(192, font13, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int4 = color3.getGreen();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color3);
        java.lang.Object obj6 = categoryAxis1.clone();
        categoryAxis1.setLabelAngle((double) 0L);
        boolean boolean9 = categoryAnchor0.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 192 + "'", int4 == 192);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.lang.String str3 = legendItem1.getToolTipText();
        boolean boolean4 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.setLabelAngle((double) 0L);
        java.util.List list9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis(0, categoryAxis18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot16.setFixedRangeAxisSpace(axisSpace20, true);
        boolean boolean23 = categoryPlot16.canSelectByPoint();
        lineAndShapeRenderer11.setPlot(categoryPlot16);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge(10);
        try {
            double double27 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) (short) -1, list9, rectangle2D10, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        boolean boolean4 = standardGradientPaintTransformer0.equals((java.lang.Object) "");
        java.awt.GradientPaint gradientPaint5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean8 = lineAndShapeRenderer6.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape10 = lineAndShapeRenderer6.lookupLegendShape(10);
        try {
            java.awt.GradientPaint gradientPaint11 = standardGradientPaintTransformer0.transform(gradientPaint5, shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke16, true);
        java.awt.Font font20 = lineAndShapeRenderer8.getLegendTextFont(0);
        lineAndShapeRenderer8.setBaseCreateEntities(false);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 0, paint24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition27);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = itemLabelPosition27.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=192,b=192]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        boolean boolean22 = lineAndShapeRenderer0.getItemVisible((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke23 = lineAndShapeRenderer19.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot24.setFixedRangeAxisSpace(axisSpace28, true);
        boolean boolean31 = categoryPlot24.canSelectByPoint();
        lineAndShapeRenderer19.setPlot(categoryPlot24);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot24.getRangeAxisEdge(10);
        try {
            double double35 = categoryAxis0.getCategoryEnd((int) (short) 1, (int) (byte) 100, rectangle2D18, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot0.setDomainGridlineStroke(stroke12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.handleClick((int) (short) 100, 4, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        try {
            java.lang.Object obj8 = keyedObjects0.getObject((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis14);
        boolean boolean16 = lineAndShapeRenderer8.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot12.panRangeAxes((double) (byte) 1, plotRenderingInfo18, point2D19);
        keyedObjects0.addObject((java.lang.Comparable) (short) 1, (java.lang.Object) plotRenderingInfo18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Object obj0 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset1 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup("hi!");
        abstractCategoryDataset1.setGroup(datasetGroup3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = abstractCategoryDataset1.getGroup();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo6 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.event.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) abstractCategoryDataset1, datasetChangeInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        boolean boolean9 = lineAndShapeRenderer1.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Stroke stroke10 = categoryPlot5.getDomainCrosshairStroke();
        boolean boolean11 = textAnchor0.equals((java.lang.Object) categoryPlot5);
        categoryPlot5.setAnchorValue(4.0d, false);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        boolean boolean7 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.awt.Font font15 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getRangeAxisLocation((int) (byte) 100);
        int int20 = categoryPlot17.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot17.axisChanged(axisChangeEvent21);
        java.awt.Paint paint23 = categoryPlot17.getDomainCrosshairPaint();
        org.jfree.data.KeyedObjects keyedObjects24 = new org.jfree.data.KeyedObjects();
        int int26 = keyedObjects24.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot29 = categoryAxis28.getPlot();
        keyedObjects24.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D16, categoryPlot17, categoryAxis28, categoryMarker31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(plot29);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setBackgroundAlpha((float) 3);
        categoryPlot0.clearSelection();
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot0.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (-1.0f));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot11.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation((int) (short) 1, axisLocation28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        boolean boolean34 = categoryPlot30.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot30.getInsets();
        categoryPlot11.setAxisOffset(rectangleInsets35);
        categoryPlot0.setAxisOffset(rectangleInsets35);
        double double39 = rectangleInsets35.trimWidth((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            rectangleInsets35.trim(rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-17.0d) + "'", double39 == (-17.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = paintList0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot3.setDrawingSupplier(drawingSupplier6, false);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot3.setDataset(categoryDataset9);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean14 = lineAndShapeRenderer12.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke20 = lineAndShapeRenderer16.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer12.setSeriesStroke(0, stroke20, true);
        java.awt.Font font24 = lineAndShapeRenderer12.getLegendTextFont(0);
        lineAndShapeRenderer12.setBaseCreateEntities(false);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer12.setSeriesItemLabelPaint((int) (short) 0, paint28);
        categoryPlot3.setBackgroundPaint(paint28);
        try {
            paintList0.setPaint((int) (short) -1, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        double double9 = rectangleInsets6.getLeft();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        boolean boolean20 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable3, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke12 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 3.0d, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(stroke12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean6 = lineAndShapeRenderer4.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape8 = lineAndShapeRenderer4.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke13 = lineAndShapeRenderer9.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color14 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape8, stroke13, (java.awt.Paint) color14);
        java.awt.Paint paint16 = legendItem15.getFillPaint();
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.awt.Font font15 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 10);
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(font15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint18 = lineAndShapeRenderer0.getSeriesOutlinePaint((int) (byte) 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        java.util.List list9 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes(255, list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.Stroke stroke11 = categoryPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        java.util.List list6 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean6 = sortOrder0.equals((java.lang.Object) true);
        java.lang.String str7 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SortOrder.DESCENDING" + "'", str7.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        java.lang.Object obj7 = categoryPlot0.clone();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        boolean boolean15 = categoryPlot11.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot11.setDomainAxisLocation(axisLocation16);
        boolean boolean18 = categoryPlot11.isRangeZoomable();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D10, categoryPlot11, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        java.lang.Object obj18 = null;
        boolean boolean19 = categoryPlot5.equals(obj18);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        java.awt.Paint paint38 = categoryPlot34.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable39 = categoryPlot34.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot41 = categoryAxis40.getPlot();
        categoryPlot34.setDomainAxis(categoryAxis40);
        categoryPlot34.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint45 = categoryAxis44.getTickMarkPaint();
        categoryPlot34.setRangeZeroBaselinePaint(paint45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot47.setDomainAxis(0, categoryAxis49);
        java.awt.Paint paint51 = categoryPlot47.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot47.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = null;
        categoryPlot47.setDrawingSupplier(drawingSupplier53);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke59 = lineAndShapeRenderer55.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot47.setDomainGridlineStroke(stroke59);
        try {
            lineAndShapeRenderer0.drawRangeLine(graphics2D29, categoryPlot30, valueAxis31, rectangle2D32, (double) (-1), paint45, stroke59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(comparable39);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15, textAnchor16, (double) 0.0f);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition18);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 1.0d);
        boolean boolean2 = selectableValue1.isSelected();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        java.awt.Paint paint15 = categoryPlot11.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable16 = categoryPlot11.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot18 = categoryAxis17.getPlot();
        categoryPlot11.setDomainAxis(categoryAxis17);
        try {
            keyedObjects0.insertValue((int) (short) 100, (java.lang.Comparable) (-1), (java.lang.Object) categoryPlot11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker(255, marker6, layer7);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean31 = lineAndShapeRenderer29.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape33 = lineAndShapeRenderer29.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke38 = lineAndShapeRenderer34.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color39 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape33, stroke38, (java.awt.Paint) color39);
        try {
            lineAndShapeRenderer0.setSeriesShape((int) (byte) -1, shape33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 192 + "'", int21 == 192);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Image image4 = categoryPlot0.getBackgroundImage();
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryPlot0.equals(obj5);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.lang.String str3 = legendItem1.getToolTipText();
        java.lang.String str4 = legendItem1.getURLText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        java.lang.Boolean boolean17 = lineAndShapeRenderer0.getSeriesVisibleInLegend(10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Image image4 = categoryPlot0.getBackgroundImage();
        java.util.List list6 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes(0, list6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.PaintList paintList5 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean7 = paintList5.equals((java.lang.Object) itemLabelAnchor6);
        boolean boolean8 = categoryAxis0.equals((java.lang.Object) paintList5);
        java.awt.Paint paint10 = paintList5.getPaint((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        int int15 = lineAndShapeRenderer0.getPassCount();
        java.lang.Boolean boolean17 = lineAndShapeRenderer0.getSeriesShapesVisible((int) (byte) -1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (10) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines((int) '#');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.Plot plot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 100);
        int int10 = categoryPlot7.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot7.axisChanged(axisChangeEvent11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis(0, categoryAxis16);
        java.awt.Paint paint18 = categoryPlot14.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRenderer();
        java.awt.Stroke stroke20 = null;
        categoryPlot14.setOutlineStroke(stroke20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot14.getRangeAxisLocation((int) (byte) 0);
        categoryPlot7.setDomainAxisLocation((int) (short) 1, axisLocation24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot7.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = categoryAxis0.reserveSpace(graphics2D4, plot5, rectangle2D6, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot11.canSelectByPoint();
        lineAndShapeRenderer6.setPlot(categoryPlot11);
        categoryPlot11.setForegroundAlpha(0.0f);
        categoryPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        java.awt.Paint paint28 = categoryPlot24.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        java.awt.Stroke stroke30 = null;
        categoryPlot24.setOutlineStroke(stroke30);
        org.jfree.data.general.DatasetGroup datasetGroup32 = categoryPlot24.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot24.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation(axisLocation34);
        categoryPlot0.setDomainAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot38.getRangeAxisLocation((int) (byte) 100);
        java.util.List list41 = categoryPlot38.getAnnotations();
        try {
            categoryPlot0.mapDatasetToRangeAxes((-1), list41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNull(datasetGroup32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        boolean boolean12 = categoryPlot3.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("CategoryAnchor.MIDDLE");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE" + "'", str2.equals("org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        java.awt.Stroke stroke12 = null;
        categoryPlot6.setOutlineStroke(stroke12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        categoryPlot6.drawOutline(graphics2D14, rectangle2D15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot6.getRangeAxis();
        java.awt.Stroke stroke18 = categoryPlot6.getRangeGridlineStroke();
        categoryPlot6.setRangeGridlinesVisible(true);
        float float21 = categoryPlot6.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        int int23 = categoryAxis22.getCategoryLabelPositionOffset();
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int25 = color24.getGreen();
        categoryAxis22.setAxisLinePaint((java.awt.Paint) color24);
        boolean boolean27 = categoryAxis22.isMinorTickMarksVisible();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        try {
            barRenderer0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis22, valueAxis28, categoryDataset29, (int) (short) -1, 1, true, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 192 + "'", int25 == 192);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = lineAndShapeRenderer11.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint17 = lineAndShapeRenderer11.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean19 = lineAndShapeRenderer11.getSeriesShapesFilled((int) (short) 0);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis(0, categoryAxis25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot23.setFixedRangeAxisSpace(axisSpace27, true);
        boolean boolean30 = categoryPlot23.canSelectByPoint();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot23.getDomainAxis();
        int int32 = categoryPlot23.getCrosshairDatasetIndex();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D41 = lineAndShapeRenderer11.createHotSpotBounds(graphics2D21, rectangle2D22, categoryPlot23, categoryAxis33, valueAxis34, categoryDataset35, (int) (byte) -1, (int) (byte) 100, false, categoryItemRendererState39, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        boolean boolean3 = legendItem1.isShapeOutlineVisible();
        boolean boolean4 = legendItem1.isLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        categoryPlot0.mapDatasetToRangeAxis(10, (int) (byte) 100);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        int int8 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        abstractCategoryDataset0.validateObject();
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean11 = lineAndShapeRenderer9.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape13 = lineAndShapeRenderer9.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer14.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape13, stroke18, (java.awt.Paint) color19);
        java.awt.Color color24 = java.awt.Color.getColor("", (int) ' ');
        java.awt.Paint paint26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean31 = lineAndShapeRenderer29.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape33 = lineAndShapeRenderer29.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        java.awt.Paint paint38 = categoryPlot34.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot34.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot34.zoomDomainAxes((double) (short) -1, plotRenderingInfo41, point2D42);
        categoryPlot34.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity48 = new org.jfree.chart.entity.PlotEntity(shape33, (org.jfree.chart.plot.Plot) categoryPlot34, "SortOrder.DESCENDING");
        java.awt.Stroke stroke49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot50.setDomainAxis(0, categoryAxis52);
        java.awt.Paint paint54 = categoryPlot50.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot50.getRenderer();
        java.awt.Paint paint56 = categoryPlot50.getDomainGridlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "AxisLocation.TOP_OR_LEFT", "", false, shape13, true, (java.awt.Paint) color24, false, paint26, stroke27, false, shape33, stroke49, paint56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.Marker marker18 = null;
        boolean boolean19 = categoryPlot5.removeDomainMarker(marker18);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot11.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation((int) (short) 1, axisLocation28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        boolean boolean34 = categoryPlot30.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot30.getInsets();
        categoryPlot11.setAxisOffset(rectangleInsets35);
        categoryPlot0.setAxisOffset(rectangleInsets35);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets35.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType39, lengthAdjustmentType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("SortOrder.DESCENDING", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer5.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace14, true);
        boolean boolean17 = categoryPlot10.canSelectByPoint();
        lineAndShapeRenderer5.setPlot(categoryPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getRangeAxisEdge(10);
        try {
            double double21 = categoryAxis0.getCategoryStart((int) (short) 10, 2, rectangle2D4, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint18 = categoryPlot5.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot5.getInsets();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            rectangleInsets19.trim(rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        try {
            categoryPlot0.zoom((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis(0, categoryAxis15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace17, true);
        boolean boolean20 = categoryPlot13.canSelectByPoint();
        lineAndShapeRenderer8.setPlot(categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getRangeAxisEdge(10);
        try {
            double double24 = categoryAxis0.getCategoryMiddle(0, 0, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        java.awt.Paint paint10 = null;
        lineAndShapeRenderer0.setLegendTextPaint(0, paint10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke12, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Stroke stroke13 = null;
        categoryPlot7.setOutlineStroke(stroke13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        boolean boolean23 = categoryPlot19.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot19.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets24.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType27, lengthAdjustmentType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer10.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer10.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer10.setBaseCreateEntities(true);
        java.awt.Font font19 = lineAndShapeRenderer10.getBaseItemLabelFont();
        boolean boolean20 = keyedObjects0.equals((java.lang.Object) lineAndShapeRenderer10);
        java.lang.Comparable comparable21 = null;
        try {
            java.lang.Object obj22 = keyedObjects0.getObject(comparable21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint7 = legendItem6.getLinePaint();
        categoryPlot0.setRangeCrosshairPaint(paint7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("java.awt.Color[r=0,g=192,b=192]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=0,g=192,b=192], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace21, true);
        boolean boolean24 = categoryPlot17.canSelectByPoint();
        lineAndShapeRenderer12.setPlot(categoryPlot17);
        java.awt.Font font27 = lineAndShapeRenderer12.getSeriesItemLabelFont((int) (short) 10);
        try {
            keyedObjects0.insertValue((int) '4', (java.lang.Comparable) "", (java.lang.Object) font27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(font27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot5.removeDomainMarker(marker18, layer19);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Font font7 = categoryAxis0.getTickLabelFont(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean2 = strokeList0.equals((java.lang.Object) textAnchor1);
        boolean boolean4 = strokeList0.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemFillPaint(3, (int) ' ');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        try {
            renderAttributes0.setSeriesShape((-1), shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = java.awt.Color.getColor("CategoryAnchor.MIDDLE", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        try {
            lineAndShapeRenderer0.setItemMargin((double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        java.lang.Boolean boolean21 = lineAndShapeRenderer0.getSeriesCreateEntities(0);
        java.awt.Paint paint23 = null;
        try {
            lineAndShapeRenderer0.setSeriesOutlinePaint((int) (short) -1, paint23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setVisible(true);
        java.lang.String str17 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 3.0d);
        java.awt.Stroke stroke18 = null;
        try {
            categoryAxis0.setAxisLineStroke(stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator7, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Image image4 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setBackgroundImageAlignment(4);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis((int) ' ', valueAxis8, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot4.setOrientation(plotOrientation10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot4.getInsets();
        java.util.List list15 = categoryPlot4.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getRangeAxisLocation((int) (byte) 100);
        java.util.List list20 = categoryPlot17.getAnnotations();
        categoryPlot17.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis(0, categoryAxis30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot28.setFixedRangeAxisSpace(axisSpace32, true);
        boolean boolean35 = categoryPlot28.canSelectByPoint();
        lineAndShapeRenderer23.setPlot(categoryPlot28);
        categoryPlot28.setForegroundAlpha(0.0f);
        categoryPlot28.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot41.setDomainAxis(0, categoryAxis43);
        java.awt.Paint paint45 = categoryPlot41.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot41.getRenderer();
        java.awt.Stroke stroke47 = null;
        categoryPlot41.setOutlineStroke(stroke47);
        org.jfree.data.general.DatasetGroup datasetGroup49 = categoryPlot41.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot41.getRangeAxisLocation((int) (byte) 0);
        categoryPlot28.setDomainAxisLocation(axisLocation51);
        categoryPlot17.setDomainAxisLocation(axisLocation51);
        try {
            categoryPlot4.setDomainAxisLocation((int) (short) -1, axisLocation51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNull(datasetGroup49);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer19.setSeriesStroke(0, stroke27, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator30);
        categoryPlot5.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean41 = lineAndShapeRenderer39.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape43 = lineAndShapeRenderer39.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke48 = lineAndShapeRenderer44.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color49 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape43, stroke48, (java.awt.Paint) color49);
        lineAndShapeRenderer19.setSeriesShape(0, shape43, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = lineAndShapeRenderer19.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(boolean41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNull(categoryToolTipGenerator53);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = shapeList0.equals(obj7);
        java.lang.Object obj9 = shapeList0.clone();
        java.awt.Shape shape11 = shapeList0.getShape(255);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        categoryPlot2.setDrawingSupplier(drawingSupplier5, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot2.getInsets();
        int int9 = objectList1.indexOf((java.lang.Object) rectangleInsets8);
        double double11 = rectangleInsets8.calculateRightOutset((double) 100);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = lineAndShapeRenderer0.getItemLabelGenerator(0, 0, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(categoryItemLabelGenerator24);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject((int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        categoryPlot0.drawOutline(graphics2D16, rectangle2D17);
        boolean boolean19 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(255);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        boolean boolean8 = categoryPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint9 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        int int14 = lineAndShapeRenderer0.getRowCount();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int16 = color15.getGreen();
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color15, false);
        java.awt.color.ColorSpace colorSpace19 = null;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        int int22 = categoryAxis21.getCategoryLabelPositionOffset();
        java.awt.Font font23 = categoryAxis21.getTickLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis21.setAxisLinePaint((java.awt.Paint) color24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray31 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray32 = color26.getComponents(floatArray31);
        float[] floatArray33 = color24.getRGBComponents(floatArray32);
        float[] floatArray34 = color20.getColorComponents(floatArray32);
        try {
            float[] floatArray35 = color15.getComponents(colorSpace19, floatArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 192 + "'", int16 == 192);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot11.canSelectByPoint();
        lineAndShapeRenderer6.setPlot(categoryPlot11);
        categoryPlot11.setForegroundAlpha(0.0f);
        categoryPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        java.awt.Paint paint28 = categoryPlot24.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        java.awt.Stroke stroke30 = null;
        categoryPlot24.setOutlineStroke(stroke30);
        org.jfree.data.general.DatasetGroup datasetGroup32 = categoryPlot24.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot24.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation(axisLocation34);
        categoryPlot0.setDomainAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) -1, categoryMarker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNull(datasetGroup32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot0.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot0.setRangeAxis(255, valueAxis15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(15, categoryURLGenerator25);
        java.awt.Shape shape28 = lineAndShapeRenderer0.getSeriesShape((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 192 + "'", int21 == 192);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(shape28);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject((java.lang.Comparable) 100.0d, (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, 4, (int) 'a');
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot9.setDrawingSupplier(drawingSupplier12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot9.setDataset(categoryDataset15);
        categoryPlot9.configureRangeAxes();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        int int19 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean23 = lineAndShapeRenderer0.getItemLineVisible(100, (int) (byte) 1);
        boolean boolean25 = lineAndShapeRenderer0.isSeriesVisibleInLegend((int) '4');
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        int int8 = defaultShadowGenerator7.calculateOffsetX();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        boolean boolean18 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        java.lang.Comparable comparable2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        java.util.List list6 = categoryPlot3.getAnnotations();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis(0, categoryAxis15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace17, true);
        boolean boolean20 = categoryPlot13.canSelectByPoint();
        lineAndShapeRenderer8.setPlot(categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getRangeAxisEdge(10);
        try {
            double double24 = categoryAxis0.getCategoryMiddle(comparable2, list6, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        boolean boolean7 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getInsets();
        java.lang.String str6 = rectangleInsets5.toString();
        double double8 = rectangleInsets5.trimHeight((double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 92.0d + "'", double8 == 92.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean6 = sortOrder0.equals((java.lang.Object) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Paint paint13 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Stroke stroke14 = categoryPlot7.getOutlineStroke();
        boolean boolean15 = sortOrder0.equals((java.lang.Object) categoryPlot7);
        categoryPlot7.clearSelection();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Paint paint9 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes10.setDefaultOutlineStroke(stroke11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean16 = lineAndShapeRenderer14.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape18 = lineAndShapeRenderer14.lookupLegendShape(10);
        java.awt.Stroke stroke19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        boolean boolean28 = lineAndShapeRenderer20.hasListener((java.util.EventListener) categoryPlot24);
        java.awt.Color color30 = java.awt.Color.magenta;
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray36 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray37 = color31.getComponents(floatArray36);
        float[] floatArray38 = color30.getComponents(floatArray37);
        lineAndShapeRenderer20.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color30, true);
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "PlotEntity: tooltip = Category Plot", "hi!", "Category Plot", false, shape5, true, paint7, true, paint9, stroke11, false, shape18, stroke19, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean6 = lineAndShapeRenderer4.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape8 = lineAndShapeRenderer4.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes((double) (short) -1, plotRenderingInfo16, point2D17);
        categoryPlot9.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "SortOrder.DESCENDING");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int25 = color24.getGreen();
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", "", shape8, (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 192 + "'", int25 == 192);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Class<?> wildcardClass5 = categoryPlot0.getClass();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        java.util.Iterator iterator7 = legendItemCollection6.iterator();
        int int8 = legendItemCollection6.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem10 = legendItemCollection6.get((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(iterator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        categoryPlot2.setDrawingSupplier(drawingSupplier5, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot2.getInsets();
        int int9 = objectList1.indexOf((java.lang.Object) rectangleInsets8);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        objectList1.set(192, (java.lang.Object) itemLabelAnchor11);
        org.jfree.chart.util.ShapeList shapeList13 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean16 = lineAndShapeRenderer14.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean18 = lineAndShapeRenderer14.getSeriesItemLabelsVisible(0);
        boolean boolean19 = shapeList13.equals((java.lang.Object) 0);
        boolean boolean20 = objectList1.equals((java.lang.Object) boolean19);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        legendItem1.setToolTipText("");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = lineAndShapeRenderer5.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer5.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean13 = lineAndShapeRenderer5.isSeriesVisible((int) 'a');
        java.awt.Font font15 = lineAndShapeRenderer5.getSeriesItemLabelFont((int) (short) 1);
        java.awt.Paint paint19 = lineAndShapeRenderer5.getItemLabelPaint(3, (int) (byte) -1, false);
        legendItem1.setLabelPaint(paint19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot9.setFixedRangeAxisSpace(axisSpace13, true);
        boolean boolean16 = categoryPlot9.canSelectByPoint();
        lineAndShapeRenderer4.setPlot(categoryPlot9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean25 = lineAndShapeRenderer23.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape27 = lineAndShapeRenderer23.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke32 = lineAndShapeRenderer28.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color33 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape27, stroke32, (java.awt.Paint) color33);
        lineAndShapeRenderer4.setSeriesShape((int) (byte) 1, shape27, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke41 = lineAndShapeRenderer37.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot42.setDomainAxis(0, categoryAxis44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot42.setFixedRangeAxisSpace(axisSpace46, true);
        boolean boolean49 = categoryPlot42.canSelectByPoint();
        lineAndShapeRenderer37.setPlot(categoryPlot42);
        int int51 = lineAndShapeRenderer37.getRowCount();
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int53 = color52.getGreen();
        lineAndShapeRenderer37.setBaseItemLabelPaint((java.awt.Paint) color52, false);
        try {
            org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem(attributedString0, "", "", "CategoryAnchor.MIDDLE", shape27, (java.awt.Paint) color52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 192 + "'", int53 == 192);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.awt.Shape shape23 = plotEntity19.getArea();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotEntity19);
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        chartChangeEvent24.setChart(jFreeChart25);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot4.setOrientation(plotOrientation10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot4.getInsets();
        double double16 = rectangleInsets14.calculateRightOutset(3.0d);
        double double18 = rectangleInsets14.calculateRightOutset(3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 2.0d, true);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        boolean boolean18 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean20 = lineAndShapeRenderer0.isSeriesItemLabelsVisible(4);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        int int25 = categoryAxis24.getCategoryLabelPositionOffset();
        java.awt.Font font26 = categoryAxis24.getTickLabelFont();
        java.awt.Color color27 = java.awt.Color.pink;
        categoryAxis24.setTickLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = lineAndShapeRenderer34.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke44 = lineAndShapeRenderer40.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer34.setSeriesOutlineStroke(10, stroke44);
        java.awt.Paint paint46 = lineAndShapeRenderer34.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        categoryPlot49.setDomainAxis(0, categoryAxis51);
        java.awt.Paint paint53 = categoryPlot49.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = categoryPlot49.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier55 = null;
        categoryPlot49.setDrawingSupplier(drawingSupplier55);
        categoryPlot49.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState62 = lineAndShapeRenderer34.initialise(graphics2D47, rectangle2D48, categoryPlot49, categoryDataset60, plotRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D64 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D21, rectangle2D22, categoryPlot23, categoryAxis24, valueAxis29, categoryDataset30, (int) '4', 4, true, categoryItemRendererState62, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(categoryItemRenderer54);
        org.junit.Assert.assertNotNull(categoryItemRendererState62);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer0.getNegativeItemLabelPosition(0, 192, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        java.awt.Paint paint17 = lineAndShapeRenderer0.getSeriesFillPaint((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        int int20 = categoryAxis19.getCategoryLabelPositionOffset();
        java.awt.Font font21 = categoryAxis19.getTickLabelFont();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis19.setAxisLinePaint((java.awt.Paint) color22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = lineAndShapeRenderer29.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke39 = lineAndShapeRenderer35.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer29.setSeriesOutlineStroke(10, stroke39);
        java.awt.Paint paint41 = lineAndShapeRenderer29.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        categoryPlot44.setDomainAxis(0, categoryAxis46);
        java.awt.Paint paint48 = categoryPlot44.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot44.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = null;
        categoryPlot44.setDrawingSupplier(drawingSupplier50);
        categoryPlot44.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = lineAndShapeRenderer29.initialise(graphics2D42, rectangle2D43, categoryPlot44, categoryDataset55, plotRenderingInfo56);
        try {
            boolean boolean58 = lineAndShapeRenderer0.hitTest((double) (byte) 0, 0.0d, graphics2D16, rectangle2D17, categoryPlot18, categoryAxis19, valueAxis24, categoryDataset25, 9, (int) (byte) -1, false, categoryItemRendererState57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(categoryItemRendererState57);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier8, true);
        int int11 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.clearRangeMarkers(0);
        java.awt.Paint paint14 = categoryPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot0.removeChangeListener(plotChangeListener15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = null;
        try {
            categoryPlot0.setRangeAxes(valueAxisArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        lineAndShapeRenderer0.clearSeriesPaints(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        double double4 = barRenderer0.getShadowYOffset();
        java.lang.Boolean boolean6 = barRenderer0.getSeriesCreateEntities((int) ' ');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis14);
        boolean boolean16 = lineAndShapeRenderer8.hasListener((java.util.EventListener) categoryPlot12);
        java.awt.Color color18 = java.awt.Color.magenta;
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray24 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray25 = color19.getComponents(floatArray24);
        float[] floatArray26 = color18.getComponents(floatArray25);
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color18, true);
        java.awt.Color color29 = color18.darker();
        barRenderer0.setSeriesItemLabelPaint(3, (java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot10.setDataset(10, categoryDataset12);
        java.lang.String str14 = categoryPlot10.getPlotType();
        categoryPlot10.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) (short) 1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getRangeAxisEdge();
        try {
            java.util.List list21 = categoryAxis4.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryPlot0.setDomainAxis(categoryAxis6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot5.zoomDomainAxes(1.0d, (-1.0d), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot5.zoomRangeAxes((double) ' ', (double) ' ', plotRenderingInfo25, point2D26);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        java.awt.Shape shape8 = shapeList0.getShape((int) '#');
        java.lang.Object obj9 = shapeList0.clone();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.awt.Shape shape23 = plotEntity19.getArea();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotEntity19);
        java.awt.Shape shape25 = plotEntity19.getArea();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis(9);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        java.lang.Object obj4 = legendItem1.clone();
        legendItem1.setSeriesKey((java.lang.Comparable) 255);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer14.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace23, true);
        boolean boolean26 = categoryPlot19.canSelectByPoint();
        lineAndShapeRenderer14.setPlot(categoryPlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getRangeAxisEdge(10);
        try {
            double double30 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (-17.0d), (java.lang.Comparable) (byte) 10, categoryDataset11, (double) 10L, rectangle2D13, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        java.awt.Paint paint23 = categoryPlot19.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable24 = categoryPlot19.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot26 = categoryAxis25.getPlot();
        categoryPlot19.setDomainAxis(categoryAxis25);
        int int28 = categoryAxis25.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getRangeAxisLocation((int) (byte) 100);
        int int33 = categoryPlot30.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = null;
        categoryPlot30.axisChanged(axisChangeEvent34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis(0, categoryAxis39);
        java.awt.Paint paint41 = categoryPlot37.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot37.getRenderer();
        java.awt.Stroke stroke43 = null;
        categoryPlot37.setOutlineStroke(stroke43);
        org.jfree.data.general.DatasetGroup datasetGroup45 = categoryPlot37.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot37.getRangeAxisLocation((int) (byte) 0);
        categoryPlot30.setDomainAxisLocation((int) (short) 1, axisLocation47);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot30.getDomainAxisEdge((int) (short) 100);
        try {
            double double51 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 10.0f, (java.lang.Comparable) 0, categoryDataset18, categoryAxis25, rectangle2D29, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(comparable24);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNull(datasetGroup45);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        boolean boolean9 = lineAndShapeRenderer1.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer1.setLegendTextFont(0, font11);
        java.awt.Stroke stroke16 = lineAndShapeRenderer1.getItemStroke(0, 15, false);
        boolean boolean17 = paintList0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        categoryAxis8.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) "-3,-3,3,3", (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-3,-3,3,3) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Paint paint14 = lineAndShapeRenderer0.getSeriesItemLabelPaint((int) (short) 10);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Stroke stroke13 = null;
        categoryPlot7.setOutlineStroke(stroke13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        boolean boolean23 = categoryPlot19.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot19.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets24);
        double double26 = rectangleInsets24.getTop();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) -1, (java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Font font19 = lineAndShapeRenderer0.getItemLabelFont((int) '#', (int) (short) 1, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        int int24 = categoryAxis23.getCategoryLabelPositionOffset();
        java.awt.Font font25 = categoryAxis23.getTickLabelFont();
        float float26 = categoryAxis23.getMinorTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke32 = lineAndShapeRenderer28.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis(0, categoryAxis35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot33.setFixedRangeAxisSpace(axisSpace37, true);
        boolean boolean40 = categoryPlot33.canSelectByPoint();
        lineAndShapeRenderer28.setPlot(categoryPlot33);
        categoryPlot33.setForegroundAlpha(0.0f);
        categoryPlot33.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot33.getRangeAxisEdge((int) (byte) 0);
        try {
            double double48 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 100.0f, (java.lang.Comparable) "AxisLocation.TOP_OR_LEFT", categoryDataset22, categoryAxis23, rectangle2D27, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        int int5 = lineAndShapeRenderer0.getColumnCount();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Paint paint8 = null;
        try {
            lineAndShapeRenderer0.setBaseOutlinePaint(paint8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) -1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10, true);
        boolean boolean13 = categoryPlot6.canSelectByPoint();
        lineAndShapeRenderer1.setPlot(categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot6.getDataRange(valueAxis17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        java.awt.Color color23 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color23);
        org.jfree.data.KeyedObject keyedObject27 = new org.jfree.data.KeyedObject((java.lang.Comparable) 3.0d, (java.lang.Object) categoryPlot6);
        java.lang.Object obj28 = keyedObject27.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("SortOrder.DESCENDING", "hi!", "CategoryAnchor.MIDDLE", "PlotEntity: tooltip = Category Plot", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint30 = lineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((double) 1);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean8 = lineAndShapeRenderer6.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape10 = lineAndShapeRenderer6.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        java.awt.Paint paint15 = categoryPlot11.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot11.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot11.zoomDomainAxes((double) (short) -1, plotRenderingInfo18, point2D19);
        categoryPlot11.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "SortOrder.DESCENDING");
        plotEntity25.setToolTipText("Category Plot");
        java.lang.String str28 = plotEntity25.getShapeCoords();
        java.awt.Shape shape29 = plotEntity25.getArea();
        barRenderer0.setBaseShape(shape29);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-3,-3,3,3" + "'", str28.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer2.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer2.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        categoryPlot10.setDrawingSupplier(drawingSupplier13, false);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot10.setDataset(categoryDataset16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis18, marker19, rectangle2D20);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer2.getBaseURLGenerator();
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color24);
        boolean boolean26 = standardGradientPaintTransformer0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        double double8 = defaultShadowGenerator7.getAngle();
        java.awt.image.BufferedImage bufferedImage9 = null;
        try {
            java.awt.image.BufferedImage bufferedImage10 = defaultShadowGenerator7.createDropShadow(bufferedImage9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.geom.GeneralPath generalPath4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.RenderingSource renderingSource6 = null;
        categoryPlot0.select(generalPath4, rectangle2D5, renderingSource6);
        categoryPlot0.mapDatasetToDomainAxis(4, 10);
        java.lang.Comparable comparable11 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace21, true);
        boolean boolean24 = categoryPlot17.canSelectByPoint();
        lineAndShapeRenderer12.setPlot(categoryPlot17);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot17.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot17.getDataRange(valueAxis28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean33 = lineAndShapeRenderer31.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke39 = lineAndShapeRenderer35.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer31.setSeriesStroke(0, stroke39, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator42 = null;
        lineAndShapeRenderer31.setBaseToolTipGenerator(categoryToolTipGenerator42);
        categoryPlot17.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot46.setDomainAxis(0, categoryAxis48);
        java.awt.Paint paint50 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot46.getRenderer();
        java.awt.Stroke stroke52 = null;
        categoryPlot46.setOutlineStroke(stroke52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        categoryPlot46.drawOutline(graphics2D54, rectangle2D55);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot46.getRangeAxis();
        java.awt.Stroke stroke58 = categoryPlot46.getRangeGridlineStroke();
        lineAndShapeRenderer31.setBaseOutlineStroke(stroke58);
        categoryPlot0.setDomainCrosshairStroke(stroke58);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.plot.Marker marker14 = null;
        try {
            categoryPlot5.addRangeMarker(marker14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = java.awt.Color.magenta;
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setShapeVisible(false);
        legendItem1.setURLText("SortOrder.DESCENDING");
        java.lang.String str9 = legendItem1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.ShadowGenerator shadowGenerator9 = categoryPlot0.getShadowGenerator();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(shadowGenerator9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = java.awt.Color.magenta;
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setShapeVisible(false);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem1.setLabelFont(font7);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer9 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = standardGradientPaintTransformer9.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType10);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        java.lang.Object obj13 = standardGradientPaintTransformer11.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=255,b=64]", paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot5.setDrawingSupplier(drawingSupplier11);
        java.awt.Font font13 = categoryPlot5.getNoDataMessageFont();
        boolean boolean14 = chartChangeEventType4.equals((java.lang.Object) font13);
        boolean boolean15 = keyedObjects2D0.equals((java.lang.Object) font13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, false);
        boolean boolean13 = lineAndShapeRenderer0.getUseOutlinePaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = lineAndShapeRenderer15.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke25 = lineAndShapeRenderer21.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer15.setSeriesOutlineStroke(10, stroke25);
        java.awt.Paint paint27 = lineAndShapeRenderer15.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        java.awt.Paint paint34 = categoryPlot30.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot30.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = null;
        categoryPlot30.setDrawingSupplier(drawingSupplier36);
        categoryPlot30.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = lineAndShapeRenderer15.initialise(graphics2D28, rectangle2D29, categoryPlot30, categoryDataset41, plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot45.setDomainAxis(0, categoryAxis47);
        java.awt.Paint paint49 = categoryPlot45.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot45.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot45.zoomDomainAxes((double) (short) -1, plotRenderingInfo52, point2D53);
        categoryPlot45.setCrosshairDatasetIndex(10, true);
        int int58 = categoryPlot45.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        categoryPlot59.setDomainAxis(0, categoryAxis61);
        java.awt.Paint paint63 = categoryPlot59.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = categoryPlot59.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier65 = null;
        categoryPlot59.setDrawingSupplier(drawingSupplier65);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke71 = lineAndShapeRenderer67.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot59.setDomainGridlineStroke(stroke71);
        categoryPlot45.setRangeCrosshairStroke(stroke71);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        int int75 = categoryAxis74.getCategoryLabelPositionOffset();
        java.awt.Font font77 = categoryAxis74.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis74.setTickMarksVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.data.category.CategoryDataset categoryDataset81 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D14, categoryItemRendererState43, rectangle2D44, categoryPlot45, categoryAxis74, valueAxis80, categoryDataset81, 0, 8, false, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertNotNull(categoryItemRendererState43);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 15 + "'", int58 == 15);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNull(categoryItemRenderer64);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
        org.junit.Assert.assertNotNull(font77);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray10 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray11 = color5.getComponents(floatArray10);
        float[] floatArray12 = color3.getRGBComponents(floatArray11);
        int int13 = color3.getTransparency();
        java.awt.Color color14 = color3.darker();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryPlot0.setDomainAxis(categoryAxis6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint11 = categoryAxis10.getTickMarkPaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint11);
        int int13 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot0.setRangeAxis((int) (byte) 1, valueAxis15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        boolean boolean12 = lineAndShapeRenderer0.getItemCreateEntity(0, (-1), false);
        double double13 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator14, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font9 = lineAndShapeRenderer0.getBaseLegendTextFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        java.awt.Paint paint14 = categoryPlot10.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot10.getRenderer();
        java.awt.Stroke stroke16 = null;
        categoryPlot10.setOutlineStroke(stroke16);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer0.getSeriesToolTipGenerator(4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setMinorTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        int int14 = lineAndShapeRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.util.StrokeList strokeList17 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean19 = strokeList17.equals((java.lang.Object) textAnchor18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor18);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition20);
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean23 = renderAttributes22.getAllowNull();
        java.awt.Stroke stroke24 = renderAttributes22.getDefaultStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = lineAndShapeRenderer25.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer25.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot33.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = null;
        categoryPlot33.setDrawingSupplier(drawingSupplier36, false);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot33.setDataset(categoryDataset39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.Marker marker42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        lineAndShapeRenderer25.drawRangeMarker(graphics2D32, categoryPlot33, valueAxis41, marker42, rectangle2D43);
        java.awt.Stroke stroke45 = categoryPlot33.getRangeGridlineStroke();
        renderAttributes22.setDefaultStroke(stroke45);
        lineAndShapeRenderer0.setBaseStroke(stroke45, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNull(categoryURLGenerator29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Color color9 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes10.setDefaultOutlineStroke(stroke11);
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot15.setFixedRangeAxisSpace(axisSpace19, true);
        categoryPlot15.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke25 = categoryPlot15.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean27 = renderAttributes26.getAllowNull();
        java.awt.Stroke stroke28 = renderAttributes26.getDefaultStroke();
        java.awt.Color color29 = java.awt.Color.red;
        renderAttributes26.setDefaultFillPaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape5, true, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke11, false, shape14, stroke25, (java.awt.Paint) color29);
        int int32 = color7.getBlue();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        double double9 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lineAndShapeRenderer29.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis(0, categoryAxis35);
        boolean boolean37 = lineAndShapeRenderer29.hasListener((java.util.EventListener) categoryPlot33);
        java.awt.Stroke stroke38 = categoryPlot33.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot33.setOrientation(plotOrientation39);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = null;
        categoryPlot33.setDrawingSupplier(drawingSupplier41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryPlot33.getInsets();
        lineAndShapeRenderer0.setPlot(categoryPlot33);
        java.awt.Shape shape46 = lineAndShapeRenderer0.lookupLegendShape(9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean49 = lineAndShapeRenderer48.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = lineAndShapeRenderer48.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(255, itemLabelPosition51);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int13 = color12.getGreen();
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.PaintList paintList15 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean17 = paintList15.equals((java.lang.Object) itemLabelAnchor16);
        boolean boolean18 = categoryAxis10.equals((java.lang.Object) paintList15);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        double double25 = barRenderer24.getItemMargin();
        barRenderer24.setMaximumBarWidth((double) 1);
        barRenderer24.setMaximumBarWidth((double) 0L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer24.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke37 = lineAndShapeRenderer33.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = lineAndShapeRenderer33.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot42.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = null;
        categoryPlot42.setDrawingSupplier(drawingSupplier45, false);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        categoryPlot42.setDataset(categoryDataset48);
        categoryPlot42.configureRangeAxes();
        lineAndShapeRenderer33.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot42);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState54 = barRenderer24.initialise(graphics2D31, rectangle2D32, categoryPlot42, categoryDataset52, plotRenderingInfo53);
        try {
            boolean boolean55 = lineAndShapeRenderer0.hitTest(0.05d, 0.05d, graphics2D7, rectangle2D8, categoryPlot9, categoryAxis10, valueAxis19, categoryDataset20, (int) (short) 1, 100, true, categoryItemRendererState54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(categoryItemRendererState54);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint3 = renderAttributes0.getSeriesPaint((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        java.awt.Paint paint13 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = null;
        categoryPlot30.setDrawingSupplier(drawingSupplier33, false);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot30.setDataset(categoryDataset36);
        categoryPlot30.configureRangeAxes();
        categoryPlot30.setNoDataMessage("hi!");
        java.awt.Stroke stroke41 = categoryPlot30.getDomainGridlineStroke();
        try {
            lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) -1, stroke41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int13 = color12.getGreen();
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color12);
        categoryPlot0.setDomainAxis(10, categoryAxis10, false);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = categoryPlot0.removeRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesCreateEntities((int) '4');
        lineAndShapeRenderer0.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setVisible(false);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer22.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis(0, categoryAxis29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace31, true);
        boolean boolean34 = categoryPlot27.canSelectByPoint();
        lineAndShapeRenderer22.setPlot(categoryPlot27);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot27.getRangeAxisEdge(10);
        try {
            double double38 = categoryAxis0.getCategorySeriesMiddle(10, 8, 4, 2, (double) 10, rectangle2D21, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot7.zoomDomainAxes((double) (short) -1, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        int int18 = categoryAxis17.getCategoryLabelPositionOffset();
        java.awt.Font font20 = categoryAxis17.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis17.setTickMarksVisible(false);
        double double23 = categoryAxis17.getFixedDimension();
        java.lang.Object obj24 = categoryAxis17.clone();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = lineAndShapeRenderer30.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke40 = lineAndShapeRenderer36.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer30.setSeriesOutlineStroke(10, stroke40);
        java.awt.Paint paint42 = lineAndShapeRenderer30.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot45.setDomainAxis(0, categoryAxis47);
        java.awt.Paint paint49 = categoryPlot45.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot45.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier51 = null;
        categoryPlot45.setDrawingSupplier(drawingSupplier51);
        categoryPlot45.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState58 = lineAndShapeRenderer30.initialise(graphics2D43, rectangle2D44, categoryPlot45, categoryDataset56, plotRenderingInfo57);
        try {
            java.awt.Shape shape59 = lineAndShapeRenderer0.createHotSpotShape(graphics2D5, rectangle2D6, categoryPlot7, categoryAxis17, valueAxis25, categoryDataset26, 0, (int) (short) 100, false, categoryItemRendererState58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(categoryItemRendererState58);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        int int5 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Font font6 = categoryAxis4.getTickLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray14 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = color7.getRGBComponents(floatArray15);
        float[] floatArray17 = color3.getColorComponents(floatArray15);
        float[] floatArray18 = java.awt.Color.RGBtoHSB(10, 100, 8, floatArray15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray6 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray7 = color1.getComponents(floatArray6);
        float[] floatArray8 = color0.getComponents(floatArray7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int10 = color9.getGreen();
        java.awt.color.ColorSpace colorSpace11 = color9.getColorSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        int int13 = categoryAxis12.getCategoryLabelPositionOffset();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis12.setAxisLinePaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray22 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray23 = color17.getComponents(floatArray22);
        float[] floatArray24 = color15.getRGBComponents(floatArray23);
        float[] floatArray25 = color0.getColorComponents(colorSpace11, floatArray23);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 192 + "'", int10 == 192);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        org.jfree.data.general.Dataset dataset3 = legendItem1.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 1.0d);
        java.lang.Number number2 = selectableValue1.getValue();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.0d + "'", number2.equals(1.0d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.panDomainAxes((double) 9, plotRenderingInfo5, point2D6);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setURLText("");
        legendItem1.setLineVisible(false);
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) 1L, (float) ' ', 1.0f);
        legendItem1.setFillPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke10 = lineAndShapeRenderer0.lookupSeriesStroke(0);
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer0.setBasePaint(paint11, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14);
        lineAndShapeRenderer0.setUseFillPaint(false);
        int int18 = lineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        java.lang.Object obj8 = keyedObjects0.clone();
        java.lang.Comparable comparable9 = null;
        try {
            int int10 = keyedObjects0.getIndex(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        boolean boolean5 = categoryPlot0.isDomainPannable();
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder6);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 1, categoryToolTipGenerator10);
        java.awt.Color color12 = java.awt.Color.orange;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer19.setSeriesStroke(0, stroke27, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator30);
        categoryPlot5.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = null;
        lineAndShapeRenderer19.setSeriesItemLabelGenerator((int) (short) 100, categoryItemLabelGenerator35, true);
        java.awt.Paint paint38 = lineAndShapeRenderer19.getBasePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = null;
        try {
            barRenderer0.setBarPainter(barPainter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers(10, layer9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes0.setDefaultOutlineStroke(stroke1);
        java.awt.Paint paint4 = renderAttributes0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Color color10 = java.awt.Color.magenta;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray16 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray17 = color11.getComponents(floatArray16);
        float[] floatArray18 = color10.getComponents(floatArray17);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, true);
        int int21 = color10.getGreen();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.setMinorTickMarkInsideLength(0.0f);
        int int8 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible((int) (short) 100);
        barRenderer0.setItemMargin((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke14 = lineAndShapeRenderer10.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer10.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        categoryPlot19.setDrawingSupplier(drawingSupplier22, false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot19.setDataset(categoryDataset25);
        categoryPlot19.configureRangeAxes();
        lineAndShapeRenderer10.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot19);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot19.removeDomainMarker(1, marker30, layer31);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean38 = lineAndShapeRenderer36.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape40 = lineAndShapeRenderer36.lookupLegendShape(10);
        java.awt.Paint paint44 = lineAndShapeRenderer36.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint45 = lineAndShapeRenderer36.getBaseLegendTextPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = lineAndShapeRenderer46.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint52 = lineAndShapeRenderer46.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer46.setBaseItemLabelPaint((java.awt.Paint) color53, false);
        lineAndShapeRenderer36.setBasePaint((java.awt.Paint) color53);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean60 = lineAndShapeRenderer57.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        categoryPlot61.setDomainAxis(0, categoryAxis63);
        boolean boolean65 = lineAndShapeRenderer57.hasListener((java.util.EventListener) categoryPlot61);
        java.awt.Stroke stroke67 = lineAndShapeRenderer57.lookupSeriesStroke(0);
        try {
            lineAndShapeRenderer0.drawRangeLine(graphics2D9, categoryPlot19, valueAxis33, rectangle2D34, 0.0d, (java.awt.Paint) color53, stroke67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(boolean38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint15 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-17.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Stroke stroke6 = barRenderer0.getSeriesOutlineStroke((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.util.ShapeList shapeList10 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean13 = lineAndShapeRenderer11.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean15 = lineAndShapeRenderer11.getSeriesItemLabelsVisible(0);
        boolean boolean16 = shapeList10.equals((java.lang.Object) 0);
        org.jfree.chart.util.ShapeList shapeList17 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean20 = lineAndShapeRenderer18.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean22 = lineAndShapeRenderer18.getSeriesItemLabelsVisible(0);
        boolean boolean23 = shapeList17.equals((java.lang.Object) 0);
        boolean boolean24 = shapeList10.equals((java.lang.Object) 0);
        java.lang.Object obj25 = shapeList10.clone();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean27 = shapeList10.equals((java.lang.Object) axisLocation26);
        categoryPlot0.setRangeAxisLocation(axisLocation26, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 4);
        java.lang.Number number2 = selectableValue1.getValue();
        java.lang.Number number3 = selectableValue1.getValue();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 4 + "'", number2.equals(4));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 4 + "'", number3.equals(4));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot5.zoomDomainAxes(1.0d, (-1.0d), plotRenderingInfo20, point2D21);
        categoryPlot5.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getInsets();
        java.lang.String str6 = rectangleInsets5.toString();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets5.getUnitType();
        double double9 = rectangleInsets5.calculateBottomOutset((double) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        lineAndShapeRenderer0.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot6.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        int int15 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) ' ', categoryAxis14);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis14.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D22, rectangleEdge23);
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 100L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D4, rectangle2D5, categoryAxis14, valueAxis27, layer28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 10, plotRenderingInfo14, point2D15);
        java.util.List list17 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        java.lang.String str20 = plotEntity19.getToolTipText();
        java.awt.Shape shape21 = null;
        try {
            plotEntity19.setArea(shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "SortOrder.DESCENDING" + "'", str20.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        barRenderer0.setSeriesVisibleInLegend(15, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot9.setDrawingSupplier(drawingSupplier12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot9.setDataset(categoryDataset15);
        categoryPlot9.configureRangeAxes();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot9.removeDomainMarker(1, marker20, layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis(0, categoryAxis25);
        java.awt.Paint paint27 = categoryPlot23.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot23.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot23.getLegendItems();
        categoryPlot9.setFixedLegendItems(legendItemCollection29);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(legendItemCollection29);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        categoryPlot0.setWeight(0);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean14 = categoryPlot0.removeRangeMarker(0, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot18.setDataset(10, categoryDataset20);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot25.setDomainAxis(0, categoryAxis27);
        java.awt.Paint paint29 = categoryPlot25.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot25.getRenderer();
        java.awt.Stroke stroke31 = null;
        categoryPlot25.setOutlineStroke(stroke31);
        org.jfree.data.general.DatasetGroup datasetGroup33 = categoryPlot25.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot25.getRangeAxisLocation((int) (byte) 0);
        categoryPlot18.setRangeAxisLocation(0, axisLocation35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState39 = lineAndShapeRenderer0.initialise(graphics2D16, rectangle2D17, categoryPlot18, categoryDataset37, plotRenderingInfo38);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean43 = lineAndShapeRenderer41.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape45 = lineAndShapeRenderer41.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot46.setDomainAxis(0, categoryAxis48);
        java.awt.Paint paint50 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot46.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot46.zoomDomainAxes((double) (short) -1, plotRenderingInfo53, point2D54);
        categoryPlot46.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity60 = new org.jfree.chart.entity.PlotEntity(shape45, (org.jfree.chart.plot.Plot) categoryPlot46, "SortOrder.DESCENDING");
        try {
            lineAndShapeRenderer0.setSeriesShape((-1), shape45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNull(datasetGroup33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(categoryItemRendererState39);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(categoryItemRenderer51);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Stroke stroke4 = renderAttributes0.getItemStroke((-1), (int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot5.setDrawingSupplier(drawingSupplier11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke17 = lineAndShapeRenderer13.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot5.setDomainGridlineStroke(stroke17);
        renderAttributes0.setDefaultOutlineStroke(stroke17);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean7 = renderAttributes6.getAllowNull();
        java.awt.Paint paint10 = renderAttributes6.getItemPaint((int) (short) 0, (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("");
        boolean boolean13 = legendItem12.isShapeFilled();
        java.awt.Color color14 = java.awt.Color.magenta;
        legendItem12.setFillPaint((java.awt.Paint) color14);
        renderAttributes6.setDefaultPaint((java.awt.Paint) color14);
        barRenderer0.setShadowPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        boolean boolean3 = legendItem1.isShapeOutlineVisible();
        legendItem1.setLineVisible(false);
        java.awt.Stroke stroke6 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot5.getDatasetGroup();
        boolean boolean19 = categoryPlot5.isDomainCrosshairVisible();
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot5.setRangeAxis(15, valueAxis22, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.awt.Shape shape23 = plotEntity19.getArea();
        plotEntity19.setToolTipText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(false);
        int int16 = lineAndShapeRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean12 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(0);
        boolean boolean13 = shapeList7.equals((java.lang.Object) 0);
        boolean boolean14 = shapeList0.equals((java.lang.Object) 0);
        java.lang.Object obj15 = shapeList0.clone();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean17 = shapeList0.equals((java.lang.Object) axisLocation16);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape19);
        shapeList0.setShape((int) (byte) 10, shape19);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity27 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "AxisLocation.TOP_OR_LEFT", "", categoryDataset24, (java.lang.Comparable) 1.0f, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        java.lang.String str5 = categoryAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0.05) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean16 = sortOrder10.equals((java.lang.Object) true);
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker(100, marker19, layer20);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean12 = lineAndShapeRenderer0.isItemLabelVisible((-1), (int) (short) -1, true);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.lookupSeriesStroke((int) (byte) 10);
        java.awt.Paint paint16 = lineAndShapeRenderer0.lookupSeriesPaint(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setNoDataMessage("hi!");
        java.awt.Stroke stroke11 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        java.awt.Paint paint10 = null;
        lineAndShapeRenderer0.setLegendTextPaint(0, paint10);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        lineAndShapeRenderer0.notifyListeners(rendererChangeEvent14);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("");
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Color color4 = java.awt.Color.magenta;
        legendItem2.setFillPaint((java.awt.Paint) color4);
        legendItem2.setShapeVisible(false);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem2.setLabelFont(font8);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem2.getFillPaintTransformer();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) legendItem2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot0.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        int int15 = lineAndShapeRenderer0.getPassCount();
        boolean boolean16 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 100);
        java.lang.Boolean boolean33 = lineAndShapeRenderer0.getSeriesVisible(192);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart5, chartChangeEventType6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent7.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent7.setType(chartChangeEventType9);
        chartChangeEvent3.setType(chartChangeEventType9);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNull(jFreeChart12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        keyedObjects0.clear();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("");
        boolean boolean12 = legendItem11.isShapeFilled();
        java.awt.Color color13 = java.awt.Color.magenta;
        legendItem11.setFillPaint((java.awt.Paint) color13);
        legendItem11.setShapeVisible(false);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem11.setLabelFont(font17);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType20 = standardGradientPaintTransformer19.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer21 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType20);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        try {
            keyedObjects0.insertValue((int) (byte) 10, (java.lang.Comparable) '4', (java.lang.Object) standardGradientPaintTransformer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(gradientPaintTransformType20);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.data.KeyedObjects keyedObjects9 = new org.jfree.data.KeyedObjects();
        int int11 = keyedObjects9.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot14 = categoryAxis13.getPlot();
        keyedObjects9.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis13);
        java.util.List list16 = keyedObjects9.getKeys();
        categoryPlot0.mapDatasetToRangeAxes((int) (byte) 1, list16);
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        java.awt.Shape shape17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        lineAndShapeRenderer0.setSeriesShape(0, shape17, false);
        boolean boolean20 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Font font19 = lineAndShapeRenderer0.getItemLabelFont((int) '#', (int) (short) 1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke24 = lineAndShapeRenderer20.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer20.setBaseURLGenerator(categoryURLGenerator25, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean30 = lineAndShapeRenderer28.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke36 = lineAndShapeRenderer32.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer28.setSeriesStroke(0, stroke36, true);
        java.awt.Font font40 = lineAndShapeRenderer28.getLegendTextFont(0);
        lineAndShapeRenderer28.setBaseCreateEntities(false);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer28.setSeriesItemLabelPaint((int) (short) 0, paint44);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = lineAndShapeRenderer28.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        lineAndShapeRenderer20.setBaseNegativeItemLabelPosition(itemLabelPosition47);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition47);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(font40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(0, valueAxis9, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis14);
        java.awt.Paint paint16 = categoryPlot12.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot12.getRenderer();
        java.awt.Stroke stroke18 = null;
        categoryPlot12.setOutlineStroke(stroke18);
        org.jfree.data.general.DatasetGroup datasetGroup20 = categoryPlot12.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot12.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation(axisLocation22, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        int int26 = categoryAxis25.getCategoryLabelPositionOffset();
        java.awt.Font font27 = categoryAxis25.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis(0, categoryAxis30);
        java.awt.Paint paint32 = categoryPlot28.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot28.getRenderer();
        java.awt.Paint paint34 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot28.getFixedLegendItems();
        categoryAxis25.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        java.awt.Paint paint37 = categoryAxis25.getTickLabelPaint();
        java.awt.Paint paint38 = categoryAxis25.getTickMarkPaint();
        categoryPlot0.setDomainAxis(categoryAxis25);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNull(datasetGroup20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = lineAndShapeRenderer5.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer5.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean13 = lineAndShapeRenderer5.isSeriesVisible((int) 'a');
        lineAndShapeRenderer5.setBaseLinesVisible(true);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer5.setBasePaint(paint16, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        lineAndShapeRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator19);
        lineAndShapeRenderer5.setUseFillPaint(false);
        java.awt.Stroke stroke24 = lineAndShapeRenderer5.lookupSeriesOutlineStroke(2);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int26 = color25.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.TOP_OR_LEFT", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "", shape4, stroke24, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(categoryPlot29);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Font font4 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font5 = categoryAxis0.getLabelFont();
        java.lang.Object obj6 = categoryAxis0.clone();
        categoryAxis0.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint();
        float float13 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot18.setDataset(10, categoryDataset20);
        java.lang.String str22 = categoryPlot18.getPlotType();
        categoryPlot18.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        categoryPlot18.setDomainCrosshairRowKey((java.lang.Comparable) (short) 1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = categoryAxis0.draw(graphics2D14, 8.0d, rectangle2D16, rectangle2D17, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = lineAndShapeRenderer4.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer4.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean12 = lineAndShapeRenderer4.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        lineAndShapeRenderer4.setSeriesURLGenerator((int) 'a', categoryURLGenerator14);
        keyedObjects2D0.addObject((java.lang.Object) lineAndShapeRenderer4, (java.lang.Comparable) (byte) 100, (java.lang.Comparable) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        int int20 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = lineAndShapeRenderer23.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer23.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = null;
        categoryPlot31.setDrawingSupplier(drawingSupplier34, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot31.setDataset(categoryDataset37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.Marker marker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        lineAndShapeRenderer23.drawRangeMarker(graphics2D30, categoryPlot31, valueAxis39, marker40, rectangle2D41);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator43 = lineAndShapeRenderer23.getBaseURLGenerator();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer23.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color45);
        categoryAxis19.setLabelPaint((java.awt.Paint) color45);
        lineAndShapeRenderer4.setBaseItemLabelPaint((java.awt.Paint) color45, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = lineAndShapeRenderer4.getBaseToolTipGenerator();
        lineAndShapeRenderer4.setSeriesVisible((int) (short) 10, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(categoryURLGenerator43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(categoryToolTipGenerator50);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = lineAndShapeRenderer0.getDrawingSupplier();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke11 = lineAndShapeRenderer7.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot12.setFixedRangeAxisSpace(axisSpace16, true);
        boolean boolean19 = categoryPlot12.canSelectByPoint();
        lineAndShapeRenderer7.setPlot(categoryPlot12);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot12.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot12.getDataRange(valueAxis23);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean28 = lineAndShapeRenderer26.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke34 = lineAndShapeRenderer30.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer26.setSeriesStroke(0, stroke34, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        lineAndShapeRenderer26.setBaseToolTipGenerator(categoryToolTipGenerator37);
        categoryPlot12.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer26, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot41.setDomainAxis(0, categoryAxis43);
        java.awt.Paint paint45 = categoryPlot41.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot41.getRenderer();
        java.awt.Stroke stroke47 = null;
        categoryPlot41.setOutlineStroke(stroke47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        categoryPlot41.drawOutline(graphics2D49, rectangle2D50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot41.getRangeAxis();
        java.awt.Stroke stroke53 = categoryPlot41.getRangeGridlineStroke();
        lineAndShapeRenderer26.setBaseOutlineStroke(stroke53);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_CYAN;
        lineAndShapeRenderer26.setSeriesFillPaint(3, (java.awt.Paint) color56, false);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color56, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.clearSeriesStrokes(false);
        boolean boolean7 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        boolean boolean15 = categoryPlot11.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot11.setDomainAxisLocation(axisLocation16);
        categoryPlot0.setDomainAxisLocation(0, axisLocation16, false);
        boolean boolean20 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Font font10 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer0.getItemLabelPaint(3, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lineAndShapeRenderer18.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        boolean boolean26 = lineAndShapeRenderer18.hasListener((java.util.EventListener) categoryPlot22);
        java.awt.Stroke stroke27 = categoryPlot22.getDomainCrosshairStroke();
        boolean boolean28 = textAnchor17.equals((java.lang.Object) categoryPlot22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke33 = lineAndShapeRenderer29.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer29.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.text.TextAnchor textAnchor38 = itemLabelPosition37.getTextAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor17, textAnchor38, (double) (short) 100);
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition40, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = lineAndShapeRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNull(drawingSupplier43);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke24 = lineAndShapeRenderer20.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot25.setDomainAxis(0, categoryAxis27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot25.setFixedRangeAxisSpace(axisSpace29, true);
        boolean boolean32 = categoryPlot25.canSelectByPoint();
        lineAndShapeRenderer20.setPlot(categoryPlot25);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot25.getRangeAxisEdge(10);
        try {
            double double36 = categoryAxis0.getCategorySeriesMiddle((-1), (int) (byte) -1, 0, (int) 'a', (double) 10L, rectangle2D19, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        float[] floatArray12 = new float[] { (short) 100, (byte) 0, (short) -1, '#' };
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 10, 0, 100, floatArray12);
        float[] floatArray14 = color2.getColorComponents(floatArray13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Color color4 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator8 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color4, 100.0f, 10, (double) 100.0f);
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1.0f, (java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke16, true);
        java.awt.Font font20 = lineAndShapeRenderer8.getLegendTextFont(0);
        lineAndShapeRenderer8.setBaseCreateEntities(false);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 0, paint24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition27);
        org.jfree.chart.text.TextAnchor textAnchor29 = itemLabelPosition27.getRotationAnchor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryPlot0.setDomainAxis(categoryAxis6);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        int int5 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setURLText("");
        legendItem1.setSeriesIndex(0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.PaintList paintList5 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean7 = paintList5.equals((java.lang.Object) itemLabelAnchor6);
        boolean boolean8 = categoryAxis0.equals((java.lang.Object) paintList5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        java.awt.Stroke stroke15 = null;
        categoryPlot9.setOutlineStroke(stroke15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        categoryPlot9.drawOutline(graphics2D17, rectangle2D18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot9.getRangeAxis();
        java.lang.String str21 = categoryPlot9.getPlotType();
        boolean boolean22 = paintList5.equals((java.lang.Object) categoryPlot9);
        java.awt.Paint paint24 = paintList5.getPaint((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.lang.Object obj21 = chartEntity20.clone();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot4.getOrientation();
        boolean boolean12 = barRenderer0.equals((java.lang.Object) plotOrientation11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setShadowVisible(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(itemLabelPosition13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Font font4 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font5 = categoryAxis0.getLabelFont();
        java.awt.Font font7 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        float float8 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.lang.Boolean boolean15 = lineAndShapeRenderer0.getSeriesCreateEntities(192);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(4, categoryURLGenerator17, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10, true);
        boolean boolean13 = categoryPlot6.canSelectByPoint();
        lineAndShapeRenderer1.setPlot(categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot6.getDataRange(valueAxis17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        java.awt.Color color23 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color23);
        org.jfree.data.KeyedObject keyedObject27 = new org.jfree.data.KeyedObject((java.lang.Comparable) 3.0d, (java.lang.Object) categoryPlot6);
        java.awt.Paint paint28 = categoryPlot6.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setDomainAxisLocation(axisLocation12, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        java.lang.Boolean boolean21 = lineAndShapeRenderer0.getSeriesCreateEntities(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(categoryPlot22);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        java.lang.Object obj2 = booleanList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        double double7 = barRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis(0, categoryAxis15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace17, true);
        boolean boolean20 = categoryPlot13.canSelectByPoint();
        lineAndShapeRenderer8.setPlot(categoryPlot13);
        boolean boolean22 = lineAndShapeRenderer8.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer8.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemFillPaint(3, (int) ' ');
        java.awt.Paint paint7 = renderAttributes0.getItemOutlinePaint(4, 3);
        java.awt.Paint paint10 = renderAttributes0.getItemOutlinePaint((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxisForDataset(10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator5);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = standardGradientPaintTransformer7.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        double double11 = barRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint14 = lineAndShapeRenderer0.getSeriesPaint(15);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color7, false);
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        categoryPlot12.setDrawingSupplier(drawingSupplier15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot12.getInsets();
        int int19 = objectList11.indexOf((java.lang.Object) rectangleInsets18);
        boolean boolean20 = color7.equals((java.lang.Object) rectangleInsets18);
        double double22 = rectangleInsets18.extendWidth(0.05d);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 16.05d + "'", double22 == 16.05d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2, textAnchor3, (double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot6.setDrawingSupplier(drawingSupplier12);
        java.awt.Font font14 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot15 = categoryPlot6.getRootPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean18 = lineAndShapeRenderer16.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape20 = lineAndShapeRenderer16.lookupLegendShape(10);
        java.awt.Paint paint24 = lineAndShapeRenderer16.getItemFillPaint((int) (short) 100, 192, false);
        plot15.setNoDataMessagePaint(paint24);
        boolean boolean26 = textAnchor3.equals((java.lang.Object) paint24);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("Category Plot", paint24);
        java.lang.Object obj28 = legendItem27.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject((java.lang.Comparable) 2, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (2) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setSeriesShapesVisible(8, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getRangeAxisLocation((int) (byte) 100);
        int int18 = categoryPlot15.getCrosshairDatasetIndex();
        boolean boolean19 = categoryPlot15.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean22 = lineAndShapeRenderer20.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape24 = lineAndShapeRenderer20.lookupLegendShape(10);
        java.awt.Font font25 = lineAndShapeRenderer20.getBaseItemLabelFont();
        categoryPlot15.setNoDataMessageFont(font25);
        lineAndShapeRenderer0.setBaseItemLabelFont(font25, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean6 = lineAndShapeRenderer4.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape8 = lineAndShapeRenderer4.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes((double) (short) -1, plotRenderingInfo16, point2D17);
        categoryPlot9.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "SortOrder.DESCENDING");
        plotEntity23.setToolTipText("Category Plot");
        java.lang.String str26 = plotEntity23.getShapeCoords();
        java.awt.Shape shape27 = plotEntity23.getArea();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer28.setShadowVisible(true);
        java.awt.Paint paint31 = barRenderer28.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = lineAndShapeRenderer32.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke42 = lineAndShapeRenderer38.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer32.setSeriesOutlineStroke(10, stroke42);
        java.awt.Paint paint44 = lineAndShapeRenderer32.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot47.setDomainAxis(0, categoryAxis49);
        java.awt.Paint paint51 = categoryPlot47.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot47.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = null;
        categoryPlot47.setDrawingSupplier(drawingSupplier53);
        categoryPlot47.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState60 = lineAndShapeRenderer32.initialise(graphics2D45, rectangle2D46, categoryPlot47, categoryDataset58, plotRenderingInfo59);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = null;
        lineAndShapeRenderer32.setBaseURLGenerator(categoryURLGenerator61);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean65 = lineAndShapeRenderer63.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape67 = lineAndShapeRenderer63.lookupLegendShape(10);
        java.awt.Font font68 = lineAndShapeRenderer63.getBaseItemLabelFont();
        lineAndShapeRenderer32.setBaseLegendTextFont(font68);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean73 = lineAndShapeRenderer70.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = null;
        categoryPlot74.setDomainAxis(0, categoryAxis76);
        boolean boolean78 = lineAndShapeRenderer70.hasListener((java.util.EventListener) categoryPlot74);
        boolean boolean82 = lineAndShapeRenderer70.isItemLabelVisible((-1), (int) (short) -1, true);
        java.awt.Stroke stroke84 = lineAndShapeRenderer70.lookupSeriesStroke((int) (byte) 10);
        lineAndShapeRenderer32.setBaseStroke(stroke84);
        org.jfree.chart.plot.CategoryPlot categoryPlot86 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation88 = categoryPlot86.getRangeAxisLocation((int) (byte) 100);
        int int89 = categoryPlot86.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent90 = null;
        categoryPlot86.axisChanged(axisChangeEvent90);
        java.awt.Paint paint92 = categoryPlot86.getDomainCrosshairPaint();
        java.awt.Stroke stroke93 = categoryPlot86.getRangeCrosshairStroke();
        java.awt.Paint paint94 = categoryPlot86.getDomainCrosshairPaint();
        try {
            org.jfree.chart.LegendItem legendItem95 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "java.awt.Color[r=255,g=255,b=64]", "hi!", shape27, paint31, stroke84, paint94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-3,-3,3,3" + "'", str26.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryURLGenerator36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(categoryItemRendererState60);
        org.junit.Assert.assertNull(boolean65);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(paint92);
        org.junit.Assert.assertNotNull(stroke93);
        org.junit.Assert.assertNotNull(paint94);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        java.lang.String str16 = categoryPlot0.getNoDataMessage();
        categoryPlot0.clearAnnotations();
        categoryPlot0.setNoDataMessage("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke10 = lineAndShapeRenderer0.lookupSeriesStroke(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getBaseStroke();
        java.awt.Shape shape13 = lineAndShapeRenderer0.lookupLegendShape((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        double double7 = barRenderer0.getShadowXOffset();
        boolean boolean8 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        renderAttributes0.setDefaultLabelFont(font12);
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultLabelVisible();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        try {
            java.awt.Stroke stroke20 = renderAttributes0.getItemOutlineStroke((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setAxisLineVisible(true);
        float float4 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        categoryPlot5.setDomainCrosshairColumnKey((java.lang.Comparable) 0.0f, false);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent19);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        boolean boolean5 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1L));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke13 = lineAndShapeRenderer9.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis(0, categoryAxis16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace18, true);
        boolean boolean21 = categoryPlot14.canSelectByPoint();
        lineAndShapeRenderer9.setPlot(categoryPlot14);
        categoryPlot14.setForegroundAlpha(0.0f);
        categoryPlot14.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint27 = categoryPlot14.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot14.getInsets();
        double double30 = rectangleInsets28.extendHeight(0.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 8.0d + "'", double30 == 8.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.Paint paint10 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        boolean boolean13 = lineAndShapeRenderer5.hasListener((java.util.EventListener) categoryPlot9);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer5.setLegendTextFont(0, font15);
        barRenderer0.setBaseLegendTextFont(font15);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addRangeMarker(8, marker8, layer9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        java.awt.Paint paint14 = categoryPlot10.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot10.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot10.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        int int19 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryPlot10.setDomainAxis((int) ' ', categoryAxis18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = lineAndShapeRenderer21.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint27 = lineAndShapeRenderer21.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean29 = lineAndShapeRenderer21.getSeriesShapesFilled((int) (short) 0);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        java.awt.Shape shape31 = lineAndShapeRenderer21.getBaseShape();
        lineAndShapeRenderer0.setSeriesShape((int) (byte) 100, shape31, false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(4, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 4);
        categoryAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        lineAndShapeRenderer0.setSeriesFillPaint(15, (java.awt.Paint) color11, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range15 = lineAndShapeRenderer0.findRangeBounds(categoryDataset14);
        java.awt.Paint paint16 = lineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo5 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int3, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo5);
        java.lang.Object obj7 = abstractCategoryDataset4.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Color color9 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes10.setDefaultOutlineStroke(stroke11);
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot15.setFixedRangeAxisSpace(axisSpace19, true);
        categoryPlot15.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke25 = categoryPlot15.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean27 = renderAttributes26.getAllowNull();
        java.awt.Stroke stroke28 = renderAttributes26.getDefaultStroke();
        java.awt.Color color29 = java.awt.Color.red;
        renderAttributes26.setDefaultFillPaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape5, true, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke11, false, shape14, stroke25, (java.awt.Paint) color29);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity37 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "Category Plot", "java.awt.Color[r=0,g=192,b=192]", categoryDataset34, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getURLText();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis(0, categoryAxis16);
        java.awt.Paint paint18 = categoryPlot14.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRenderer();
        java.awt.Stroke stroke20 = null;
        categoryPlot14.setOutlineStroke(stroke20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot14.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean29 = lineAndShapeRenderer26.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        boolean boolean34 = lineAndShapeRenderer26.hasListener((java.util.EventListener) categoryPlot30);
        java.awt.Stroke stroke36 = lineAndShapeRenderer26.lookupSeriesStroke(0);
        java.awt.Stroke stroke37 = lineAndShapeRenderer26.getBaseStroke();
        categoryPlot0.setDomainGridlineStroke(stroke37);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot11.canSelectByPoint();
        lineAndShapeRenderer6.setPlot(categoryPlot11);
        categoryPlot11.setForegroundAlpha(0.0f);
        categoryPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        java.awt.Paint paint28 = categoryPlot24.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        java.awt.Stroke stroke30 = null;
        categoryPlot24.setOutlineStroke(stroke30);
        org.jfree.data.general.DatasetGroup datasetGroup32 = categoryPlot24.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot24.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation(axisLocation34);
        categoryPlot0.setDomainAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis(0, categoryAxis39);
        java.awt.Paint paint41 = categoryPlot37.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot37.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = categoryPlot37.getLegendItems();
        java.lang.Object obj44 = null;
        boolean boolean45 = legendItemCollection43.equals(obj44);
        categoryPlot0.setFixedLegendItems(legendItemCollection43);
        int int47 = legendItemCollection43.getItemCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke52 = lineAndShapeRenderer48.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = lineAndShapeRenderer48.getDrawingSupplier();
        lineAndShapeRenderer48.clearSeriesPaints(false);
        boolean boolean56 = legendItemCollection43.equals((java.lang.Object) lineAndShapeRenderer48);
        java.util.Iterator iterator57 = legendItemCollection43.iterator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean64 = lineAndShapeRenderer62.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape66 = lineAndShapeRenderer62.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke71 = lineAndShapeRenderer67.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color72 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape66, stroke71, (java.awt.Paint) color72);
        legendItemCollection43.add(legendItem73);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNull(datasetGroup32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(drawingSupplier53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(iterator57);
        org.junit.Assert.assertNull(boolean64);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color72);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer19.setSeriesStroke(0, stroke27, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator30);
        categoryPlot5.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        java.awt.Paint paint38 = categoryPlot34.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot34.getRenderer();
        java.awt.Stroke stroke40 = null;
        categoryPlot34.setOutlineStroke(stroke40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        categoryPlot34.drawOutline(graphics2D42, rectangle2D43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot34.getRangeAxis();
        java.awt.Stroke stroke46 = categoryPlot34.getRangeGridlineStroke();
        lineAndShapeRenderer19.setBaseOutlineStroke(stroke46);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot49.getRangeAxisLocation((int) (byte) 100);
        java.util.List list52 = categoryPlot49.getAnnotations();
        java.awt.Color color53 = java.awt.Color.orange;
        categoryPlot49.setBackgroundPaint((java.awt.Paint) color53);
        lineAndShapeRenderer19.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color53, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator57);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation59 = null;
        try {
            lineAndShapeRenderer19.addAnnotation(categoryAnnotation59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        lineAndShapeRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        java.awt.Paint paint10 = null;
        lineAndShapeRenderer0.setLegendTextPaint(0, paint10);
        java.awt.Color color12 = java.awt.Color.yellow;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color12);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers((int) (byte) 100, layer14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        int int8 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset((int) ' ', categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        categoryAxis0.setMinorTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 4);
        float float15 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Color color22 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        categoryPlot18.setRangeMinorGridlinePaint((java.awt.Paint) color22);
        categoryPlot5.setRangeGridlinePaint((java.awt.Paint) color22);
        int int26 = color22.getRGB();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-14336) + "'", int26 == (-14336));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        int int12 = lineAndShapeRenderer0.getDefaultEntityRadius();
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean6 = lineAndShapeRenderer4.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape8 = lineAndShapeRenderer4.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes((double) (short) -1, plotRenderingInfo16, point2D17);
        categoryPlot9.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "SortOrder.DESCENDING");
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape8);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "rect", "hi!", "", shape8, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        java.lang.Object obj4 = objectList0.get(3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Stroke stroke10 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(0);
        boolean boolean12 = lineAndShapeRenderer0.isSeriesItemLabelsVisible(100);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color4);
        boolean boolean7 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot4.getOrientation();
        boolean boolean12 = barRenderer0.equals((java.lang.Object) plotOrientation11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = lineAndShapeRenderer13.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer13.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean21 = lineAndShapeRenderer13.isSeriesVisible((int) 'a');
        lineAndShapeRenderer13.setBaseLinesVisible(true);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer13.setBasePaint(paint24, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        lineAndShapeRenderer13.setBaseItemLabelGenerator(categoryItemLabelGenerator27);
        lineAndShapeRenderer13.setUseFillPaint(false);
        java.awt.Stroke stroke32 = lineAndShapeRenderer13.lookupSeriesOutlineStroke(2);
        barRenderer0.setBaseStroke(stroke32);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer6.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer6.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        categoryPlot14.setDrawingSupplier(drawingSupplier17, false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot14.setDataset(categoryDataset20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        lineAndShapeRenderer6.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis22, marker23, rectangle2D24);
        java.awt.Stroke stroke26 = categoryPlot14.getRangeGridlineStroke();
        categoryAxis0.setAxisLineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        java.awt.Paint paint15 = categoryPlot11.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot11.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        categoryPlot11.setDrawingSupplier(drawingSupplier17);
        java.awt.Font font19 = categoryPlot11.getNoDataMessageFont();
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font19);
        java.lang.Object obj21 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemFillPaint(3, (int) ' ');
        java.awt.Stroke stroke5 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        lineAndShapeRenderer0.setBaseSeriesVisible(true, true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int2 = keyedObjects2D0.getColumnCount();
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        try {
            java.lang.Comparable comparable9 = keyedObjects0.getKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = lineAndShapeRenderer4.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer4.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        categoryPlot12.setDrawingSupplier(drawingSupplier15, false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot12.setDataset(categoryDataset18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D11, categoryPlot12, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = lineAndShapeRenderer4.getBaseURLGenerator();
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer4.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color26);
        categoryAxis0.setLabelPaint((java.awt.Paint) color26);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke36 = lineAndShapeRenderer32.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis(0, categoryAxis39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot37.setFixedRangeAxisSpace(axisSpace41, true);
        boolean boolean44 = categoryPlot37.canSelectByPoint();
        lineAndShapeRenderer32.setPlot(categoryPlot37);
        categoryPlot37.setForegroundAlpha(0.0f);
        categoryPlot37.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot37.getRangeAxisEdge((int) (byte) 0);
        try {
            java.util.List list52 = categoryAxis0.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(categoryURLGenerator24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        java.lang.Object obj4 = legendItem1.clone();
        legendItem1.setShapeVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setBackgroundImageAlpha(1.0f);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor16);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot0.axisChanged(axisChangeEvent8);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo7, point2D8);
        categoryPlot0.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        int int18 = color16.getAlpha();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 0.0f);
        java.awt.Paint paint12 = null;
        lineAndShapeRenderer0.setSeriesPaint(2, paint12, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke19 = lineAndShapeRenderer15.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot20.setDomainAxis(0, categoryAxis22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot20.setFixedRangeAxisSpace(axisSpace24, true);
        boolean boolean27 = categoryPlot20.canSelectByPoint();
        lineAndShapeRenderer15.setPlot(categoryPlot20);
        lineAndShapeRenderer15.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int36 = color35.getGreen();
        java.awt.Color color37 = java.awt.Color.getColor("hi!", color35);
        lineAndShapeRenderer15.setSeriesOutlinePaint(0, (java.awt.Paint) color37);
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color37, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 192 + "'", int36 == 192);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        legendItem1.setToolTipText("hi!");
        boolean boolean6 = legendItem1.equals((java.lang.Object) (short) 10);
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color14 = java.awt.Color.BLUE;
        java.awt.Color color16 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes17.setDefaultOutlineStroke(stroke18);
        java.awt.Shape shape21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace26, true);
        categoryPlot22.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke32 = categoryPlot22.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean34 = renderAttributes33.getAllowNull();
        java.awt.Stroke stroke35 = renderAttributes33.getDefaultStroke();
        java.awt.Color color36 = java.awt.Color.red;
        renderAttributes33.setDefaultFillPaint((java.awt.Paint) color36);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape12, true, (java.awt.Paint) color14, false, (java.awt.Paint) color16, stroke18, false, shape21, stroke32, (java.awt.Paint) color36);
        legendItem1.setLine(shape12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot0.markerChanged(markerChangeEvent8);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 1.0f, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        categoryPlot2.setDrawingSupplier(drawingSupplier5, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot2.getInsets();
        int int9 = objectList1.indexOf((java.lang.Object) rectangleInsets8);
        double double11 = rectangleInsets8.calculateBottomInset(100.0d);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getDomainAxisEdge((int) '#');
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        categoryPlot5.setBackgroundImageAlignment(10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        float float3 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.lang.String str4 = categoryAxis0.getLabelURL();
        categoryAxis0.setMinorTickMarkOutsideLength((float) '#');
        java.lang.String str8 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0L);
        java.awt.Paint paint9 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(0);
        java.awt.Paint paint4 = paintList0.getPaint((int) (short) 100);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint4);
    }
}

