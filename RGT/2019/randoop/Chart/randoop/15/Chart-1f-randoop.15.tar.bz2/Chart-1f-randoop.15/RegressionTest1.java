import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean7 = lineAndShapeRenderer4.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis(0, categoryAxis10);
        boolean boolean12 = lineAndShapeRenderer4.hasListener((java.util.EventListener) categoryPlot8);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer4.setLegendTextFont(0, font14);
        java.awt.Stroke stroke19 = lineAndShapeRenderer4.getItemStroke(0, 15, false);
        java.awt.Stroke stroke23 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        categoryPlot0.setDomainCrosshairStroke(stroke23);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        double double19 = categoryAxis8.getLowerMargin();
        float float20 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        int int8 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot0.indexOf(categoryDataset9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer0.getSeriesItemLabelGenerator((-1));
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getRangeAxisLocation((int) (byte) 100);
        java.util.List list19 = categoryPlot16.getAnnotations();
        java.awt.Color color20 = java.awt.Color.orange;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot16.removeDomainMarker(marker22, layer23);
        java.awt.Paint paint25 = categoryPlot16.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        int int27 = categoryAxis26.getCategoryLabelPositionOffset();
        java.awt.Font font28 = categoryAxis26.getTickLabelFont();
        java.awt.Font font30 = categoryAxis26.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font31 = categoryAxis26.getLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D39 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D14, rectangle2D15, categoryPlot16, categoryAxis26, valueAxis32, categoryDataset33, 9, (int) (byte) -1, false, categoryItemRendererState37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=255,g=255,b=64]");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot2.setDataset(10, categoryDataset4);
        java.lang.String str6 = categoryPlot2.getPlotType();
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        java.lang.Object obj9 = categoryPlot2.clone();
        boolean boolean10 = standardCategorySeriesLabelGenerator1.equals(obj9);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer19.setSeriesStroke(0, stroke27, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator30);
        categoryPlot5.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        java.awt.Paint paint38 = categoryPlot34.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot34.getRenderer();
        java.awt.Stroke stroke40 = null;
        categoryPlot34.setOutlineStroke(stroke40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        categoryPlot34.drawOutline(graphics2D42, rectangle2D43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot34.getRangeAxis();
        java.awt.Stroke stroke46 = categoryPlot34.getRangeGridlineStroke();
        lineAndShapeRenderer19.setBaseOutlineStroke(stroke46);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot49.getRangeAxisLocation((int) (byte) 100);
        java.util.List list52 = categoryPlot49.getAnnotations();
        java.awt.Color color53 = java.awt.Color.orange;
        categoryPlot49.setBackgroundPaint((java.awt.Paint) color53);
        lineAndShapeRenderer19.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color53, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator57);
        boolean boolean61 = lineAndShapeRenderer19.getItemVisible((int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Font font10 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 1);
        boolean boolean11 = lineAndShapeRenderer0.getBaseShapesVisible();
        lineAndShapeRenderer0.setDefaultEntityRadius(10);
        boolean boolean14 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        java.awt.Font font9 = lineAndShapeRenderer0.getBaseItemLabelFont();
        java.awt.Shape shape11 = lineAndShapeRenderer0.getLegendShape((int) (byte) 1);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Color color13 = java.awt.Color.magenta;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean17 = lineAndShapeRenderer15.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape19 = lineAndShapeRenderer15.lookupLegendShape(10);
        int int20 = lineAndShapeRenderer15.getColumnCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer15.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot22.getRangeAxisLocation((int) (byte) 100);
        int int25 = categoryPlot22.getCrosshairDatasetIndex();
        boolean boolean26 = categoryPlot22.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean29 = lineAndShapeRenderer27.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape31 = lineAndShapeRenderer27.lookupLegendShape(10);
        java.awt.Font font32 = lineAndShapeRenderer27.getBaseItemLabelFont();
        categoryPlot22.setNoDataMessageFont(font32);
        lineAndShapeRenderer15.setBaseItemLabelFont(font32);
        lineAndShapeRenderer0.setBaseItemLabelFont(font32, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        boolean boolean9 = lineAndShapeRenderer1.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Stroke stroke10 = categoryPlot5.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot5.setOrientation(plotOrientation11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        categoryPlot5.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot5.getInsets();
        double double17 = rectangleInsets15.calculateTopOutset((-17.0d));
        double double19 = rectangleInsets15.calculateBottomInset((double) (-1));
        boolean boolean20 = sortOrder0.equals((java.lang.Object) double19);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes((double) (byte) 0, (double) 10.0f, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) (short) 10);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        boolean boolean15 = categoryPlot11.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot11.setDomainAxisLocation(axisLocation16);
        categoryPlot0.setDomainAxisLocation(0, axisLocation16, false);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.extendWidth((double) ' ');
        boolean boolean13 = color8.equals((java.lang.Object) rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 34.0d + "'", double12 == 34.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        int int13 = categoryPlot10.getCrosshairDatasetIndex();
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setDomainAxisLocation(axisLocation15);
        boolean boolean17 = categoryPlot10.isRangeZoomable();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean22 = lineAndShapeRenderer20.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape24 = lineAndShapeRenderer20.lookupLegendShape(10);
        java.awt.Paint paint28 = lineAndShapeRenderer20.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint29 = lineAndShapeRenderer20.getBaseLegendTextPaint();
        java.awt.Stroke stroke31 = lineAndShapeRenderer20.lookupSeriesOutlineStroke((int) (byte) 0);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) '4', stroke31);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray15 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray16 = color10.getComponents(floatArray15);
        lineAndShapeRenderer0.setSeriesOutlinePaint(3, (java.awt.Paint) color10, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 100);
        int int9 = categoryPlot6.getCrosshairDatasetIndex();
        java.awt.Image image10 = categoryPlot6.getBackgroundImage();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot6.markerChanged(markerChangeEvent11);
        boolean boolean13 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = barRenderer0.initialise(graphics2D4, rectangle2D5, categoryPlot6, categoryDataset14, plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererState16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        categoryPlot0.mapDatasetToDomainAxis(10, 100);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot0.getDomainMarkers(layer11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.lang.Object obj1 = abstractCategoryDataset0.clone();
        java.lang.Object obj2 = abstractCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str17 = categoryAnchor16.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str17.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        int int14 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint15 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lineAndShapeRenderer0);
        lineAndShapeRenderer0.setItemLabelAnchorOffset(0.2d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        java.awt.Paint paint5 = lineAndShapeRenderer0.getSeriesPaint(100);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot11.canSelectByPoint();
        lineAndShapeRenderer6.setPlot(categoryPlot11);
        categoryPlot11.setForegroundAlpha(0.0f);
        categoryPlot11.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        java.awt.Paint paint28 = categoryPlot24.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        java.awt.Stroke stroke30 = null;
        categoryPlot24.setOutlineStroke(stroke30);
        org.jfree.data.general.DatasetGroup datasetGroup32 = categoryPlot24.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot24.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation(axisLocation34);
        categoryPlot0.setDomainAxisLocation(axisLocation34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis(0, categoryAxis39);
        java.awt.Paint paint41 = categoryPlot37.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot37.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = categoryPlot37.getLegendItems();
        java.lang.Object obj44 = null;
        boolean boolean45 = legendItemCollection43.equals(obj44);
        categoryPlot0.setFixedLegendItems(legendItemCollection43);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNull(datasetGroup32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(legendItemCollection47);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean12 = lineAndShapeRenderer10.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer14.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer10.setSeriesStroke(0, stroke18, true);
        java.awt.Font font22 = lineAndShapeRenderer10.getLegendTextFont(0);
        lineAndShapeRenderer10.setBaseCreateEntities(false);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer10.setSeriesItemLabelPaint((int) (short) 0, paint26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        int int32 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Font font33 = categoryAxis31.getTickLabelFont();
        java.awt.Color color34 = java.awt.Color.pink;
        categoryAxis31.setTickLabelPaint((java.awt.Paint) color34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis31.setLabelPaint((java.awt.Paint) color36);
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = shapeList0.equals(obj7);
        java.awt.Shape shape10 = shapeList0.getShape((int) '4');
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        lineAndShapeRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true);
        lineAndShapeRenderer0.setBaseShapesVisible(true);
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot3.zoomRangeAxes((double) (byte) 1, plotRenderingInfo10, point2D11, true);
        categoryPlot3.clearSelection();
        org.jfree.chart.plot.Marker marker15 = null;
        try {
            categoryPlot3.addRangeMarker(marker15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint6 = legendItem5.getLinePaint();
        legendItem5.setToolTipText("hi!");
        boolean boolean10 = legendItem5.equals((java.lang.Object) (short) 10);
        legendItem5.setLineVisible(true);
        java.awt.Paint paint13 = legendItem5.getFillPaint();
        keyedObjects2D0.addObject((java.lang.Object) paint13, (java.lang.Comparable) '4', (java.lang.Comparable) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        java.awt.Color color11 = java.awt.Color.getColor("", (int) ' ');
        boolean boolean12 = rectangleInsets6.equals((java.lang.Object) color11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets6.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType14, lengthAdjustmentType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        renderAttributes0.setDefaultLabelFont(font12);
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultLabelVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke20 = lineAndShapeRenderer16.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer16.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer16.getPlot();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        lineAndShapeRenderer16.setSeriesFillPaint(15, (java.awt.Paint) color27, true);
        renderAttributes0.setDefaultOutlinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart5, chartChangeEventType6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent7.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent7.setType(chartChangeEventType9);
        chartChangeEvent3.setType(chartChangeEventType9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot3.zoomRangeAxes((double) (byte) 1, plotRenderingInfo10, point2D11, true);
        java.awt.Paint paint14 = categoryPlot3.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextOutlineStroke();
        java.lang.Object obj22 = defaultDrawingSupplier20.clone();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        lineAndShapeRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(15, categoryURLGenerator25);
        int int27 = lineAndShapeRenderer0.getColumnCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot29.setDomainAxis(0, categoryAxis31);
        java.awt.Paint paint33 = categoryPlot29.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot29.getRenderer();
        java.awt.Stroke stroke35 = null;
        categoryPlot29.setOutlineStroke(stroke35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = null;
        categoryPlot29.setDrawingSupplier(drawingSupplier37, true);
        double double40 = categoryPlot29.getRangeCrosshairValue();
        java.awt.Stroke stroke41 = categoryPlot29.getDomainCrosshairStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke41);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 192 + "'", int21 == 192);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getFixedDimension();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(10, valueAxis9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        double double12 = barRenderer11.getItemMargin();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer11.setShadowPaint((java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        barRenderer11.setBaseOutlinePaint((java.awt.Paint) color15);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int19 = color18.getGreen();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        int int22 = categoryAxis21.getCategoryLabelPositionOffset();
        java.awt.Font font23 = categoryAxis21.getTickLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis21.setAxisLinePaint((java.awt.Paint) color24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray31 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray32 = color26.getComponents(floatArray31);
        float[] floatArray33 = color24.getRGBComponents(floatArray32);
        float[] floatArray34 = color15.getColorComponents(colorSpace20, floatArray33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        categoryPlot35.setDomainAxis(0, categoryAxis37);
        java.awt.Paint paint39 = categoryPlot35.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot35.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot35.getLegendItems();
        categoryPlot35.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot35.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo46, point2D47);
        boolean boolean49 = color15.equals((java.lang.Object) point2D47);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 192 + "'", int19 == 192);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        java.lang.Object obj4 = null;
        objectList0.set(4, obj4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean12 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(0);
        boolean boolean13 = shapeList7.equals((java.lang.Object) 0);
        boolean boolean14 = shapeList0.equals((java.lang.Object) 0);
        java.lang.Object obj15 = shapeList0.clone();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean17 = shapeList0.equals((java.lang.Object) axisLocation16);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape19);
        shapeList0.setShape((int) (byte) 10, shape19);
        java.lang.Object obj22 = shapeList0.clone();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Font font10 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 1);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean17 = lineAndShapeRenderer14.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        boolean boolean22 = lineAndShapeRenderer14.hasListener((java.util.EventListener) categoryPlot18);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        int int25 = categoryAxis24.getCategoryLabelPositionOffset();
        java.awt.Font font26 = categoryAxis24.getTickLabelFont();
        categoryPlot18.setDomainAxis(categoryAxis24);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        int int29 = categoryAxis28.getCategoryLabelPositionOffset();
        java.awt.Font font30 = categoryAxis28.getTickLabelFont();
        java.awt.Font font32 = categoryAxis28.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font33 = categoryAxis28.getLabelFont();
        java.awt.Font font35 = categoryAxis28.getTickLabelFont((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D13, categoryPlot18, categoryAxis28, categoryMarker36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot4.setOrientation(plotOrientation10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) (short) -1, plotRenderingInfo13, point2D14, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.lang.Boolean boolean15 = lineAndShapeRenderer0.getSeriesCreateEntities(192);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getItemLabelPaint(255, (int) (byte) -1, true);
        boolean boolean21 = lineAndShapeRenderer0.isSeriesItemLabelsVisible(255);
        lineAndShapeRenderer0.setDrawOutlines(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        boolean boolean5 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1L));
        categoryAxis0.setTickMarkInsideLength((float) 15);
        double double11 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("rect");
        categoryAxis1.setMinorTickMarkOutsideLength((float) (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((double) 1);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = java.awt.Color.magenta;
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setShapeVisible(false);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem1.setLabelFont(font7);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer9 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = standardGradientPaintTransformer9.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType10);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean19 = lineAndShapeRenderer17.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape21 = lineAndShapeRenderer17.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer22.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape21, stroke26, (java.awt.Paint) color27);
        legendItem1.setFillPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke30 = legendItem1.getLineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer31 = legendItem1.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer31);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardCategorySeriesLabelGenerator0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot5.getRangeAxisEdge((int) (byte) 0);
        java.util.List list20 = categoryPlot5.getCategories();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot5.addChangeListener(plotChangeListener21);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(list20);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Color color2 = java.awt.Color.getColor("-3,-3,3,3", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color8);
        double double10 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color14);
        categoryAxis0.setLowerMargin((double) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects2D0, jFreeChart1);
        java.util.List list3 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Comparable comparable5 = keyedObjects2D0.getColumnKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        double double6 = categoryAxis0.getFixedDimension();
        boolean boolean7 = categoryAxis0.isTickMarksVisible();
        java.awt.Paint paint8 = categoryAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Color color1 = java.awt.Color.getColor("-3,-3,3,3");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedRangeAxisSpace(axisSpace15, true);
        boolean boolean18 = categoryPlot11.canSelectByPoint();
        float float19 = categoryPlot11.getForegroundAlpha();
        boolean boolean20 = categoryPlot11.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            lineAndShapeRenderer0.drawOutline(graphics2D10, categoryPlot11, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        double double8 = defaultShadowGenerator7.getAngle();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        double double10 = defaultShadowGenerator7.getAngle();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = lineAndShapeRenderer0.getLegendItems();
        int int11 = legendItemCollection10.getItemCount();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo5 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int3, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo5);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState7 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState7);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState9 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearRangeMarkers(100);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getFixedDimension();
        try {
            categoryPlot0.setDomainAxis((-1), categoryAxis11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        double double8 = defaultShadowGenerator7.getAngle();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        int int10 = color9.getRed();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        java.awt.Paint paint14 = categoryPlot10.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot10.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot10.setDrawingSupplier(drawingSupplier16);
        java.awt.Font font18 = categoryPlot10.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot19 = categoryPlot10.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke25 = lineAndShapeRenderer21.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean26 = sortOrder20.equals((java.lang.Object) true);
        categoryPlot10.setColumnRenderingOrder(sortOrder20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean31 = lineAndShapeRenderer28.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot32.setDomainAxis(0, categoryAxis34);
        boolean boolean36 = lineAndShapeRenderer28.hasListener((java.util.EventListener) categoryPlot32);
        java.awt.Stroke stroke38 = lineAndShapeRenderer28.lookupSeriesStroke(0);
        categoryPlot10.setOutlineStroke(stroke38);
        boolean boolean40 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation(axisLocation41, false);
        java.lang.String str44 = axisLocation41.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str44.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer0.setBasePaint(paint11, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        try {
            lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-1), itemLabelPosition17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((-17.0d), 0.0d, (double) (byte) -1, (double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        legendItem1.setToolTipText("hi!");
        boolean boolean6 = legendItem1.equals((java.lang.Object) (short) 10);
        java.lang.Object obj7 = legendItem1.clone();
        java.awt.Shape shape8 = null;
        try {
            legendItem1.setLine(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot9.setDrawingSupplier(drawingSupplier12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot9.setDataset(categoryDataset15);
        categoryPlot9.configureRangeAxes();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        categoryPlot9.clearRangeMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot9.addDomainMarker(255, categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean16 = sortOrder10.equals((java.lang.Object) true);
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lineAndShapeRenderer18.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        boolean boolean26 = lineAndShapeRenderer18.hasListener((java.util.EventListener) categoryPlot22);
        java.awt.Stroke stroke28 = lineAndShapeRenderer18.lookupSeriesStroke(0);
        categoryPlot0.setOutlineStroke(stroke28);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Stroke stroke2 = renderAttributes0.getDefaultStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer3.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        categoryPlot11.setDrawingSupplier(drawingSupplier14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(categoryDataset17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        lineAndShapeRenderer3.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis19, marker20, rectangle2D21);
        java.awt.Stroke stroke23 = categoryPlot11.getRangeGridlineStroke();
        renderAttributes0.setDefaultStroke(stroke23);
        try {
            java.awt.Font font26 = renderAttributes0.getSeriesLabelFont((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean16 = sortOrder10.equals((java.lang.Object) true);
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lineAndShapeRenderer18.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        boolean boolean26 = lineAndShapeRenderer18.hasListener((java.util.EventListener) categoryPlot22);
        java.awt.Stroke stroke28 = lineAndShapeRenderer18.lookupSeriesStroke(0);
        categoryPlot0.setOutlineStroke(stroke28);
        org.jfree.chart.plot.Marker marker30 = null;
        boolean boolean31 = categoryPlot0.removeDomainMarker(marker30);
        int int32 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10, true);
        boolean boolean13 = categoryPlot6.canSelectByPoint();
        lineAndShapeRenderer1.setPlot(categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot6.getDataRange(valueAxis17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis(0, categoryAxis21);
        java.awt.Color color23 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        categoryPlot19.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        categoryPlot6.setRangeGridlinePaint((java.awt.Paint) color23);
        org.jfree.data.KeyedObject keyedObject27 = new org.jfree.data.KeyedObject((java.lang.Comparable) 3.0d, (java.lang.Object) categoryPlot6);
        java.lang.Object obj28 = keyedObject27.getObject();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke33 = lineAndShapeRenderer29.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot34.setFixedRangeAxisSpace(axisSpace38, true);
        boolean boolean41 = categoryPlot34.canSelectByPoint();
        lineAndShapeRenderer29.setPlot(categoryPlot34);
        categoryPlot34.setForegroundAlpha(0.0f);
        categoryPlot34.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint47 = categoryPlot34.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryPlot34.getInsets();
        double double50 = rectangleInsets48.extendHeight(0.0d);
        boolean boolean51 = keyedObject27.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 8.0d + "'", double50 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        java.awt.Stroke stroke17 = lineAndShapeRenderer2.getItemStroke(0, 15, false);
        strokeList0.setStroke(100, stroke17);
        java.awt.Stroke stroke20 = strokeList0.getStroke((int) '#');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(stroke20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot4.axisChanged(axisChangeEvent11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        java.lang.Comparable comparable9 = null;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        try {
            keyedObjects0.addObject(comparable9, (java.lang.Object) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 100);
        java.util.List list40 = categoryPlot37.getAnnotations();
        categoryPlot37.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke47 = lineAndShapeRenderer43.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        categoryPlot48.setDomainAxis(0, categoryAxis50);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        categoryPlot48.setFixedRangeAxisSpace(axisSpace52, true);
        boolean boolean55 = categoryPlot48.canSelectByPoint();
        lineAndShapeRenderer43.setPlot(categoryPlot48);
        categoryPlot48.setForegroundAlpha(0.0f);
        categoryPlot48.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        categoryPlot61.setDomainAxis(0, categoryAxis63);
        java.awt.Paint paint65 = categoryPlot61.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = categoryPlot61.getRenderer();
        java.awt.Stroke stroke67 = null;
        categoryPlot61.setOutlineStroke(stroke67);
        org.jfree.data.general.DatasetGroup datasetGroup69 = categoryPlot61.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot61.getRangeAxisLocation((int) (byte) 0);
        categoryPlot48.setDomainAxisLocation(axisLocation71);
        categoryPlot37.setDomainAxisLocation(axisLocation71);
        java.lang.String str74 = axisLocation71.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean77 = plotOrientation75.equals((java.lang.Object) 1.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation75);
        try {
            double double79 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 0.05d, (java.lang.Comparable) "java.awt.Color[r=255,g=255,b=64]", categoryDataset34, categoryAxis35, rectangle2D36, rectangleEdge78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(categoryItemRenderer66);
        org.junit.Assert.assertNull(datasetGroup69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str74.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        double double8 = defaultShadowGenerator7.getAngle();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        int int10 = color9.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean16 = lineAndShapeRenderer14.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape18 = lineAndShapeRenderer14.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke23 = lineAndShapeRenderer19.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color24 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape18, stroke23, (java.awt.Paint) color24);
        barRenderer0.setSeriesShape((int) (byte) 10, shape18, false);
        boolean boolean28 = barRenderer0.getAutoPopulateSeriesStroke();
        barRenderer0.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        boolean boolean18 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean25 = lineAndShapeRenderer23.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape27 = lineAndShapeRenderer23.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke32 = lineAndShapeRenderer28.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color33 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape27, stroke32, (java.awt.Paint) color33);
        lineAndShapeRenderer0.setBaseShape(shape27, true);
        java.awt.Font font38 = lineAndShapeRenderer0.getLegendTextFont((int) ' ');
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(font38);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Font font19 = lineAndShapeRenderer0.getItemLabelFont((int) '#', (int) (short) 1, false);
        lineAndShapeRenderer0.setBaseSeriesVisible(true, true);
        java.awt.Paint paint23 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        keyedObjects0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15, textAnchor16, (double) 0.0f);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition18);
        boolean boolean21 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color7, false);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesOutlinePaint((int) (short) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis(0, categoryAxis14);
        java.awt.Color color16 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        categoryPlot12.setRangeMinorGridlinePaint((java.awt.Paint) color16);
        int int19 = categoryPlot12.getBackgroundImageAlignment();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot12.panRangeAxes((double) (byte) 0, plotRenderingInfo22, point2D23);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Font font12 = categoryAxis10.getTickLabelFont();
        categoryPlot4.setDomainAxis(categoryAxis10);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = lineAndShapeRenderer0.getLegendItems();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects2D0, jFreeChart1);
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        int int5 = keyedObjects3.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        keyedObjects3.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis7);
        java.util.List list10 = keyedObjects3.getKeys();
        int int11 = keyedObjects3.getItemCount();
        keyedObjects3.clear();
        java.lang.Object obj13 = keyedObjects3.clone();
        keyedObjects2D0.addObject((java.lang.Object) keyedObjects3, (java.lang.Comparable) ' ', (java.lang.Comparable) "PlotEntity: tooltip = Category Plot");
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = java.awt.Color.magenta;
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setShapeVisible(false);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem1.setLabelFont(font7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = legendItem1.getFillPaintTransformer();
        java.awt.Shape shape10 = legendItem1.getShape();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        boolean boolean9 = lineAndShapeRenderer1.hasListener((java.util.EventListener) categoryPlot5);
        boolean boolean10 = lineAndShapeRenderer1.getBaseItemLabelsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer1.setSeriesURLGenerator(192, categoryURLGenerator12);
        boolean boolean14 = lineAndShapeRenderer1.getBaseSeriesVisible();
        boolean boolean15 = gradientPaintTransformType0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.awt.Shape shape16 = lineAndShapeRenderer1.getBaseLegendShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        boolean boolean18 = lineAndShapeRenderer1.removeAnnotation(categoryAnnotation17);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) '#', 3, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer17.getPositiveItemLabelPosition((int) '#', (int) (byte) -1, true);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(8, itemLabelPosition21);
        boolean boolean23 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis8.setLabelPaint((java.awt.Paint) color19);
        categoryAxis8.setUpperMargin(1.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        legendItem1.setToolTipText("");
        legendItem1.setLineVisible(true);
        java.awt.Stroke stroke7 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color3);
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        boolean boolean5 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-1L));
        double double9 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 100L);
        java.awt.Font font21 = categoryAxis8.getLabelFont();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible((int) (short) 100);
        boolean boolean6 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = lineAndShapeRenderer0.getSeriesCreateEntities((int) ' ');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean16 = sortOrder10.equals((java.lang.Object) true);
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lineAndShapeRenderer18.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        boolean boolean26 = lineAndShapeRenderer18.hasListener((java.util.EventListener) categoryPlot22);
        java.awt.Stroke stroke28 = lineAndShapeRenderer18.lookupSeriesStroke(0);
        categoryPlot0.setOutlineStroke(stroke28);
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 1, 0);
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        try {
            categoryPlot0.addRangeMarker(100, marker34, layer35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 10, plotRenderingInfo14, point2D15);
        double double17 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(0, categoryURLGenerator33, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int13 = color12.getGreen();
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color12);
        categoryPlot0.setDomainAxis(10, categoryAxis10, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer((-14336));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8);
        try {
            keyedObjects2D0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot3.getDataset(0);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot3.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        boolean boolean12 = lineAndShapeRenderer0.getItemCreateEntity(0, (-1), false);
        double double13 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryPlot0.setDomainAxis(categoryAxis6);
        int int9 = categoryAxis6.getMaximumCategoryLabelLines();
        double double10 = categoryAxis6.getLowerMargin();
        java.lang.Class<?> wildcardClass11 = categoryAxis6.getClass();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = lineAndShapeRenderer0.getURLGenerator(2, 15, false);
        boolean boolean20 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = lineAndShapeRenderer11.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint17 = lineAndShapeRenderer11.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean19 = lineAndShapeRenderer11.getSeriesShapesFilled((int) (short) 0);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot0.getRendererForDataset(categoryDataset21);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean26 = lineAndShapeRenderer23.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis(0, categoryAxis29);
        boolean boolean31 = lineAndShapeRenderer23.hasListener((java.util.EventListener) categoryPlot27);
        java.awt.Stroke stroke32 = categoryPlot27.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot27.setOrientation(plotOrientation33);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = null;
        categoryPlot27.setDrawingSupplier(drawingSupplier35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryPlot27.getInsets();
        double double39 = rectangleInsets37.calculateRightOutset(3.0d);
        double double41 = rectangleInsets37.calculateBottomInset((double) '4');
        categoryPlot0.setAxisOffset(rectangleInsets37);
        double double43 = rectangleInsets37.getBottom();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(categoryItemRenderer22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 8.0d + "'", double39 == 8.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(4, categoryURLGenerator4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = lineAndShapeRenderer0.getDrawingSupplier();
        lineAndShapeRenderer0.setBaseCreateEntities(false, false);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getSeriesShape((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(drawingSupplier5);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot5.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        int int14 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryPlot5.setDomainAxis((int) ' ', categoryAxis13);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis13.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D21, rectangleEdge22);
        double double24 = categoryAxis13.getLowerMargin();
        java.util.List list25 = categoryPlot0.getCategoriesForAxis(categoryAxis13);
        boolean boolean26 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) font1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.calculateBottomOutset((double) 'a');
        double double9 = rectangleInsets6.getTop();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setVisible(true);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Stroke stroke4 = renderAttributes0.getItemStroke((-1), (int) 'a');
        java.awt.Paint paint6 = renderAttributes0.getSeriesPaint((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType9, 8.0d, (double) 15, (double) 100L, 0.05d);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets15.getUnitType();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(unitType16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Stroke stroke4 = renderAttributes0.getItemStroke((-1), (int) 'a');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean7 = lineAndShapeRenderer5.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape9 = lineAndShapeRenderer5.lookupLegendShape(10);
        java.awt.Paint paint13 = lineAndShapeRenderer5.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint14 = lineAndShapeRenderer5.getBaseLegendTextPaint();
        java.awt.Stroke stroke16 = lineAndShapeRenderer5.lookupSeriesOutlineStroke((int) (byte) 0);
        renderAttributes0.setDefaultOutlineStroke(stroke16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable23 = categoryPlot18.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot25 = categoryAxis24.getPlot();
        categoryPlot18.setDomainAxis(categoryAxis24);
        int int27 = categoryAxis24.getMaximumCategoryLabelLines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean31 = lineAndShapeRenderer28.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot32.setDomainAxis(0, categoryAxis34);
        boolean boolean36 = lineAndShapeRenderer28.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot32.panRangeAxes((double) (byte) 1, plotRenderingInfo38, point2D39);
        java.awt.Paint paint41 = categoryPlot32.getRangeGridlinePaint();
        categoryAxis24.setLabelPaint(paint41);
        renderAttributes0.setDefaultOutlinePaint(paint41);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        int int6 = categoryAxis5.getCategoryLabelPositionOffset();
        java.awt.Font font7 = categoryAxis5.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        int int11 = categoryPlot8.getCrosshairDatasetIndex();
        boolean boolean12 = categoryPlot8.isRangeCrosshairVisible();
        categoryAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        boolean boolean14 = itemLabelPosition4.equals((java.lang.Object) categoryPlot8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects2D0, jFreeChart1);
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Object obj5 = keyedObjects2D0.getObject((java.lang.Comparable) 10.0f, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        categoryPlot0.setWeight(0);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType9, 8.0d, (double) 15, (double) 100L, 0.05d);
        double double17 = rectangleInsets15.calculateBottomInset((double) 2);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.awt.Shape shape23 = plotEntity19.getArea();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotEntity19);
        java.lang.String str25 = plotEntity19.getURLText();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("hi!");
        abstractCategoryDataset0.setGroup(datasetGroup2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = abstractCategoryDataset0.getGroup();
        java.lang.Object obj5 = abstractCategoryDataset0.clone();
        abstractCategoryDataset0.validateObject();
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        int int3 = categoryAxis2.getCategoryLabelPositionOffset();
        java.awt.Font font4 = categoryAxis2.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        java.awt.Paint paint11 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getFixedLegendItems();
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        java.awt.Paint paint14 = categoryAxis2.getTickLabelPaint();
        barRenderer0.setShadowPaint(paint14);
        barRenderer0.setAutoPopulateSeriesShape(true);
        java.awt.Stroke stroke19 = barRenderer0.lookupSeriesOutlineStroke(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setBackgroundAlpha((float) 3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot0.getDatasetRenderingOrder();
        boolean boolean12 = datasetRenderingOrder10.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        try {
            java.lang.Object obj11 = keyedObjects0.getObject((java.lang.Comparable) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (9) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean33 = lineAndShapeRenderer31.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape35 = lineAndShapeRenderer31.lookupLegendShape(10);
        java.awt.Font font36 = lineAndShapeRenderer31.getBaseItemLabelFont();
        lineAndShapeRenderer0.setBaseLegendTextFont(font36);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean41 = lineAndShapeRenderer38.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot42.setDomainAxis(0, categoryAxis44);
        boolean boolean46 = lineAndShapeRenderer38.hasListener((java.util.EventListener) categoryPlot42);
        boolean boolean50 = lineAndShapeRenderer38.isItemLabelVisible((-1), (int) (short) -1, true);
        java.awt.Stroke stroke52 = lineAndShapeRenderer38.lookupSeriesStroke((int) (byte) 10);
        lineAndShapeRenderer0.setBaseStroke(stroke52);
        java.awt.Paint paint54 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot5.addDomainMarker((int) (short) 0, categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean6 = sortOrder0.equals((java.lang.Object) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Paint paint13 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Stroke stroke14 = categoryPlot7.getOutlineStroke();
        boolean boolean15 = sortOrder0.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean22 = lineAndShapeRenderer20.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape24 = lineAndShapeRenderer20.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke29 = lineAndShapeRenderer25.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color30 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape24, stroke29, (java.awt.Paint) color30);
        categoryPlot7.setDomainCrosshairStroke(stroke29);
        categoryPlot7.clearDomainMarkers();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot11.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation((int) (short) 1, axisLocation28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        boolean boolean34 = categoryPlot30.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot30.getInsets();
        categoryPlot11.setAxisOffset(rectangleInsets35);
        categoryPlot0.setAxisOffset(rectangleInsets35);
        double double39 = rectangleInsets35.trimWidth(4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-12.0d) + "'", double39 == (-12.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis0.getCategoryLabelPositions();
        java.lang.String str17 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesShape();
        boolean boolean25 = lineAndShapeRenderer0.isItemLabelVisible(0, 8, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        plot9.removeChangeListener(plotChangeListener10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        categoryPlot0.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Paint paint10 = categoryPlot0.getNoDataMessagePaint();
        boolean boolean11 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        double double6 = categoryAxis0.getFixedDimension();
        boolean boolean7 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis0.getLabelInsets();
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis(0, categoryAxis18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot16.setFixedRangeAxisSpace(axisSpace20, true);
        boolean boolean23 = categoryPlot16.canSelectByPoint();
        lineAndShapeRenderer11.setPlot(categoryPlot16);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge(10);
        categoryAxis8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot16.zoomRangeAxes((double) 255, plotRenderingInfo29, point2D30, false);
        boolean boolean33 = categoryPlot16.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        int int8 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot0.indexOf(categoryDataset9);
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        java.lang.Object obj4 = legendItem1.clone();
        int int5 = legendItem1.getDatasetIndex();
        java.awt.Paint paint6 = legendItem1.getLinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray6 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray7 = color1.getComponents(floatArray6);
        float[] floatArray8 = color0.getComponents(floatArray7);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset9 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo10 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) abstractCategoryDataset9, datasetChangeInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Font font10 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 1);
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Stroke stroke13 = null;
        categoryPlot7.setOutlineStroke(stroke13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot0.getDomainAxisEdge((int) (short) 100);
        int int21 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        java.util.List list4 = keyedObjects2D0.getRowKeys();
        int int5 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot4.getOrientation();
        boolean boolean12 = barRenderer0.equals((java.lang.Object) plotOrientation11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setSeriesToolTipGenerator((int) '#', categoryToolTipGenerator14, false);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getRangeAxisLocation((int) (byte) 100);
        int int22 = categoryPlot19.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot19.axisChanged(axisChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        categoryPlot26.setDomainAxis(0, categoryAxis28);
        java.awt.Paint paint30 = categoryPlot26.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot26.getRenderer();
        java.awt.Stroke stroke32 = null;
        categoryPlot26.setOutlineStroke(stroke32);
        org.jfree.data.general.DatasetGroup datasetGroup34 = categoryPlot26.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot26.getRangeAxisLocation((int) (byte) 0);
        categoryPlot19.setDomainAxisLocation((int) (short) 1, axisLocation36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot19.getDomainAxisEdge((int) (short) 100);
        try {
            double double40 = categoryAxis0.getCategoryMiddle(0, 2, rectangle2D18, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNull(datasetGroup34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getBase();
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryPlot0.setDomainAxis(categoryAxis6);
        int int9 = categoryAxis6.getMaximumCategoryLabelLines();
        double double10 = categoryAxis6.getLowerMargin();
        boolean boolean11 = categoryAxis6.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        java.awt.Font font19 = lineAndShapeRenderer0.getLegendTextFont(15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(font19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean17 = lineAndShapeRenderer15.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape19 = lineAndShapeRenderer15.lookupLegendShape(10);
        int int20 = lineAndShapeRenderer15.getColumnCount();
        lineAndShapeRenderer15.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        lineAndShapeRenderer15.setBaseItemLabelGenerator(categoryItemLabelGenerator23, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = lineAndShapeRenderer15.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color3);
        categoryAxis0.setLabelToolTip("java.awt.Color[r=0,g=192,b=192]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getRangeAxisLocation((int) (byte) 100);
        int int20 = categoryPlot17.getCrosshairDatasetIndex();
        boolean boolean21 = categoryPlot17.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot17.setDomainAxisLocation(axisLocation22);
        categoryPlot5.setDomainAxisLocation((int) (byte) 10, axisLocation22, false);
        categoryPlot5.clearRangeMarkers(2);
        categoryPlot5.setNoDataMessage("PlotEntity: tooltip = Category Plot");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        org.jfree.data.KeyedObjects keyedObjects10 = new org.jfree.data.KeyedObjects();
        int int12 = keyedObjects10.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.util.SortOrder sortOrder13 = org.jfree.chart.util.SortOrder.DESCENDING;
        keyedObjects10.sortByKeys(sortOrder13);
        keyedObjects0.sortByObjects(sortOrder13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean11 = lineAndShapeRenderer9.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke17 = lineAndShapeRenderer13.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer9.setSeriesStroke(0, stroke17, true);
        java.awt.Font font21 = lineAndShapeRenderer9.getLegendTextFont(0);
        lineAndShapeRenderer9.setBaseCreateEntities(false);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer9.setSeriesItemLabelPaint((int) (short) 0, paint25);
        categoryPlot0.setBackgroundPaint(paint25);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke29 = defaultDrawingSupplier28.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier28, false);
        java.awt.Paint paint32 = defaultDrawingSupplier28.getNextFillPaint();
        java.awt.Paint paint33 = defaultDrawingSupplier28.getNextPaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis0.setLabelPaint((java.awt.Paint) color5);
        categoryAxis0.setLabelAngle((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font9 = lineAndShapeRenderer0.getBaseLegendTextFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        java.awt.Paint paint14 = categoryPlot10.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot10.getRenderer();
        java.awt.Stroke stroke16 = null;
        categoryPlot10.setOutlineStroke(stroke16);
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        categoryPlot10.clearSelection();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        boolean boolean10 = categoryPlot0.removeDomainMarker(255, marker8, layer9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("hi!");
        abstractCategoryDataset0.setGroup(datasetGroup2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = abstractCategoryDataset0.getGroup();
        java.lang.Object obj5 = abstractCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup6 = abstractCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(datasetGroup6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        int int5 = lineAndShapeRenderer0.getColumnCount();
        java.awt.Paint paint7 = lineAndShapeRenderer0.lookupLegendTextPaint((-1));
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        java.awt.Stroke stroke12 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint();
        java.awt.Paint paint13 = categoryAxis0.getTickMarkPaint();
        java.awt.Font font14 = categoryAxis0.getLabelFont();
        float float15 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot4.setOrientation(plotOrientation10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot4.getInsets();
        double double16 = rectangleInsets14.extendWidth((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 116.0d + "'", double16 == 116.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot6.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        int int15 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) ' ', categoryAxis14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer17.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint23 = lineAndShapeRenderer17.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean25 = lineAndShapeRenderer17.getSeriesShapesFilled((int) (short) 0);
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        java.awt.Shape shape27 = lineAndShapeRenderer17.getBaseShape();
        barRenderer0.setBaseShape(shape27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        try {
            barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot5.setDomainAxisLocation(axisLocation28);
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        boolean boolean33 = categoryPlot5.removeDomainMarker(marker31, layer32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace34);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis8.setLabelPaint((java.awt.Paint) color19);
        int int21 = color19.getBlue();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        java.lang.String str20 = plotEntity19.getToolTipText();
        java.lang.String str21 = plotEntity19.getShapeType();
        java.lang.String str22 = plotEntity19.toString();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "SortOrder.DESCENDING" + "'", str20.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PlotEntity: tooltip = SortOrder.DESCENDING" + "'", str22.equals("PlotEntity: tooltip = SortOrder.DESCENDING"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot4.getOrientation();
        boolean boolean12 = barRenderer0.equals((java.lang.Object) plotOrientation11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setSeriesToolTipGenerator((int) '#', categoryToolTipGenerator14, false);
        java.awt.Paint paint20 = barRenderer0.getItemOutlinePaint((int) (byte) 100, 0, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = lineAndShapeRenderer4.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer4.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean12 = lineAndShapeRenderer4.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        lineAndShapeRenderer4.setSeriesURLGenerator((int) 'a', categoryURLGenerator14);
        keyedObjects2D0.addObject((java.lang.Object) lineAndShapeRenderer4, (java.lang.Comparable) (byte) 100, (java.lang.Comparable) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        int int20 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = lineAndShapeRenderer23.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer23.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot31.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = null;
        categoryPlot31.setDrawingSupplier(drawingSupplier34, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot31.setDataset(categoryDataset37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.Marker marker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        lineAndShapeRenderer23.drawRangeMarker(graphics2D30, categoryPlot31, valueAxis39, marker40, rectangle2D41);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator43 = lineAndShapeRenderer23.getBaseURLGenerator();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer23.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color45);
        categoryAxis19.setLabelPaint((java.awt.Paint) color45);
        lineAndShapeRenderer4.setBaseItemLabelPaint((java.awt.Paint) color45, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = lineAndShapeRenderer4.getBaseToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = lineAndShapeRenderer4.getURLGenerator((int) (short) -1, 1, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(categoryURLGenerator43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(categoryToolTipGenerator50);
        org.junit.Assert.assertNull(categoryURLGenerator54);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer0.getURLGenerator((int) (short) 0, (int) (byte) 10, true);
        boolean boolean13 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.data.Range range7 = barRenderer0.findRangeBounds(categoryDataset5, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Stroke stroke13 = null;
        categoryPlot7.setOutlineStroke(stroke13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation17);
        float float19 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.zoomDomainAxes(16.05d, 0.0d, plotRenderingInfo22, point2D23);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator5);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = standardGradientPaintTransformer7.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        barRenderer0.setMaximumBarWidth((double) ' ');
        double double13 = barRenderer0.getBase();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot4.setOrientation(plotOrientation10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot4.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot4.getInsets();
        java.util.List list15 = categoryPlot4.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19);
        java.awt.Paint paint21 = categoryPlot17.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot17.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        categoryPlot17.setDrawingSupplier(drawingSupplier23);
        java.awt.Font font25 = categoryPlot17.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot26 = categoryPlot17.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder27 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke32 = lineAndShapeRenderer28.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean33 = sortOrder27.equals((java.lang.Object) true);
        categoryPlot17.setColumnRenderingOrder(sortOrder27);
        categoryPlot4.setRowRenderingOrder(sortOrder27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot9.setDrawingSupplier(drawingSupplier12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot9.setDataset(categoryDataset15);
        categoryPlot9.configureRangeAxes();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot9.getRendererForDataset(categoryDataset22);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Stroke stroke10 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(0);
        try {
            lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer10.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint16 = lineAndShapeRenderer10.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer10.setBaseItemLabelPaint((java.awt.Paint) color17, false);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        int int22 = categoryAxis21.getCategoryLabelPositionOffset();
        java.awt.Font font23 = categoryAxis21.getTickLabelFont();
        java.awt.Font font25 = categoryAxis21.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        lineAndShapeRenderer0.setBaseItemLabelFont(font25);
        java.awt.Stroke stroke28 = lineAndShapeRenderer0.getSeriesStroke(2);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        boolean boolean9 = lineAndShapeRenderer1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject(comparable0, (java.lang.Object) boolean9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemPaint((int) (short) 0, (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        boolean boolean7 = legendItem6.isShapeFilled();
        java.awt.Color color8 = java.awt.Color.magenta;
        legendItem6.setFillPaint((java.awt.Paint) color8);
        renderAttributes0.setDefaultPaint((java.awt.Paint) color8);
        java.awt.Color color11 = color8.brighter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        int int13 = categoryPlot10.getCrosshairDatasetIndex();
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setDomainAxisLocation(axisLocation15);
        boolean boolean17 = categoryPlot10.isRangeZoomable();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot10.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis(0, categoryAxis23);
        java.awt.Paint paint25 = categoryPlot21.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot21.getRenderer();
        java.awt.Paint paint27 = categoryPlot21.getDomainGridlinePaint();
        categoryPlot10.setRangeZeroBaselinePaint(paint27);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier8, true);
        int int11 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.clearRangeMarkers(0);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot0.setRangeAxis((int) (short) 10, valueAxis15, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 100);
        int int14 = categoryPlot11.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot11.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot11.setDomainAxisLocation((int) (short) 1, axisLocation28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        boolean boolean34 = categoryPlot30.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot30.getInsets();
        categoryPlot11.setAxisOffset(rectangleInsets35);
        categoryPlot0.setAxisOffset(rectangleInsets35);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean6 = sortOrder0.equals((java.lang.Object) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Paint paint13 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Stroke stroke14 = categoryPlot7.getOutlineStroke();
        boolean boolean15 = sortOrder0.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean22 = lineAndShapeRenderer20.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape24 = lineAndShapeRenderer20.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke29 = lineAndShapeRenderer25.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color30 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape24, stroke29, (java.awt.Paint) color30);
        categoryPlot7.setDomainCrosshairStroke(stroke29);
        categoryPlot7.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) '#', false);
        boolean boolean12 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        legendItem1.setDatasetIndex((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.PaintList paintList5 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean7 = paintList5.equals((java.lang.Object) itemLabelAnchor6);
        boolean boolean8 = categoryAxis0.equals((java.lang.Object) paintList5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        java.awt.Stroke stroke15 = null;
        categoryPlot9.setOutlineStroke(stroke15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        categoryPlot9.drawOutline(graphics2D17, rectangle2D18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot9.getRangeAxis();
        java.lang.String str21 = categoryPlot9.getPlotType();
        boolean boolean22 = paintList5.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        try {
            int int24 = categoryPlot9.getDomainAxisIndex(categoryAxis23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo5 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int3, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo5);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo7 = datasetChangeEvent6.getInfo();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo8 = datasetChangeEvent6.getInfo();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(datasetChangeInfo7);
        org.junit.Assert.assertNotNull(datasetChangeInfo8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        legendItem1.setToolTipText("hi!");
        boolean boolean6 = legendItem1.equals((java.lang.Object) (short) 10);
        legendItem1.setDescription("{0}");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        java.awt.Paint paint26 = categoryPlot22.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot22.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = null;
        categoryPlot22.setDrawingSupplier(drawingSupplier28);
        java.awt.Font font30 = categoryPlot22.getNoDataMessageFont();
        boolean boolean31 = chartChangeEventType21.equals((java.lang.Object) font30);
        lineAndShapeRenderer0.setLegendTextFont(0, font30);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer0.setSeriesPaint(10, paint34, true);
        java.awt.Paint paint37 = lineAndShapeRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator38);
        org.jfree.chart.LegendItem legendItem42 = lineAndShapeRenderer0.getLegendItem((int) ' ', 8);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(legendItem42);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double7 = rectangleInsets6.getTop();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.geom.GeneralPath generalPath4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.RenderingSource renderingSource6 = null;
        categoryPlot0.select(generalPath4, rectangle2D5, renderingSource6);
        categoryPlot0.mapDatasetToDomainAxis(4, 10);
        java.awt.Stroke stroke11 = null;
        try {
            categoryPlot0.setRangeZeroBaselineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.plot.Plot plot12 = categoryPlot3.getParent();
        boolean boolean13 = categoryPlot3.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        categoryPlot0.drawOutline(graphics2D16, rectangle2D17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = lineAndShapeRenderer0.getLegendItems();
        int int11 = lineAndShapeRenderer0.getPassCount();
        java.awt.Shape shape12 = lineAndShapeRenderer0.getBaseShape();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean9 = lineAndShapeRenderer6.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        boolean boolean14 = lineAndShapeRenderer6.hasListener((java.util.EventListener) categoryPlot10);
        java.awt.Stroke stroke15 = categoryPlot10.getDomainCrosshairStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot10.getDrawingSupplier();
        categoryPlot10.setOutlineVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = lineAndShapeRenderer0.initialise(graphics2D4, rectangle2D5, categoryPlot10, categoryDataset19, plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(categoryItemRendererState21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.Paint paint11 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        int int11 = categoryAxis10.getCategoryLabelPositionOffset();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int13 = color12.getGreen();
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color12);
        categoryPlot0.setDomainAxis(10, categoryAxis10, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        categoryPlot17.setDrawingSupplier(drawingSupplier20, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot17.getInsets();
        java.awt.Paint paint24 = categoryPlot17.getRangeCrosshairPaint();
        org.jfree.chart.util.ShadowGenerator shadowGenerator25 = categoryPlot17.getShadowGenerator();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 192 + "'", int13 == 192);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shadowGenerator25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "SortOrder.DESCENDING", "Category Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer0.setBaseCreateEntities(true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray15 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray16 = color10.getComponents(floatArray15);
        lineAndShapeRenderer0.setSeriesOutlinePaint(3, (java.awt.Paint) color10, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer0.getLegendItem(2, (int) (short) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator23, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 10, plotRenderingInfo14, point2D15);
        float float17 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.panDomainAxes(4.0d, plotRenderingInfo19, point2D20);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot5.getDatasetGroup();
        boolean boolean19 = categoryPlot5.isDomainCrosshairVisible();
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getRangeAxisLocation((int) (byte) 100);
        int int24 = categoryPlot21.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset25 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo26 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int24, (org.jfree.data.general.Dataset) abstractCategoryDataset25, datasetChangeInfo26);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = datasetChangeEvent27.getInfo();
        categoryPlot5.datasetChanged(datasetChangeEvent27);
        org.jfree.data.general.Dataset dataset30 = datasetChangeEvent27.getDataset();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(datasetChangeInfo28);
        org.junit.Assert.assertNotNull(dataset30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 0.0f);
        java.awt.Paint paint12 = null;
        lineAndShapeRenderer0.setSeriesPaint(2, paint12, true);
        lineAndShapeRenderer0.clearSeriesPaints(false);
        java.awt.Shape shape18 = lineAndShapeRenderer0.getLegendShape(1);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(shape18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        int int13 = categoryPlot10.getCrosshairDatasetIndex();
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setDomainAxisLocation(axisLocation15);
        boolean boolean17 = categoryPlot10.isRangeZoomable();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot10.getRangeAxisForDataset((int) 'a');
        categoryPlot10.clearRangeAxes();
        boolean boolean22 = categoryPlot10.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible((int) (short) 100);
        barRenderer0.setShadowVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot5.getRangeAxisEdge((int) (byte) 0);
        boolean boolean20 = categoryPlot5.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean33 = lineAndShapeRenderer31.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape35 = lineAndShapeRenderer31.lookupLegendShape(10);
        java.awt.Font font36 = lineAndShapeRenderer31.getBaseItemLabelFont();
        lineAndShapeRenderer0.setBaseLegendTextFont(font36);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean41 = lineAndShapeRenderer38.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot42.setDomainAxis(0, categoryAxis44);
        boolean boolean46 = lineAndShapeRenderer38.hasListener((java.util.EventListener) categoryPlot42);
        boolean boolean50 = lineAndShapeRenderer38.isItemLabelVisible((-1), (int) (short) -1, true);
        java.awt.Stroke stroke52 = lineAndShapeRenderer38.lookupSeriesStroke((int) (byte) 10);
        lineAndShapeRenderer0.setBaseStroke(stroke52);
        java.awt.Shape shape59 = null;
        java.awt.Color color60 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int61 = color60.getGreen();
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "java.awt.Color[r=255,g=255,b=64]", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", shape59, (java.awt.Paint) color60);
        lineAndShapeRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color60, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 192 + "'", int61 == 192);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        boolean boolean5 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, false);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(layer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        categoryPlot0.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot0.getRangeMarkers(layer11);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getInsets();
        double double6 = rectangleInsets5.getRight();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) 10L, (float) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-7903) + "'", int3 == (-7903));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        java.awt.Image image10 = null;
        categoryPlot4.setBackgroundImage(image10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        boolean boolean3 = barRenderer0.getAutoPopulateSeriesShape();
        double double4 = barRenderer0.getMaximumBarWidth();
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        int int3 = categoryAxis2.getCategoryLabelPositionOffset();
        java.awt.Font font4 = categoryAxis2.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        java.awt.Paint paint11 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getFixedLegendItems();
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        java.awt.Paint paint14 = categoryAxis2.getTickLabelPaint();
        barRenderer0.setShadowPaint(paint14);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        barRenderer0.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        try {
            barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("hi!");
        abstractCategoryDataset0.setGroup(datasetGroup2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = abstractCategoryDataset0.getGroup();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        categoryPlot6.setDrawingSupplier(drawingSupplier12);
        java.awt.Font font14 = categoryPlot6.getNoDataMessageFont();
        boolean boolean15 = chartChangeEventType5.equals((java.lang.Object) font14);
        boolean boolean16 = datasetGroup4.equals((java.lang.Object) font14);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint2 = renderAttributes0.getDefaultFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.lang.String str21 = chartEntity20.getShapeCoords();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-3,-3,3,3" + "'", str21.equals("-3,-3,3,3"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType9, 8.0d, (double) 15, (double) 100L, 0.05d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 9, 3.0d, (double) '4', (-1.0d));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int3 = java.awt.Color.HSBtoRGB((float) 255, (float) (-1L), (float) 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.geom.GeneralPath generalPath4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.RenderingSource renderingSource6 = null;
        categoryPlot0.select(generalPath4, rectangle2D5, renderingSource6);
        categoryPlot0.mapDatasetToDomainAxis(4, 10);
        java.lang.String str11 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot0.getDomainAxisForDataset(0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("CategoryAnchor.MIDDLE");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray4 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE" + "'", str2.equals("org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE" + "'", str3.equals("org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer10.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer10.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer10.setBaseCreateEntities(true);
        java.awt.Font font19 = lineAndShapeRenderer10.getBaseItemLabelFont();
        boolean boolean20 = keyedObjects0.equals((java.lang.Object) lineAndShapeRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        int int24 = categoryAxis23.getCategoryLabelPositionOffset();
        java.awt.Font font25 = categoryAxis23.getTickLabelFont();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis23.setAxisLinePaint((java.awt.Paint) color26);
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) 100);
        try {
            keyedObjects0.insertValue((int) 'a', (java.lang.Comparable) "", (java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer0.getPositiveItemLabelPosition(0, (int) (byte) -1, true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color2);
        java.lang.Object obj5 = categoryAxis0.clone();
        java.lang.Object obj6 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        boolean boolean2 = objectList0.equals(obj1);
        java.lang.Object obj3 = null;
        int int4 = objectList0.indexOf(obj3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator13, false);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.data.Range range17 = lineAndShapeRenderer0.findRangeBounds(categoryDataset16);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(9, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        float float3 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.lang.String str4 = categoryAxis0.getLabelURL();
        categoryAxis0.setMinorTickMarkOutsideLength((float) '#');
        java.lang.String str8 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0L);
        java.lang.Comparable comparable9 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem22 = lineAndShapeRenderer0.getLegendItem((-1), (int) (byte) 100);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis(0, categoryAxis13);
        java.awt.Paint paint15 = categoryPlot11.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot11.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        categoryPlot11.setDrawingSupplier(drawingSupplier17);
        java.awt.Font font19 = categoryPlot11.getNoDataMessageFont();
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 100, font19);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean27 = lineAndShapeRenderer25.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape29 = lineAndShapeRenderer25.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke34 = lineAndShapeRenderer30.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color35 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape29, stroke34, (java.awt.Paint) color35);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke34, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis(0, categoryAxis3);
        boolean boolean5 = categoryPlot1.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot1.getInsets();
        categoryPlot1.setRangeZeroBaselineVisible(false);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "{0}");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setURLText("");
        legendItem1.setLineVisible(false);
        java.lang.Comparable comparable6 = legendItem1.getSeriesKey();
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        categoryPlot0.clearDomainMarkers((int) (byte) 0);
        java.awt.Paint paint6 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        keyedObjects0.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis4);
        java.util.List list7 = keyedObjects0.getKeys();
        int int8 = keyedObjects0.getItemCount();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer10.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer10.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer10.setBaseCreateEntities(true);
        java.awt.Font font19 = lineAndShapeRenderer10.getBaseItemLabelFont();
        boolean boolean20 = keyedObjects0.equals((java.lang.Object) lineAndShapeRenderer10);
        keyedObjects0.clear();
        java.lang.Comparable comparable22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis(0, categoryAxis25);
        java.awt.Color color27 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        categoryPlot23.setRangeMinorGridlinePaint((java.awt.Paint) color27);
        int int30 = categoryPlot23.getBackgroundImageAlignment();
        categoryPlot23.clearRangeAxes();
        try {
            keyedObjects0.setObject(comparable22, (java.lang.Object) categoryPlot23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis8.getCategorySeriesMiddle((int) (byte) 0, 0, 0, (int) (short) 100, (-1.0d), rectangle2D16, rectangleEdge17);
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 100L);
        java.awt.Font font22 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 2.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color4);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        int int8 = categoryPlot0.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 0, (double) 1L, plotRenderingInfo11, point2D12);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addRangeMarker(marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.lang.String str23 = plotEntity19.toString();
        java.lang.String str24 = plotEntity19.toString();
        org.jfree.chart.plot.Plot plot25 = plotEntity19.getPlot();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotEntity: tooltip = Category Plot" + "'", str23.equals("PlotEntity: tooltip = Category Plot"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PlotEntity: tooltip = Category Plot" + "'", str24.equals("PlotEntity: tooltip = Category Plot"));
        org.junit.Assert.assertNotNull(plot25);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        int int7 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation8);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        java.awt.Paint paint25 = lineAndShapeRenderer0.getItemLabelPaint(9, (-7903), false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        java.awt.Font font4 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font5 = categoryAxis0.getLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        java.util.List list13 = categoryPlot10.getAnnotations();
        java.awt.Color color14 = java.awt.Color.orange;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = categoryAxis0.draw(graphics2D6, (double) (byte) 10, rectangle2D8, rectangle2D9, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 100);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        java.awt.Paint paint5 = categoryPlot1.getRangeMinorGridlinePaint();
        boolean boolean6 = categoryPlot1.isDomainPannable();
        java.lang.String str7 = categoryPlot1.getPlotType();
        try {
            org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "AxisLocation.BOTTOM_OR_LEFT", "PlotEntity: tooltip = Category Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) keyedObjects2D0, jFreeChart1);
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        int int5 = keyedObjects3.getIndex((java.lang.Comparable) "SortOrder.DESCENDING");
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        keyedObjects3.setObject((java.lang.Comparable) 4, (java.lang.Object) categoryAxis7);
        java.util.List list10 = keyedObjects3.getKeys();
        int int11 = keyedObjects3.getItemCount();
        keyedObjects3.clear();
        java.lang.Object obj13 = keyedObjects3.clone();
        keyedObjects2D0.addObject((java.lang.Object) keyedObjects3, (java.lang.Comparable) ' ', (java.lang.Comparable) "PlotEntity: tooltip = Category Plot");
        int int18 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 100.0f);
        java.util.List list19 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.canSelectByPoint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis11);
        java.awt.Paint paint13 = categoryPlot9.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        java.awt.Stroke stroke15 = null;
        categoryPlot9.setOutlineStroke(stroke15);
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot9.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation(10, axisLocation19, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart4);
        categoryPlot0.setForegroundAlpha((float) (-1L));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.awt.Color color3 = java.awt.Color.magenta;
        legendItem1.setFillPaint((java.awt.Paint) color3);
        legendItem1.setShapeVisible(false);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem1.setLabelFont(font7);
        java.awt.Shape shape9 = legendItem1.getLine();
        boolean boolean10 = legendItem1.isShapeFilled();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = lineAndShapeRenderer0.getLegendItems();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(legendItemCollection29);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint2 = legendItem1.getLinePaint();
        boolean boolean3 = legendItem1.isShapeOutlineVisible();
        java.awt.Paint paint4 = legendItem1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        chartChangeEvent3.setType(chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertNull(chartChangeEventType7);
        org.junit.Assert.assertNull(chartChangeEventType8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            categoryPlot5.handleClick(9, 8, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo5 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int3, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo5);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState7 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState7);
        java.lang.Object obj9 = abstractCategoryDataset4.clone();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState10 = null;
        abstractCategoryDataset4.setSelectionState(categoryDatasetSelectionState10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.lang.String str23 = plotEntity19.toString();
        java.awt.Shape shape24 = plotEntity19.getArea();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean27 = lineAndShapeRenderer25.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape29 = lineAndShapeRenderer25.lookupLegendShape(10);
        plotEntity19.setArea(shape29);
        java.lang.String str31 = plotEntity19.getToolTipText();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotEntity: tooltip = Category Plot" + "'", str23.equals("PlotEntity: tooltip = Category Plot"));
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Category Plot" + "'", str31.equals("Category Plot"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        int int5 = lineAndShapeRenderer0.getColumnCount();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke8 = lineAndShapeRenderer4.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesStroke(0, stroke8, true);
        java.awt.Font font12 = lineAndShapeRenderer0.getLegendTextFont(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 0, paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        java.awt.Paint paint26 = categoryPlot22.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot22.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = null;
        categoryPlot22.setDrawingSupplier(drawingSupplier28);
        java.awt.Font font30 = categoryPlot22.getNoDataMessageFont();
        boolean boolean31 = chartChangeEventType21.equals((java.lang.Object) font30);
        lineAndShapeRenderer0.setLegendTextFont(0, font30);
        boolean boolean33 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot0.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        categoryPlot0.setRangeAxis(255, valueAxis15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean19 = lineAndShapeRenderer17.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape21 = lineAndShapeRenderer17.lookupLegendShape(10);
        java.awt.Paint paint25 = lineAndShapeRenderer17.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint26 = lineAndShapeRenderer17.getBaseLegendTextPaint();
        java.lang.Boolean boolean28 = lineAndShapeRenderer17.getSeriesCreateEntities((int) (short) 10);
        int int29 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean8 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 0);
        boolean boolean12 = lineAndShapeRenderer0.getItemCreateEntity(0, (-1), false);
        double double13 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis(0, categoryAxis19);
        java.awt.Paint paint21 = categoryPlot17.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot17.getRenderer();
        java.awt.Stroke stroke23 = null;
        categoryPlot17.setOutlineStroke(stroke23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        categoryPlot17.drawOutline(graphics2D25, rectangle2D26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot17.getRangeAxis();
        java.awt.Stroke stroke29 = categoryPlot17.getRangeGridlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke29);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        java.lang.String str16 = categoryPlot0.getNoDataMessage();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean23 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(0);
        java.awt.Paint paint25 = lineAndShapeRenderer19.getSeriesOutlinePaint(0);
        java.awt.Font font26 = null;
        lineAndShapeRenderer19.setBaseItemLabelFont(font26, false);
        categoryPlot0.setRenderer(8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        java.lang.Comparable comparable30 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNull(comparable30);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        java.lang.Object obj7 = categoryPlot0.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color8);
        int int10 = color8.getBlue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 192 + "'", int10 == 192);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers(layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        int int13 = categoryAxis12.getCategoryLabelPositionOffset();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        java.awt.Paint paint21 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot15.getFixedLegendItems();
        categoryAxis12.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        categoryAxis12.setLabelURL("hi!");
        categoryAxis12.setVisible(true);
        categoryPlot0.setDomainAxis(0, categoryAxis12, true);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(legendItemCollection22);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot8.addDomainMarker(8, categoryMarker21, layer22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((double) 1);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke13 = lineAndShapeRenderer9.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer9.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot18.setDrawingSupplier(drawingSupplier21, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot18.setDataset(categoryDataset24);
        categoryPlot18.configureRangeAxes();
        lineAndShapeRenderer9.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot18);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState30 = barRenderer0.initialise(graphics2D7, rectangle2D8, categoryPlot18, categoryDataset28, plotRenderingInfo29);
        boolean boolean31 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        barRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(categoryItemRendererState30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        java.util.List list4 = keyedObjects2D0.getRowKeys();
        int int5 = keyedObjects2D0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint7 = categoryAxis6.getTickMarkPaint();
        keyedObjects2D0.setObject((java.lang.Object) paint7, (java.lang.Comparable) 2.0f, (java.lang.Comparable) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        double double8 = rectangleInsets6.trimWidth((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType9, 8.0d, (double) 15, (double) 100L, 0.05d);
        java.lang.String str16 = unitType9.toString();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-17.0d) + "'", double8 == (-17.0d));
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnitType.ABSOLUTE" + "'", str16.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean16 = lineAndShapeRenderer14.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape18 = lineAndShapeRenderer14.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke23 = lineAndShapeRenderer19.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color24 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape18, stroke23, (java.awt.Paint) color24);
        barRenderer0.setSeriesShape((int) (byte) 10, shape18, false);
        int int28 = barRenderer0.getRowCount();
        double double29 = barRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Color color3 = java.awt.Color.getColor("", (int) ' ');
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) -1, color3, 100.0f, 10, (double) 100.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis(0, categoryAxis10);
        java.awt.Paint paint12 = categoryPlot8.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot8.getRenderer();
        java.awt.Stroke stroke14 = null;
        categoryPlot8.setOutlineStroke(stroke14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier16, true);
        double double19 = categoryPlot8.getRangeCrosshairValue();
        java.awt.Stroke stroke20 = categoryPlot8.getDomainCrosshairStroke();
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        boolean boolean23 = defaultShadowGenerator7.equals((java.lang.Object) categoryPlot8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint7 = legendItem6.getLinePaint();
        categoryPlot0.setRangeCrosshairPaint(paint7);
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryPlot0.markerChanged(markerChangeEvent9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(100.0d, 0.0d, rectangle2D13, renderingSource14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getRangeAxisLocation((int) (byte) 100);
        java.util.List list19 = categoryPlot16.getAnnotations();
        categoryPlot16.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer22.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis(0, categoryAxis29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace31, true);
        boolean boolean34 = categoryPlot27.canSelectByPoint();
        lineAndShapeRenderer22.setPlot(categoryPlot27);
        categoryPlot27.setForegroundAlpha(0.0f);
        categoryPlot27.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        categoryPlot40.setDomainAxis(0, categoryAxis42);
        java.awt.Paint paint44 = categoryPlot40.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot40.getRenderer();
        java.awt.Stroke stroke46 = null;
        categoryPlot40.setOutlineStroke(stroke46);
        org.jfree.data.general.DatasetGroup datasetGroup48 = categoryPlot40.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot40.getRangeAxisLocation((int) (byte) 0);
        categoryPlot27.setDomainAxisLocation(axisLocation50);
        categoryPlot16.setDomainAxisLocation(axisLocation50);
        java.lang.String str53 = axisLocation50.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation50);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(categoryItemRenderer45);
        org.junit.Assert.assertNull(datasetGroup48);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str53.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        boolean boolean18 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        lineAndShapeRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot5.setDrawingSupplier(drawingSupplier8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot5.getInsets();
        int int12 = objectList4.indexOf((java.lang.Object) rectangleInsets11);
        double double14 = rectangleInsets11.calculateTopOutset((double) ' ');
        categoryAxis0.setTickLabelInsets(rectangleInsets11);
        double double16 = rectangleInsets11.getTop();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createInsetRectangle(rectangle2D17, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        java.awt.Font font10 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (short) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer0.getItemLabelPaint(3, (int) (byte) -1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean17 = lineAndShapeRenderer15.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape19 = lineAndShapeRenderer15.lookupLegendShape(10);
        java.awt.Paint paint23 = lineAndShapeRenderer15.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint24 = lineAndShapeRenderer15.getBaseLegendTextPaint();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        lineAndShapeRenderer15.setSeriesFillPaint((int) 'a', (java.awt.Paint) color26);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color26);
        lineAndShapeRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        int int5 = lineAndShapeRenderer0.getColumnCount();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.lang.Boolean boolean13 = lineAndShapeRenderer0.getSeriesVisibleInLegend((int) (short) -1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.lang.Object obj1 = abstractCategoryDataset0.clone();
        org.jfree.data.general.DatasetGroup datasetGroup2 = abstractCategoryDataset0.getGroup();
        java.lang.String str3 = datasetGroup2.getID();
        java.lang.Object obj4 = datasetGroup2.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOID" + "'", str3.equals("NOID"));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke12 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(stroke12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        renderAttributes0.setDefaultLabelFont(font12);
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultLabelVisible();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Paint paint18 = renderAttributes0.getDefaultFillPaint();
        try {
            renderAttributes0.setSeriesCreateEntity((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        double double4 = barRenderer0.getShadowYOffset();
        double double5 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer0.getBarPainter();
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent8.setType(chartChangeEventType10);
        chartChangeEvent3.setType(chartChangeEventType10);
        org.junit.Assert.assertNull(chartChangeEventType4);
        org.junit.Assert.assertNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        boolean boolean23 = lineAndShapeRenderer0.getItemLineVisible(100, (int) (byte) 1);
        java.awt.Font font24 = lineAndShapeRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font24);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator5);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = standardGradientPaintTransformer7.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.data.Range range13 = barRenderer0.findRangeBounds(categoryDataset11, false);
        boolean boolean15 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer0.setShadowYOffset((double) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Shape shape5 = lineAndShapeRenderer0.getBaseLegendShape();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean3 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean5 = lineAndShapeRenderer1.getSeriesItemLabelsVisible(0);
        boolean boolean6 = shapeList0.equals((java.lang.Object) 0);
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        java.lang.Boolean boolean12 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(0);
        boolean boolean13 = shapeList7.equals((java.lang.Object) 0);
        boolean boolean14 = shapeList0.equals((java.lang.Object) 0);
        java.lang.Object obj15 = shapeList0.clone();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean17 = shapeList0.equals((java.lang.Object) axisLocation16);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape19);
        shapeList0.setShape((int) (byte) 10, shape19);
        int int22 = shapeList0.size();
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier8, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        int int12 = categoryPlot0.indexOf(categoryDataset11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo7, point2D8);
        categoryPlot0.setCrosshairDatasetIndex(10, true);
        int int13 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis(0, categoryAxis16);
        java.awt.Paint paint18 = categoryPlot14.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        categoryPlot14.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer22.getItemStroke((int) (short) 1, (int) (short) 100, true);
        categoryPlot14.setDomainGridlineStroke(stroke26);
        categoryPlot0.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        int int30 = categoryAxis29.getCategoryLabelPositionOffset();
        java.awt.Font font31 = categoryAxis29.getTickLabelFont();
        java.awt.Font font33 = categoryAxis29.getTickLabelFont((java.lang.Comparable) "CategoryAnchor.MIDDLE");
        java.awt.Font font34 = categoryAxis29.getLabelFont();
        java.awt.Font font36 = categoryAxis29.getTickLabelFont((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        categoryPlot0.setNoDataMessageFont(font36);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color4);
        boolean boolean7 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(10, categoryDataset2);
        java.lang.String str4 = categoryPlot0.getPlotType();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 100);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 1, false);
        java.awt.Stroke stroke10 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            categoryPlot0.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier8, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        int int14 = lineAndShapeRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.util.StrokeList strokeList17 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean19 = strokeList17.equals((java.lang.Object) textAnchor18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor18);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition20);
        boolean boolean22 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        boolean boolean16 = lineAndShapeRenderer0.getUseOutlinePaint();
        java.awt.Shape shape20 = lineAndShapeRenderer0.getItemShape(1, 0, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getColumnCount();
        int int3 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = lineAndShapeRenderer4.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer4.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean12 = lineAndShapeRenderer4.isSeriesVisible((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        lineAndShapeRenderer4.setSeriesURLGenerator((int) 'a', categoryURLGenerator14);
        keyedObjects2D0.addObject((java.lang.Object) lineAndShapeRenderer4, (java.lang.Comparable) (byte) 100, (java.lang.Comparable) '#');
        java.lang.Comparable comparable20 = keyedObjects2D0.getRowKey((int) (short) 0);
        try {
            java.lang.Object obj23 = keyedObjects2D0.getObject((java.lang.Comparable) '#', (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (#) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (byte) 100 + "'", comparable20.equals((byte) 100));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setAxisLineVisible(true);
        categoryAxis0.setMaximumCategoryLabelLines(3);
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int3 = color2.getGreen();
        java.awt.Color color4 = java.awt.Color.getColor("hi!", color2);
        java.awt.Color color5 = java.awt.Color.getColor("org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", color4);
        int int6 = color4.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        java.lang.Boolean boolean21 = lineAndShapeRenderer0.getSeriesCreateEntities(0);
        boolean boolean24 = lineAndShapeRenderer0.getItemShapeFilled(192, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        java.awt.geom.GeneralPath generalPath4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.RenderingSource renderingSource6 = null;
        categoryPlot0.select(generalPath4, rectangle2D5, renderingSource6);
        categoryPlot0.mapDatasetToDomainAxis(4, 10);
        java.awt.Stroke stroke11 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset14);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot2.setDomainAxis(0, categoryAxis4);
        java.awt.Paint paint6 = categoryPlot2.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot2.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot2.setDrawingSupplier(drawingSupplier8);
        java.awt.Font font10 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot11 = categoryPlot2.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder12 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke17 = lineAndShapeRenderer13.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean18 = sortOrder12.equals((java.lang.Object) true);
        categoryPlot2.setColumnRenderingOrder(sortOrder12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        boolean boolean28 = lineAndShapeRenderer20.hasListener((java.util.EventListener) categoryPlot24);
        java.awt.Stroke stroke30 = lineAndShapeRenderer20.lookupSeriesStroke(0);
        categoryPlot2.setOutlineStroke(stroke30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot2.getRangeAxisEdge();
        org.jfree.chart.util.StrokeList strokeList33 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean35 = strokeList33.equals((java.lang.Object) textAnchor34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer37.setShadowVisible(true);
        java.awt.Paint paint40 = barRenderer37.getBaseOutlinePaint();
        double double41 = barRenderer37.getShadowYOffset();
        java.lang.Boolean boolean43 = barRenderer37.getSeriesCreateEntities((int) ' ');
        java.awt.Stroke stroke44 = barRenderer37.getBaseOutlineStroke();
        strokeList33.setStroke(2, stroke44);
        categoryPlot2.setOutlineStroke(stroke44);
        java.lang.Comparable comparable47 = null;
        try {
            keyedObjects2D0.setObject((java.lang.Object) stroke44, comparable47, (java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setRangeCrosshairValue((double) 1);
        java.awt.Color color11 = java.awt.Color.orange;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (short) -1, plotRenderingInfo12, point2D13);
        categoryPlot5.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "SortOrder.DESCENDING");
        plotEntity19.setToolTipText("Category Plot");
        java.lang.String str22 = plotEntity19.getShapeCoords();
        java.lang.String str23 = plotEntity19.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis(0, categoryAxis26);
        java.awt.Paint paint28 = categoryPlot24.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = null;
        categoryPlot24.setDrawingSupplier(drawingSupplier30);
        java.awt.Font font32 = categoryPlot24.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot33 = categoryPlot24.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder34 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke39 = lineAndShapeRenderer35.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean40 = sortOrder34.equals((java.lang.Object) true);
        categoryPlot24.setColumnRenderingOrder(sortOrder34);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean45 = lineAndShapeRenderer42.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot46.setDomainAxis(0, categoryAxis48);
        boolean boolean50 = lineAndShapeRenderer42.hasListener((java.util.EventListener) categoryPlot46);
        java.awt.Stroke stroke52 = lineAndShapeRenderer42.lookupSeriesStroke(0);
        categoryPlot24.setOutlineStroke(stroke52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot24.getRangeAxisEdge();
        boolean boolean55 = plotEntity19.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotEntity: tooltip = Category Plot" + "'", str23.equals("PlotEntity: tooltip = Category Plot"));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis(0, categoryAxis9);
        java.awt.Paint paint11 = categoryPlot7.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot7.getRenderer();
        java.awt.Stroke stroke13 = null;
        categoryPlot7.setOutlineStroke(stroke13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation17);
        java.awt.Stroke stroke19 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot5.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = axisLocation28.getOpposite();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        double double3 = barRenderer0.getBase();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.LegendItem legendItem8 = barRenderer0.getLegendItem((int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) (short) -1, plotRenderingInfo6, point2D7, true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        lineAndShapeRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawOutline(graphics2D8, rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot0.select(0.0d, 0.0d, rectangle2D13, renderingSource14);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        int int18 = categoryPlot0.indexOf(categoryDataset17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot9 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer11.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean16 = sortOrder10.equals((java.lang.Object) true);
        categoryPlot0.setColumnRenderingOrder(sortOrder10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean21 = lineAndShapeRenderer18.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        boolean boolean26 = lineAndShapeRenderer18.hasListener((java.util.EventListener) categoryPlot22);
        java.awt.Stroke stroke28 = lineAndShapeRenderer18.lookupSeriesStroke(0);
        categoryPlot0.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.StrokeList strokeList31 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean33 = strokeList31.equals((java.lang.Object) textAnchor32);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer35.setShadowVisible(true);
        java.awt.Paint paint38 = barRenderer35.getBaseOutlinePaint();
        double double39 = barRenderer35.getShadowYOffset();
        java.lang.Boolean boolean41 = barRenderer35.getSeriesCreateEntities((int) ' ');
        java.awt.Stroke stroke42 = barRenderer35.getBaseOutlineStroke();
        strokeList31.setStroke(2, stroke42);
        categoryPlot0.setOutlineStroke(stroke42);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean47 = lineAndShapeRenderer45.getSeriesItemLabelsVisible(100);
        java.awt.Stroke stroke49 = lineAndShapeRenderer45.lookupSeriesStroke(10);
        categoryPlot0.setDomainGridlineStroke(stroke49);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertNull(boolean41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint18 = categoryPlot5.getOutlinePaint();
        org.jfree.chart.plot.Plot plot19 = categoryPlot5.getRootPlot();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(plot19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot5.setDomainAxisLocation(axisLocation28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot5.getRendererForDataset(categoryDataset30);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(categoryItemRenderer31);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        java.lang.Boolean boolean15 = lineAndShapeRenderer0.getSeriesCreateEntities(192);
        java.awt.Stroke stroke16 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot5.getDatasetGroup();
        boolean boolean19 = categoryPlot5.isDomainCrosshairVisible();
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getRangeAxisLocation((int) (byte) 100);
        int int24 = categoryPlot21.getCrosshairDatasetIndex();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset25 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo26 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) int24, (org.jfree.data.general.Dataset) abstractCategoryDataset25, datasetChangeInfo26);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = datasetChangeEvent27.getInfo();
        categoryPlot5.datasetChanged(datasetChangeEvent27);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo30 = datasetChangeEvent27.getInfo();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(datasetChangeInfo28);
        org.junit.Assert.assertNotNull(datasetChangeInfo30);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setLegendTextFont(0, font10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemStroke(0, 15, false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (byte) -1, false);
        java.lang.Boolean boolean21 = lineAndShapeRenderer0.getSeriesCreateEntities(0);
        boolean boolean22 = lineAndShapeRenderer0.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint4 = barRenderer0.getSeriesFillPaint(15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeFilled();
        java.lang.String str3 = legendItem1.getToolTipText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem1.getFillPaintTransformer();
        java.lang.String str5 = legendItem1.getToolTipText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer6.setShadowVisible(true);
        java.awt.Paint paint9 = barRenderer6.getBaseOutlinePaint();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("");
        boolean boolean12 = legendItem11.isShapeFilled();
        java.awt.Color color13 = java.awt.Color.magenta;
        legendItem11.setFillPaint((java.awt.Paint) color13);
        legendItem11.setShapeVisible(false);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendItem11.setLabelFont(font17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem11.getFillPaintTransformer();
        barRenderer6.setGradientPaintTransformer(gradientPaintTransformer19);
        legendItem1.setFillPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint22 = legendItem1.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        java.awt.Shape shape32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color34 = java.awt.Color.BLUE;
        java.awt.Color color36 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes37 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes37.setDefaultOutlineStroke(stroke38);
        java.awt.Shape shape41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot42.setDomainAxis(0, categoryAxis44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot42.setFixedRangeAxisSpace(axisSpace46, true);
        categoryPlot42.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke52 = categoryPlot42.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes53 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean54 = renderAttributes53.getAllowNull();
        java.awt.Stroke stroke55 = renderAttributes53.getDefaultStroke();
        java.awt.Color color56 = java.awt.Color.red;
        renderAttributes53.setDefaultFillPaint((java.awt.Paint) color56);
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape32, true, (java.awt.Paint) color34, false, (java.awt.Paint) color36, stroke38, false, shape41, stroke52, (java.awt.Paint) color56);
        lineAndShapeRenderer0.setBaseStroke(stroke38);
        lineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        java.awt.Paint paint22 = categoryPlot18.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot18.getRenderer();
        java.awt.Stroke stroke24 = null;
        categoryPlot18.setOutlineStroke(stroke24);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot18.getRangeAxisLocation((int) (byte) 0);
        categoryPlot5.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean33 = lineAndShapeRenderer30.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis(0, categoryAxis36);
        boolean boolean38 = lineAndShapeRenderer30.hasListener((java.util.EventListener) categoryPlot34);
        java.awt.Stroke stroke40 = lineAndShapeRenderer30.lookupSeriesStroke(0);
        java.awt.Stroke stroke41 = lineAndShapeRenderer30.getBaseStroke();
        categoryPlot5.setDomainGridlineStroke(stroke41);
        categoryPlot5.setDomainCrosshairColumnKey((java.lang.Comparable) (-1L), false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemFillPaint(3, (int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        java.awt.Paint paint10 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRenderer();
        java.awt.Stroke stroke12 = null;
        categoryPlot6.setOutlineStroke(stroke12);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot6.getRangeAxisLocation((int) (byte) 0);
        java.awt.Paint paint17 = categoryPlot6.getRangeMinorGridlinePaint();
        renderAttributes0.setSeriesPaint((int) (short) 100, paint17);
        java.awt.Font font19 = renderAttributes0.getDefaultLabelFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(font19);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 100);
        int int4 = categoryPlot1.getCrosshairDatasetIndex();
        java.awt.Image image5 = categoryPlot1.getBackgroundImage();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot1.markerChanged(markerChangeEvent6);
        boolean boolean8 = strokeList0.equals((java.lang.Object) categoryPlot1);
        categoryPlot1.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation5);
        categoryPlot0.setForegroundAlpha(0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.BLACK;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        barRenderer0.setBaseItemLabelFont(font6, false);
        try {
            barRenderer0.setSeriesItemLabelsVisible((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setVisible(true);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis0.getLabelInsets();
        double double19 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset(categoryDataset14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        categoryPlot26.setDomainAxis(0, categoryAxis28);
        java.awt.Paint paint30 = categoryPlot26.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot26.getRenderer();
        java.awt.Stroke stroke32 = null;
        categoryPlot26.setOutlineStroke(stroke32);
        categoryPlot26.setWeight(0);
        boolean boolean36 = categoryPlot26.isOutlineVisible();
        int int37 = categoryPlot26.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        int int39 = categoryAxis38.getCategoryLabelPositionOffset();
        java.awt.Font font40 = categoryAxis38.getTickLabelFont();
        float float41 = categoryAxis38.getMinorTickMarkOutsideLength();
        java.lang.String str42 = categoryAxis38.getLabelURL();
        categoryAxis38.setMinorTickMarkOutsideLength((float) '#');
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = lineAndShapeRenderer50.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke60 = lineAndShapeRenderer56.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer50.setSeriesOutlineStroke(10, stroke60);
        java.awt.Paint paint62 = lineAndShapeRenderer50.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        categoryPlot65.setDomainAxis(0, categoryAxis67);
        java.awt.Paint paint69 = categoryPlot65.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = categoryPlot65.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier71 = null;
        categoryPlot65.setDrawingSupplier(drawingSupplier71);
        categoryPlot65.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState78 = lineAndShapeRenderer50.initialise(graphics2D63, rectangle2D64, categoryPlot65, categoryDataset76, plotRenderingInfo77);
        try {
            java.awt.Shape shape79 = lineAndShapeRenderer0.createHotSpotShape(graphics2D24, rectangle2D25, categoryPlot26, categoryAxis38, valueAxis45, categoryDataset46, (int) (short) 1, 255, true, categoryItemRendererState78);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNull(categoryURLGenerator54);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(categoryItemRenderer70);
        org.junit.Assert.assertNotNull(categoryItemRendererState78);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisLocation.BOTTOM_OR_LEFT", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        int int3 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        java.awt.Paint paint6 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis(4);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = lineAndShapeRenderer0.getSelectedItemAttributes();
        java.awt.Paint paint21 = renderAttributes18.getItemOutlinePaint(0, 4);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(renderAttributes18);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setShadowVisible(true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible((int) (short) 100);
        int int6 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowVisible(true);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(100, categoryItemLabelGenerator5);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = standardGradientPaintTransformer7.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        boolean boolean11 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        java.awt.Font font4 = barRenderer0.getSeriesItemLabelFont((-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((double) 1);
        barRenderer0.setMaximumBarWidth((double) 0L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke13 = lineAndShapeRenderer9.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer9.getPositiveItemLabelPosition(10, (int) (short) 0, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot18.setDrawingSupplier(drawingSupplier21, false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot18.setDataset(categoryDataset24);
        categoryPlot18.configureRangeAxes();
        lineAndShapeRenderer9.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot18);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState30 = barRenderer0.initialise(graphics2D7, rectangle2D8, categoryPlot18, categoryDataset28, plotRenderingInfo29);
        boolean boolean31 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis(0, categoryAxis35);
        java.awt.Paint paint37 = categoryPlot33.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot33.getRenderer();
        java.awt.Stroke stroke39 = null;
        categoryPlot33.setOutlineStroke(stroke39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        categoryPlot33.drawOutline(graphics2D41, rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            barRenderer0.drawBackground(graphics2D32, categoryPlot33, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(categoryItemRendererState30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryItemRenderer38);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        java.awt.Paint paint14 = categoryPlot10.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot10.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot10.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        int int19 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryPlot10.setDomainAxis((int) ' ', categoryAxis18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = lineAndShapeRenderer21.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint27 = lineAndShapeRenderer21.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean29 = lineAndShapeRenderer21.getSeriesShapesFilled((int) (short) 0);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        java.awt.Shape shape31 = lineAndShapeRenderer21.getBaseShape();
        lineAndShapeRenderer0.setSeriesShape((int) (byte) 100, shape31, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator34, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = lineAndShapeRenderer0.getDrawingSupplier();
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color14 = java.awt.Color.BLUE;
        java.awt.Color color16 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes17.setDefaultOutlineStroke(stroke18);
        java.awt.Shape shape21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot22.setDomainAxis(0, categoryAxis24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace26, true);
        categoryPlot22.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke32 = categoryPlot22.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean34 = renderAttributes33.getAllowNull();
        java.awt.Stroke stroke35 = renderAttributes33.getDefaultStroke();
        java.awt.Color color36 = java.awt.Color.red;
        renderAttributes33.setDefaultFillPaint((java.awt.Paint) color36);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape12, true, (java.awt.Paint) color14, false, (java.awt.Paint) color16, stroke18, false, shape21, stroke32, (java.awt.Paint) color36);
        lineAndShapeRenderer0.setSeriesPaint(0, (java.awt.Paint) color14, false);
        java.awt.Paint paint41 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.util.List list3 = categoryPlot0.getAnnotations();
        java.awt.Color color4 = java.awt.Color.orange;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot0.removeDomainMarker(marker6, layer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState13 = null;
        boolean boolean14 = categoryPlot0.render(graphics2D9, rectangle2D10, (int) ' ', plotRenderingInfo12, categoryCrosshairState13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation((int) (byte) 0);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Paint paint13 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean17 = lineAndShapeRenderer14.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis(0, categoryAxis20);
        boolean boolean22 = lineAndShapeRenderer14.hasListener((java.util.EventListener) categoryPlot18);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot18.setOrientation(plotOrientation24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        categoryPlot18.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot18.getInsets();
        double double30 = rectangleInsets28.calculateRightOutset(3.0d);
        categoryPlot0.setAxisOffset(rectangleInsets28);
        java.lang.String str32 = rectangleInsets28.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 8.0d + "'", double30 == 8.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str32.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setAxisLineVisible(true);
        double double4 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer0.setBasePaint(paint11, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14);
        java.awt.Paint paint17 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape23 = lineAndShapeRenderer19.lookupLegendShape(10);
        java.awt.Paint paint27 = lineAndShapeRenderer19.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint28 = lineAndShapeRenderer19.getBaseLegendTextPaint();
        java.awt.Stroke stroke30 = lineAndShapeRenderer19.lookupSeriesOutlineStroke((int) (byte) 0);
        lineAndShapeRenderer0.setSeriesOutlineStroke(1, stroke30, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean35 = lineAndShapeRenderer33.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke41 = lineAndShapeRenderer37.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer33.setSeriesStroke(0, stroke41, true);
        java.awt.Font font45 = lineAndShapeRenderer33.getLegendTextFont(0);
        lineAndShapeRenderer33.setBaseCreateEntities(false);
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer33.setSeriesItemLabelPaint((int) (short) 0, paint49);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = lineAndShapeRenderer33.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType54 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        categoryPlot55.setDomainAxis(0, categoryAxis57);
        java.awt.Paint paint59 = categoryPlot55.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = categoryPlot55.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier61 = null;
        categoryPlot55.setDrawingSupplier(drawingSupplier61);
        java.awt.Font font63 = categoryPlot55.getNoDataMessageFont();
        boolean boolean64 = chartChangeEventType54.equals((java.lang.Object) font63);
        lineAndShapeRenderer33.setLegendTextFont(0, font63);
        java.awt.Paint paint67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer33.setSeriesPaint(10, paint67, true);
        java.awt.Paint paint70 = lineAndShapeRenderer33.getBaseFillPaint();
        lineAndShapeRenderer0.setBaseItemLabelPaint(paint70);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(font45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertNotNull(chartChangeEventType54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(categoryItemRenderer60);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        boolean boolean3 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        double double5 = barRenderer4.getItemMargin();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer4.getBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter6);
        barRenderer0.setBarPainter(barPainter6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(barPainter6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke5 = lineAndShapeRenderer1.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace10, true);
        boolean boolean13 = categoryPlot6.canSelectByPoint();
        lineAndShapeRenderer1.setPlot(categoryPlot6);
        lineAndShapeRenderer1.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes19 = lineAndShapeRenderer1.getSelectedItemAttributes();
        boolean boolean20 = lineAndShapeRenderer1.getBaseCreateEntities();
        boolean boolean21 = datasetRenderingOrder0.equals((java.lang.Object) lineAndShapeRenderer1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(renderAttributes19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lineAndShapeRenderer29.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis(0, categoryAxis35);
        boolean boolean37 = lineAndShapeRenderer29.hasListener((java.util.EventListener) categoryPlot33);
        java.awt.Stroke stroke38 = categoryPlot33.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot33.setOrientation(plotOrientation39);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = null;
        categoryPlot33.setDrawingSupplier(drawingSupplier41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryPlot33.getInsets();
        lineAndShapeRenderer0.setPlot(categoryPlot33);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelGenerator((-14336), categoryItemLabelGenerator46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setBackgroundAlpha((float) 3);
        boolean boolean10 = categoryPlot0.canSelectByRegion();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint6 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        int int8 = categoryAxis7.getCategoryLabelPositionOffset();
        java.awt.Font font9 = categoryAxis7.getTickLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis7.setAxisLinePaint((java.awt.Paint) color10);
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 100);
        java.util.List list14 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean8 = lineAndShapeRenderer0.isSeriesVisible((int) 'a');
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        lineAndShapeRenderer0.setBasePaint(paint11, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14);
        lineAndShapeRenderer0.setUseFillPaint(false);
        java.awt.Stroke stroke19 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke25 = lineAndShapeRenderer21.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        categoryPlot26.setDomainAxis(0, categoryAxis28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot26.setFixedRangeAxisSpace(axisSpace30, true);
        boolean boolean33 = categoryPlot26.canSelectByPoint();
        lineAndShapeRenderer21.setPlot(categoryPlot26);
        lineAndShapeRenderer21.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean41 = lineAndShapeRenderer39.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape43 = lineAndShapeRenderer39.lookupLegendShape(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        categoryPlot44.setDomainAxis(0, categoryAxis46);
        java.awt.Paint paint48 = categoryPlot44.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot44.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot44.zoomDomainAxes((double) (short) -1, plotRenderingInfo51, point2D52);
        categoryPlot44.setCrosshairDatasetIndex(10, true);
        org.jfree.chart.entity.PlotEntity plotEntity58 = new org.jfree.chart.entity.PlotEntity(shape43, (org.jfree.chart.plot.Plot) categoryPlot44, "SortOrder.DESCENDING");
        plotEntity58.setToolTipText("Category Plot");
        java.lang.String str61 = plotEntity58.getShapeCoords();
        java.lang.String str62 = plotEntity58.toString();
        java.awt.Shape shape63 = plotEntity58.getArea();
        lineAndShapeRenderer21.setBaseShape(shape63);
        try {
            lineAndShapeRenderer0.setSeriesShape((-4), shape63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(boolean41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "-3,-3,3,3" + "'", str61.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "PlotEntity: tooltip = Category Plot" + "'", str62.equals("PlotEntity: tooltip = Category Plot"));
        org.junit.Assert.assertNotNull(shape63);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        boolean boolean12 = lineAndShapeRenderer0.isItemLabelVisible((-1), (int) (short) -1, true);
        java.awt.Shape shape14 = lineAndShapeRenderer0.lookupLegendShape((-4));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint6 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint7 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        double double6 = categoryAxis0.getFixedDimension();
        boolean boolean7 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "", "SortOrder.DESCENDING");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        boolean boolean4 = categoryPlot0.isDomainPannable();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getInsets();
        java.lang.String str6 = rectangleInsets5.toString();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets5.getUnitType();
        double double9 = rectangleInsets5.trimWidth((double) 192);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 176.0d + "'", double9 == 176.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = categoryPlot0.getDataRange(valueAxis11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE1" + "'", str1.equals("ItemLabelAnchor.INSIDE1"));
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        renderAttributes0.setDefaultLabelFont(font12);
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultLabelVisible();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("");
        java.awt.Paint paint20 = legendItem19.getLinePaint();
        renderAttributes0.setDefaultOutlinePaint(paint20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 1L);
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.setTickMarkOutsideLength((float) (short) -1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean10 = lineAndShapeRenderer8.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke16 = lineAndShapeRenderer12.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke16, true);
        java.awt.Font font20 = lineAndShapeRenderer8.getLegendTextFont(0);
        lineAndShapeRenderer8.setBaseCreateEntities(false);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 0, paint24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis(0, categoryAxis32);
        java.awt.Paint paint34 = categoryPlot30.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot30.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = null;
        categoryPlot30.setDrawingSupplier(drawingSupplier36);
        java.awt.Font font38 = categoryPlot30.getNoDataMessageFont();
        boolean boolean39 = chartChangeEventType29.equals((java.lang.Object) font38);
        lineAndShapeRenderer8.setLegendTextFont(0, font38);
        categoryAxis0.setLabelFont(font38);
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(chartChangeEventType29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemPaint((int) (short) 0, (int) (byte) 10);
        java.awt.Paint paint7 = renderAttributes0.getItemFillPaint((int) (byte) 0, (int) (byte) -1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = lineAndShapeRenderer9.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        lineAndShapeRenderer9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        java.awt.Stroke stroke19 = lineAndShapeRenderer9.lookupSeriesOutlineStroke(0);
        try {
            renderAttributes0.setSeriesOutlineStroke((int) (byte) 0, stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge(10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot5.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer23.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer19.setSeriesStroke(0, stroke27, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer19.setBaseToolTipGenerator(categoryToolTipGenerator30);
        categoryPlot5.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19, true);
        java.awt.Shape shape34 = lineAndShapeRenderer19.getBaseShape();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Paint paint4 = renderAttributes0.getItemPaint((int) (short) 0, (int) (byte) 10);
        java.awt.Stroke stroke7 = renderAttributes0.getItemStroke(192, 0);
        java.awt.Paint paint8 = renderAttributes0.getDefaultPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier3, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) color7);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-7903), false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        boolean boolean14 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        double double17 = barRenderer16.getItemMargin();
        org.jfree.chart.renderer.category.BarPainter barPainter18 = barRenderer16.getBarPainter();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer16.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        lineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(barPainter18);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) 1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer6.getItemStroke((int) (short) 1, (int) (short) 100, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(10, stroke10);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        java.awt.Paint paint19 = categoryPlot15.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot15.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        categoryPlot15.mapDatasetToDomainAxis(10, 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, categoryDataset26, plotRenderingInfo27);
        boolean boolean29 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(categoryItemRendererState28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean9 = lineAndShapeRenderer6.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(0, categoryAxis12);
        boolean boolean14 = lineAndShapeRenderer6.hasListener((java.util.EventListener) categoryPlot10);
        java.awt.Stroke stroke16 = lineAndShapeRenderer6.lookupSeriesStroke(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean19 = lineAndShapeRenderer17.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape21 = lineAndShapeRenderer17.lookupLegendShape(10);
        java.awt.Paint paint25 = lineAndShapeRenderer17.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint26 = lineAndShapeRenderer17.getBaseLegendTextPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = lineAndShapeRenderer27.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint33 = lineAndShapeRenderer27.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer27.setBaseItemLabelPaint((java.awt.Paint) color34, false);
        lineAndShapeRenderer17.setBasePaint((java.awt.Paint) color34);
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "AxisLocation.TOP_OR_LEFT", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", shape4, (java.awt.Paint) color5, stroke16, (java.awt.Paint) color34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNull(categoryURLGenerator31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Color color10 = java.awt.Color.magenta;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray16 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray17 = color11.getComponents(floatArray16);
        float[] floatArray18 = color10.getComponents(floatArray17);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color10, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer0.getSeriesStroke((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("hi!");
        abstractCategoryDataset0.setGroup(datasetGroup2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getRangeAxisLocation((int) (byte) 100);
        int int7 = categoryPlot4.getCrosshairDatasetIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot4.axisChanged(axisChangeEvent8);
        java.awt.Paint paint10 = categoryPlot4.getDomainCrosshairPaint();
        java.awt.Stroke stroke11 = categoryPlot4.getRangeCrosshairStroke();
        abstractCategoryDataset0.removeChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setShadowVisible(true);
        java.awt.Paint paint17 = barRenderer14.getBaseOutlinePaint();
        double double18 = barRenderer14.getShadowYOffset();
        java.lang.Boolean boolean20 = barRenderer14.getSeriesCreateEntities((int) ' ');
        java.awt.Stroke stroke21 = barRenderer14.getBaseOutlineStroke();
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color4);
        categoryPlot0.clearRangeMarkers((int) '#');
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 100);
        int int6 = categoryPlot3.getCrosshairDatasetIndex();
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot3.zoomRangeAxes((double) (byte) 1, plotRenderingInfo10, point2D11, true);
        categoryPlot3.clearSelection();
        java.awt.Stroke stroke15 = categoryPlot3.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis(0, categoryAxis18);
        java.awt.Paint paint20 = categoryPlot16.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot16.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        categoryPlot16.setDrawingSupplier(drawingSupplier22);
        java.awt.Font font24 = categoryPlot16.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot25 = categoryPlot16.getRootPlot();
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke31 = lineAndShapeRenderer27.getItemStroke((int) (short) 1, (int) (short) 100, true);
        boolean boolean32 = sortOrder26.equals((java.lang.Object) true);
        categoryPlot16.setColumnRenderingOrder(sortOrder26);
        categoryPlot3.setRowRenderingOrder(sortOrder26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 100);
        int int13 = categoryPlot10.getCrosshairDatasetIndex();
        boolean boolean14 = categoryPlot10.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setDomainAxisLocation(axisLocation15);
        boolean boolean17 = categoryPlot10.isRangeZoomable();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot10.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot22.getRangeAxisLocation((int) (byte) 100);
        int int25 = categoryPlot22.getCrosshairDatasetIndex();
        boolean boolean26 = categoryPlot22.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setDomainAxisLocation(axisLocation27);
        categoryPlot10.setRangeAxisLocation(0, axisLocation27, false);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        boolean boolean16 = lineAndShapeRenderer0.getUseOutlinePaint();
        boolean boolean17 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis(0, categoryAxis8);
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer2.setLegendTextFont(0, font12);
        renderAttributes0.setDefaultLabelFont(font12);
        java.lang.Boolean boolean15 = renderAttributes0.getDefaultLabelVisible();
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("Category Plot");
        legendItem18.setURLText("hi!");
        java.awt.Shape shape21 = legendItem18.getLine();
        try {
            renderAttributes0.setSeriesShape((-14336), shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        categoryPlot5.setForegroundAlpha(0.0f);
        categoryPlot5.setRangeZeroBaselineVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot5.getDatasetGroup();
        boolean boolean19 = categoryPlot5.isDomainCrosshairVisible();
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean22 = renderAttributes21.getAllowNull();
        java.awt.Stroke stroke23 = renderAttributes21.getDefaultStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = lineAndShapeRenderer24.getURLGenerator(0, (int) (byte) 1, true);
        lineAndShapeRenderer24.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = null;
        categoryPlot32.setDrawingSupplier(drawingSupplier35, false);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot32.setDataset(categoryDataset38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.Marker marker41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D31, categoryPlot32, valueAxis40, marker41, rectangle2D42);
        java.awt.Stroke stroke44 = categoryPlot32.getRangeGridlineStroke();
        renderAttributes21.setDefaultStroke(stroke44);
        categoryPlot5.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot5.getRangeAxis(9);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNull(categoryURLGenerator28);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(valueAxis48);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape4 = lineAndShapeRenderer0.lookupLegendShape(10);
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemFillPaint((int) (short) 100, 192, false);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer10.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint16 = lineAndShapeRenderer10.lookupLegendTextPaint((int) (short) 100);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer10.setBaseItemLabelPaint((java.awt.Paint) color17, false);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color17);
        float[] floatArray28 = new float[] { (short) 100, (byte) 0, (short) -1, '#' };
        float[] floatArray29 = java.awt.Color.RGBtoHSB((int) (short) 10, 0, 100, floatArray28);
        float[] floatArray30 = color17.getComponents(floatArray28);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', (double) 2.0f, (double) '#', (double) '#');
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        java.awt.Shape shape13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Color color17 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes18.setDefaultOutlineStroke(stroke19);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis(0, categoryAxis25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot23.setFixedRangeAxisSpace(axisSpace27, true);
        categoryPlot23.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke33 = categoryPlot23.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes34 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean35 = renderAttributes34.getAllowNull();
        java.awt.Stroke stroke36 = renderAttributes34.getDefaultStroke();
        java.awt.Color color37 = java.awt.Color.red;
        renderAttributes34.setDefaultFillPaint((java.awt.Paint) color37);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape13, true, (java.awt.Paint) color15, false, (java.awt.Paint) color17, stroke19, false, shape22, stroke33, (java.awt.Paint) color37);
        categoryPlot0.setRangeMinorGridlineStroke(stroke19);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean21 = lineAndShapeRenderer19.getSeriesItemLabelsVisible(100);
        java.awt.Shape shape23 = lineAndShapeRenderer19.lookupLegendShape(10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke28 = lineAndShapeRenderer24.getItemStroke((int) (short) 1, (int) (short) 100, true);
        java.awt.Color color29 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=192,b=192]", "", "java.awt.Color[r=0,g=192,b=192]", "CategoryAnchor.MIDDLE", shape23, stroke28, (java.awt.Paint) color29);
        lineAndShapeRenderer0.setSeriesShape((int) (byte) 1, shape23, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator33);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        chartChangeEvent3.setType(chartChangeEventType5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartChangeEvent3.setChart(jFreeChart7);
        org.junit.Assert.assertNull(chartChangeEventType4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Color color9 = java.awt.Color.gray;
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        renderAttributes10.setDefaultOutlineStroke(stroke11);
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis(0, categoryAxis17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot15.setFixedRangeAxisSpace(axisSpace19, true);
        categoryPlot15.setRangeCrosshairValue((double) (-1.0f), false);
        java.awt.Stroke stroke25 = categoryPlot15.getRangeCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes26 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean27 = renderAttributes26.getAllowNull();
        java.awt.Stroke stroke28 = renderAttributes26.getDefaultStroke();
        java.awt.Color color29 = java.awt.Color.red;
        renderAttributes26.setDefaultFillPaint((java.awt.Paint) color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "java.awt.Color[r=0,g=192,b=192]", "org.jfree.data.UnknownKeyException: CategoryAnchor.MIDDLE", false, shape5, true, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke11, false, shape14, stroke25, (java.awt.Paint) color29);
        legendItem31.setDatasetIndex((int) (byte) 0);
        legendItem31.setDescription("hi!");
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        java.awt.Paint paint37 = legendItem31.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke6 = null;
        categoryPlot0.setOutlineStroke(stroke6);
        categoryPlot0.setWeight(0);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot0.getDataRange(valueAxis12);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = lineAndShapeRenderer1.getURLGenerator(0, (int) (byte) 1, true);
        java.awt.Paint paint7 = lineAndShapeRenderer1.lookupLegendTextPaint((int) (short) 100);
        java.lang.Boolean boolean9 = lineAndShapeRenderer1.getSeriesShapesFilled((int) (short) 0);
        java.awt.Paint paint11 = null;
        lineAndShapeRenderer1.setLegendTextPaint(0, paint11);
        lineAndShapeRenderer1.setUseSeriesOffset(false);
        int int15 = objectList0.indexOf((java.lang.Object) lineAndShapeRenderer1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        lineAndShapeRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator16);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke7 = categoryPlot0.getOutlineStroke();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        int int10 = categoryAxis9.getCategoryLabelPositionOffset();
        java.awt.Font font11 = categoryAxis9.getTickLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis9.setAxisLinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray19 = new float[] { (-1.0f), (short) 10, (-1L), 1.0f };
        float[] floatArray20 = color14.getComponents(floatArray19);
        float[] floatArray21 = color12.getRGBComponents(floatArray20);
        float[] floatArray22 = color8.getColorComponents(floatArray20);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        java.awt.Paint paint4 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRenderer();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis(10, valueAxis9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        double double12 = barRenderer11.getItemMargin();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer11.setShadowPaint((java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        barRenderer11.setBaseOutlinePaint((java.awt.Paint) color15);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot0.addChangeListener(plotChangeListener18);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        int int13 = categoryAxis12.getCategoryLabelPositionOffset();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int15 = color14.getGreen();
        categoryAxis12.setAxisLinePaint((java.awt.Paint) color14);
        boolean boolean17 = categoryAxis12.isMinorTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis12.getLabelInsets();
        java.awt.Paint paint20 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) (-1L));
        categoryAxis12.setTickMarkInsideLength((float) 15);
        int int23 = categoryPlot3.getDomainAxisIndex(categoryAxis12);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot3.getDomainAxisForDataset((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 192 + "'", int15 == 192);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(categoryAxis25);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setBackgroundAlpha((float) 3);
        boolean boolean10 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot0.setRangeAxisLocation(0, axisLocation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        boolean boolean1 = renderAttributes0.getAllowNull();
        java.awt.Stroke stroke2 = renderAttributes0.getDefaultStroke();
        java.lang.Boolean boolean3 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Stroke stroke5 = renderAttributes0.getSeriesStroke(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible((-1), (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis(0, categoryAxis6);
        boolean boolean8 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Stroke stroke9 = categoryPlot4.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getRangeMarkers(0, layer11);
        java.awt.Font font13 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace14);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getColumnKey((-7903));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -7903");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getItemStroke((int) (short) 1, (int) (short) 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis(0, categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        boolean boolean12 = categoryPlot5.canSelectByPoint();
        lineAndShapeRenderer0.setPlot(categoryPlot5);
        int int14 = lineAndShapeRenderer0.getRowCount();
        java.awt.Paint paint15 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font16);
        java.awt.Stroke stroke21 = lineAndShapeRenderer0.getItemStroke(11, (int) (short) 1, true);
        boolean boolean22 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis5);
        java.awt.Paint paint7 = categoryPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot3.getRenderer();
        java.awt.Paint paint9 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot3.getFixedLegendItems();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint14 = categoryAxis0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint14);
    }
}

