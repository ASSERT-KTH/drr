import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj6 = timeSeries5.clone();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((int) (byte) 1, 11);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries9);
        boolean boolean13 = timeSeries9.getNotify();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj16 = timeSeries15.clone();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        timeSeries15.delete(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj33 = timeSeries32.clone();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day34.equals(obj35);
//        int int37 = day34.getMonth();
//        int int38 = day34.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) (-1));
//        java.lang.String str41 = timeSeries32.getDescription();
//        java.util.List list42 = timeSeries32.getItems();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj47 = timeSeries46.clone();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        int int54 = fixedMillisecond51.compareTo((java.lang.Object) year53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.previous();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean62 = day55.equals((java.lang.Object) (short) 10);
//        long long63 = day55.getMiddleMillisecond();
//        boolean boolean65 = day55.equals((java.lang.Object) 1L);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 9999, false);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) Double.NaN);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        int int74 = fixedMillisecond72.compareTo((java.lang.Object) 1.0d);
//        int int75 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond72.next();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560193199999L + "'", long63 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Time", "org.jfree.data.time.TimePeriodFormatException: July 10");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(2, year2);
        org.jfree.data.time.Year year4 = month3.getYear();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year4);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj8 = timeSeries7.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day9.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
//        double double16 = timeSeries7.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Date date20 = fixedMillisecond19.getStart();
//        long long21 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.previous();
//        long long23 = fixedMillisecond19.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond19.getLastMillisecond(calendar24);
//        int int26 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day27.equals(obj28);
//        int int30 = day27.getMonth();
//        int int31 = day27.getYear();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.Object obj33 = null;
//        boolean boolean34 = day32.equals(obj33);
//        int int35 = day32.getMonth();
//        java.lang.Class<?> wildcardClass36 = day32.getClass();
//        boolean boolean37 = day27.equals((java.lang.Object) day32);
//        long long38 = day32.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day32.previous();
//        long long40 = day32.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj45 = timeSeries44.clone();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        timeSeries44.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        int int57 = day56.getYear();
//        long long58 = day56.getMiddleMillisecond();
//        int int59 = day56.getYear();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day60.equals(obj61);
//        int int63 = day60.getMonth();
//        int int64 = day56.compareTo((java.lang.Object) int63);
//        java.lang.String str65 = day56.toString();
//        java.util.Date date66 = day56.getStart();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date66);
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) day67, (double) 132L);
//        boolean boolean70 = day32.equals((java.lang.Object) timeSeries44);
//        long long71 = day32.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day32.next();
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod72);
//        java.util.Collection collection74 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries73);
//        try {
//            timeSeries73.delete(9999, (-9999), false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193199999L + "'", long58 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10-June-2019" + "'", str65.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 43626L + "'", long71 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(collection74);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDescription("11-June-2019");
        double double12 = timeSeries3.getMaxY();
        try {
            java.lang.Number number14 = timeSeries3.getValue(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        long long5 = fixedMillisecond4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        int int8 = month2.getMonth();
        long long9 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820208000001L) + "'", long9 == (-61820208000001L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, 0.0d);
        timeSeriesDataItem13.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        boolean boolean20 = timeSeriesDataItem13.equals((java.lang.Object) fixedMillisecond17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, 0.0d);
        timeSeriesDataItem26.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        boolean boolean33 = timeSeriesDataItem26.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem35.getPeriod();
        boolean boolean37 = timeSeriesDataItem22.equals((java.lang.Object) timeSeriesDataItem35);
        boolean boolean38 = year7.equals((java.lang.Object) timeSeriesDataItem35);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = year7.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getYearValue();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 132L + "'", long4 == 132L);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        java.util.Date date13 = day5.getStart();
//        java.util.TimeZone timeZone14 = null;
//        try {
//            org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13, timeZone14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj14 = timeSeries13.clone();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        timeSeries13.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 10);
        long long29 = fixedMillisecond23.getSerialIndex();
        java.lang.Number number30 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        long long31 = fixedMillisecond23.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond23.getTime();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj36 = timeSeries35.clone();
        timeSeries35.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean39 = year31.equals((java.lang.Object) timeSeries35);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        java.lang.String str10 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(2, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
        timeSeries18.setKey((java.lang.Comparable) 0.0d);
        boolean boolean24 = month13.equals((java.lang.Object) timeSeries18);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.util.List list26 = timeSeries3.getItems();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries3.removeChangeListener(seriesChangeListener27);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "9-June-2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month0);
        java.lang.String str4 = seriesChangeEvent3.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=June 2019]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=June 2019]"));
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "hi!", "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day4.getYear();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        java.lang.Class<?> wildcardClass13 = day9.getClass();
//        boolean boolean14 = day4.equals((java.lang.Object) day9);
//        long long15 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day9.previous();
//        long long17 = day9.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj22 = timeSeries21.clone();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        timeSeries21.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getYear();
//        long long35 = day33.getMiddleMillisecond();
//        int int36 = day33.getYear();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = day37.equals(obj38);
//        int int40 = day37.getMonth();
//        int int41 = day33.compareTo((java.lang.Object) int40);
//        java.lang.String str42 = day33.toString();
//        java.util.Date date43 = day33.getStart();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day44, (double) 132L);
//        boolean boolean47 = day9.equals((java.lang.Object) timeSeries21);
//        long long48 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.SerialDate serialDate52 = day9.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560193199999L + "'", long35 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertNotNull(serialDate52);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date20 = fixedMillisecond19.getStart();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.previous();
        long long23 = fixedMillisecond19.getSerialIndex();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond19.getLastMillisecond(calendar24);
        int int26 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.List list27 = timeSeries3.getItems();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.Year year31 = month30.getYear();
        int int32 = month30.getMonth();
        org.jfree.data.time.Year year33 = month30.getYear();
        long long34 = month30.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) (-61851744000000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 105L + "'", long34 == 105L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        seriesException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("December 10");
        java.lang.String str17 = seriesException16.toString();
        java.lang.Throwable[] throwableArray18 = seriesException16.getSuppressed();
        seriesException9.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable[] throwableArray20 = seriesException9.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: December 10" + "'", str17.equals("org.jfree.data.general.SeriesException: December 10"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) '4');
        java.lang.String str3 = month2.toString();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 52" + "'", str3.equals("October 52"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 52" + "'", str4.equals("October 52"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3);
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = regularTimePeriod1.toString();
//        java.util.Date date3 = regularTimePeriod1.getEnd();
//        long long4 = regularTimePeriod1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-June-2019" + "'", str2.equals("9-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560106799999L + "'", long4 == 1560106799999L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 10);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, 0.0d);
        timeSeriesDataItem24.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        boolean boolean31 = timeSeriesDataItem24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem33.getPeriod();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(2, year36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        int int40 = year36.compareTo((java.lang.Object) day38);
        int int41 = timeSeriesDataItem33.compareTo((java.lang.Object) day38);
        timeSeriesDataItem33.setValue((java.lang.Number) 1551427199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries3.addOrUpdate(timeSeriesDataItem33);
        java.lang.Object obj45 = timeSeriesDataItem44.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (short) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date7, timeZone9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        timeSeriesDataItem29.setValue((java.lang.Number) (-61851744000000L));
//        timeSeriesDataItem29.setValue((java.lang.Number) (-62135784000001L));
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 1.0d);
        int int35 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Date date36 = fixedMillisecond32.getTime();
        java.util.TimeZone timeZone37 = null;
        try {
            org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        int int2 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries7.getNextTimePeriod();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener18);
        timeSeries3.removeAgedItems(1560106799999L, false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = day11.compareTo((java.lang.Object) fixedMillisecond12);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) '4');
        timeSeries3.setKey((java.lang.Comparable) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, 0.0d);
        timeSeriesDataItem15.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, 0.0d);
        timeSeriesDataItem21.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        boolean boolean28 = timeSeriesDataItem21.equals((java.lang.Object) fixedMillisecond25);
        boolean boolean29 = timeSeriesDataItem15.equals((java.lang.Object) timeSeriesDataItem21);
        java.lang.Object obj30 = null;
        int int31 = timeSeriesDataItem21.compareTo(obj30);
        java.lang.Number number32 = timeSeriesDataItem21.getValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.0d + "'", number32.equals(0.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        timeSeriesDataItem29.setValue((java.lang.Number) (-61851744000000L));
//        boolean boolean32 = timeSeriesDataItem29.isSelected();
//        java.lang.Object obj33 = null;
//        boolean boolean34 = timeSeriesDataItem29.equals(obj33);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj12 = timeSeries11.clone();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) day13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = fixedMillisecond16.compareTo((java.lang.Object) year18);
        boolean boolean20 = month2.equals((java.lang.Object) int19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61822886400000L) + "'", long7 == (-61822886400000L));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj14 = timeSeries13.clone();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        timeSeries13.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 10);
        long long29 = fixedMillisecond23.getSerialIndex();
        java.lang.Number number30 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        java.lang.Comparable comparable31 = timeSeries3.getKey();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, 0.0d);
        timeSeriesDataItem35.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        boolean boolean42 = timeSeriesDataItem35.equals((java.lang.Object) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (-1.0f));
        timeSeriesDataItem44.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeriesDataItem44.getPeriod();
        java.lang.Number number48 = timeSeriesDataItem44.getValue();
        boolean boolean49 = timeSeries3.equals((java.lang.Object) timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 0.0f + "'", comparable31.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0f) + "'", number48.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setRangeDescription("December 10");
        timeSeries3.setNotify(false);
        java.lang.Class class20 = timeSeries3.getTimePeriodClass();
        try {
            timeSeries3.delete((int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class20);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo6);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent3.getSummary();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNull(seriesChangeInfo8);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        long long30 = fixedMillisecond22.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str35 = timePeriodFormatException34.toString();
        java.lang.String str36 = timePeriodFormatException34.toString();
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        boolean boolean38 = fixedMillisecond22.equals((java.lang.Object) timePeriodFormatException34);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        java.util.List list13 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries14.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
        int int27 = fixedMillisecond24.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 10);
        timeSeries14.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, 0.0d);
        timeSeriesDataItem35.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        boolean boolean42 = timeSeriesDataItem35.equals((java.lang.Object) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(2, year47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        int int51 = year47.compareTo((java.lang.Object) day49);
        int int52 = timeSeriesDataItem44.compareTo((java.lang.Object) day49);
        timeSeriesDataItem44.setValue((java.lang.Number) 1551427199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries14.addOrUpdate(timeSeriesDataItem44);
        timeSeries9.setKey((java.lang.Comparable) timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getSerialIndex();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        java.lang.String str64 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries3.addChangeListener(seriesChangeListener65);
        java.lang.Class class67 = timeSeries3.getTimePeriodClass();
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(class67);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = year1.compareTo((java.lang.Object) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj11 = timeSeries10.clone();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Object obj13 = null;
        boolean boolean14 = day12.equals(obj13);
        int int15 = day12.getMonth();
        int int16 = day12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) (-1));
        java.lang.String str19 = timeSeries10.getDescription();
        java.util.List list20 = timeSeries10.getItems();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj25 = timeSeries24.clone();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) year31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        int int34 = day33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.previous();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) day33);
        java.lang.String str37 = timeSeries36.getRangeDescription();
        boolean boolean38 = timeSeries36.getNotify();
        boolean boolean39 = year1.equals((java.lang.Object) boolean38);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        double double12 = timeSeries3.getMaxY();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
//        timeSeriesDataItem16.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(2, year28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        int int32 = year28.compareTo((java.lang.Object) day30);
//        int int33 = timeSeriesDataItem25.compareTo((java.lang.Object) day30);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj38 = timeSeries37.clone();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.Object obj40 = null;
//        boolean boolean41 = day39.equals(obj40);
//        int int42 = day39.getMonth();
//        int int43 = day39.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) (-1));
//        java.lang.String str46 = timeSeries37.getDescription();
//        java.util.List list47 = timeSeries37.getItems();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj52 = timeSeries51.clone();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        int int59 = fixedMillisecond56.compareTo((java.lang.Object) year58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day60.previous();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond56.previous();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day30, regularTimePeriod64);
//        timeSeries65.removeAgedItems(false);
//        java.lang.Class class68 = timeSeries65.getTimePeriodClass();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day69, 0.0d);
//        java.lang.Class<?> wildcardClass73 = day69.getClass();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        int int75 = day74.getYear();
//        long long76 = day74.getMiddleMillisecond();
//        int int77 = day74.getYear();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.lang.Object obj79 = null;
//        boolean boolean80 = day78.equals(obj79);
//        int int81 = day78.getMonth();
//        int int82 = day74.compareTo((java.lang.Object) int81);
//        java.lang.String str83 = day74.toString();
//        java.util.Date date84 = day74.getStart();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date84);
//        java.util.TimeZone timeZone87 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date84, timeZone87);
//        java.util.TimeZone timeZone89 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date84, timeZone89);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(class68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560193199999L + "'", long76 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "10-June-2019" + "'", str83.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        long long9 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day0.next();
//        java.lang.String str11 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560193199999L + "'", long9 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        java.util.List list10 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), (-9999), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        timeSeries3.setRangeDescription("10-June-2019");
        java.lang.Object obj14 = timeSeries3.clone();
        java.lang.Comparable comparable15 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0.0f + "'", comparable15.equals(0.0f));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184192113L + "'", long1 == 1560184192113L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = year1.compareTo((java.lang.Object) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        long long7 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day19.next();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getYear();
//        long long20 = day18.getMiddleMillisecond();
//        int int21 = day18.getYear();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day18.compareTo((java.lang.Object) int25);
//        long long27 = day18.getMiddleMillisecond();
//        java.lang.Number number28 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean29 = timeSeries3.isEmpty();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193199999L + "'", long20 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560193199999L + "'", long27 == 1560193199999L);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 4, false);
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.createCopy((int) (short) 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("October 52");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj21 = timeSeries20.clone();
        long long22 = timeSeries20.getMaximumItemAge();
        java.util.Collection collection23 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.setNotify(false);
        timeSeries7.setRangeDescription("");
        timeSeries7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        try {
            timeSeries7.setMaximumItemAge((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.Year year11 = month9.getYear();
        java.lang.String str12 = month9.toString();
        long long13 = month9.getLastMillisecond();
        org.jfree.data.time.Year year14 = month9.getYear();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) year14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year14.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 10" + "'", str12.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61820208000001L) + "'", long13 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        java.lang.Object obj18 = null;
        int int19 = timeSeriesDataItem9.compareTo(obj18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.lang.Comparable comparable18 = timeSeries3.getKey();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getYear();
//        long long21 = day19.getMiddleMillisecond();
//        int int22 = day19.getYear();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day23.equals(obj24);
//        int int26 = day23.getMonth();
//        int int27 = day19.compareTo((java.lang.Object) int26);
//        java.lang.String str28 = day19.toString();
//        int int29 = day19.getYear();
//        long long30 = day19.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate31 = day19.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        java.lang.Number number33 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 0.0f + "'", comparable18.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560193199999L + "'", long21 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560150000000L + "'", long30 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(number33);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj32 = timeSeries31.clone();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.lang.Object obj34 = null;
        boolean boolean35 = day33.equals(obj34);
        int int36 = day33.getMonth();
        int int37 = day33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) (-1));
        int int40 = day33.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day33);
        timeSeries7.setDescription("");
        double double44 = timeSeries7.getMinY();
        java.util.List list45 = timeSeries7.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int4 = month3.getMonth();
        org.jfree.data.time.Year year5 = month3.getYear();
        long long6 = year5.getSerialIndex();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(2147483647, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        int int65 = day64.getMonth();
        java.lang.String str66 = day64.toString();
        long long67 = day64.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "31-December-1969" + "'", str66.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28799999L + "'", long67 == 28799999L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(2, year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(10L);
        boolean boolean23 = month19.equals((java.lang.Object) fixedMillisecond22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month19.next();
        timeSeries3.update(regularTimePeriod24, (java.lang.Number) (-57600000L));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        timeSeriesDataItem3.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
//        timeSeriesDataItem16.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
//        boolean boolean27 = timeSeriesDataItem12.equals((java.lang.Object) timeSeriesDataItem25);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        long long30 = day28.getMiddleMillisecond();
//        int int31 = day28.getYear();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.Object obj33 = null;
//        boolean boolean34 = day32.equals(obj33);
//        int int35 = day32.getMonth();
//        int int36 = day28.compareTo((java.lang.Object) int35);
//        java.lang.String str37 = day28.toString();
//        int int38 = day28.getYear();
//        long long39 = day28.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate40 = day28.getSerialDate();
//        java.lang.String str41 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, 0.0d);
//        timeSeries45.setKey((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj55 = timeSeries54.clone();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.Object obj57 = null;
//        boolean boolean58 = day56.equals(obj57);
//        int int59 = day56.getMonth();
//        int int60 = day56.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (double) (-1));
//        java.lang.String str63 = timeSeries54.getDescription();
//        java.util.List list64 = timeSeries54.getItems();
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj69 = timeSeries68.clone();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day70.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries68.createCopy((org.jfree.data.time.RegularTimePeriod) day70, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        int int76 = fixedMillisecond73.compareTo((java.lang.Object) year75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        int int78 = day77.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day77.previous();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean84 = day77.equals((java.lang.Object) (short) 10);
//        long long85 = day77.getMiddleMillisecond();
//        boolean boolean87 = day77.equals((java.lang.Object) 1L);
//        java.lang.String str88 = day77.toString();
//        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day77);
//        int int90 = day28.compareTo((java.lang.Object) day77);
//        boolean boolean91 = timeSeriesDataItem25.equals((java.lang.Object) day28);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560193199999L + "'", long30 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560150000000L + "'", long39 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(obj55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNull(str63);
//        org.junit.Assert.assertNotNull(list64);
//        org.junit.Assert.assertNotNull(obj69);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560193199999L + "'", long85 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "10-June-2019" + "'", str88.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month2.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        long long15 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj20 = timeSeries19.clone();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.lang.Object obj22 = null;
        boolean boolean23 = day21.equals(obj22);
        int int24 = day21.getMonth();
        int int25 = day21.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (double) (-1));
        java.lang.String str28 = timeSeries19.getDescription();
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) year40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = day42.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.previous();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        java.lang.String str16 = timeSeries7.getDescription();
        java.util.List list17 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj22 = timeSeries21.clone();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = fixedMillisecond26.compareTo((java.lang.Object) year28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        int int31 = day30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.previous();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) day30);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        boolean boolean35 = day0.equals((java.lang.Object) timeSeries33);
        java.lang.Comparable comparable36 = timeSeries33.getKey();
        java.lang.String str37 = timeSeries33.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0f + "'", comparable36.equals(0.0f));
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 0.0d);
        long long4 = year1.getSerialIndex();
        java.util.Date date5 = year1.getStart();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        long long15 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj20 = timeSeries19.clone();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.lang.Object obj22 = null;
        boolean boolean23 = day21.equals(obj22);
        int int24 = day21.getMonth();
        int int25 = day21.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (double) (-1));
        java.lang.String str28 = timeSeries19.getDescription();
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) year40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = day42.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.previous();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        boolean boolean48 = timeSeriesDataItem47.isSelected();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        java.lang.Object obj65 = null;
        boolean boolean66 = day64.equals(obj65);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        timeSeries60.setDomainDescription("org.jfree.data.general.SeriesException: December 10");
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        int int77 = month76.getMonth();
//        org.jfree.data.time.Year year78 = month76.getYear();
//        java.lang.String str79 = month76.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = month76.previous();
//        java.lang.Number number81 = timeSeries60.getValue((org.jfree.data.time.RegularTimePeriod) month76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = month76.previous();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 12 + "'", int77 == 12);
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "December 10" + "'", str79.equals("December 10"));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + number81 + "' != '" + (-1.0d) + "'", number81.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("July 10");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj23 = timeSeries22.clone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Object obj25 = null;
        boolean boolean26 = day24.equals(obj25);
        int int27 = day24.getMonth();
        int int28 = day24.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) (-1));
        java.lang.String str31 = timeSeries22.getDescription();
        java.util.List list32 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj37 = timeSeries36.clone();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        int int44 = fixedMillisecond41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        int int46 = day45.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day45.previous();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) day45);
        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
        boolean boolean50 = day15.equals((java.lang.Object) timeSeries48);
        java.lang.Comparable comparable51 = timeSeries48.getKey();
        java.lang.String str52 = timeSeries48.getDomainDescription();
        int int53 = timeSeries48.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries3.addAndOrUpdate(timeSeries48);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + 0.0f + "'", comparable51.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(timeSeries54);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.Object obj12 = timeSeries3.clone();
        java.lang.Class class13 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = fixedMillisecond12.compareTo((java.lang.Object) year14);
        boolean boolean16 = year1.equals((java.lang.Object) int15);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year1.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        long long16 = year12.getSerialIndex();
        long long17 = year12.getLastMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            year12.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj16 = timeSeries15.clone();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Object obj18 = null;
        boolean boolean19 = day17.equals(obj18);
        int int20 = day17.getMonth();
        int int21 = day17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
        java.lang.String str24 = timeSeries15.getDescription();
        java.util.List list25 = timeSeries15.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj30 = timeSeries29.clone();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int37 = fixedMillisecond34.compareTo((java.lang.Object) year36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        int int39 = day38.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day38.previous();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj46 = timeSeries45.clone();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.lang.Object obj48 = null;
        boolean boolean49 = day47.equals(obj48);
        int int50 = day47.getMonth();
        int int51 = day47.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) (-1));
        java.lang.String str54 = timeSeries45.getDescription();
        java.util.List list55 = timeSeries45.getItems();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj60 = timeSeries59.clone();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) day61, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        int int67 = fixedMillisecond64.compareTo((java.lang.Object) year66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        int int69 = day68.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day68.previous();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (org.jfree.data.time.RegularTimePeriod) day68);
        java.util.Date date72 = fixedMillisecond64.getTime();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date72);
        boolean boolean75 = timeSeries15.equals((java.lang.Object) date72);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date72);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries60);
//        timeSeries60.fireSeriesChanged();
//        java.lang.Object obj74 = null;
//        boolean boolean75 = timeSeries60.equals(obj74);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        timeSeries60.setDescription("hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener74 = null;
//        timeSeries60.removeChangeListener(seriesChangeListener74);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        long long12 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener82 = null;
//        timeSeries80.removeChangeListener(seriesChangeListener82);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray10 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        long long3 = month2.getLastMillisecond();
        long long4 = month2.getMiddleMillisecond();
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1551427199999L + "'", long3 == 1551427199999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1550217599999L + "'", long4 == 1550217599999L);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        long long44 = day5.getSerialIndex();
//        long long45 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) 0.0d);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        java.lang.Number number14 = timeSeries3.getValue(regularTimePeriod13);
        java.util.List list15 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        int int10 = day5.getMonth();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries14.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
        int int27 = fixedMillisecond24.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (short) 10);
        long long30 = fixedMillisecond24.getSerialIndex();
        java.util.Date date31 = fixedMillisecond24.getTime();
        int int32 = day5.compareTo((java.lang.Object) fixedMillisecond24);
        java.util.Date date33 = fixedMillisecond24.getStart();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        timeSeries1.setMaximumItemAge(2019L);
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", comparable2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", comparable5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries7.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDescription("11-June-2019");
        double double12 = timeSeries3.getMaxY();
        timeSeries3.setMaximumItemCount(5);
        double double15 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        timeSeries3.fireSeriesChanged();
        timeSeries3.removeAgedItems(true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj6 = timeSeries5.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = fixedMillisecond10.compareTo((java.lang.Object) year12);
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) int13);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        timeSeries3.setRangeDescription("hi!");
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(class14);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
//        timeSeriesDataItem8.setValue((java.lang.Number) 8);
//        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getFirstMillisecond();
//        int int14 = year12.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
//        long long16 = year12.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9999);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        int int23 = day19.getYear();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.Object obj25 = null;
//        boolean boolean26 = day24.equals(obj25);
//        int int27 = day24.getMonth();
//        java.lang.Class<?> wildcardClass28 = day24.getClass();
//        boolean boolean29 = day19.equals((java.lang.Object) day24);
//        long long30 = day24.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        java.lang.Number number32 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, number32);
//        boolean boolean34 = year12.equals((java.lang.Object) day24);
//        long long35 = year12.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date20 = fixedMillisecond19.getStart();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.previous();
        long long23 = fixedMillisecond19.getSerialIndex();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond19.getLastMillisecond(calendar24);
        int int26 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries3.setDomainDescription("9-June-2019");
        timeSeries3.setMaximumItemCount(4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        int int4 = month3.getMonth();
//        org.jfree.data.time.Year year5 = month3.getYear();
//        java.lang.String str6 = month3.toString();
//        long long7 = month3.getLastMillisecond();
//        org.jfree.data.time.Year year8 = month3.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        long long10 = year8.getLastMillisecond();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, year8);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj16 = timeSeries15.clone();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries15.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass25 = timeSeries15.getClass();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day26.equals(obj27);
//        int int29 = day26.getMonth();
//        int int30 = day26.getYear();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.Object obj32 = null;
//        boolean boolean33 = day31.equals(obj32);
//        int int34 = day31.getMonth();
//        java.lang.Class<?> wildcardClass35 = day31.getClass();
//        boolean boolean36 = day26.equals((java.lang.Object) day31);
//        long long37 = day31.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day31.previous();
//        long long39 = day31.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 11);
//        boolean boolean42 = year8.equals((java.lang.Object) timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 10" + "'", str6.equals("December 10"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820208000001L) + "'", long7 == (-61820208000001L));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61820208000001L) + "'", long10 == (-61820208000001L));
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43626L + "'", long39 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        boolean boolean27 = timeSeriesDataItem12.equals((java.lang.Object) timeSeriesDataItem25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, (int) '4');
        boolean boolean31 = timeSeriesDataItem12.equals((java.lang.Object) '4');
        timeSeriesDataItem12.setSelected(true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        long long6 = month5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, 0.0d);
//        long long50 = day46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 10);
//        java.util.Date date53 = day46.getEnd();
//        java.lang.String str54 = day46.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        int int6 = month5.getMonth();
        long long7 = month5.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 23640L + "'", long7 == 23640L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.String str30 = timeSeries29.getRangeDescription();
        java.lang.String str31 = timeSeries29.getRangeDescription();
        java.lang.Comparable comparable32 = timeSeries29.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 0.0f + "'", comparable32.equals(0.0f));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        int int76 = day75.getYear();
//        long long77 = day75.getMiddleMillisecond();
//        int int78 = day75.getYear();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        java.lang.Object obj80 = null;
//        boolean boolean81 = day79.equals(obj80);
//        int int82 = day79.getMonth();
//        int int83 = day75.compareTo((java.lang.Object) int82);
//        java.lang.String str84 = day75.toString();
//        java.util.Date date85 = day75.getStart();
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = day87.previous();
//        java.lang.Number number89 = null;
//        timeSeries3.add(regularTimePeriod88, number89);
//        int int91 = timeSeries3.getMaximumItemCount();
//        java.util.List list92 = timeSeries3.getItems();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560193199999L + "'", long77 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 6 + "'", int82 == 6);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "10-June-2019" + "'", str84.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2147483647 + "'", int91 == 2147483647);
//        org.junit.Assert.assertNotNull(list92);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getYear();
//        long long7 = day5.getMiddleMillisecond();
//        int int8 = day5.getYear();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day5.compareTo((java.lang.Object) int12);
//        java.lang.String str14 = day5.toString();
//        java.util.Date date15 = day5.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date15, timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day20.equals(obj21);
//        int int23 = day20.getMonth();
//        int int24 = day20.getYear();
//        java.util.Date date25 = day20.getEnd();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date25, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560193199999L + "'", long7 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        long long9 = month7.getFirstMillisecond();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) long9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61893820800000L) + "'", long9 == (-61893820800000L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, "org.jfree.data.time.TimePeriodFormatException: ", "10-June-2019");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate12);
//        java.lang.String str18 = day17.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setRangeDescription("December 10");
        timeSeries3.setNotify(false);
        java.lang.Class class20 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection21 = timeSeries3.getTimePeriods();
        java.lang.String str22 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "December 10" + "'", str22.equals("December 10"));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        timeSeries3.setRangeDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        int int23 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (-1));
//        int int26 = day19.getYear();
//        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
//        long long28 = day19.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class30, seriesChangeInfo32);
        java.lang.Object obj34 = seriesChangeEvent33.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj9 = timeSeries8.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries8.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = fixedMillisecond18.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 10);
        timeSeries8.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj31 = timeSeries30.clone();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.lang.Object obj33 = null;
        boolean boolean34 = day32.equals(obj33);
        int int35 = day32.getMonth();
        int int36 = day32.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (double) (-1));
        java.lang.String str39 = timeSeries30.getDescription();
        java.util.List list40 = timeSeries30.getItems();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj45 = timeSeries44.clone();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        int int52 = fixedMillisecond49.compareTo((java.lang.Object) year51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        int int54 = day53.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day53.previous();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) day53);
        java.util.Date date57 = fixedMillisecond49.getTime();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond49.getFirstMillisecond(calendar59);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 35L + "'", long60 == 35L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj25 = timeSeries24.clone();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.lang.Object obj27 = null;
        boolean boolean28 = day26.equals(obj27);
        int int29 = day26.getMonth();
        int int30 = day26.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) (-1));
        java.lang.String str33 = timeSeries24.getDescription();
        java.util.List list34 = timeSeries24.getItems();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj39 = timeSeries38.clone();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) day40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        int int46 = fixedMillisecond43.compareTo((java.lang.Object) year45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        int int48 = day47.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day47.previous();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) day47);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        boolean boolean52 = day17.equals((java.lang.Object) timeSeries50);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries3.addAndOrUpdate(timeSeries50);
        long long54 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
        java.util.TimeZone timeZone33 = null;
        try {
            org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30, timeZone33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        int int5 = month0.compareTo((java.lang.Object) month2);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        timeSeries3.fireSeriesChanged();
//        java.lang.Object obj74 = timeSeries3.clone();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj74);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61891228800001L) + "'", long5 == (-61891228800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61893820800000L) + "'", long6 == (-61893820800000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo1);
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date60);
        java.util.TimeZone timeZone66 = null;
        java.util.Locale locale67 = null;
        try {
            org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date60, timeZone66, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.util.List list3 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", comparable2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getFirstMillisecond();
        long long7 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61822886400000L) + "'", long6 == (-61822886400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 132L + "'", long7 == 132L);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        long long6 = day4.getMiddleMillisecond();
//        int int7 = day4.getYear();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day8.equals(obj9);
//        int int11 = day8.getMonth();
//        int int12 = day4.compareTo((java.lang.Object) int11);
//        java.lang.String str13 = day4.toString();
//        int int14 = day4.getYear();
//        timeSeries3.setKey((java.lang.Comparable) int14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        long long18 = fixedMillisecond17.getFirstMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 100L, false);
//        long long22 = timeSeries3.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj9 = timeSeries8.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries8.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = fixedMillisecond18.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 10);
        timeSeries8.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries8);
        timeSeries26.removeAgedItems(0L, false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj34 = timeSeries33.clone();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        timeSeries33.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("");
//        int int46 = fixedMillisecond43.compareTo((java.lang.Object) "");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (double) (short) 10);
//        timeSeries33.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day51.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, 0.0d);
//        timeSeriesDataItem54.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
//        boolean boolean61 = timeSeriesDataItem54.equals((java.lang.Object) fixedMillisecond58);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = timeSeriesDataItem63.getPeriod();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(2, year66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.previous();
//        int int70 = year66.compareTo((java.lang.Object) day68);
//        int int71 = timeSeriesDataItem63.compareTo((java.lang.Object) day68);
//        timeSeriesDataItem63.setValue((java.lang.Number) 1551427199999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries33.addOrUpdate(timeSeriesDataItem63);
//        boolean boolean75 = timeSeries3.equals((java.lang.Object) timeSeries33);
//        java.lang.String str76 = timeSeries3.getRangeDescription();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 35L + "'", long60 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "10-June-2019" + "'", str76.equals("10-June-2019"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(2L, false);
        boolean boolean16 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        java.lang.Number number20 = timeSeries3.getValue((int) (byte) 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, 0.0d);
        timeSeriesDataItem14.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        boolean boolean21 = timeSeriesDataItem14.equals((java.lang.Object) fixedMillisecond18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(2, year26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        int int30 = year26.compareTo((java.lang.Object) day28);
        int int31 = timeSeriesDataItem23.compareTo((java.lang.Object) day28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries9.addOrUpdate(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }
}

