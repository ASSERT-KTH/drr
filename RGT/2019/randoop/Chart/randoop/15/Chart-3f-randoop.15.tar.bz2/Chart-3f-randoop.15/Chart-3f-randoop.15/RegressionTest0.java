import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.time.TimePeriodFormatException: hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        long long3 = year0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        try {
            java.lang.Number number14 = timeSeries3.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, 0.0d);
        timeSeriesDataItem17.setValue((java.lang.Number) 8);
        try {
            timeSeries3.add(timeSeriesDataItem17, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        java.lang.Class<?> wildcardClass9 = day5.getClass();
        boolean boolean10 = day0.equals((java.lang.Object) day5);
        java.util.Date date11 = day0.getEnd();
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        java.lang.Class<?> wildcardClass9 = day5.getClass();
        boolean boolean10 = day0.equals((java.lang.Object) day5);
        java.util.Calendar calendar11 = null;
        try {
            day0.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        int int12 = fixedMillisecond8.compareTo((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        int int12 = year8.compareTo((java.lang.Object) day10);
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 1559372400000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries3.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        try {
            timeSeries29.delete(2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setKey((java.lang.Comparable) 2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.String str13 = regularTimePeriod12.toString();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11-June-2019" + "'", str13.equals("11-June-2019"));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.Object obj12 = timeSeries3.clone();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy((int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("December 10");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        java.util.Calendar calendar12 = null;
//        try {
//            day11.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setValue((java.lang.Number) 8);
        try {
            timeSeries3.add(timeSeriesDataItem16, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        java.util.TimeZone timeZone12 = null;
//        java.util.Locale locale13 = null;
//        try {
//            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10, timeZone12, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries17.setRangeDescription("December 10");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries17.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        try {
            timeSeries29.delete((int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        int int72 = timeSeries60.getItemCount();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.Object obj12 = timeSeries3.clone();
        double double13 = timeSeries3.getMaxY();
        try {
            timeSeries3.update((int) (byte) 10, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        java.lang.Class<?> wildcardClass9 = day5.getClass();
        boolean boolean10 = day0.equals((java.lang.Object) day5);
        java.util.Date date11 = day0.getEnd();
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) 0.0d);
        try {
            timeSeries3.delete(6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        try {
            timeSeries29.delete(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 132L);
        try {
            java.lang.Number number3 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        java.lang.String str12 = timeSeries3.getDescription();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean33 = day26.equals((java.lang.Object) (short) 10);
//        long long34 = day26.getMiddleMillisecond();
//        boolean boolean36 = day26.equals((java.lang.Object) 1L);
//        java.lang.Object obj37 = null;
//        int int38 = day26.compareTo(obj37);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560193199999L + "'", long34 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        long long3 = year1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
        try {
            timeSeries3.add(timeSeriesDataItem25);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(9, 8);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month17, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getNextTimePeriod();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = regularTimePeriod15.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.util.Calendar calendar12 = null;
        try {
            day5.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj16 = timeSeries15.clone();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        timeSeries15.delete(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj33 = timeSeries32.clone();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day34.equals(obj35);
//        int int37 = day34.getMonth();
//        int int38 = day34.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) (-1));
//        java.lang.String str41 = timeSeries32.getDescription();
//        java.util.List list42 = timeSeries32.getItems();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj47 = timeSeries46.clone();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        int int54 = fixedMillisecond51.compareTo((java.lang.Object) year53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.previous();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean62 = day55.equals((java.lang.Object) (short) 10);
//        long long63 = day55.getMiddleMillisecond();
//        boolean boolean65 = day55.equals((java.lang.Object) 1L);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 9999, false);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) Double.NaN);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day71, 0.0d);
//        timeSeriesDataItem74.setValue((java.lang.Number) 8);
//        timeSeriesDataItem74.setValue((java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
//        timeSeriesDataItem74.setSelected(false);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560193199999L + "'", long63 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries9, seriesChangeInfo11);
        try {
            timeSeries9.update(9, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.lang.String str15 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: December 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        java.util.TimeZone timeZone33 = null;
        try {
            org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30, timeZone33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.Year year3 = month2.getYear();
        long long4 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61893820800000L) + "'", long4 == (-61893820800000L));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.String str4 = seriesChangeEvent3.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        int int47 = month46.getMonth();
//        org.jfree.data.time.Year year48 = month46.getYear();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 5);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
//        org.junit.Assert.assertNotNull(year48);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        java.util.Calendar calendar30 = null;
//        try {
//            long long31 = day19.getFirstMillisecond(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        long long3 = year1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        int int7 = month2.getMonth();
        int int8 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = year1.compareTo((java.lang.Object) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Object obj30 = timeSeries29.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj30);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        java.lang.Object obj8 = seriesChangeEvent6.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        java.lang.String str12 = timeSeries3.getDescription();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean33 = day26.equals((java.lang.Object) (short) 10);
//        long long34 = day26.getMiddleMillisecond();
//        boolean boolean36 = day26.equals((java.lang.Object) 1L);
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day26.getLastMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560193199999L + "'", long34 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent3.getSummary();
//        java.lang.String str5 = seriesChangeEvent3.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNull(seriesChangeInfo4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 10);
        long long3 = year2.getLastMillisecond();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) 'a', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61820208000001L) + "'", long3 == (-61820208000001L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.String str31 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
        timeSeries3.setKey((java.lang.Comparable) 10L);
        boolean boolean35 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries41 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month38, regularTimePeriod40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class30, seriesChangeInfo32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        java.lang.Class<?> wildcardClass4 = day0.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond22.previous();
        long long31 = fixedMillisecond22.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        boolean boolean27 = timeSeriesDataItem12.equals((java.lang.Object) timeSeriesDataItem25);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean27);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 132L);
//        java.lang.String str2 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day8.equals(obj9);
//        int int11 = day8.getMonth();
//        int int12 = day8.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries6.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass16 = timeSeries6.getClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        java.lang.Class<?> wildcardClass26 = day22.getClass();
//        boolean boolean27 = day17.equals((java.lang.Object) day22);
//        long long28 = day22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day22.previous();
//        long long30 = day22.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, 0.0d);
//        timeSeriesDataItem38.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
//        boolean boolean45 = timeSeriesDataItem38.equals((java.lang.Object) fixedMillisecond42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) (-1.0f));
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries1.addOrUpdate(timeSeriesDataItem47);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        long long12 = timeSeries3.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        boolean boolean11 = timeSeries9.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries9.add(regularTimePeriod12, (double) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Date date74 = fixedMillisecond73.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date74);
//        timeSeries3.setKey((java.lang.Comparable) date74);
//        try {
//            timeSeries3.delete(0, (int) (short) -1, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertNotNull(date74);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
//        java.util.TimeZone timeZone13 = null;
//        java.util.Locale locale14 = null;
//        try {
//            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13, locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
        java.util.TimeZone timeZone33 = null;
        try {
            org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date30, timeZone33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        java.util.Calendar calendar8 = null;
        try {
            year7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.addChangeListener(seriesChangeListener44);
//        try {
//            timeSeries17.delete(9, (int) (byte) -1, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        timeSeriesDataItem12.setValue((java.lang.Number) 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long18 = fixedMillisecond17.getFirstMillisecond();
        java.util.Date date19 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("11-June-2019");
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        long long9 = day0.getMiddleMillisecond();
//        long long10 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560193199999L + "'", long9 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        int int7 = month2.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 2);
        int int4 = year1.compareTo((java.lang.Object) 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 10" + "'", str6.equals("December 10"));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj16 = timeSeries15.clone();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        timeSeries15.delete(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj33 = timeSeries32.clone();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day34.equals(obj35);
//        int int37 = day34.getMonth();
//        int int38 = day34.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) (-1));
//        java.lang.String str41 = timeSeries32.getDescription();
//        java.util.List list42 = timeSeries32.getItems();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj47 = timeSeries46.clone();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        int int54 = fixedMillisecond51.compareTo((java.lang.Object) year53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.previous();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean62 = day55.equals((java.lang.Object) (short) 10);
//        long long63 = day55.getMiddleMillisecond();
//        boolean boolean65 = day55.equals((java.lang.Object) 1L);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 9999, false);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) Double.NaN);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day71, 0.0d);
//        timeSeriesDataItem74.setValue((java.lang.Number) 8);
//        timeSeriesDataItem74.setValue((java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
//        boolean boolean80 = timeSeriesDataItem79.isSelected();
//        timeSeriesDataItem79.setSelected(false);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560193199999L + "'", long63 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.lang.Object obj5 = null;
        boolean boolean6 = day4.equals(obj5);
        int int7 = day4.getMonth();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        int int9 = year0.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.createCopy((int) (byte) 1, 11);
        java.util.List list19 = timeSeries18.getItems();
        boolean boolean20 = year0.equals((java.lang.Object) list19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year0.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(obj18);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        long long3 = year0.getSerialIndex();
        long long4 = year0.getLastMillisecond();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        long long2 = year1.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            timeSeries3.update((int) 'a', (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        java.lang.Object obj6 = seriesChangeEvent3.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(obj6);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int7);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent9.getSummary();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(seriesChangeInfo10);
//        org.junit.Assert.assertNull(seriesChangeInfo11);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.String str31 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
        timeSeries3.setKey((java.lang.Comparable) 10L);
        boolean boolean35 = timeSeries3.isEmpty();
        java.lang.Object obj36 = timeSeries3.clone();
        java.lang.Class class37 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(class37);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.String str31 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
        timeSeries3.setKey((java.lang.Comparable) 10L);
        boolean boolean35 = timeSeries3.isEmpty();
        java.lang.Object obj36 = timeSeries3.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long39 = fixedMillisecond38.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond38);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond38.getLastMillisecond(calendar41);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2L + "'", long39 == 2L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2L + "'", long42 == 2L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        java.util.TimeZone timeZone64 = null;
        java.util.Locale locale65 = null;
        try {
            org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date60, timeZone64, locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int19 = month18.getMonth();
        org.jfree.data.time.Year year20 = month18.getYear();
        java.lang.String str21 = month18.toString();
        long long22 = month18.getLastMillisecond();
        org.jfree.data.time.Year year23 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        long long25 = year23.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1560193199999L, true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "December 10" + "'", str21.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61820208000001L) + "'", long22 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj16 = timeSeries15.clone();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        int int21 = day17.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1));
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        timeSeries15.delete(regularTimePeriod27);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj33 = timeSeries32.clone();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day34.equals(obj35);
//        int int37 = day34.getMonth();
//        int int38 = day34.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) (-1));
//        java.lang.String str41 = timeSeries32.getDescription();
//        java.util.List list42 = timeSeries32.getItems();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj47 = timeSeries46.clone();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        int int54 = fixedMillisecond51.compareTo((java.lang.Object) year53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.previous();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean62 = day55.equals((java.lang.Object) (short) 10);
//        long long63 = day55.getMiddleMillisecond();
//        boolean boolean65 = day55.equals((java.lang.Object) 1L);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 9999, false);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) Double.NaN);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day71, 0.0d);
//        timeSeriesDataItem74.setValue((java.lang.Number) 8);
//        timeSeriesDataItem74.setValue((java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
//        timeSeriesDataItem79.setSelected(false);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560193199999L + "'", long63 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("October 52");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        int int4 = month2.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Comparable comparable30 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 0.0f + "'", comparable30.equals(0.0f));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) '4');
        timeSeries3.setKey((java.lang.Comparable) '4');
        timeSeries3.setRangeDescription("10-June-2019");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
//        java.util.TimeZone timeZone13 = null;
//        try {
//            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10, timeZone13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 132L);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        try {
            java.lang.Number number4 = timeSeries1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, 0.0d);
//        timeSeriesDataItem21.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        boolean boolean28 = timeSeriesDataItem21.equals((java.lang.Object) fixedMillisecond25);
//        java.lang.Number number29 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(number29);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1.0f, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        try {
//            timeSeries3.delete(9, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        java.lang.Object obj14 = null;
        boolean boolean15 = timeSeriesDataItem12.equals(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (byte) 10);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "July 10" + "'", str3.equals("July 10"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.List list15 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day5.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent6.setSummary(seriesChangeInfo7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Year year3 = month2.getYear();
        long long4 = year3.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        long long8 = month7.getSerialIndex();
        boolean boolean9 = year3.equals((java.lang.Object) long8);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 132L + "'", long8 == 132L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day65.previous();
        timeSeries3.add(regularTimePeriod66, (java.lang.Number) 0L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.next();
        long long17 = year12.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61820208000001L) + "'", long17 == (-61820208000001L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy(7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        timeSeriesDataItem3.setValue((java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        timeSeriesDataItem3.setSelected(false);
        timeSeriesDataItem3.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) year10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int11, seriesChangeInfo12);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + 0 + "'", obj14.equals(0));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        timeSeries3.setRangeDescription("hi!");
        double double14 = timeSeries3.getMaxY();
        timeSeries3.setDescription("11-June-2019");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        timeSeries3.delete(regularTimePeriod15);
        java.util.Date date17 = regularTimePeriod15.getStart();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        java.lang.String str31 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
        timeSeries3.setKey((java.lang.Comparable) 10L);
        java.lang.Comparable comparable35 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 10L + "'", comparable35.equals(10L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        timeSeries3.setMaximumItemAge((long) ' ');
        long long15 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj32 = timeSeries31.clone();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.lang.Object obj34 = null;
        boolean boolean35 = day33.equals(obj34);
        int int36 = day33.getMonth();
        int int37 = day33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) (-1));
        int int40 = day33.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day33);
        timeSeries7.setDescription("");
        try {
            java.lang.Number number45 = timeSeries7.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        timeSeriesDataItem3.setValue((java.lang.Number) 7);
        timeSeriesDataItem3.setSelected(true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        timeSeries3.setMaximumItemAge(0L);
        try {
            timeSeries3.update(8, (java.lang.Number) (-61891228800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(2L, false);
        boolean boolean16 = timeSeries3.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(2L, false);
        boolean boolean16 = timeSeries3.getNotify();
        java.lang.String str17 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str17);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.util.Calendar calendar18 = null;
//        try {
//            month10.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        timeSeries3.clear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = null;
//        try {
//            timeSeries3.update(regularTimePeriod73, (java.lang.Number) (-1.0d));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        java.lang.String str16 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L);
        double double2 = timeSeries1.getMaxY();
        boolean boolean3 = timeSeries1.isEmpty();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        java.util.Calendar calendar44 = null;
//        try {
//            long long45 = day5.getLastMillisecond(calendar44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        timeSeries7.setKey((java.lang.Comparable) 0.0d);
//        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Date date16 = fixedMillisecond15.getStart();
//        long long17 = fixedMillisecond15.getMiddleMillisecond();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond15.peg(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
//        java.lang.String str24 = timeSeries7.getDescription();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        long long26 = month25.getFirstMillisecond();
//        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj32 = timeSeries31.clone();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day33.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) (-1));
//        int int40 = day33.getYear();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day33);
//        int int42 = day33.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        java.util.TimeZone timeZone12 = null;
//        try {
//            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10, timeZone12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        try {
            timeSeries3.delete((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int9 = month8.getMonth();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.lang.String str11 = month8.toString();
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Year year13 = month8.getYear();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year13, (double) (byte) 1, true);
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) 'a', year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December 10" + "'", str11.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820208000001L) + "'", long12 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
        boolean boolean14 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        java.lang.Object obj12 = timeSeries3.clone();
        java.util.List list13 = timeSeries3.getItems();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = year1.compareTo((java.lang.Object) day3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        boolean boolean8 = year1.equals((java.lang.Object) long7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        timeSeries3.setRangeDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.lang.Object obj20 = null;
        boolean boolean21 = day19.equals(obj20);
        int int22 = day19.getMonth();
        int int23 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (-1));
        int int26 = day19.getYear();
        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
        int int28 = day19.getYear();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.lang.Object obj5 = null;
        boolean boolean6 = day4.equals(obj5);
        int int7 = day4.getMonth();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        int int9 = year0.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.lang.Object obj5 = null;
        boolean boolean6 = day4.equals(obj5);
        int int7 = day4.getMonth();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        int int9 = year0.compareTo((java.lang.Object) wildcardClass8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj32 = timeSeries31.clone();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.lang.Object obj34 = null;
        boolean boolean35 = day33.equals(obj34);
        int int36 = day33.getMonth();
        int int37 = day33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) (-1));
        int int40 = day33.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day33);
        timeSeries7.setDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9999);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day2.equals(obj3);
//        int int5 = day2.getMonth();
//        int int6 = day2.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        int int10 = day7.getMonth();
//        java.lang.Class<?> wildcardClass11 = day7.getClass();
//        boolean boolean12 = day2.equals((java.lang.Object) day7);
//        long long13 = day7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, number15);
//        try {
//            timeSeries1.delete(0, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long33 = fixedMillisecond32.getFirstMillisecond();
        java.util.Date date34 = fixedMillisecond32.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date34, timeZone37);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries3.add(regularTimePeriod8, (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: July 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        java.lang.String str12 = timeSeries3.getDescription();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
//        java.lang.String str31 = timeSeries3.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
//        timeSeries3.setKey((java.lang.Comparable) 10L);
//        boolean boolean35 = timeSeries3.isEmpty();
//        java.lang.Object obj36 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj41 = timeSeries40.clone();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.Object obj43 = null;
//        boolean boolean44 = day42.equals(obj43);
//        int int45 = day42.getMonth();
//        int int46 = day42.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeries40.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass50 = timeSeries40.getClass();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.Object obj52 = null;
//        boolean boolean53 = day51.equals(obj52);
//        int int54 = day51.getMonth();
//        int int55 = day51.getYear();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.Object obj57 = null;
//        boolean boolean58 = day56.equals(obj57);
//        int int59 = day56.getMonth();
//        java.lang.Class<?> wildcardClass60 = day56.getClass();
//        boolean boolean61 = day51.equals((java.lang.Object) day56);
//        long long62 = day56.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day56.previous();
//        long long64 = day56.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (java.lang.Number) 11);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(2, year68);
//        long long70 = year68.getLastMillisecond();
//        boolean boolean71 = timeSeriesDataItem66.equals((java.lang.Object) year68);
//        try {
//            timeSeries3.add(timeSeriesDataItem66, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 43626L + "'", long62 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 43626L + "'", long64 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate12);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 1.0d);
        int int35 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.lang.String str36 = fixedMillisecond32.toString();
        java.lang.String str37 = fixedMillisecond32.toString();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str36.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str37.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 4, false);
        timeSeries3.removeAgedItems((long) (short) 1, false);
        try {
            timeSeries3.delete(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        long long2 = year1.getFirstMillisecond();
        long long3 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61851744000000L) + "'", long2 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        long long2 = year1.getFirstMillisecond();
        long long3 = year1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getFirstMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31507200000L) + "'", long32 == (-31507200000L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            timeSeries7.update(regularTimePeriod25, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 1);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 100, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.time.Year year5 = month2.getYear();
        boolean boolean7 = month2.equals((java.lang.Object) 0);
        long long8 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61891228800001L) + "'", long8 == (-61891228800001L));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        long long2 = year1.getLastMillisecond();
        int int3 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        java.lang.Object obj12 = timeSeries3.clone();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        int int25 = day14.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 1561964399999L);
//        java.util.Calendar calendar28 = null;
//        try {
//            day14.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        int int11 = day0.getDayOfMonth();
//        java.util.Calendar calendar12 = null;
//        try {
//            day0.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
//        java.util.Calendar calendar15 = null;
//        try {
//            day14.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        java.lang.String str6 = seriesChangeEvent3.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        try {
//            timeSeries3.removeAgedItems((-61893820800000L), true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 4, false);
        timeSeries3.removeAgedItems((long) (short) 1, false);
        timeSeries3.update(0, (java.lang.Number) (-61851744000000L));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        boolean boolean14 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj19 = timeSeries18.clone();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.Object obj21 = null;
        boolean boolean22 = day20.equals(obj21);
        int int23 = day20.getMonth();
        int int24 = day20.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) (-1));
        java.lang.String str27 = timeSeries18.getDescription();
        java.util.List list28 = timeSeries18.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj33 = timeSeries32.clone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = fixedMillisecond37.compareTo((java.lang.Object) year39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond37.previous();
        int int46 = timeSeries3.getIndex(regularTimePeriod45);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        double double13 = timeSeries3.getMaxY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getNextTimePeriod();
        try {
            timeSeries3.delete(0, 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        long long14 = day13.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        timeSeriesDataItem4.setValue((java.lang.Number) 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        boolean boolean27 = timeSeriesDataItem12.equals((java.lang.Object) timeSeriesDataItem25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, (int) '4');
        boolean boolean31 = timeSeriesDataItem12.equals((java.lang.Object) '4');
        timeSeriesDataItem12.setValue((java.lang.Number) 3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        java.lang.Object obj12 = timeSeries3.clone();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        int int25 = day14.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 1561964399999L);
//        timeSeries3.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
//        try {
//            timeSeries3.delete((int) (byte) 100, (int) ' ', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        boolean boolean14 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj19 = timeSeries18.clone();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.Object obj21 = null;
        boolean boolean22 = day20.equals(obj21);
        int int23 = day20.getMonth();
        int int24 = day20.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) (-1));
        java.lang.String str27 = timeSeries18.getDescription();
        java.util.List list28 = timeSeries18.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj33 = timeSeries32.clone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = fixedMillisecond37.compareTo((java.lang.Object) year39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day41);
        java.lang.Class<?> wildcardClass45 = timeSeries44.getClass();
        boolean boolean46 = timeSeries3.equals((java.lang.Object) timeSeries44);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 0.0d);
        long long4 = year1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62135784000001L) + "'", long4 == (-62135784000001L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        long long33 = fixedMillisecond32.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        boolean boolean28 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj8 = timeSeries7.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day9.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
//        double double16 = timeSeries7.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
//        timeSeries3.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day20.equals(obj21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (-1L));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
//        long long26 = day20.getFirstMillisecond();
//        java.util.Calendar calendar27 = null;
//        try {
//            day20.peg(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560150000000L + "'", long26 == 1560150000000L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate(regularTimePeriod4, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        timeSeries3.setKey((java.lang.Comparable) (-1.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        java.lang.String str7 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "September 8" + "'", str7.equals("September 8"));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo6);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
//        seriesChangeEvent3.setSummary(seriesChangeInfo8);
//        java.lang.Object obj10 = seriesChangeEvent3.getSource();
//        java.lang.Object obj11 = seriesChangeEvent3.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(obj11);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("October 52");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str11 = timePeriodFormatException10.toString();
        java.lang.String str12 = timePeriodFormatException10.toString();
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate12);
//        long long17 = day16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day10.equals(obj11);
//        int int13 = day10.getMonth();
//        java.lang.Class<?> wildcardClass14 = day10.getClass();
//        boolean boolean15 = day5.equals((java.lang.Object) day10);
//        long long16 = day10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.previous();
//        boolean boolean18 = day0.equals((java.lang.Object) day10);
//        int int19 = day0.getMonth();
//        long long20 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener15);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 5);
        boolean boolean6 = month2.equals((java.lang.Object) 5);
        int int7 = month2.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries9, seriesChangeInfo11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        long long15 = day13.getMiddleMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 1546329600000L);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193199999L + "'", long15 == 1560193199999L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        long long15 = timeSeries3.getMaximumItemAge();
        try {
            timeSeries3.delete((-9999), 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        long long44 = day5.getSerialIndex();
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = day5.getFirstMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        boolean boolean6 = timeSeriesDataItem3.isSelected();
        timeSeriesDataItem3.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj19 = timeSeries18.clone();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.Object obj21 = null;
        boolean boolean22 = day20.equals(obj21);
        int int23 = day20.getMonth();
        int int24 = day20.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) (-1));
        java.lang.String str27 = timeSeries18.getDescription();
        java.util.List list28 = timeSeries18.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj33 = timeSeries32.clone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = fixedMillisecond37.compareTo((java.lang.Object) year39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj49 = timeSeries48.clone();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.lang.Object obj51 = null;
        boolean boolean52 = day50.equals(obj51);
        int int53 = day50.getMonth();
        int int54 = day50.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (double) (-1));
        java.lang.String str57 = timeSeries48.getDescription();
        java.util.List list58 = timeSeries48.getItems();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj63 = timeSeries62.clone();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day64.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries62.createCopy((org.jfree.data.time.RegularTimePeriod) day64, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        int int70 = fixedMillisecond67.compareTo((java.lang.Object) year69);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        int int72 = day71.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = day71.previous();
        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, (org.jfree.data.time.RegularTimePeriod) day71);
        java.util.Date date75 = fixedMillisecond67.getTime();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date75);
        boolean boolean78 = timeSeries18.equals((java.lang.Object) date75);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date75);
        java.util.TimeZone timeZone80 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date75, timeZone80);
        java.util.TimeZone timeZone82 = null;
        java.util.Locale locale83 = null;
        try {
            org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date75, timeZone82, locale83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeSeries74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        boolean boolean82 = timeSeries3.isEmpty();
//        boolean boolean83 = timeSeries3.isEmpty();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        java.lang.String str16 = timeSeries7.getDescription();
        java.util.List list17 = timeSeries7.getItems();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj22 = timeSeries21.clone();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = fixedMillisecond26.compareTo((java.lang.Object) year28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        int int31 = day30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.previous();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) day30);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        boolean boolean35 = day0.equals((java.lang.Object) timeSeries33);
        org.jfree.data.time.SerialDate serialDate36 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent6.getSummary();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        long long18 = year16.getSerialIndex();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 4, false);
        timeSeries3.removeAgedItems((long) (short) 1, false);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj28 = timeSeries27.clone();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.lang.Object obj30 = null;
        boolean boolean31 = day29.equals(obj30);
        int int32 = day29.getMonth();
        int int33 = day29.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) (-1));
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj8 = timeSeries7.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day9.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
//        double double16 = timeSeries7.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
//        timeSeries3.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day20.equals(obj21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (-1L));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
//        long long26 = day20.getFirstMillisecond();
//        long long27 = day20.getFirstMillisecond();
//        int int28 = day20.getYear();
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560150000000L + "'", long26 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        java.lang.String str14 = month2.toString();
        int int15 = month2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "February 2019" + "'", str14.equals("February 2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        long long16 = year12.getSerialIndex();
        long long17 = year12.getLastMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year12.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 8" + "'", str3.equals("September 8"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43626L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries3.setNotify(true);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        long long19 = day17.getLastMillisecond();
//        int int20 = day17.getMonth();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long16 = fixedMillisecond15.getSerialIndex();
        java.util.Date date17 = fixedMillisecond15.getTime();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent6.getSummary();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        double double12 = timeSeries3.getMaxY();
//        boolean boolean13 = timeSeries3.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj20 = timeSeries19.clone();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day21.equals(obj22);
//        int int24 = day21.getMonth();
//        int int25 = day21.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries19.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass29 = timeSeries19.getClass();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day30.equals(obj31);
//        int int33 = day30.getMonth();
//        int int34 = day30.getYear();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = day35.equals(obj36);
//        int int38 = day35.getMonth();
//        java.lang.Class<?> wildcardClass39 = day35.getClass();
//        boolean boolean40 = day30.equals((java.lang.Object) day35);
//        long long41 = day35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.previous();
//        long long43 = day35.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 11);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(2, year47);
//        long long49 = year47.getLastMillisecond();
//        boolean boolean50 = timeSeriesDataItem45.equals((java.lang.Object) year47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getYear();
//        long long5 = day3.getMiddleMillisecond();
//        int int6 = day3.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 2);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        int int11 = day3.compareTo((java.lang.Object) fixedMillisecond8);
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 10L, true);
//        long long15 = day3.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193199999L + "'", long15 == 1560193199999L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, 0.0d);
//        long long50 = day46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem52.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDescription("11-June-2019");
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int16 = month15.getMonth();
        org.jfree.data.time.Year year17 = month15.getYear();
        java.lang.String str18 = month15.toString();
        long long19 = month15.getLastMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 132L, false);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "December 10" + "'", str18.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61820208000001L) + "'", long19 == (-61820208000001L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        timeSeries3.fireSeriesChanged();
        java.lang.Class<?> wildcardClass65 = timeSeries3.getClass();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, 0.0d);
        timeSeriesDataItem69.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getMiddleMillisecond(calendar74);
        boolean boolean76 = timeSeriesDataItem69.equals((java.lang.Object) fixedMillisecond73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day79, 0.0d);
        timeSeriesDataItem82.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar87 = null;
        long long88 = fixedMillisecond86.getMiddleMillisecond(calendar87);
        boolean boolean89 = timeSeriesDataItem82.equals((java.lang.Object) fixedMillisecond86);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = timeSeriesDataItem91.getPeriod();
        boolean boolean93 = timeSeriesDataItem78.equals((java.lang.Object) timeSeriesDataItem91);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem94 = timeSeries3.addOrUpdate(timeSeriesDataItem91);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 35L + "'", long75 == 35L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 35L + "'", long88 == 35L);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        long long4 = day0.getSerialIndex();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1561964399999L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        timeSeries3.delete(regularTimePeriod15);
        boolean boolean17 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 132L);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        boolean boolean9 = fixedMillisecond4.equals((java.lang.Object) int8);
        java.util.Date date10 = fixedMillisecond4.getTime();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "October 52", "", "");
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        java.lang.Object obj18 = null;
        int int19 = timeSeriesDataItem9.compareTo(obj18);
        timeSeriesDataItem9.setValue((java.lang.Number) 1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, 0.0d);
//        long long50 = day46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 10);
//        timeSeries17.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj14 = timeSeries13.clone();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Object obj16 = null;
        boolean boolean17 = day15.equals(obj16);
        int int18 = day15.getMonth();
        int int19 = day15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (-1));
        double double22 = timeSeries13.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries9.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date26 = fixedMillisecond25.getStart();
        long long27 = fixedMillisecond25.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
        long long29 = fixedMillisecond25.getSerialIndex();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond25.getLastMillisecond(calendar30);
        int int32 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        boolean boolean33 = month2.equals((java.lang.Object) int32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        java.lang.String str12 = timeSeries3.getDescription();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean33 = day26.equals((java.lang.Object) (short) 10);
//        int int34 = day26.getDayOfMonth();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo1);
//        java.lang.String str3 = seriesChangeEvent2.toString();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
        long long33 = year32.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1.0f));
        java.util.Date date36 = year32.getEnd();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1969L + "'", long33 == 1969L);
        org.junit.Assert.assertNotNull(date36);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day5.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        timeSeriesDataItem3.setValue((java.lang.Number) 100.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = year1.compareTo((java.lang.Object) day3);
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, 0.0d);
        timeSeriesDataItem17.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        boolean boolean24 = timeSeriesDataItem17.equals((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(2, year29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        int int33 = year29.compareTo((java.lang.Object) day31);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) day31);
        timeSeriesDataItem26.setValue((java.lang.Number) 10);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int40 = month39.getMonth();
        org.jfree.data.time.Year year41 = month39.getYear();
        java.lang.String str42 = month39.toString();
        long long43 = month39.getLastMillisecond();
        org.jfree.data.time.Year year44 = month39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        boolean boolean46 = timeSeriesDataItem26.equals((java.lang.Object) regularTimePeriod45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod45, "October 52", "");
        timeSeries7.delete(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 12 + "'", int40 == 12);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "December 10" + "'", str42.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61820208000001L) + "'", long43 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries7.setMaximumItemAge((long) 4);
        try {
            java.lang.Number number21 = timeSeries7.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        boolean boolean9 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getSerialIndex();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2L + "'", long4 == 2L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date60);
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj70 = timeSeries69.clone();
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        java.lang.Object obj72 = null;
        boolean boolean73 = day71.equals(obj72);
        int int74 = day71.getMonth();
        int int75 = day71.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, (double) (-1));
        java.lang.String str78 = timeSeries69.getDescription();
        java.util.List list79 = timeSeries69.getItems();
        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj84 = timeSeries83.clone();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = day85.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond88 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries83.createCopy((org.jfree.data.time.RegularTimePeriod) day85, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond88);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year();
        int int91 = fixedMillisecond88.compareTo((java.lang.Object) year90);
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day();
        int int93 = day92.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = day92.previous();
        org.jfree.data.time.TimeSeries timeSeries95 = timeSeries69.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond88, (org.jfree.data.time.RegularTimePeriod) day92);
        java.lang.Class class96 = timeSeries69.getTimePeriodClass();
        java.lang.Class class97 = org.jfree.data.time.RegularTimePeriod.downsize(class96);
        boolean boolean98 = fixedMillisecond65.equals((java.lang.Object) class97);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(list79);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(timeSeries89);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2019 + "'", int93 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(timeSeries95);
        org.junit.Assert.assertNotNull(class96);
        org.junit.Assert.assertNotNull(class97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(2, year28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
        int int32 = year28.compareTo((java.lang.Object) day30);
        int int33 = timeSeriesDataItem25.compareTo((java.lang.Object) day30);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj38 = timeSeries37.clone();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.lang.Object obj40 = null;
        boolean boolean41 = day39.equals(obj40);
        int int42 = day39.getMonth();
        int int43 = day39.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) (-1));
        java.lang.String str46 = timeSeries37.getDescription();
        java.util.List list47 = timeSeries37.getItems();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj52 = timeSeries51.clone();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        int int59 = fixedMillisecond56.compareTo((java.lang.Object) year58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        int int61 = day60.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day60.previous();
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (org.jfree.data.time.RegularTimePeriod) day60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond56.previous();
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day30, regularTimePeriod64);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day66, 0.0d);
        timeSeriesDataItem69.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getMiddleMillisecond(calendar74);
        boolean boolean76 = timeSeriesDataItem69.equals((java.lang.Object) fixedMillisecond73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day79, 0.0d);
        timeSeriesDataItem82.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar87 = null;
        long long88 = fixedMillisecond86.getMiddleMillisecond(calendar87);
        boolean boolean89 = timeSeriesDataItem82.equals((java.lang.Object) fixedMillisecond86);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond86, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = timeSeriesDataItem91.getPeriod();
        boolean boolean93 = timeSeriesDataItem78.equals((java.lang.Object) timeSeriesDataItem91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = timeSeriesDataItem91.getPeriod();
        try {
            timeSeries3.add(timeSeriesDataItem91);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 35L + "'", long75 == 35L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 35L + "'", long88 == 35L);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 1.0d);
        int int35 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.lang.String str36 = fixedMillisecond32.toString();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str36.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        long long12 = timeSeries3.getMaximumItemAge();
        java.lang.String str13 = timeSeries3.getDomainDescription();
        try {
            timeSeries3.delete(12, 2019, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        java.lang.Object obj12 = timeSeries3.clone();
        java.util.List list13 = timeSeries3.getItems();
        boolean boolean14 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) '4');
        timeSeries3.setKey((java.lang.Comparable) '4');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, 0.0d);
        timeSeriesDataItem15.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        boolean boolean22 = timeSeriesDataItem15.equals((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (-1.0f));
        timeSeriesDataItem24.setSelected(false);
        java.lang.Number number27 = timeSeriesDataItem24.getValue();
        int int29 = timeSeriesDataItem24.compareTo((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (-1.0f) + "'", number27.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        try {
            timeSeries3.delete((int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.setNotify(false);
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        double double12 = timeSeries7.getMinY();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0f + "'", comparable11.equals(0.0f));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.next();
        long long17 = year12.getSerialIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        int int11 = fixedMillisecond8.compareTo((java.lang.Object) year10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Object obj13 = null;
//        boolean boolean14 = day12.equals(obj13);
//        int int15 = day12.getMonth();
//        int int16 = day12.getYear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day17.equals(obj18);
//        int int20 = day17.getMonth();
//        java.lang.Class<?> wildcardClass21 = day17.getClass();
//        boolean boolean22 = day12.equals((java.lang.Object) day17);
//        long long23 = day17.getSerialIndex();
//        int int24 = fixedMillisecond8.compareTo((java.lang.Object) long23);
//        java.util.Date date25 = fixedMillisecond8.getTime();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        timeSeries3.delete(regularTimePeriod15);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.Year year11 = month9.getYear();
        java.lang.String str12 = month9.toString();
        long long13 = month9.getLastMillisecond();
        org.jfree.data.time.Year year14 = month9.getYear();
        boolean boolean15 = fixedMillisecond1.equals((java.lang.Object) year14);
        long long16 = year14.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 10" + "'", str12.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61820208000001L) + "'", long13 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.util.List list4 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1969" + "'", str4.equals("December 1969"));
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9999);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day2.equals(obj3);
//        int int5 = day2.getMonth();
//        int int6 = day2.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day7.equals(obj8);
//        int int10 = day7.getMonth();
//        java.lang.Class<?> wildcardClass11 = day7.getClass();
//        boolean boolean12 = day2.equals((java.lang.Object) day7);
//        long long13 = day7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, number15);
//        int int17 = timeSeries1.getItemCount();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(2, year15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        int int19 = year15.compareTo((java.lang.Object) day17);
        int int20 = timeSeriesDataItem12.compareTo((java.lang.Object) day17);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int26 = month25.getMonth();
        org.jfree.data.time.Year year27 = month25.getYear();
        java.lang.String str28 = month25.toString();
        long long29 = month25.getLastMillisecond();
        org.jfree.data.time.Year year30 = month25.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        boolean boolean32 = timeSeriesDataItem12.equals((java.lang.Object) regularTimePeriod31);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod31, "October 52", "");
        long long36 = timeSeries35.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "December 10" + "'", str28.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61820208000001L) + "'", long29 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        long long15 = day13.getMiddleMillisecond();
//        int int16 = day13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 2);
//        long long19 = fixedMillisecond18.getSerialIndex();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        int int21 = day13.compareTo((java.lang.Object) fixedMillisecond18);
//        long long22 = day13.getLastMillisecond();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (byte) 0);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193199999L + "'", long15 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2L + "'", long19 == 2L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) 1, 11);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.lang.Object obj9 = null;
        boolean boolean10 = day8.equals(obj9);
        int int11 = day8.getMonth();
        int int12 = day8.getYear();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Object obj14 = null;
        boolean boolean15 = day13.equals(obj14);
        int int16 = day13.getMonth();
        java.lang.Class<?> wildcardClass17 = day13.getClass();
        boolean boolean18 = day8.equals((java.lang.Object) day13);
        java.lang.Number number19 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day13, number19);
        java.lang.Comparable comparable21 = timeSeries3.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0f + "'", comparable21.equals(0.0f));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond8.peg(calendar10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar10, seriesChangeInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setValue((java.lang.Number) 8);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) 8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = year13.getYear();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year13);
        long long17 = year13.getSerialIndex();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(9999, year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        int int12 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.String str30 = timeSeries29.getRangeDescription();
        boolean boolean31 = timeSeries29.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate(regularTimePeriod32, (java.lang.Number) (-61891228800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener18);
        timeSeries3.removeAgedItems((long) (byte) -1, false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setRangeDescription("December 10");
        timeSeries3.setNotify(false);
        java.lang.Class class20 = timeSeries3.getTimePeriodClass();
        java.lang.String str21 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = year32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.next();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.lang.Object obj37 = null;
        boolean boolean38 = day36.equals(obj37);
        int int39 = day36.getMonth();
        java.lang.Class<?> wildcardClass40 = day36.getClass();
        int int41 = year32.compareTo((java.lang.Object) wildcardClass40);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        timeSeriesDataItem4.setValue((java.lang.Number) (short) 100);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj17 = timeSeries16.clone();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Object obj19 = null;
        boolean boolean20 = day18.equals(obj19);
        int int21 = day18.getMonth();
        int int22 = day18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) (-1));
        java.lang.String str25 = timeSeries16.getDescription();
        java.util.List list26 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj31 = timeSeries30.clone();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        int int38 = fixedMillisecond35.compareTo((java.lang.Object) year37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        int int40 = day39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.previous();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        boolean boolean44 = day9.equals((java.lang.Object) timeSeries42);
        java.lang.Comparable comparable45 = timeSeries42.getKey();
        java.lang.String str46 = timeSeries42.getDomainDescription();
        int int47 = timeSeries42.getItemCount();
        int int48 = timeSeriesDataItem4.compareTo((java.lang.Object) int47);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 0.0f + "'", comparable45.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        long long6 = day4.getMiddleMillisecond();
//        int int7 = day4.getYear();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day8.equals(obj9);
//        int int11 = day8.getMonth();
//        int int12 = day4.compareTo((java.lang.Object) int11);
//        java.lang.String str13 = day4.toString();
//        int int14 = day4.getYear();
//        timeSeries3.setKey((java.lang.Comparable) int14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = null;
//        try {
//            timeSeries3.add(timeSeriesDataItem16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getMiddleMillisecond();
//        int int15 = day12.getYear();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Object obj17 = null;
//        boolean boolean18 = day16.equals(obj17);
//        int int19 = day16.getMonth();
//        int int20 = day12.compareTo((java.lang.Object) int19);
//        java.lang.String str21 = day12.toString();
//        java.util.Date date22 = day12.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        boolean boolean24 = timeSeries3.equals((java.lang.Object) day23);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560193199999L + "'", long14 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.Year year3 = month2.getYear();
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        long long4 = month2.getFirstMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getYear();
//        long long7 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        long long9 = day5.getSerialIndex();
//        int int10 = month2.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        long long14 = month13.getSerialIndex();
//        int int15 = month2.compareTo((java.lang.Object) month13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61893820800000L) + "'", long4 == (-61893820800000L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 132L + "'", long14 == 132L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-2) + "'", int15 == (-2));
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.Year year14 = month2.getYear();
        long long15 = month2.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month2.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1551427199999L + "'", long15 == 1551427199999L);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj19 = timeSeries18.clone();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day20.equals(obj21);
//        int int23 = day20.getMonth();
//        int int24 = day20.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) (-1));
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(2, year28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        timeSeries18.delete(regularTimePeriod30);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj36 = timeSeries35.clone();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = day37.equals(obj38);
//        int int40 = day37.getMonth();
//        int int41 = day37.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) (-1));
//        java.lang.String str44 = timeSeries35.getDescription();
//        java.util.List list45 = timeSeries35.getItems();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj50 = timeSeries49.clone();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day51.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        int int57 = fixedMillisecond54.compareTo((java.lang.Object) year56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.previous();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) day58);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean65 = day58.equals((java.lang.Object) (short) 10);
//        long long66 = day58.getMiddleMillisecond();
//        boolean boolean68 = day58.equals((java.lang.Object) 1L);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day58, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj76 = timeSeries75.clone();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.lang.Object obj78 = null;
//        boolean boolean79 = day77.equals(obj78);
//        int int80 = day77.getMonth();
//        int int81 = day77.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries75.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day77, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries75.getNextTimePeriod();
//        double double85 = timeSeries75.getMaxY();
//        java.util.Collection collection86 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries75);
//        long long87 = timeSeries18.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj92 = timeSeries91.clone();
//        org.jfree.data.time.TimeSeries timeSeries95 = timeSeries91.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection96 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries95);
//        boolean boolean97 = timeSeries18.isEmpty();
//        boolean boolean98 = fixedMillisecond13.equals((java.lang.Object) boolean97);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertNotNull(list45);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560193199999L + "'", long66 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(obj76);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 6 + "'", int80 == 6);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + double85 + "' != '" + (-1.0d) + "'", double85 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection86);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 9223372036854775807L + "'", long87 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj92);
//        org.junit.Assert.assertNotNull(timeSeries95);
//        org.junit.Assert.assertNotNull(collection96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries3.getTimePeriodClass();
        boolean boolean31 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        int int36 = month34.getYearValue();
        long long37 = month34.getLastMillisecond();
        timeSeries3.setKey((java.lang.Comparable) month34);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 8 + "'", int36 == 8);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61891228800001L) + "'", long37 == (-61891228800001L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.Year year23 = month22.getYear();
        boolean boolean24 = timeSeriesDataItem3.equals((java.lang.Object) month22);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getYear();
//        long long5 = day3.getMiddleMillisecond();
//        int int6 = day3.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 2);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        int int11 = day3.compareTo((java.lang.Object) fixedMillisecond8);
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 10L, true);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj19 = timeSeries18.clone();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
//        timeSeriesDataItem23.setValue((java.lang.Number) 8);
//        boolean boolean26 = timeSeries18.equals((java.lang.Object) 8);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getFirstMillisecond();
//        int int29 = year27.getYear();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) year27);
//        int int31 = timeSeries18.getMaximumItemCount();
//        boolean boolean32 = day3.equals((java.lang.Object) timeSeries18);
//        long long33 = day3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193199999L + "'", long5 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 8);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, 0.0d);
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond13);
        boolean boolean17 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem9);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = timeSeriesDataItem3.compareTo((java.lang.Object) day18);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj8 = timeSeries7.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day9.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
//        double double16 = timeSeries7.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
//        timeSeries3.setMaximumItemAge((long) (byte) 1);
//        java.lang.Object obj20 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj25 = timeSeries24.clone();
//        timeSeries24.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries24.addChangeListener(seriesChangeListener28);
//        double double30 = timeSeries24.getMinY();
//        timeSeries24.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj37 = timeSeries36.clone();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.Object obj39 = null;
//        boolean boolean40 = day38.equals(obj39);
//        int int41 = day38.getMonth();
//        int int42 = day38.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (double) (-1));
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(2, year46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
//        timeSeries36.delete(regularTimePeriod48);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj54 = timeSeries53.clone();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.Object obj56 = null;
//        boolean boolean57 = day55.equals(obj56);
//        int int58 = day55.getMonth();
//        int int59 = day55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (double) (-1));
//        java.lang.String str62 = timeSeries53.getDescription();
//        java.util.List list63 = timeSeries53.getItems();
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj68 = timeSeries67.clone();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries67.createCopy((org.jfree.data.time.RegularTimePeriod) day69, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
//        int int75 = fixedMillisecond72.compareTo((java.lang.Object) year74);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        int int77 = day76.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day76.previous();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (org.jfree.data.time.RegularTimePeriod) day76);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean83 = day76.equals((java.lang.Object) (short) 10);
//        long long84 = day76.getMiddleMillisecond();
//        boolean boolean86 = day76.equals((java.lang.Object) 1L);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) day76, (double) 9999, false);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day76, (java.lang.Number) Double.NaN);
//        timeSeries3.setKey((java.lang.Comparable) day76);
//        long long93 = day76.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertNotNull(list63);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560193199999L + "'", long84 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 43626L + "'", long93 == 43626L);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        java.lang.String str8 = month2.toString();
        java.lang.String str9 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 10" + "'", str8.equals("December 10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "December 10" + "'", str9.equals("December 10"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
        double double13 = timeSeries3.getMaxY();
        timeSeries3.setRangeDescription("December 10");
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj20 = timeSeries19.clone();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.lang.Object obj22 = null;
        boolean boolean23 = day21.equals(obj22);
        int int24 = day21.getMonth();
        int int25 = day21.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (double) (-1));
        java.lang.String str28 = timeSeries19.getDescription();
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) year40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        int int43 = day42.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.previous();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj50 = timeSeries49.clone();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        java.lang.Object obj52 = null;
        boolean boolean53 = day51.equals(obj52);
        int int54 = day51.getMonth();
        int int55 = day51.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (double) (-1));
        java.lang.String str58 = timeSeries49.getDescription();
        java.util.List list59 = timeSeries49.getItems();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj64 = timeSeries63.clone();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day65.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries63.createCopy((org.jfree.data.time.RegularTimePeriod) day65, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        int int71 = fixedMillisecond68.compareTo((java.lang.Object) year70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
        int int73 = day72.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day72.previous();
        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (org.jfree.data.time.RegularTimePeriod) day72);
        java.util.Date date76 = fixedMillisecond68.getTime();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date76);
        boolean boolean79 = timeSeries19.equals((java.lang.Object) date76);
        timeSeries19.fireSeriesChanged();
        java.lang.Class<?> wildcardClass81 = timeSeries19.getClass();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(2019);
        java.util.Date date84 = year83.getStart();
        java.util.TimeZone timeZone85 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date84, timeZone85);
        boolean boolean87 = timeSeries3.equals((java.lang.Object) timeZone85);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(timeSeries75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj32 = timeSeries31.clone();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.lang.Object obj34 = null;
        boolean boolean35 = day33.equals(obj34);
        int int36 = day33.getMonth();
        int int37 = day33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) (-1));
        int int40 = day33.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day33);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj46 = timeSeries45.clone();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.lang.Object obj48 = null;
        boolean boolean49 = day47.equals(obj48);
        int int50 = day47.getMonth();
        int int51 = day47.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) (-1));
        java.lang.String str54 = timeSeries45.getDescription();
        java.util.List list55 = timeSeries45.getItems();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj60 = timeSeries59.clone();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) day61, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        int int67 = fixedMillisecond64.compareTo((java.lang.Object) year66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        int int69 = day68.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day68.previous();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (org.jfree.data.time.RegularTimePeriod) day68);
        java.util.Date date72 = fixedMillisecond64.getTime();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date72);
        boolean boolean74 = day33.equals((java.lang.Object) day73);
        java.util.Calendar calendar75 = null;
        try {
            long long76 = day73.getLastMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        double double12 = timeSeries3.getMaxY();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, 0.0d);
//        timeSeriesDataItem16.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        boolean boolean23 = timeSeriesDataItem16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(2, year28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        int int32 = year28.compareTo((java.lang.Object) day30);
//        int int33 = timeSeriesDataItem25.compareTo((java.lang.Object) day30);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj38 = timeSeries37.clone();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.Object obj40 = null;
//        boolean boolean41 = day39.equals(obj40);
//        int int42 = day39.getMonth();
//        int int43 = day39.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) (-1));
//        java.lang.String str46 = timeSeries37.getDescription();
//        java.util.List list47 = timeSeries37.getItems();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj52 = timeSeries51.clone();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        int int59 = fixedMillisecond56.compareTo((java.lang.Object) year58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day60.previous();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond56.previous();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day30, regularTimePeriod64);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent66 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day30);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo67 = seriesChangeEvent66.getSummary();
//        java.lang.String str68 = seriesChangeEvent66.toString();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNull(seriesChangeInfo67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str68.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
//        timeSeries3.setKey((java.lang.Comparable) 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj13 = timeSeries12.clone();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) (-1));
//        java.lang.String str21 = timeSeries12.getDescription();
//        java.util.List list22 = timeSeries12.getItems();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj27 = timeSeries26.clone();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) day28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        int int34 = fixedMillisecond31.compareTo((java.lang.Object) year33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.previous();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean42 = day35.equals((java.lang.Object) (short) 10);
//        long long43 = day35.getMiddleMillisecond();
//        boolean boolean45 = day35.equals((java.lang.Object) 1L);
//        java.lang.String str46 = day35.toString();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getYear();
//        long long50 = day48.getMiddleMillisecond();
//        int int51 = day48.getYear();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Object obj53 = null;
//        boolean boolean54 = day52.equals(obj53);
//        int int55 = day52.getMonth();
//        int int56 = day48.compareTo((java.lang.Object) int55);
//        java.lang.String str57 = day48.toString();
//        java.util.Date date58 = day48.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day48);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560193199999L + "'", long43 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560193199999L + "'", long50 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDescription("11-June-2019");
        double double12 = timeSeries3.getMaxY();
        timeSeries3.setMaximumItemCount(5);
        try {
            timeSeries3.delete(9, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
        timeSeriesDataItem8.setValue((java.lang.Number) 8);
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy(3, (int) (byte) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj16 = timeSeries15.clone();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        timeSeries15.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) (-61891228800001L));
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) year40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(6, year40);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar5, seriesChangeInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 8);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1L));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem4, seriesChangeInfo5);
        timeSeriesDataItem4.setValue((java.lang.Number) (short) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) 1560150000000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        long long12 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries3.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        long long13 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj18 = timeSeries17.clone();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        timeSeries17.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        long long31 = day29.getMiddleMillisecond();
//        int int32 = day29.getYear();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Object obj34 = null;
//        boolean boolean35 = day33.equals(obj34);
//        int int36 = day33.getMonth();
//        int int37 = day29.compareTo((java.lang.Object) int36);
//        java.lang.String str38 = day29.toString();
//        java.util.Date date39 = day29.getStart();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 132L);
//        boolean boolean43 = day5.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, 0.0d);
//        long long50 = day46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries17.addOrUpdate(regularTimePeriod53, (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193199999L + "'", long31 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int8 = month7.getMonth();
        org.jfree.data.time.Year year9 = month7.getYear();
        java.lang.String str10 = month7.toString();
        long long11 = month7.getLastMillisecond();
        org.jfree.data.time.Year year12 = month7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (byte) 1, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 4, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = year17.equals((java.lang.Object) date27);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 10" + "'", str10.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820208000001L) + "'", long11 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 10);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.lang.String str2 = month0.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(6, year11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year11, "", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year11.next();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries3.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.Object obj21 = null;
        boolean boolean22 = day20.equals(obj21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.lang.Object obj27 = null;
        boolean boolean28 = day26.equals(obj27);
        int int29 = day26.getMonth();
        int int30 = day26.getYear();
        int int31 = timeSeriesDataItem25.compareTo((java.lang.Object) int30);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesException: December 10");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, 0.0d);
        timeSeriesDataItem20.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        boolean boolean27 = timeSeriesDataItem20.equals((java.lang.Object) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (-1.0f));
        try {
            timeSeries3.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, 5, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) year11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(6, year11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year11.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
//        long long2 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj12 = timeSeries11.clone();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Object obj14 = null;
//        boolean boolean15 = day13.equals(obj14);
//        int int16 = day13.getMonth();
//        int int17 = day13.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1));
//        double double20 = timeSeries11.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries7.addAndOrUpdate(timeSeries11);
//        timeSeries7.setMaximumItemAge((long) (byte) 1);
//        java.lang.Object obj24 = timeSeries7.clone();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj29 = timeSeries28.clone();
//        timeSeries28.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries28.addChangeListener(seriesChangeListener32);
//        double double34 = timeSeries28.getMinY();
//        timeSeries28.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj41 = timeSeries40.clone();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.Object obj43 = null;
//        boolean boolean44 = day42.equals(obj43);
//        int int45 = day42.getMonth();
//        int int46 = day42.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (double) (-1));
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(2, year50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.next();
//        timeSeries40.delete(regularTimePeriod52);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj58 = timeSeries57.clone();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        java.lang.Object obj60 = null;
//        boolean boolean61 = day59.equals(obj60);
//        int int62 = day59.getMonth();
//        int int63 = day59.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) (-1));
//        java.lang.String str66 = timeSeries57.getDescription();
//        java.util.List list67 = timeSeries57.getItems();
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj72 = timeSeries71.clone();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day73.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) day73, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        int int79 = fixedMillisecond76.compareTo((java.lang.Object) year78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        int int81 = day80.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day80.previous();
//        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (org.jfree.data.time.RegularTimePeriod) day80);
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean87 = day80.equals((java.lang.Object) (short) 10);
//        long long88 = day80.getMiddleMillisecond();
//        boolean boolean90 = day80.equals((java.lang.Object) 1L);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) day80, (double) 9999, false);
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day80, (java.lang.Number) Double.NaN);
//        timeSeries7.setKey((java.lang.Comparable) day80);
//        org.jfree.data.time.TimeSeries timeSeries97 = timeSeries3.addAndOrUpdate(timeSeries7);
//        timeSeries3.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertNull(str66);
//        org.junit.Assert.assertNotNull(list67);
//        org.junit.Assert.assertNotNull(obj72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(timeSeries77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeSeries83);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560193199999L + "'", long88 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertNotNull(timeSeries97);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        boolean boolean13 = timeSeries3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj21 = timeSeries20.clone();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        timeSeries20.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        int int33 = fixedMillisecond30.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (short) 10);
        timeSeries20.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, 0.0d);
        timeSeriesDataItem41.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getMiddleMillisecond(calendar46);
        boolean boolean48 = timeSeriesDataItem41.equals((java.lang.Object) fixedMillisecond45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(2, year53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
        int int57 = year53.compareTo((java.lang.Object) day55);
        int int58 = timeSeriesDataItem50.compareTo((java.lang.Object) day55);
        timeSeriesDataItem50.setValue((java.lang.Number) 1551427199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries20.addOrUpdate(timeSeriesDataItem50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeriesDataItem61.getPeriod();
        try {
            timeSeries3.add(regularTimePeriod62, (java.lang.Number) 9223372036854775807L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 35L + "'", long47 == 35L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        java.lang.Object obj12 = timeSeries3.clone();
//        java.util.List list13 = timeSeries3.getItems();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        int int25 = day14.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 1561964399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Date date30 = fixedMillisecond29.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
//        boolean boolean33 = day14.equals((java.lang.Object) date30);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        timeSeries3.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        double double9 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getYearValue();
//        int int12 = month10.getYearValue();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day13);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy((int) '#', (-9999));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(collection18);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: July 10");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries17.setRangeDescription("December 10");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.Year year23 = month22.getYear();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1546329600000L);
        boolean boolean28 = timeSeries17.getNotify();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        timeSeriesDataItem3.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(2, year15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        int int19 = year15.compareTo((java.lang.Object) day17);
        int int20 = timeSeriesDataItem12.compareTo((java.lang.Object) day17);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        java.lang.Number number23 = timeSeriesDataItem12.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem12.getPeriod();
        java.lang.Object obj26 = timeSeriesDataItem12.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10 + "'", number23.equals(10));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(obj26);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        boolean boolean82 = timeSeries3.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond(10L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        java.lang.Object obj30 = timeSeriesDataItem29.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 1.0d);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond32.getTime();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
//        int int40 = timeSeriesDataItem29.compareTo((java.lang.Object) serialDate39);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("December 10");
        java.lang.String str4 = seriesException3.toString();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: December 10" + "'", str4.equals("org.jfree.data.general.SeriesException: December 10"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        timeSeries60.setDescription("hi!");
//        timeSeries60.removeAgedItems(false);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setMaximumItemCount(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setRangeDescription("December 10");
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj22 = timeSeries21.clone();
//        timeSeries21.setNotify(false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries21.addChangeListener(seriesChangeListener25);
//        double double27 = timeSeries21.getMinY();
//        timeSeries21.setDescription("11-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj34 = timeSeries33.clone();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.Object obj36 = null;
//        boolean boolean37 = day35.equals(obj36);
//        int int38 = day35.getMonth();
//        int int39 = day35.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(2, year43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
//        timeSeries33.delete(regularTimePeriod45);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj51 = timeSeries50.clone();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Object obj53 = null;
//        boolean boolean54 = day52.equals(obj53);
//        int int55 = day52.getMonth();
//        int int56 = day52.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day52, (double) (-1));
//        java.lang.String str59 = timeSeries50.getDescription();
//        java.util.List list60 = timeSeries50.getItems();
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj65 = timeSeries64.clone();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) day66, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        int int72 = fixedMillisecond69.compareTo((java.lang.Object) year71);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        int int74 = day73.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day73.previous();
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) day73);
//        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean80 = day73.equals((java.lang.Object) (short) 10);
//        long long81 = day73.getMiddleMillisecond();
//        boolean boolean83 = day73.equals((java.lang.Object) 1L);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) day73, (double) 9999, false);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day73, (java.lang.Number) Double.NaN);
//        java.lang.Number number89 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day73);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertNull(str59);
//        org.junit.Assert.assertNotNull(list60);
//        org.junit.Assert.assertNotNull(obj65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2019 + "'", int74 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560193199999L + "'", long81 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNull(number89);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int2 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getYear();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day0.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        int int2 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) 0.0d);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        java.lang.Number number14 = timeSeries3.getValue(regularTimePeriod13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date17 = fixedMillisecond16.getStart();
        java.lang.Number number18 = null;
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number18);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        timeSeries3.fireSeriesChanged();
        java.lang.Class<?> wildcardClass65 = timeSeries3.getClass();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(2019);
        java.util.Date date68 = year67.getStart();
        java.util.TimeZone timeZone69 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date68, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date68);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNull(regularTimePeriod70);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timePeriodFormatException1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("July 10");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("December 10");
        java.lang.String str13 = seriesException12.toString();
        java.lang.Throwable[] throwableArray14 = seriesException12.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.Throwable[] throwableArray16 = seriesException5.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: July 10" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: July 10"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: July 10" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: July 10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: December 10" + "'", str13.equals("org.jfree.data.general.SeriesException: December 10"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Date date30 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        java.util.Calendar calendar33 = null;
        fixedMillisecond32.peg(calendar33);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.lang.Object obj5 = null;
        boolean boolean6 = day4.equals(obj5);
        int int7 = day4.getMonth();
        java.lang.Class<?> wildcardClass8 = day4.getClass();
        int int9 = year0.compareTo((java.lang.Object) wildcardClass8);
        java.lang.String str10 = year0.toString();
        java.lang.String str11 = year0.toString();
        long long12 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 10);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, 0.0d);
        timeSeriesDataItem24.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        boolean boolean31 = timeSeriesDataItem24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem33.getPeriod();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(2, year36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        int int40 = year36.compareTo((java.lang.Object) day38);
        int int41 = timeSeriesDataItem33.compareTo((java.lang.Object) day38);
        timeSeriesDataItem33.setValue((java.lang.Number) 1551427199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries3.addOrUpdate(timeSeriesDataItem33);
        try {
            timeSeries3.delete((int) ' ', (int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setRangeDescription("December 10");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, 0.0d);
        timeSeriesDataItem21.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        boolean boolean28 = timeSeriesDataItem21.equals((java.lang.Object) fixedMillisecond25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, 0.0d);
        timeSeriesDataItem34.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        boolean boolean41 = timeSeriesDataItem34.equals((java.lang.Object) fixedMillisecond38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem43.getPeriod();
        boolean boolean45 = timeSeriesDataItem30.equals((java.lang.Object) timeSeriesDataItem43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeriesDataItem43.getPeriod();
        timeSeriesDataItem43.setValue((java.lang.Number) 2019);
        timeSeries3.add(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(2, year6);
        long long8 = month7.getLastMillisecond();
        long long9 = month7.getMiddleMillisecond();
        org.jfree.data.time.Year year10 = month7.getYear();
        boolean boolean11 = year4.equals((java.lang.Object) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1551427199999L + "'", long8 == 1551427199999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1550217599999L + "'", long9 == 1550217599999L);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        timeSeriesDataItem29.setSelected(true);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        timeSeries3.setMaximumItemAge(0L);
        double double32 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date33 = fixedMillisecond32.getStart();
        long long34 = fixedMillisecond32.getMiddleMillisecond();
        long long35 = fixedMillisecond32.getMiddleMillisecond();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getLastMillisecond(calendar36);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        double double12 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        long long15 = timeSeries3.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy(7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9999);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, 0.0d);
        timeSeriesDataItem5.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        boolean boolean12 = timeSeriesDataItem5.equals((java.lang.Object) fixedMillisecond9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-1.0f));
        timeSeries1.add(timeSeriesDataItem14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (short) 10);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj24 = timeSeries23.clone();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.lang.Object obj26 = null;
        boolean boolean27 = day25.equals(obj26);
        int int28 = day25.getMonth();
        int int29 = day25.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (double) (-1));
        double double32 = timeSeries23.getMaxY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, 0.0d);
        timeSeriesDataItem36.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        boolean boolean43 = timeSeriesDataItem36.equals((java.lang.Object) fixedMillisecond40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeriesDataItem45.getPeriod();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(2, year48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
        int int52 = year48.compareTo((java.lang.Object) day50);
        int int53 = timeSeriesDataItem45.compareTo((java.lang.Object) day50);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj58 = timeSeries57.clone();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.lang.Object obj60 = null;
        boolean boolean61 = day59.equals(obj60);
        int int62 = day59.getMonth();
        int int63 = day59.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) (-1));
        java.lang.String str66 = timeSeries57.getDescription();
        java.util.List list67 = timeSeries57.getItems();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj72 = timeSeries71.clone();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day73.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries71.createCopy((org.jfree.data.time.RegularTimePeriod) day73, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        int int79 = fixedMillisecond76.compareTo((java.lang.Object) year78);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
        int int81 = day80.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day80.previous();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (org.jfree.data.time.RegularTimePeriod) day80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond76.previous();
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day50, regularTimePeriod84);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent86 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day50);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day50);
        long long88 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener89 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener89);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2019 + "'", int81 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(timeSeries85);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 9223372036854775807L + "'", long88 == 9223372036854775807L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) '#');
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (short) 10);
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 10" + "'", str5.equals("December 10"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61820208000001L) + "'", long6 == (-61820208000001L));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day26.next();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, 0.0d);
//        timeSeriesDataItem8.setValue((java.lang.Number) 8);
//        boolean boolean11 = timeSeries3.equals((java.lang.Object) 8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getFirstMillisecond();
//        int int14 = year12.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
//        long long16 = year12.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9999);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        int int23 = day19.getYear();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.Object obj25 = null;
//        boolean boolean26 = day24.equals(obj25);
//        int int27 = day24.getMonth();
//        java.lang.Class<?> wildcardClass28 = day24.getClass();
//        boolean boolean29 = day19.equals((java.lang.Object) day24);
//        long long30 = day24.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.previous();
//        java.lang.Number number32 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, number32);
//        boolean boolean34 = year12.equals((java.lang.Object) day24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year12.previous();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj8 = timeSeries7.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = day9.equals(obj10);
//        int int12 = day9.getMonth();
//        int int13 = day9.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
//        double double16 = timeSeries7.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, 0.0d);
//        timeSeriesDataItem21.setValue((java.lang.Number) 8);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, 0.0d);
//        timeSeriesDataItem27.setSelected(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        boolean boolean34 = timeSeriesDataItem27.equals((java.lang.Object) fixedMillisecond31);
//        boolean boolean35 = timeSeriesDataItem21.equals((java.lang.Object) timeSeriesDataItem27);
//        java.lang.Object obj36 = null;
//        int int37 = timeSeriesDataItem27.compareTo(obj36);
//        timeSeries17.add(timeSeriesDataItem27, false);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.Object obj41 = null;
//        boolean boolean42 = day40.equals(obj41);
//        int int43 = day40.getMonth();
//        int int44 = day40.getYear();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day45.equals(obj46);
//        int int48 = day45.getMonth();
//        java.lang.Class<?> wildcardClass49 = day45.getClass();
//        boolean boolean50 = day40.equals((java.lang.Object) day45);
//        int int51 = day40.getDayOfMonth();
//        try {
//            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day40, (double) (-1L), true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        try {
            java.lang.Number number6 = timeSeries3.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj9 = timeSeries8.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries8.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = fixedMillisecond18.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 10);
        timeSeries8.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date29 = fixedMillisecond28.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries8.getDataItem(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 32L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        timeSeries3.setRangeDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.lang.Object obj20 = null;
        boolean boolean21 = day19.equals(obj20);
        int int22 = day19.getMonth();
        int int23 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) (-1));
        int int26 = day19.getYear();
        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries3.add(regularTimePeriod16, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        int int65 = day64.getMonth();
        long long66 = day64.getFirstMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-57600000L) + "'", long66 == (-57600000L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDescription("11-June-2019");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day12, seriesChangeInfo13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent14.getSummary();
        boolean boolean16 = timeSeries3.equals((java.lang.Object) seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj21 = timeSeries20.clone();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(seriesChangeInfo15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        int int7 = day4.getMonth();
//        int int8 = day0.compareTo((java.lang.Object) int7);
//        java.lang.String str9 = day0.toString();
//        java.util.Date date10 = day0.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
//        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("December 10");
//        java.lang.String str17 = seriesException16.toString();
//        java.lang.Throwable[] throwableArray18 = seriesException16.getSuppressed();
//        seriesException14.addSuppressed((java.lang.Throwable) seriesException16);
//        int int20 = day12.compareTo((java.lang.Object) seriesException14);
//        org.jfree.data.time.SerialDate serialDate21 = day12.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193199999L + "'", long2 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: December 10" + "'", str17.equals("org.jfree.data.general.SeriesException: December 10"));
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate21);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(2, year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        timeSeries3.delete(regularTimePeriod15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day22.equals(obj23);
//        int int25 = day22.getMonth();
//        int int26 = day22.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        java.lang.String str29 = timeSeries20.getDescription();
//        java.util.List list30 = timeSeries20.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj35 = timeSeries34.clone();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = fixedMillisecond39.compareTo((java.lang.Object) year41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day43.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(12, (int) (short) 10);
//        boolean boolean50 = day43.equals((java.lang.Object) (short) 10);
//        long long51 = day43.getMiddleMillisecond();
//        boolean boolean53 = day43.equals((java.lang.Object) 1L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day43, (double) 9999, false);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Object obj63 = null;
//        boolean boolean64 = day62.equals(obj63);
//        int int65 = day62.getMonth();
//        int int66 = day62.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        double double70 = timeSeries60.getMaxY();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        long long72 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj77 = timeSeries76.clone();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries76.createCopy((int) (byte) 1, 11);
//        java.util.Collection collection81 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries80);
//        boolean boolean82 = timeSeries3.isEmpty();
//        java.lang.Object obj83 = timeSeries3.clone();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(list30);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560193199999L + "'", long51 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-1.0d) + "'", double70 == (-1.0d));
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(collection81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(obj83);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str4 = timePeriodFormatException3.toString();
        java.lang.String str5 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable7 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        timeSeries7.setKey((java.lang.Comparable) 0.0d);
        boolean boolean13 = month2.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date16 = fixedMillisecond15.getStart();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        long long20 = fixedMillisecond15.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 9, false);
        java.lang.String str24 = timeSeries7.getDescription();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) long26);
        java.lang.Object obj28 = timeSeries7.clone();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, 0.0d);
        timeSeriesDataItem32.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        boolean boolean39 = timeSeriesDataItem32.equals((java.lang.Object) fixedMillisecond36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem41.getPeriod();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(2, year44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        int int48 = year44.compareTo((java.lang.Object) day46);
        int int49 = timeSeriesDataItem41.compareTo((java.lang.Object) day46);
        timeSeriesDataItem41.setValue((java.lang.Number) 10);
        java.lang.Number number52 = timeSeriesDataItem41.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem41.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeriesDataItem41.getPeriod();
        timeSeries7.add(timeSeriesDataItem41, true);
        timeSeries7.setMaximumItemAge((long) 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 10 + "'", number52.equals(10));
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 1.0d);
        int int35 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.util.Date date36 = fixedMillisecond32.getTime();
        long long37 = fixedMillisecond32.getSerialIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        int int3 = day0.getMonth();
        int int4 = day0.getYear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        java.lang.Class<?> wildcardClass9 = day5.getClass();
        boolean boolean10 = day0.equals((java.lang.Object) day5);
        java.util.Date date11 = day0.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        int int9 = day5.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
//        java.lang.Class<?> wildcardClass13 = timeSeries3.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day14.equals(obj15);
//        int int17 = day14.getMonth();
//        int int18 = day14.getYear();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Object obj20 = null;
//        boolean boolean21 = day19.equals(obj20);
//        int int22 = day19.getMonth();
//        java.lang.Class<?> wildcardClass23 = day19.getClass();
//        boolean boolean24 = day14.equals((java.lang.Object) day19);
//        long long25 = day19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day19.previous();
//        long long27 = day19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
//        timeSeriesDataItem29.setValue((java.lang.Number) (-1.0f));
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Date date2 = fixedMillisecond1.getStart();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        long long9 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj9 = timeSeries8.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries8.setMaximumItemCount(2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = fixedMillisecond18.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (short) 10);
        timeSeries8.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj31 = timeSeries30.clone();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.lang.Object obj33 = null;
        boolean boolean34 = day32.equals(obj33);
        int int35 = day32.getMonth();
        int int36 = day32.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (double) (-1));
        java.lang.String str39 = timeSeries30.getDescription();
        java.util.List list40 = timeSeries30.getItems();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj45 = timeSeries44.clone();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        int int52 = fixedMillisecond49.compareTo((java.lang.Object) year51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        int int54 = day53.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day53.previous();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) day53);
        java.util.Date date57 = fixedMillisecond49.getTime();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries8.addChangeListener(seriesChangeListener59);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(date57);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj8 = timeSeries7.clone();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Object obj10 = null;
        boolean boolean11 = day9.equals(obj10);
        int int12 = day9.getMonth();
        int int13 = day9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day9, (double) (-1));
        double double16 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries7);
        long long18 = timeSeries17.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day5.equals(obj6);
//        int int8 = day5.getMonth();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        boolean boolean10 = day0.equals((java.lang.Object) day5);
//        long long11 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day5.previous();
//        org.jfree.data.time.SerialDate serialDate13 = day5.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) 0.0d);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, 0.0d);
        timeSeriesDataItem14.setSelected(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        boolean boolean21 = timeSeriesDataItem14.equals((java.lang.Object) fixedMillisecond18);
        java.lang.Object obj22 = timeSeriesDataItem14.clone();
        timeSeries3.add(timeSeriesDataItem14, true);
        int int25 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries9, seriesChangeInfo11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = seriesChangeEvent12.getSummary();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(seriesChangeInfo13);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        timeSeries29.removeAgedItems((long) ' ', false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj6 = timeSeries5.clone();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.createCopy((int) (byte) 1, 11);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.addAndOrUpdate(timeSeries9);
        java.lang.Object obj13 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8, "", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        timeSeries3.setKey((java.lang.Comparable) 0.0d);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        java.lang.Number number14 = timeSeries3.getValue(regularTimePeriod13);
        java.util.List list15 = timeSeries3.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.lang.Object obj6 = null;
        boolean boolean7 = day5.equals(obj6);
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
        java.lang.String str12 = timeSeries3.getDescription();
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj34 = timeSeries33.clone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.lang.Object obj36 = null;
        boolean boolean37 = day35.equals(obj36);
        int int38 = day35.getMonth();
        int int39 = day35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) (-1));
        java.lang.String str42 = timeSeries33.getDescription();
        java.util.List list43 = timeSeries33.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "hi!", "10-June-2019");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) year54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        int int57 = day56.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.previous();
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Date date60 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date60);
        boolean boolean63 = timeSeries3.equals((java.lang.Object) date60);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60);
        java.util.TimeZone timeZone65 = null;
        java.util.Locale locale66 = null;
        try {
            org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date60, timeZone65, locale66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }
}

