import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType3);
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        java.lang.Class<?> wildcardClass6 = intervalMarker2.getClass();
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test05");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
//        java.lang.String str3 = dateTickUnit2.toString();
//        java.lang.String str5 = dateTickUnit2.valueToString((double) (short) 10);
//        java.lang.Class class6 = null;
//        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
//        java.lang.String str10 = dateTickUnit9.toString();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        java.util.Date date15 = dateTickUnit9.addToDate(date12);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date15, timeZone16);
//        java.lang.String str18 = dateTickUnit2.dateToString(date15);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str3.equals("DateTickUnit[HOUR, -457]"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str10.equals("DateTickUnit[HOUR, -457]"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "5/22/19" + "'", str18.equals("5/22/19"));
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMaxRegularValue();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        double double16 = stackedBarRenderer3D14.getMaximumBarWidth();
        stackedBarRenderer3D14.setBaseCreateEntities(false, false);
        boolean boolean20 = boxAndWhiskerItem9.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list12 = defaultStatisticalCategoryDataset11.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        double double16 = ringPlot15.getInnerSeparatorExtension();
        boolean boolean17 = barRenderer3D2.hasListener((java.util.EventListener) ringPlot15);
        ringPlot15.setPieIndex((int) '4');
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer3.setBaseOutlinePaint(paint4);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        lineAndShapeRenderer3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        boolean boolean8 = lineAndShapeRenderer3.getUseFillPaint();
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        lineAndShapeRenderer3.setBaseFillPaint(paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        lineAndShapeRenderer3.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator13, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D18.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer3D18.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D26 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D26.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = null;
        barRenderer3D26.setLegendItemToolTipGenerator(categorySeriesLabelGenerator29);
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint33 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal(paint32, paint33);
        barRenderer3D26.setSeriesItemLabelPaint((int) (byte) 100, paint33, false);
        java.awt.Font font38 = barRenderer3D26.getSeriesItemLabelFont((-1));
        java.awt.Paint paint39 = barRenderer3D26.getWallPaint();
        boolean boolean40 = barRenderer3D18.equals((java.lang.Object) barRenderer3D26);
        java.awt.Stroke stroke42 = barRenderer3D18.getSeriesOutlineStroke(1);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D18.setBaseFillPaint((java.awt.Paint) color43, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator47 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D18.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator47);
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        boolean boolean51 = piePlot50.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator52 = null;
        piePlot50.setLegendLabelToolTipGenerator(pieSectionLabelGenerator52);
        java.awt.Font font54 = piePlot50.getLabelFont();
        java.awt.Paint paint55 = piePlot50.getNoDataMessagePaint();
        java.awt.Paint paint56 = piePlot50.getLabelOutlinePaint();
        barRenderer3D18.setBasePaint(paint56, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent59 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        lineAndShapeRenderer3.notifyListeners(rendererChangeEvent59);
        waferMapPlot0.rendererChanged(rendererChangeEvent59);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint3, (java.awt.Paint) color5, paint6, paint7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        waterfallBarRenderer8.setSeriesItemLabelGenerator((int) (short) 0, categoryItemLabelGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color19 = java.awt.Color.black;
        boolean boolean20 = layer18.equals((java.lang.Object) color19);
        categoryPlot12.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = intervalMarker17.getLabelOffset();
        boolean boolean23 = waterfallBarRenderer8.equals((java.lang.Object) rectangleInsets22);
        double double24 = waterfallBarRenderer8.getLowerClip();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D28.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer3D28.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D36 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D36.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = null;
        barRenderer3D36.setLegendItemToolTipGenerator(categorySeriesLabelGenerator39);
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint43 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean44 = org.jfree.chart.util.PaintUtilities.equal(paint42, paint43);
        barRenderer3D36.setSeriesItemLabelPaint((int) (byte) 100, paint43, false);
        java.awt.Font font48 = barRenderer3D36.getSeriesItemLabelFont((-1));
        java.awt.Paint paint49 = barRenderer3D36.getWallPaint();
        boolean boolean50 = barRenderer3D28.equals((java.lang.Object) barRenderer3D36);
        java.awt.Stroke stroke52 = barRenderer3D28.getSeriesOutlineStroke(1);
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D28.setBaseFillPaint((java.awt.Paint) color53, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator57 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D28.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator57);
        waterfallBarRenderer8.setSeriesToolTipGenerator(3, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator57);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(font48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(stroke52);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list12 = defaultStatisticalCategoryDataset11.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        double double16 = ringPlot15.getInnerSeparatorExtension();
        boolean boolean17 = barRenderer3D2.hasListener((java.util.EventListener) ringPlot15);
        ringPlot15.setSectionDepth(0.0d);
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean22 = org.jfree.chart.util.PaintUtilities.equal(paint20, paint21);
        ringPlot15.setSeparatorPaint(paint20);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setShadowXOffset(0.35d);
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        java.lang.Class class11 = null;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        int int15 = taskSeriesCollection9.getRowIndex((java.lang.Comparable) date12);
        double double16 = piePlot1.getExplodePercent((java.lang.Comparable) int15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double43 = rectangleConstraint42.getWidth();
        org.jfree.data.Range range44 = rectangleConstraint42.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D45 = blockContainer21.arrange(graphics2D41, rectangleConstraint42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint3, (java.awt.Paint) color5, paint6, paint7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        waterfallBarRenderer8.setSeriesItemLabelGenerator((int) (short) 0, categoryItemLabelGenerator10);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = waterfallBarRenderer8.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.getAutoRangeIncludesZero();
        numberAxis14.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis14.java2DToValue((double) (byte) -1, rectangle2D22, rectangleEdge23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list26 = categoryPlot25.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color29 = java.awt.Color.black;
        boolean boolean30 = layer28.equals((java.lang.Object) color29);
        java.util.Collection collection31 = categoryPlot25.getRangeMarkers(layer28);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryPlot25.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot25.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list36 = categoryPlot35.getAnnotations();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        textTitle39.draw(graphics2D40, rectangle2D41);
        textTitle39.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets();
        double double48 = rectangleInsets46.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState51 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo50);
        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo50.getDataArea();
        rectangleInsets46.trim(rectangle2D52);
        textTitle39.draw(graphics2D45, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot56.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = plotRenderingInfo62.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean67 = numberAxis66.getAutoRangeIncludesZero();
        numberAxis66.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState73 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo72);
        java.awt.geom.Rectangle2D rectangle2D74 = plotRenderingInfo72.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = numberAxis66.java2DToValue((double) (byte) -1, rectangle2D74, rectangleEdge75);
        java.awt.geom.Point2D point2D77 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D74);
        categoryPlot56.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo62, point2D77);
        boolean boolean79 = categoryPlot35.render(graphics2D37, rectangle2D52, 7, plotRenderingInfo62);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState80 = waterfallBarRenderer8.initialise(graphics2D13, rectangle2D22, categoryPlot25, (int) (byte) 1, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + Double.NEGATIVE_INFINITY + "'", double76 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Class class2 = null;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        int int6 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) date3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Paint paint26 = barRenderer3D11.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D31.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        barRenderer3D11.setSeriesPositiveItemLabelPosition(8, itemLabelPosition35, false);
        boolean boolean38 = sortOrder8.equals((java.lang.Object) 8);
        categoryPlot0.setColumnRenderingOrder(sortOrder8);
        java.awt.Paint paint40 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint41 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean42 = org.jfree.chart.util.PaintUtilities.equal(paint40, paint41);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset43 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list44 = defaultStatisticalCategoryDataset43.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset43, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint41, (org.jfree.data.general.Dataset) pieDataset46);
        org.jfree.data.general.Dataset dataset48 = datasetChangeEvent47.getDataset();
        categoryPlot0.datasetChanged(datasetChangeEvent47);
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot();
        polarPlot50.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        double double53 = numberAxis52.getFixedAutoRange();
        boolean boolean54 = numberAxis52.isVerticalTickLabels();
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis52.setTickMarkStroke(stroke55);
        polarPlot50.setAngleGridlineStroke(stroke55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        double double59 = numberAxis58.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = numberAxis58.getMarkerBand();
        org.jfree.data.Range range61 = polarPlot50.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis58);
        numberAxis58.setLabel("CategoryAnchor.MIDDLE");
        org.jfree.data.Range range64 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis58);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertNotNull(dataset48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand60);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.lang.Number number24 = null;
        java.util.List list27 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem28 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number24, (java.lang.Number) 3, (java.lang.Number) 100.0d, list27);
        java.lang.Number number29 = boxAndWhiskerItem28.getMinRegularValue();
        boolean boolean30 = jFreeChart14.equals((java.lang.Object) number29);
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart14.getLegend((int) ' ');
        org.jfree.chart.plot.Plot plot33 = jFreeChart14.getPlot();
        jFreeChart14.fireChartChanged();
        org.jfree.chart.event.ChartProgressListener chartProgressListener35 = null;
        jFreeChart14.removeProgressListener(chartProgressListener35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(legendTitle32);
        org.junit.Assert.assertNotNull(plot33);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.gantt.TaskSeries taskSeries2 = null;
        try {
            taskSeriesCollection0.add(taskSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        java.awt.Paint paint6 = minMaxCategoryRenderer0.getGroupPaint();
        java.awt.Stroke stroke7 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D23.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = null;
        barRenderer3D23.setLegendItemToolTipGenerator(categorySeriesLabelGenerator26);
        java.awt.Paint paint29 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint30 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean31 = org.jfree.chart.util.PaintUtilities.equal(paint29, paint30);
        barRenderer3D23.setSeriesItemLabelPaint((int) (byte) 100, paint30, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = null;
        barRenderer3D23.setBaseItemLabelGenerator(categoryItemLabelGenerator34, false);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color37.createContext(colorModel38, rectangle39, rectangle2D40, affineTransform41, renderingHints42);
        barRenderer3D23.setBaseOutlinePaint((java.awt.Paint) color37);
        float[] floatArray49 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray50 = color37.getRGBComponents(floatArray49);
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("ThreadContext", font20, (java.awt.Paint) color37);
        boolean boolean52 = jFreeChart14.equals((java.lang.Object) font20);
        jFreeChart14.clearSubtitles();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }
}

