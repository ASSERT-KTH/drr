import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!", "hi!" };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.0f, 0.0f, 0.0f, (short) 10 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0f, 0.0f, 0.0f, (short) 10 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.0f, 0.0f, 0.0f, (short) 10 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) 100, (-1L), (short) 10, 0.0f, 1.0d, (short) 1 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) 100, (-1L), (short) 10, 0.0f, 1.0d, (short) 1 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (short) 100, (-1L), (short) 10, 0.0f, 1.0d, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (short) 100, (-1L), (short) 10, 0.0f, 1.0d, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (short) 100, (-1L), (short) 10, 0.0f, 1.0d, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray25, numberArray32, numberArray39, numberArray46, numberArray53 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset55 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray2, numberArray18, numberArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 1, (double) 1.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Number[] numberArray1 = new java.lang.Number[] { 10 };
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 10 };
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray1, numberArray3 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 100, (byte) -1, (byte) -1 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 100, (byte) -1, (byte) -1 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray8, numberArray12 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray4, numberArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        java.awt.Stroke stroke5 = null;
        try {
            barRenderer3D2.setBaseStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            barRenderer3D2.drawDomainGridline(graphics2D8, categoryPlot9, rectangle2D10, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        try {
            plot8.zoom((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Comparable comparable4 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 0.25d, (java.lang.Comparable) (-1.0f), comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D2.setSeriesURLGenerator(9, categoryURLGenerator8, true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) (byte) 0, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1, (float) ' ', (float) 10L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D3.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        barRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        barRenderer3D3.setSeriesItemLabelPaint((int) (byte) 100, paint10, false);
        java.awt.Font font15 = barRenderer3D3.getSeriesItemLabelFont((-1));
        barRenderer3D3.setItemLabelAnchorOffset((double) (-1));
        boolean boolean18 = gradientPaintTransformType0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Stroke stroke8 = null;
        try {
            piePlot1.setLabelLinkStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        try {
            barRenderer3D2.setPlot(categoryPlot19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D3.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        barRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        barRenderer3D3.setSeriesItemLabelPaint((int) (byte) 100, paint10, false);
        java.awt.Font font15 = barRenderer3D3.getSeriesItemLabelFont((-1));
        java.awt.Paint paint16 = barRenderer3D3.getWallPaint();
        java.awt.Stroke stroke17 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint16, stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        barRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color18);
        float[] floatArray30 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray31 = color18.getRGBComponents(floatArray30);
        java.awt.Stroke stroke32 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D35.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = null;
        barRenderer3D35.setLegendItemToolTipGenerator(categorySeriesLabelGenerator38);
        java.awt.Paint paint41 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean43 = org.jfree.chart.util.PaintUtilities.equal(paint41, paint42);
        barRenderer3D35.setSeriesItemLabelPaint((int) (byte) 100, paint42, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        barRenderer3D35.setBaseItemLabelGenerator(categoryItemLabelGenerator46, false);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel50 = null;
        java.awt.Rectangle rectangle51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.RenderingHints renderingHints54 = null;
        java.awt.PaintContext paintContext55 = color49.createContext(colorModel50, rectangle51, rectangle2D52, affineTransform53, renderingHints54);
        barRenderer3D35.setBaseOutlinePaint((java.awt.Paint) color49);
        float[] floatArray61 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray62 = color49.getRGBComponents(floatArray61);
        java.awt.Stroke stroke63 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker(100.0d, (double) 7, (java.awt.Paint) color18, stroke32, (java.awt.Paint) color49, stroke63, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paintContext55);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) 0.0d, comparable3, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator18);
        org.jfree.chart.block.Arrangement arrangement20 = null;
        org.jfree.chart.block.Arrangement arrangement21 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer3D2, arrangement20, arrangement21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) (short) 10, (-1.0f), (double) 100L, (float) 5, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        try {
            barRenderer3D2.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot8, categoryAxis9, valueAxis10, categoryDataset11, 0, 3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) -1, 7, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, 0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) shape5);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        boolean boolean3 = barRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            barRenderer3D2.drawBackground(graphics2D4, categoryPlot5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = paintList0.clone();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        try {
            paintList0.setPaint((int) (byte) -1, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        try {
            barRenderer3D5.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, 0.0d);
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape5, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean21 = piePlot20.isCircular();
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean24 = org.jfree.chart.util.PaintUtilities.equal(paint22, paint23);
        piePlot20.setBaseSectionPaint(paint22);
        java.lang.Object obj26 = piePlot20.clone();
        java.awt.Paint paint27 = piePlot20.getBaseSectionPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot1.initialise(graphics2D17, rectangle2D18, piePlot20, (java.lang.Integer) 15, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = null;
        try {
            numberAxis0.setRange(range1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        double double6 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            barRenderer3D2.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis5, rectangle2D7, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) ' ', (double) 100.0f, true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer3D9.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean15 = size2D6.equals((java.lang.Object) barRenderer3D9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer3D9.getNegativeItemLabelPosition((int) (short) 0, (int) (byte) 10);
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            stackedBarRenderer3D3.drawOutline(graphics2D20, categoryPlot21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean11 = piePlot10.isCircular();
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint13 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean14 = org.jfree.chart.util.PaintUtilities.equal(paint12, paint13);
        piePlot10.setBaseSectionPaint(paint12);
        piePlot10.setIgnoreNullValues(false);
        boolean boolean18 = piePlot10.getSectionOutlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo21);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState23 = piePlot1.initialise(graphics2D4, rectangle2D8, piePlot10, (java.lang.Integer) 10, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        stackedBarRenderer3D3.setIncludeBaseInRange(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        double double12 = size2D2.width;
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        piePlot1.setShadowYOffset(10.0d);
        java.awt.Stroke stroke10 = null;
        try {
            piePlot1.setBaseSectionOutlineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer23 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke24 = minMaxCategoryRenderer23.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint22, stroke24);
        barRenderer3D2.setSeriesStroke(15, stroke24);
        java.io.ObjectOutputStream objectOutputStream27 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke24, objectOutputStream27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        boolean boolean14 = barRenderer3D2.isSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer3D2.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState19 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo24);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = barRenderer3D2.initialise(graphics2D16, rectangle2D20, categoryPlot21, 2, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer23 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke24 = minMaxCategoryRenderer23.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint22, stroke24);
        barRenderer3D2.setSeriesStroke(15, stroke24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) (byte) 0, 0.0d);
        barRenderer3D2.setBaseShape(shape28, false);
        try {
            barRenderer3D2.setSeriesItemLabelsVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ThreadContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) (short) 100);
        java.lang.String str3 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str3.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        try {
            intervalMarker2.setLabelOffsetType(lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        java.awt.Paint paint7 = stackedBarRenderer3D3.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        try {
            java.lang.Number number12 = defaultStatisticalCategoryDataset8.getMeanValue(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = minMaxCategoryRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        java.awt.Stroke stroke13 = null;
        barRenderer3D5.setSeriesOutlineStroke(0, stroke13);
        barRenderer3D5.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("ThreadContext", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        double double4 = rectangleInsets0.calculateBottomOutset((double) 0L);
        double double6 = rectangleInsets0.calculateRightOutset((double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer10 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke11 = minMaxCategoryRenderer10.getGroupStroke();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint13);
        minMaxCategoryRenderer10.setSeriesItemLabelPaint(0, paint13);
        stackedBarRenderer3D3.setSeriesOutlinePaint((int) '#', paint13, false);
        double double18 = stackedBarRenderer3D3.getBase();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean6 = stackedBarRenderer3D5.getAutoPopulateSeriesStroke();
        boolean boolean7 = textFragment1.equals((java.lang.Object) boolean6);
        java.awt.Paint paint8 = textFragment1.getPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment1.draw(graphics2D9, (float) 10L, 1.0f, textAnchor12, 100.0f, (float) 9, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 0.0f);
        java.awt.Font font4 = textTitle1.getFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo1.getSubplotInfo((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.lang.Boolean boolean3 = minMaxCategoryRenderer0.getSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[][] doubleArray0 = new double[][] {};
        double[] doubleArray3 = new double[] { (byte) 10, 2 };
        double[] doubleArray6 = new double[] { (byte) 10, 2 };
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray6 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = null;
        try {
            numberAxis3D0.setRangeType(rangeType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean46 = stackedBarRenderer3D45.getAutoPopulateSeriesStroke();
        boolean boolean47 = textFragment41.equals((java.lang.Object) boolean46);
        java.awt.Paint paint48 = textFragment41.getPaint();
        textLine38.addFragment(textFragment41);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        try {
            double double10 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D2.setBaseFillPaint(paint19);
        java.awt.Stroke stroke21 = barRenderer3D2.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.String[] strArray5 = new java.lang.String[] { "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "ThreadContext", "GradientPaintTransformType.CENTER_HORIZONTAL", "({0}, {1}) = {3} - {4}" };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 86400000L, 10.0f, 10.0f, (short) -1, (byte) 1, 10.0f };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray12, numberArray19, numberArray26, numberArray33, numberArray40, numberArray47 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] {};
        java.lang.Number[] numberArray50 = new java.lang.Number[] {};
        java.lang.Number[] numberArray51 = new java.lang.Number[] {};
        java.lang.Number[] numberArray52 = new java.lang.Number[] {};
        java.lang.Number[] numberArray53 = new java.lang.Number[] {};
        java.lang.Number[] numberArray54 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray49, numberArray50, numberArray51, numberArray52, numberArray53, numberArray54 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset56 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray5, numberArray48, numberArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.util.Rotation rotation10 = null;
        try {
            piePlot1.setDirection(rotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        size2D2.width = 0.0d;
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("GradientPaintTransformType.CENTER_HORIZONTAL", graphics2D1, (float) (short) 10, (float) 10L, (double) (short) 10, (float) ' ', 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarkOutsideLength(0.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (byte) 0, 0.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType7 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor6, categoryLabelWidthType7, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 900000L, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) 0);
        java.lang.Comparable comparable8 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) 0.25d, comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesCreateEntities(100);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        columnArrangement4.clear();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.util.List list10 = boxAndWhiskerItem9.getOutliers();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxOutlier();
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = plotRenderingInfo1.getSubplotInfo((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Number[][] numberArray0 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L, 0.35d, 10, (short) 100 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 1L, 0.35d, 10, (short) 100 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray5, numberArray10 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset12 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray0, numberArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        java.awt.Stroke stroke13 = null;
        barRenderer3D5.setSeriesOutlineStroke(0, stroke13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D5.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer0.getLegendItem((int) (byte) 100, 0);
        lineAndShapeRenderer0.setDrawOutlines(false);
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeRow(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        barRenderer3D9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator12);
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint16);
        barRenderer3D9.setSeriesItemLabelPaint((int) (byte) 100, paint16, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer3D9.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        barRenderer3D9.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer30 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke31 = minMaxCategoryRenderer30.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint29, stroke31);
        barRenderer3D9.setSeriesStroke(15, stroke31);
        stackedBarRenderer3D3.setBaseStroke(stroke31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        barRenderer3D2.setBaseCreateEntities(false);
        barRenderer3D2.setSeriesItemLabelsVisible(2, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (double) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean7 = stackedBarRenderer3D6.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D6.setBaseSeriesVisible(false);
        java.awt.Paint paint10 = stackedBarRenderer3D6.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = stackedBarRenderer3D6.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range12, (double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint2.toRangeHeight(range14);
        org.jfree.data.Range range16 = rectangleConstraint2.getHeightRange();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", graphics2D1, 10.0f, (float) 10, textAnchor4, 1.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        double double10 = piePlot8.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot8.getLegendLabelToolTipGenerator();
        java.awt.Font font12 = piePlot8.getLabelFont();
        piePlot8.setShadowXOffset(0.35d);
        boolean boolean15 = piePlot1.equals((java.lang.Object) 0.35d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D3.setDrawBarOutline(false);
        boolean boolean6 = plotOrientation0.equals((java.lang.Object) false);
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("", "", "", image10, "", "", "");
        boolean boolean15 = plotOrientation0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.PaintList paintList43 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj44 = paintList43.clone();
        int int45 = paintList43.size();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean47 = paintList43.equals((java.lang.Object) textBlockAnchor46);
        try {
            java.awt.Shape shape51 = textBlock0.calculateBounds(graphics2D40, (float) (short) 1, (float) 10L, textBlockAnchor46, (float) 1L, (float) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) (-1.0d), (java.lang.Number) (short) 10);
        boolean boolean4 = defaultKeyedValue2.equals((java.lang.Object) 900000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.lang.Comparable comparable4 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 0L, comparable4, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        try {
            textTitle1.setPosition(rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(8, 0, (int) (byte) 1, 10, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint3, (java.awt.Paint) color5, paint6, paint7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D19.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer3D19.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean25 = size2D16.equals((java.lang.Object) barRenderer3D19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = barRenderer3D19.getNegativeItemLabelPosition((int) (short) 0, (int) (byte) 10);
        stackedBarRenderer3D13.setPositiveItemLabelPositionFallback(itemLabelPosition28);
        waterfallBarRenderer8.setSeriesPositiveItemLabelPosition(15, itemLabelPosition28, false);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo34);
        java.awt.Font font37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("", font37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo41.getDataArea();
        textTitle38.draw(graphics2D39, rectangle2D43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        double double48 = numberAxis47.getFixedAutoRange();
        boolean boolean49 = numberAxis47.isVerticalTickLabels();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list51 = defaultStatisticalCategoryDataset50.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset53 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50, (java.lang.Comparable) 0.35d);
        try {
            waterfallBarRenderer8.drawItem(graphics2D32, categoryItemRendererState35, rectangle2D43, categoryPlot45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50, (int) (short) 0, 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(pieDataset53);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment4.draw(graphics2D5, (float) 0, (float) 0, textAnchor8, (float) 8, (float) 15, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke10 = minMaxCategoryRenderer9.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint8, stroke10);
        double double12 = valueMarker11.getValue();
        java.awt.Stroke stroke13 = valueMarker11.getStroke();
        minMaxCategoryRenderer0.setBaseOutlineStroke(stroke13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        double double3 = size2D2.height;
        double double4 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray4 = new double[] { 0.0f, 3.0d, (byte) 0, 12 };
        double[] doubleArray9 = new double[] { 0.0f, 3.0d, (byte) 0, 12 };
        double[] doubleArray14 = new double[] { 0.0f, 3.0d, (byte) 0, 12 };
        double[] doubleArray19 = new double[] { 0.0f, 3.0d, (byte) 0, 12 };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray23, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray25);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray20, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Stroke stroke27 = null;
        try {
            barRenderer3D2.setBaseOutlineStroke(stroke27, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean3 = lineAndShapeRenderer0.getBaseShapesVisible();
        try {
            lineAndShapeRenderer0.setSeriesShapesFilled((-457), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color16.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        barRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color16);
        barRenderer3D2.setAutoPopulateSeriesPaint(false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        double double29 = numberAxis28.getFixedAutoRange();
        numberAxis28.setLabelAngle((double) 0L);
        java.awt.Font font33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("", font33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo37);
        java.awt.geom.Rectangle2D rectangle2D39 = plotRenderingInfo37.getDataArea();
        textTitle34.draw(graphics2D35, rectangle2D39);
        try {
            barRenderer3D2.drawRangeGridline(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis28, rectangle2D39, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 0, (java.lang.Boolean) false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            barRenderer3D2.drawDomainGridline(graphics2D16, categoryPlot17, rectangle2D18, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot12.getDataset();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean20 = numberAxis19.getAutoRangeIncludesZero();
        numberAxis19.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis19.java2DToValue((double) (byte) -1, rectangle2D27, rectangleEdge28);
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D27);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean34 = numberAxis33.getAutoRangeIncludesZero();
        numberAxis33.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState40 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo39.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis33.java2DToValue((double) (byte) -1, rectangle2D41, rectangleEdge42);
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D41);
        org.jfree.chart.plot.PlotState plotState45 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState48 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo47);
        try {
            multiplePiePlot12.draw(graphics2D16, rectangle2D27, point2D44, plotState45, plotRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) paintArray1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (double) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean7 = stackedBarRenderer3D6.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D6.setBaseSeriesVisible(false);
        java.awt.Paint paint10 = stackedBarRenderer3D6.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = stackedBarRenderer3D6.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range12, (double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint2.toRangeHeight(range14);
        java.lang.String str16 = rectangleConstraint15.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]" + "'", str16.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("JFreeChart", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke8 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 100L, stroke8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis3D0.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint3, (java.awt.Paint) color5, paint6, paint7);
        boolean boolean10 = waterfallBarRenderer8.equals((java.lang.Object) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = waterfallBarRenderer8.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        try {
            waterfallBarRenderer8.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(itemLabelPosition11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = minMaxCategoryRenderer0.getSeriesToolTipGenerator(3);
        boolean boolean10 = minMaxCategoryRenderer0.getItemCreateEntity(3, (int) (byte) 10);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = rendererState19.getInfo();
        int int21 = plotRenderingInfo20.getSubplotCount();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = minMaxCategoryRenderer0.initialise(graphics2D11, rectangle2D12, categoryPlot13, 8, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setSeriesVisibleInLegend(3, (java.lang.Boolean) false, true);
        java.awt.Shape shape10 = stackedBarRenderer3D3.getBaseShape();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), (float) (short) 0, (float) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-35) + "'", int3 == (-35));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        boolean boolean6 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 5, (java.lang.Comparable) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot12.getDataset();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        boolean boolean19 = piePlot18.isCircular();
        double double20 = piePlot18.getInteriorGap();
        java.awt.Font font21 = piePlot18.getNoDataMessageFont();
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray24, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font21, (org.jfree.chart.plot.Plot) multiplePiePlot28, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart30.createBufferedImage(5, 9, chartRenderingInfo33);
        jFreeChart30.setAntiAlias(false);
        try {
            multiplePiePlot12.setPieChart(jFreeChart30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.25d + "'", double20 == 0.25d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(bufferedImage34);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        barRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color18);
        float[] floatArray30 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray31 = color18.getRGBComponents(floatArray30);
        try {
            float[] floatArray32 = color0.getComponents(colorSpace1, floatArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot1.addChangeListener(plotChangeListener7);
        piePlot1.setShadowXOffset((double) 100L);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        piePlot12.setBaseSectionPaint(paint14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot12.addChangeListener(plotChangeListener18);
        piePlot12.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D24.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = null;
        barRenderer3D24.setLegendItemToolTipGenerator(categorySeriesLabelGenerator27);
        java.awt.Paint paint30 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint31 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean32 = org.jfree.chart.util.PaintUtilities.equal(paint30, paint31);
        barRenderer3D24.setSeriesItemLabelPaint((int) (byte) 100, paint31, false);
        piePlot12.setBaseSectionOutlinePaint(paint31);
        piePlot1.setShadowPaint(paint31);
        piePlot1.setSectionOutlinesVisible(true);
        piePlot1.setLabelLinkMargin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer3D5.setBaseURLGenerator(categoryURLGenerator12);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextFillPaint();
        barRenderer3D5.setBaseItemLabelPaint(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        projectInfo0.addOptionalLibrary("");
        java.lang.String str5 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Number[] numberArray0 = new java.lang.Number[] {};
        java.lang.Number[] numberArray1 = new java.lang.Number[] {};
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray0, numberArray1, numberArray2, numberArray3, numberArray4, numberArray5 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 3, 0L, 9, 100L, 8, (short) 100 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 3, 0L, 9, 100L, 8, (short) 100 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 3, 0L, 9, 100L, 8, (short) 100 };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray13, numberArray20, numberArray27 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset29 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray6, numberArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        piePlot1.markerChanged(markerChangeEvent5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        try {
            valueMarker4.setAlpha(10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color16.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        barRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color16);
        barRenderer3D2.setAutoPopulateSeriesPaint(false);
        java.awt.Shape shape27 = barRenderer3D2.lookupSeriesShape((int) (byte) -1);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = barRenderer3D2.initialise(graphics2D28, rectangle2D29, categoryPlot30, 2, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isCircular();
        double double5 = piePlot3.getInteriorGap();
        java.awt.Font font6 = piePlot3.getNoDataMessageFont();
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray9, doubleArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font6, (org.jfree.chart.plot.Plot) multiplePiePlot13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("poly", font6, (java.awt.Paint) color16, (float) (byte) -1, textMeasurer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = stackedBarRenderer3D3.getToolTipGenerator((int) (byte) 100, (int) '#');
        boolean boolean13 = stackedBarRenderer3D3.isSeriesVisible(3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.awt.RenderingHints renderingHints19 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        piePlot1.setLabelGap((double) 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("poly");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) '#', 255, (int) (short) 1, (int) (byte) -1, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock5.draw(graphics2D6, (float) (short) -1, (float) 5, textBlockAnchor9);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint22);
        barRenderer3D15.setSeriesItemLabelPaint((int) (byte) 100, paint22, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        barRenderer3D15.setBaseItemLabelGenerator(categoryItemLabelGenerator26, false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color29.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        barRenderer3D15.setBaseOutlinePaint((java.awt.Paint) color29);
        float[] floatArray41 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray42 = color29.getRGBComponents(floatArray41);
        org.jfree.chart.text.TextLine textLine43 = new org.jfree.chart.text.TextLine("ThreadContext", font12, (java.awt.Paint) color29);
        textBlock5.addLine(textLine43);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        boolean boolean48 = piePlot47.isCircular();
        java.awt.Paint paint49 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint50 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean51 = org.jfree.chart.util.PaintUtilities.equal(paint49, paint50);
        piePlot47.setBaseSectionPaint(paint49);
        java.lang.Object obj53 = piePlot47.clone();
        org.jfree.chart.plot.Plot plot54 = piePlot47.getParent();
        java.awt.Font font55 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot47.setLabelFont(font55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = new org.jfree.chart.util.RectangleInsets();
        double double59 = rectangleInsets57.trimHeight((double) 1L);
        java.awt.Paint paint60 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder(rectangleInsets57, paint60);
        piePlot47.setBackgroundPaint(paint60);
        java.awt.Font font63 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean64 = piePlot47.equals((java.lang.Object) font63);
        java.awt.Paint paint65 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint66 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean67 = org.jfree.chart.util.PaintUtilities.equal(paint65, paint66);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset68 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list69 = defaultStatisticalCategoryDataset68.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset71 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset68, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent72 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint66, (org.jfree.data.general.Dataset) pieDataset71);
        textBlock5.addLine("", font63, paint66);
        piePlot1.setLabelPaint(paint66);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-1.0d) + "'", double59 == (-1.0d));
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertNotNull(pieDataset71);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 2, stroke8);
        piePlot1.zoom((double) 9);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot1.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(pieDataset12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.trimHeight((double) 1L);
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, paint22);
        java.awt.Color color24 = java.awt.Color.green;
        java.awt.Paint paint25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint26 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer27 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint22, (java.awt.Paint) color24, paint25, paint26);
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=128,g=128,b=128] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.lang.String str5 = rectangleInsets0.toString();
        double double7 = rectangleInsets0.calculateBottomOutset((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.String str3 = intervalCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelGap((double) 1L);
        try {
            double double4 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLabelAngle((double) 0L);
        java.lang.Object obj4 = numberAxis0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis0.getTickUnit();
        java.lang.String str7 = numberTickUnit5.valueToString((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("PlotOrientation.HORIZONTAL", graphics2D1, (float) 0L, (float) (short) -1, (double) (short) -1, 1.0f, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.trimHeight((double) 1L);
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, paint4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        java.awt.Paint paint7 = blockBorder5.getPaint();
        statisticalBarRenderer0.setErrorIndicatorPaint(paint7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.title.Title title5 = titleChangeEvent4.getTitle();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent4.setType(chartChangeEventType6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(title5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        java.lang.Object obj2 = axisSpace0.clone();
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray5, doubleArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray7);
        boolean boolean9 = axisSpace0.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) (byte) 100, (float) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle4.draw(graphics2D5, rectangle2D6);
        textTitle4.setPadding((double) 10, (double) 1, (double) 0.0f, 0.0d);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState19 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        rectangleInsets14.trim(rectangle2D20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        double double24 = rectangleInsets22.trimHeight((double) 1L);
        java.awt.Paint paint25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets22, paint25);
        java.awt.Paint paint27 = blockBorder26.getPaint();
        boolean boolean29 = blockBorder26.equals((java.lang.Object) 10.0f);
        java.lang.Object obj30 = textTitle4.draw(graphics2D13, rectangle2D20, (java.lang.Object) boolean29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean34 = numberAxis33.getAutoRangeIncludesZero();
        numberAxis33.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState40 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo39.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis33.java2DToValue((double) (byte) -1, rectangle2D41, rectangleEdge42);
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D41);
        org.jfree.chart.plot.PlotState plotState45 = new org.jfree.chart.plot.PlotState();
        java.util.Map map46 = plotState45.getSharedAxisStates();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        boolean boolean50 = piePlot49.isCircular();
        double double51 = piePlot49.getInteriorGap();
        java.awt.Font font52 = piePlot49.getNoDataMessageFont();
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[][] doubleArray57 = new double[][] { doubleArray55, doubleArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray57);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot59 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset58);
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font52, (org.jfree.chart.plot.Plot) multiplePiePlot59, false);
        multiplePiePlot59.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState68 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo67);
        java.awt.geom.Rectangle2D rectangle2D69 = plotRenderingInfo67.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState70 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = rendererState70.getInfo();
        int int72 = plotRenderingInfo71.getSubplotCount();
        multiplePiePlot59.handleClick(12, (int) (byte) 100, plotRenderingInfo71);
        try {
            multiplePiePlot1.draw(graphics2D2, rectangle2D20, point2D44, plotState45, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.NEGATIVE_INFINITY + "'", double43 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(map46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.25d + "'", double51 == 0.25d);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(plotRenderingInfo71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getStartPercent();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        ganttRenderer0.setIncompletePaint(paint6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35d + "'", double1 == 0.35d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean18 = piePlot1.equals((java.lang.Object) font17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot1.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(pieURLGenerator19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str3 = dateTickUnit2.toString();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.TimeZone timeZone6 = null;
        try {
            java.util.Date date7 = dateTickUnit2.rollDate(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str3.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) (byte) 0, (float) 3, textAnchor4, (double) (-1), (float) (-2208960000000L), (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint21 = barRenderer3D2.getSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D25 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = null;
        barRenderer3D25.setLegendItemToolTipGenerator(categorySeriesLabelGenerator28);
        java.awt.Paint paint31 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal(paint31, paint32);
        barRenderer3D25.setSeriesItemLabelPaint((int) (byte) 100, paint32, false);
        barRenderer3D2.setSeriesItemLabelPaint(12, paint32, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ1();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBaseSectionPaint();
        java.lang.Comparable comparable9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        boolean boolean12 = piePlot11.isCircular();
        java.awt.Paint paint13 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal(paint13, paint14);
        piePlot11.setBaseSectionPaint(paint13);
        java.lang.Object obj17 = piePlot11.clone();
        java.awt.Paint paint18 = piePlot11.getBaseSectionPaint();
        try {
            piePlot1.setSectionOutlinePaint(comparable9, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        java.awt.Font font4 = piePlot1.getNoDataMessageFont();
        double double5 = piePlot1.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray31);
        org.jfree.data.Range range33 = barRenderer3D2.findRangeBounds(categoryDataset32);
        double double34 = barRenderer3D2.getItemMargin();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        try {
            java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.setAntiAlias(false);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.getAutoRangeIncludesZero();
        numberAxis22.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis22.java2DToValue((double) (byte) -1, rectangle2D30, rectangleEdge31);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean36 = numberAxis35.getAutoRangeIncludesZero();
        numberAxis35.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo41.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis35.java2DToValue((double) (byte) -1, rectangle2D43, rectangleEdge44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D43);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        try {
            jFreeChart14.draw(graphics2D21, rectangle2D30, point2D46, chartRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.NEGATIVE_INFINITY + "'", double32 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        try {
            java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage(7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (7) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, 0.0f, (float) 86400000L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ItemLabelAnchor.OUTSIDE4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean27 = stackedBarRenderer3D26.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D26.setBaseSeriesVisible(false);
        java.awt.Paint paint30 = stackedBarRenderer3D26.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range32 = stackedBarRenderer3D26.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset31);
        numberAxis0.setRange(range32, true, true);
        boolean boolean36 = numberAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBaseSectionPaint();
        piePlot1.setBackgroundAlpha((float) 0);
        piePlot1.setShadowYOffset((double) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list12 = defaultStatisticalCategoryDataset11.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        double double16 = ringPlot15.getInnerSeparatorExtension();
        boolean boolean17 = barRenderer3D2.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean20 = numberAxis19.getAutoRangeIncludesZero();
        numberAxis19.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis19.java2DToValue((double) (byte) -1, rectangle2D27, rectangleEdge28);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets();
        double double33 = rectangleInsets31.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo35.getDataArea();
        rectangleInsets31.trim(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis19.valueToJava2D((double) 7, rectangle2D37, rectangleEdge39);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement45 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment41, verticalAlignment42, (double) 0.0f, (double) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        boolean boolean48 = piePlot47.isCircular();
        double double49 = piePlot47.getInteriorGap();
        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) horizontalAlignment41, (java.lang.Object) piePlot47);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot piePlot54 = new org.jfree.chart.plot.PiePlot(pieDataset53);
        boolean boolean55 = piePlot54.isCircular();
        double double56 = piePlot54.getInteriorGap();
        java.awt.Font font57 = piePlot54.getNoDataMessageFont();
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray60, doubleArray61 };
        org.jfree.data.category.CategoryDataset categoryDataset63 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray62);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot64 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset63);
        org.jfree.chart.JFreeChart jFreeChart66 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font57, (org.jfree.chart.plot.Plot) multiplePiePlot64, false);
        multiplePiePlot64.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState73 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo72);
        java.awt.geom.Rectangle2D rectangle2D74 = plotRenderingInfo72.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState75 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = rendererState75.getInfo();
        int int77 = plotRenderingInfo76.getSubplotCount();
        multiplePiePlot64.handleClick(12, (int) (byte) 100, plotRenderingInfo76);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState79 = ringPlot15.initialise(graphics2D18, rectangle2D37, piePlot47, (java.lang.Integer) 0, plotRenderingInfo76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.NEGATIVE_INFINITY + "'", double29 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.25d + "'", double49 == 0.25d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.25d + "'", double56 == 0.25d);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(plotRenderingInfo76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        boolean boolean43 = piePlot42.isCircular();
        java.awt.Paint paint44 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint45 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean46 = org.jfree.chart.util.PaintUtilities.equal(paint44, paint45);
        piePlot42.setBaseSectionPaint(paint44);
        java.lang.Object obj48 = piePlot42.clone();
        org.jfree.chart.plot.Plot plot49 = piePlot42.getParent();
        java.awt.Font font50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot42.setLabelFont(font50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets();
        double double54 = rectangleInsets52.trimHeight((double) 1L);
        java.awt.Paint paint55 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets52, paint55);
        piePlot42.setBackgroundPaint(paint55);
        java.awt.Font font58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean59 = piePlot42.equals((java.lang.Object) font58);
        java.awt.Paint paint60 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint61 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean62 = org.jfree.chart.util.PaintUtilities.equal(paint60, paint61);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset63 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list64 = defaultStatisticalCategoryDataset63.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset66 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset63, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint61, (org.jfree.data.general.Dataset) pieDataset66);
        textBlock0.addLine("", font58, paint61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment69 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment70 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement73 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment69, verticalAlignment70, (double) (short) 1, (double) 7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment74 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement77 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment69, verticalAlignment74, 0.0d, 3.0d);
        flowArrangement77.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-1.0d) + "'", double54 == (-1.0d));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNotNull(pieDataset66);
        org.junit.Assert.assertNotNull(horizontalAlignment69);
        org.junit.Assert.assertNotNull(verticalAlignment74);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textBlock0.getLineAlignment();
        org.jfree.chart.text.TextLine textLine41 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(textLine41);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue(3, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        try {
            int int22 = defaultIntervalCategoryDataset20.getRowIndex((java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 1);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) 9);
        int int4 = keyToGroupMap1.getGroupCount();
        java.util.List list5 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        java.awt.Font font20 = barRenderer3D8.getSeriesItemLabelFont((-1));
        java.awt.Paint paint21 = barRenderer3D8.getWallPaint();
        piePlot1.setBaseSectionOutlinePaint(paint21);
        java.lang.String str23 = piePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pie Plot" + "'", str23.equals("Pie Plot"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("DateTickUnit[HOUR, -457]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        try {
            lineAndShapeRenderer2.setPlot(categoryPlot3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 90.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setLicenceName("");
//        java.lang.String str3 = projectInfo0.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart" + "'", str3.equals("JFreeChart"));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean27 = stackedBarRenderer3D26.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D26.setBaseSeriesVisible(false);
        java.awt.Paint paint30 = stackedBarRenderer3D26.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range32 = stackedBarRenderer3D26.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset31);
        numberAxis0.setRange(range32, true, true);
        double double36 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.lang.Object obj3 = piePlot1.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) itemLabelAnchor0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        double double3 = size2D2.height;
        double double4 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer8 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint3, (java.awt.Paint) color5, paint6, paint7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        waterfallBarRenderer8.setSeriesItemLabelGenerator((int) (short) 0, categoryItemLabelGenerator10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean16 = stackedBarRenderer3D15.getAutoPopulateSeriesStroke();
        double double17 = stackedBarRenderer3D15.getMaximumBarWidth();
        java.awt.Paint paint18 = stackedBarRenderer3D15.getBaseFillPaint();
        waterfallBarRenderer8.setPositiveBarPaint(paint18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray2, doubleArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (short) 100, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean7 = stackedBarRenderer3D6.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D6.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint12 = stackedBarRenderer3D6.lookupSeriesOutlinePaint(0);
        boolean boolean13 = meanAndStandardDeviation2.equals((java.lang.Object) paint12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        outlierListCollection0.setHighFarOut(true);
        boolean boolean5 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (double) ' ');
        double double3 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        textTitle6.setMargin(100.0d, (double) 3600000L, (double) 2, (double) (byte) -1);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        java.util.Map map2 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
        org.junit.Assert.assertNotNull(map2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        int int2 = color1.getAlpha();
        java.awt.Color color3 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]", color1);
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray9 = new float[] { (byte) 0, (-35), (short) 10, 1.0f };
        try {
            float[] floatArray10 = color3.getColorComponents(colorSpace4, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        barRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color18);
        float[] floatArray30 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray31 = color18.getRGBComponents(floatArray30);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("ThreadContext", font1, (java.awt.Paint) color18);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D35.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = null;
        barRenderer3D35.setLegendItemToolTipGenerator(categorySeriesLabelGenerator38);
        java.awt.Paint paint41 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean43 = org.jfree.chart.util.PaintUtilities.equal(paint41, paint42);
        barRenderer3D35.setSeriesItemLabelPaint((int) (byte) 100, paint42, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        barRenderer3D35.setBaseItemLabelGenerator(categoryItemLabelGenerator46, false);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel50 = null;
        java.awt.Rectangle rectangle51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.RenderingHints renderingHints54 = null;
        java.awt.PaintContext paintContext55 = color49.createContext(colorModel50, rectangle51, rectangle2D52, affineTransform53, renderingHints54);
        barRenderer3D35.setBaseOutlinePaint((java.awt.Paint) color49);
        float[] floatArray61 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray62 = color49.getRGBComponents(floatArray61);
        float[] floatArray63 = color18.getRGBColorComponents(floatArray62);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paintContext55);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer0.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(1, (java.lang.Boolean) true);
        boolean boolean10 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.clearSubtitles();
        boolean boolean20 = jFreeChart14.isBorderVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        try {
            barRenderer3D2.setSeriesItemLabelsVisible((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart14.getLegend((int) 'a');
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart14.getLegend((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNull(legendTitle20);
        org.junit.Assert.assertNull(legendTitle22);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        try {
            textBlock0.draw(graphics2D41, 0.0f, 0.0f, textBlockAnchor44, 0.0f, (float) (-1), (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (short) 10);
        try {
            java.lang.Comparable comparable6 = defaultStatisticalCategoryDataset0.getColumnKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 900000L, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        piePlot1.setForegroundAlpha((float) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double7 = ganttRenderer6.getStartPercent();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = barRenderer3D10.getBaseItemLabelGenerator();
        java.awt.Paint paint25 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint26 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean27 = org.jfree.chart.util.PaintUtilities.equal(paint25, paint26);
        barRenderer3D10.setSeriesPaint((int) 'a', paint25);
        ganttRenderer6.setIncompletePaint(paint25);
        piePlot1.setLabelOutlinePaint(paint25);
        piePlot1.setExplodePercent((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.35d + "'", double7 == 0.35d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textFragment4.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        double double10 = piePlot8.getInteriorGap();
        java.awt.Font font11 = piePlot8.getNoDataMessageFont();
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray14, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font11, (org.jfree.chart.plot.Plot) multiplePiePlot18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = multiplePiePlot18.getDataset();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot18);
        java.awt.Paint paint23 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal(paint23, paint24);
        boolean boolean26 = valueMarker4.equals((java.lang.Object) boolean25);
        java.lang.Class class27 = null;
        try {
            java.util.EventListener[] eventListenerArray28 = valueMarker4.getListeners(class27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        textTitle42.draw(graphics2D43, rectangle2D44);
        textTitle42.setExpandToFitSpace(true);
        java.awt.Paint paint48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle42.setPaint(paint48);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean54 = stackedBarRenderer3D53.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D53.setBaseSeriesVisible(false);
        blockContainer21.add((org.jfree.chart.block.Block) textTitle42, (java.lang.Object) stackedBarRenderer3D53);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean60 = numberAxis59.getAutoRangeIncludesZero();
        numberAxis59.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo65);
        java.awt.geom.Rectangle2D rectangle2D67 = plotRenderingInfo65.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = numberAxis59.java2DToValue((double) (byte) -1, rectangle2D67, rectangleEdge68);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = new org.jfree.chart.util.RectangleInsets();
        double double73 = rectangleInsets71.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState76 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo75);
        java.awt.geom.Rectangle2D rectangle2D77 = plotRenderingInfo75.getDataArea();
        rectangleInsets71.trim(rectangle2D77);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        double double80 = numberAxis59.valueToJava2D((double) 7, rectangle2D77, rectangleEdge79);
        try {
            blockContainer21.draw(graphics2D58, rectangle2D77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.NEGATIVE_INFINITY + "'", double69 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font3 = intervalMarker2.getLabelFont();
        try {
            intervalMarker2.setAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke18 = null;
        barRenderer3D2.setSeriesOutlineStroke(1, stroke18);
        int int20 = barRenderer3D2.getPassCount();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = barRenderer3D2.getGradientPaintTransformer();
        barRenderer3D2.setSeriesCreateEntities(0, (java.lang.Boolean) false, true);
        barRenderer3D2.setMaximumBarWidth(1.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        multiplePiePlot12.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState23 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = rendererState23.getInfo();
        int int25 = plotRenderingInfo24.getSubplotCount();
        multiplePiePlot12.handleClick(12, (int) (byte) 100, plotRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState27 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo24);
        java.awt.geom.Point2D point2D28 = null;
        try {
            int int29 = plotRenderingInfo24.getSubplotIndex(point2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesLinesVisible((-457));
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        boolean boolean4 = numberAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        rectangleInsets0.trim(rectangle2D6);
        double double9 = rectangleInsets0.trimWidth((double) 900000L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 899998.0d + "'", double9 == 899998.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        java.lang.Comparable[] comparableArray22 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray24 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray25 = null;
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray32, numberArray39 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset41 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray22, (java.lang.Comparable[]) strArray24, numberArray25, numberArray40);
        try {
            defaultIntervalCategoryDataset20.setCategoryKeys((java.lang.Comparable[]) strArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(comparableArray22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        numberAxis0.setFixedDimension(0.0d);
        java.awt.Color color7 = org.jfree.chart.util.PaintUtilities.stringToColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        numberAxis0.setTickLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer0.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(1, (java.lang.Boolean) true);
        org.jfree.chart.LegendItem legendItem12 = lineAndShapeRenderer0.getLegendItem((int) (byte) 1, (int) (short) 100);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        size2D2.width = 1.0f;
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            java.lang.Number number3 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) date1, (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setBaseCreateEntities(false, false);
        boolean boolean9 = stackedBarRenderer3D3.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = ganttRenderer0.getIncompletePaint();
        ganttRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultStatisticalCategoryDataset0.getColumnKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets21.createInsetRectangle(rectangle2D23, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis1.setLowerMargin(0.0d);
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font6);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 90.0d, font6);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 2, stroke8);
        piePlot1.zoom((double) 9);
        piePlot1.setOutlineVisible(false);
        java.awt.Stroke stroke15 = null;
        try {
            piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 1, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to java.lang.Short");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        barRenderer3D5.setLegendItemToolTipGenerator(categorySeriesLabelGenerator8);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal(paint11, paint12);
        barRenderer3D5.setSeriesItemLabelPaint((int) (byte) 100, paint12, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer3D5.setBaseItemLabelGenerator(categoryItemLabelGenerator16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        barRenderer3D5.setBaseOutlinePaint((java.awt.Paint) color19);
        float[] floatArray31 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray32 = color19.getRGBComponents(floatArray31);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("ThreadContext", font2, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment34 = textLine33.getFirstTextFragment();
        java.awt.Font font35 = textFragment34.getFont();
        java.awt.Paint paint37 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke39 = minMaxCategoryRenderer38.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint37, stroke39);
        org.jfree.chart.text.TextAnchor textAnchor41 = valueMarker40.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font45 = intervalMarker44.getLabelFont();
        valueMarker40.setLabelFont(font45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        boolean boolean49 = piePlot48.isCircular();
        double double50 = piePlot48.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator51 = piePlot48.getLegendLabelToolTipGenerator();
        valueMarker40.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot48);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]", font35, (org.jfree.chart.plot.Plot) piePlot48, false);
        piePlot48.setExplodePercent((java.lang.Comparable) 100L, 3.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(textFragment34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.25d + "'", double50 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator51);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        minMaxCategoryRenderer0.setDrawLines(true);
        minMaxCategoryRenderer0.setBaseItemLabelsVisible(true, false);
        int int12 = minMaxCategoryRenderer0.getPassCount();
        boolean boolean14 = minMaxCategoryRenderer0.isSeriesVisible(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0d, shape3, "({0}, {1}) = {3} - {4}", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        java.lang.String str7 = categoryLabelEntity6.getShapeType();
        java.lang.String str8 = categoryLabelEntity6.getURLText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator9 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator10 = null;
        try {
            java.lang.String str11 = categoryLabelEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator9, uRLTagFragmentGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) numberTickUnit14);
        try {
            java.lang.Number number18 = taskSeriesCollection0.getStartValue((int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        java.awt.Paint paint7 = stackedBarRenderer3D3.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range9, (double) 2);
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, (-1.0d), (double) (byte) 0);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(range14);
        java.util.Date date16 = dateRange15.getUpperDate();
        java.util.TimeZone timeZone17 = null;
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinRegularValue();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxOutlier();
        java.lang.Number number12 = boxAndWhiskerItem9.getMinRegularValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        try {
            java.lang.Number number24 = defaultIntervalCategoryDataset20.getValue((java.lang.Comparable) (-457), (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("JFreeChart", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLowerMargin(0.0d);
        double double4 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.util.List list3 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (-1L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        try {
            java.lang.Number number23 = defaultIntervalCategoryDataset20.getStartValue((java.lang.Comparable) 8, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        textTitle1.setWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        int int6 = defaultCategoryDataset5.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getFixedAutoRange();
        numberAxis10.setLabelAngle((double) 0L);
        java.lang.Object obj14 = numberAxis10.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis10.getTickUnit();
        int int16 = taskSeriesCollection8.getRowIndex((java.lang.Comparable) numberTickUnit15);
        defaultCategoryDataset5.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int16, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity21 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) 10L, 0.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 1);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) 9);
        int int4 = keyToGroupMap1.getGroupCount();
        int int6 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint2 = waterfallBarRenderer1.getNegativeBarPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer1.setLastBarPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer5 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke6 = minMaxCategoryRenderer5.getGroupStroke();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint8);
        minMaxCategoryRenderer5.setSeriesItemLabelPaint(0, paint8);
        javax.swing.Icon icon11 = minMaxCategoryRenderer5.getObjectIcon();
        minMaxCategoryRenderer5.setDrawLines(true);
        minMaxCategoryRenderer5.setBaseItemLabelsVisible(true, false);
        java.awt.Stroke stroke17 = minMaxCategoryRenderer5.getBaseStroke();
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Paint paint20 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer21 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke22 = minMaxCategoryRenderer21.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint20, stroke22);
        java.awt.Stroke stroke24 = valueMarker23.getStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 1, (java.awt.Paint) color3, stroke17, (java.awt.Paint) color18, stroke24, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(icon11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        java.awt.Color color9 = java.awt.Color.lightGray;
        stackedBarRenderer3D3.setSeriesFillPaint(5, (java.awt.Paint) color9, true);
        java.awt.Stroke stroke12 = null;
        try {
            stackedBarRenderer3D3.setBaseStroke(stroke12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        piePlot2.setShadowXOffset((double) 100L);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean14 = piePlot13.isCircular();
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint16);
        piePlot13.setBaseSectionPaint(paint15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot13.addChangeListener(plotChangeListener19);
        piePlot13.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D25 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = null;
        barRenderer3D25.setLegendItemToolTipGenerator(categorySeriesLabelGenerator28);
        java.awt.Paint paint31 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal(paint31, paint32);
        barRenderer3D25.setSeriesItemLabelPaint((int) (byte) 100, paint32, false);
        piePlot13.setBaseSectionOutlinePaint(paint32);
        piePlot2.setShadowPaint(paint32);
        boolean boolean38 = dateTickMarkPosition0.equals((java.lang.Object) paint32);
        java.lang.String str39 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTickMarkPosition.END" + "'", str39.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) textTitle6);
        intervalMarker2.setEndValue((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        double double2 = axisSpace0.getRight();
        java.lang.String str3 = axisSpace0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        defaultKeyedValues0.addValue((java.lang.Comparable) date2, (java.lang.Number) 90.0d);
        defaultKeyedValues0.clear();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("First");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean5 = piePlot4.isCircular();
        double double6 = piePlot4.getInteriorGap();
        java.awt.Font font7 = piePlot4.getNoDataMessageFont();
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font7, (org.jfree.chart.plot.Plot) multiplePiePlot14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = multiplePiePlot14.getDataset();
        try {
            java.lang.String str19 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset17, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.25d + "'", double6 == 0.25d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset17);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        boolean boolean23 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str3 = dateTickUnit2.toString();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str7 = dateTickUnit6.toString();
        java.lang.Class class8 = null;
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        java.util.Date date12 = dateTickUnit6.addToDate(date9);
        java.util.TimeZone timeZone13 = null;
        try {
            java.util.Date date14 = dateTickUnit2.addToDate(date9, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str3.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str7.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        try {
            java.lang.Number number24 = defaultIntervalCategoryDataset20.getValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setRenderAsPercentages(false);
        stackedAreaRenderer1.setRenderAsPercentages(true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection7.getRowIndex((java.lang.Comparable) numberTickUnit14);
        defaultCategoryDataset4.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int15, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        categoryItemEntity20.setColumnKey((java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis8.getMarkerBand();
        org.jfree.data.Range range11 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean16 = stackedBarRenderer3D15.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D15.setBaseSeriesVisible(false);
        java.awt.Paint paint19 = stackedBarRenderer3D15.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = stackedBarRenderer3D15.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range21, (double) 2);
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (-1.0d), (double) (byte) 0);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(range26);
        numberAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange27, true, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint9 = stackedBarRenderer3D3.lookupSeriesOutlinePaint(0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list11 = defaultStatisticalCategoryDataset10.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10, (java.lang.Comparable) 0.35d);
        org.jfree.data.Range range14 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot1.setURLGenerator(pieURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis0.getMarkerBand();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        double double8 = ringPlot7.getOuterSeparatorExtension();
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 60000L, (double) (short) 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        boolean boolean23 = numberAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer3D2.getURLGenerator((int) (byte) -1, (int) ' ');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(90.0d, 0.0d, true);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer3D8.setBaseItemLabelGenerator(categoryItemLabelGenerator19, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = color22.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        barRenderer3D8.setBaseOutlinePaint((java.awt.Paint) color22);
        float[] floatArray34 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray35 = color22.getRGBComponents(floatArray34);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("ThreadContext", font5, (java.awt.Paint) color22);
        org.jfree.chart.text.TextFragment textFragment37 = textLine36.getFirstTextFragment();
        java.awt.Font font38 = textFragment37.getFont();
        stackedBarRenderer3D3.setBaseItemLabelFont(font38, true);
        java.awt.Paint paint42 = stackedBarRenderer3D3.lookupSeriesFillPaint((int) 'a');
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(textFragment37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = paintList0.clone();
        int int2 = paintList0.size();
        paintList0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        barRenderer3D2.setBaseCreateEntities(false);
        java.awt.Stroke stroke17 = barRenderer3D2.getItemOutlineStroke((int) (short) 100, (int) (byte) 10);
        boolean boolean18 = barRenderer3D2.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean7 = valueMarker4.equals((java.lang.Object) minMaxCategoryRenderer6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        try {
            valueMarker4.setLabelAnchor(rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(8, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aug" + "'", str2.equals("Aug"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        waterfallBarRenderer0.setBaseURLGenerator(categoryURLGenerator1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis1.java2DToValue((double) (byte) -1, rectangle2D9, rectangleEdge10);
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal(shape0, (java.awt.Shape) rectangle2D9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = ganttRenderer0.getIncompletePaint();
        int int12 = ganttRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        java.awt.Shape shape5 = stackedBarRenderer3D3.lookupSeriesShape((-16777216));
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color16.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        barRenderer3D2.setBaseOutlinePaint((java.awt.Paint) color16);
        barRenderer3D2.setAutoPopulateSeriesPaint(false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke31 = barRenderer3D2.getSeriesOutlineStroke(5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(stroke31);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, (double) (byte) 0, 0.0d);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, 3.0d, (float) 1, (float) 3600000L);
        piePlot1.setLegendItemShape(shape8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot1.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getLabelInsets();
        numberAxis3D0.setTickLabelInsets(rectangleInsets4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        rectangleInsets8.trim(rectangle2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets16.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        rectangleInsets16.trim(rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            org.jfree.chart.axis.AxisState axisState26 = numberAxis3D0.draw(graphics2D6, (double) 10.0f, rectangle2D14, rectangle2D22, rectangleEdge24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = paintList0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = paintList0.equals((java.lang.Object) defaultCategoryDataset2);
        try {
            defaultCategoryDataset2.removeRow((java.lang.Comparable) "({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        boolean boolean3 = textAnchor0.equals((java.lang.Object) defaultStatisticalCategoryDataset1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getAlpha();
        int int2 = color0.getAlpha();
        java.awt.color.ColorSpace colorSpace3 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D6.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        barRenderer3D6.setLegendItemToolTipGenerator(categorySeriesLabelGenerator9);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint13 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean14 = org.jfree.chart.util.PaintUtilities.equal(paint12, paint13);
        barRenderer3D6.setSeriesItemLabelPaint((int) (byte) 100, paint13, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        barRenderer3D6.setBaseItemLabelGenerator(categoryItemLabelGenerator17, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        barRenderer3D6.setBaseOutlinePaint((java.awt.Paint) color20);
        float[] floatArray32 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray33 = color20.getRGBComponents(floatArray32);
        try {
            float[] floatArray34 = color0.getColorComponents(colorSpace3, floatArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLowerMargin(0.0d);
        numberAxis0.setLowerMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        java.lang.Comparable comparable22 = null;
        try {
            java.lang.Number number23 = defaultIntervalCategoryDataset20.getStartValue((java.lang.Comparable) "JFreeChart", comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.awt.Image image9 = null;
        projectInfo7.setLogo(image9);
        java.awt.Image image11 = projectInfo7.getLogo();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowCount();
        double double7 = defaultStatisticalCategoryDataset0.getRangeUpperBound(true);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str3 = dateTickUnit2.toString();
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        java.util.Date date8 = dateTickUnit2.addToDate(date5);
        int int9 = dateTickUnit2.getRollCount();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str3.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-457) + "'", int9 == (-457));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-35), (java.lang.Number) 0.0f, (java.lang.Comparable) (-2208960000000L), (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        java.lang.Number number12 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100.0d, (java.lang.Comparable) "Other");
        try {
            java.lang.Comparable comparable14 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        barRenderer3D2.setBaseCreateEntities(false);
        java.awt.Stroke stroke17 = barRenderer3D2.getItemOutlineStroke((int) (short) 100, (int) (byte) 10);
        java.awt.Paint paint19 = barRenderer3D2.getSeriesOutlinePaint((int) (short) -1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot4.getSeparatorStroke();
        ringPlot4.setShadowXOffset(0.05d);
        double double9 = ringPlot4.getOuterSeparatorExtension();
        boolean boolean10 = ringPlot4.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean3 = numberAxis2.getAutoRangeIncludesZero();
        numberAxis2.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo8.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis2.java2DToValue((double) (byte) -1, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.getAutoRangeIncludesZero();
        numberAxis15.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis15.java2DToValue((double) (byte) -1, rectangle2D23, rectangleEdge24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D23);
        org.jfree.chart.plot.PlotState plotState27 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        try {
            piePlot3D0.draw(graphics2D1, rectangle2D10, point2D26, plotState27, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.NEGATIVE_INFINITY + "'", double25 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D26);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        java.util.Iterator iterator1 = outlierListCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getPadding();
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        java.lang.Object obj2 = axisSpace0.clone();
        java.lang.String str3 = axisSpace0.toString();
        java.lang.Object obj4 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 10.0d, 1.0d, 7, (java.lang.Comparable) "JFreeChart");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot4.getSeparatorStroke();
        ringPlot4.setShadowXOffset(0.05d);
        double double9 = ringPlot4.getOuterSeparatorExtension();
        ringPlot4.setSectionDepth((double) (byte) 0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        double double8 = rectangleInsets6.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        numberAxis0.setLabelInsets(rectangleInsets6);
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        numberAxis0.setTickLabelFont(font11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        try {
            barRenderer3D2.setSeriesItemLabelsVisible((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.getAutoRangeIncludesZero();
        numberAxis8.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis8.java2DToValue((double) (byte) -1, rectangle2D16, rectangleEdge17);
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean22 = piePlot21.isCircular();
        java.awt.Paint paint23 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal(paint23, paint24);
        piePlot21.setBaseSectionPaint(paint23);
        java.lang.Object obj27 = piePlot21.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState33 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo30);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState34 = ringPlot4.initialise(graphics2D5, rectangle2D16, piePlot21, (java.lang.Integer) (-457), plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Paint paint0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D3.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        barRenderer3D3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator6);
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        barRenderer3D3.setSeriesItemLabelPaint((int) (byte) 100, paint10, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator14, false);
        barRenderer3D3.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint23 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer24 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke25 = minMaxCategoryRenderer24.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint23, stroke25);
        barRenderer3D3.setSeriesStroke(15, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double30 = rectangleInsets28.trimHeight((double) 1L);
        java.awt.Paint paint31 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, paint31);
        java.lang.String str33 = rectangleInsets28.toString();
        try {
            org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder(paint0, stroke25, rectangleInsets28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str33.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        paintList0.clear();
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot1.addChangeListener(plotChangeListener7);
        piePlot1.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        barRenderer3D13.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint19, paint20);
        barRenderer3D13.setSeriesItemLabelPaint((int) (byte) 100, paint20, false);
        piePlot1.setBaseSectionOutlinePaint(paint20);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        boolean boolean27 = piePlot26.isCircular();
        java.awt.Paint paint28 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint29 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal(paint28, paint29);
        piePlot26.setBaseSectionPaint(paint28);
        java.awt.Paint paint32 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot26.setLabelPaint(paint32);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot26.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator34);
        piePlot1.setMinimumArcAngleToDraw((double) (-1L));
        java.awt.Stroke stroke38 = piePlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (short) 100, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        double double10 = piePlot8.getInteriorGap();
        java.awt.Font font11 = piePlot8.getNoDataMessageFont();
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray14, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font11, (org.jfree.chart.plot.Plot) multiplePiePlot18, false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = multiplePiePlot18.getDataset();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot18);
        java.lang.String str23 = multiplePiePlot18.getPlotType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Multiple Pie Plot" + "'", str23.equals("Multiple Pie Plot"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer0.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = lineAndShapeRenderer0.getToolTipGenerator((-16777216), (int) (byte) -1);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((int) (byte) -1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("#00c000", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = '4';
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 100, (float) (byte) -1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLabelAngle((double) 0L);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis0.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean21 = stackedBarRenderer3D20.getAutoPopulateSeriesStroke();
        boolean boolean22 = textFragment16.equals((java.lang.Object) boolean21);
        boolean boolean23 = barRenderer3D2.equals((java.lang.Object) textFragment16);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D28.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = null;
        barRenderer3D28.setLegendItemToolTipGenerator(categorySeriesLabelGenerator31);
        java.awt.Paint paint34 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean36 = org.jfree.chart.util.PaintUtilities.equal(paint34, paint35);
        barRenderer3D28.setSeriesItemLabelPaint((int) (byte) 100, paint35, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = null;
        barRenderer3D28.setBaseItemLabelGenerator(categoryItemLabelGenerator39, false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color42.createContext(colorModel43, rectangle44, rectangle2D45, affineTransform46, renderingHints47);
        barRenderer3D28.setBaseOutlinePaint((java.awt.Paint) color42);
        float[] floatArray54 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray55 = color42.getRGBComponents(floatArray54);
        org.jfree.chart.text.TextLine textLine56 = new org.jfree.chart.text.TextLine("ThreadContext", font25, (java.awt.Paint) color42);
        barRenderer3D2.setBaseItemLabelFont(font25);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator18);
        barRenderer3D2.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        boolean boolean23 = barRenderer3D2.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean29 = numberAxis28.getAutoRangeIncludesZero();
        numberAxis28.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo34.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = numberAxis28.java2DToValue((double) (byte) -1, rectangle2D36, rectangleEdge37);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState45 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo44.getDataArea();
        rectangleInsets40.trim(rectangle2D46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = numberAxis28.valueToJava2D((double) 7, rectangle2D46, rectangleEdge48);
        try {
            barRenderer3D2.drawDomainMarker(graphics2D24, categoryPlot25, categoryAxis26, categoryMarker27, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setNegativeArrowVisible(true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, (double) (byte) 0, 0.0d);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, 3.0d, (float) 1, (float) 3600000L);
        piePlot1.setLegendItemShape(shape8);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        boolean boolean18 = piePlot17.isCircular();
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint19, paint20);
        piePlot17.setBaseSectionPaint(paint19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        piePlot17.addChangeListener(plotChangeListener23);
        piePlot17.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D29 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D29.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = null;
        barRenderer3D29.setLegendItemToolTipGenerator(categorySeriesLabelGenerator32);
        java.awt.Paint paint35 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint36 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean37 = org.jfree.chart.util.PaintUtilities.equal(paint35, paint36);
        barRenderer3D29.setSeriesItemLabelPaint((int) (byte) 100, paint36, false);
        piePlot17.setBaseSectionOutlinePaint(paint36);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        boolean boolean43 = piePlot42.isCircular();
        java.awt.Paint paint44 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint45 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean46 = org.jfree.chart.util.PaintUtilities.equal(paint44, paint45);
        piePlot42.setBaseSectionPaint(paint44);
        java.awt.Paint paint48 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot42.setLabelPaint(paint48);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = piePlot42.getLegendLabelGenerator();
        piePlot17.setLegendLabelGenerator(pieSectionLabelGenerator50);
        piePlot1.setLabelGenerator(pieSectionLabelGenerator50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = stackedAreaRenderer1.getSeriesURLGenerator(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            org.jfree.data.Range range5 = stackedAreaRenderer1.findRangeBounds(categoryDataset4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) numberTickUnit14);
        try {
            java.lang.Number number18 = taskSeriesCollection0.getPercentComplete(8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        boolean boolean5 = textBlock3.equals((java.lang.Object) paint4);
        org.jfree.chart.util.PaintList paintList6 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj7 = paintList6.clone();
        int int8 = paintList6.size();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean10 = paintList6.equals((java.lang.Object) textBlockAnchor9);
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick13 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) dateTickUnit2, textBlock3, textBlockAnchor9, textAnchor11, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean10 = numberAxis9.getAutoRangeIncludesZero();
        numberAxis9.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo15.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis9.java2DToValue((double) (byte) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D17);
        lineBorder5.draw(graphics2D6, rectangle2D17);
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder5);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D25 = textTitle1.arrange(graphics2D23, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis0.java2DToValue((double) (byte) -1, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis0.setMarkerBand(markerAxisBand11);
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isCircular();
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal(paint5, paint6);
        piePlot3.setBaseSectionPaint(paint5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot3.addChangeListener(plotChangeListener9);
        java.awt.Paint paint11 = piePlot3.getLabelOutlinePaint();
        minMaxCategoryRenderer0.setGroupPaint(paint11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        boolean boolean3 = lineAndShapeRenderer2.getUseOutlinePaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        lineAndShapeRenderer2.setSeriesStroke(0, stroke5, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator31 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D2.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator31);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection33 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection33);
        taskSeriesCollection33.removeAll();
        try {
            java.lang.String str37 = intervalCategoryToolTipGenerator31.generateRowLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection33, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator30);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset((double) 0.5f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean7 = blockBorder4.equals((java.lang.Object) paint6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Multiple Pie Plot", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        lineAndShapeRenderer0.setBaseFillPaint(paint6, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list11 = categoryPlot10.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis13.setLowerMargin(0.0d);
        int int16 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        double double25 = numberAxis24.getFixedAutoRange();
        boolean boolean26 = numberAxis24.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis24.refreshTicks(graphics2D27, axisState28, rectangle2D32, rectangleEdge33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis19.getCategoryEnd((int) (byte) -1, 0, rectangle2D32, rectangleEdge35);
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D9, categoryPlot10, categoryAxis13, categoryMarker17, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator18);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D22.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = null;
        barRenderer3D22.setLegendItemToolTipGenerator(categorySeriesLabelGenerator25);
        java.awt.Paint paint28 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint29 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal(paint28, paint29);
        barRenderer3D22.setSeriesItemLabelPaint((int) (byte) 100, paint29, false);
        java.awt.Font font34 = barRenderer3D22.getSeriesItemLabelFont((-1));
        barRenderer3D22.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke38 = null;
        barRenderer3D22.setSeriesOutlineStroke(1, stroke38);
        int int40 = barRenderer3D22.getPassCount();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = barRenderer3D22.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D44 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D44.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator47 = null;
        barRenderer3D44.setLegendItemToolTipGenerator(categorySeriesLabelGenerator47);
        java.awt.Paint paint50 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint51 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean52 = org.jfree.chart.util.PaintUtilities.equal(paint50, paint51);
        barRenderer3D44.setSeriesItemLabelPaint((int) (byte) 100, paint51, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = null;
        barRenderer3D44.setBaseItemLabelGenerator(categoryItemLabelGenerator55);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator57 = barRenderer3D44.getBaseItemLabelGenerator();
        java.awt.Paint paint59 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint60 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean61 = org.jfree.chart.util.PaintUtilities.equal(paint59, paint60);
        barRenderer3D44.setSeriesPaint((int) 'a', paint59);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition64 = barRenderer3D44.getSeriesNegativeItemLabelPosition((-1));
        barRenderer3D22.setBasePositiveItemLabelPosition(itemLabelPosition64, true);
        barRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition64);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(font34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer41);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition64);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        try {
            defaultIntervalCategoryDataset20.setEndValue((int) (byte) 0, (java.lang.Comparable) "First", (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = areaRenderer0.getItemLabelGenerator(1, (-1));
        java.awt.Stroke stroke5 = areaRenderer0.getSeriesOutlineStroke(0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) textTitle6);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer8);
        double double10 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.lang.Comparable comparable9 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart11.getPadding();
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart11.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        textTitle42.draw(graphics2D43, rectangle2D44);
        textTitle42.setExpandToFitSpace(true);
        java.awt.Paint paint48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle42.setPaint(paint48);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean54 = stackedBarRenderer3D53.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D53.setBaseSeriesVisible(false);
        blockContainer21.add((org.jfree.chart.block.Block) textTitle42, (java.lang.Object) stackedBarRenderer3D53);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets();
        double double60 = rectangleInsets58.trimHeight((double) 1L);
        java.awt.Paint paint61 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder62 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, paint61);
        java.awt.Paint paint63 = blockBorder62.getPaint();
        blockContainer21.setFrame((org.jfree.chart.block.BlockFrame) blockBorder62);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.plot.Plot plot15 = jFreeChart14.getPlot();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart14.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setItemMargin((double) 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.Range range10 = defaultStatisticalCategoryDataset7.getRangeBounds(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.trimHeight((double) 1L);
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder9);
        double double12 = textTitle2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryAnchor.MIDDLE", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.trimHeight((double) 1L);
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder9);
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle2.getBounds();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean6 = stackedBarRenderer3D5.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D5.setBaseSeriesVisible(false);
        java.awt.Paint paint9 = stackedBarRenderer3D5.getBasePaint();
        numberAxis3D1.setTickLabelPaint(paint9);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        barRenderer3D13.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint19, paint20);
        barRenderer3D13.setSeriesItemLabelPaint((int) (byte) 100, paint20, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        barRenderer3D13.setBaseItemLabelGenerator(categoryItemLabelGenerator24);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = barRenderer3D13.getBaseItemLabelGenerator();
        java.awt.Paint paint28 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint29 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean30 = org.jfree.chart.util.PaintUtilities.equal(paint28, paint29);
        barRenderer3D13.setSeriesPaint((int) 'a', paint28);
        numberAxis3D1.setTickLabelPaint(paint28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str4 = dateTickUnit3.toString();
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Date date9 = dateTickUnit3.addToDate(date6);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone10);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker14.setStartValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = intervalMarker14.getLabelOffset();
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) date9, (java.lang.Object) rectangleInsets17);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D21.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = null;
        barRenderer3D21.setLegendItemToolTipGenerator(categorySeriesLabelGenerator24);
        java.awt.Paint paint27 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint28 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal(paint27, paint28);
        barRenderer3D21.setSeriesItemLabelPaint((int) (byte) 100, paint28, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
        barRenderer3D21.setBaseItemLabelGenerator(categoryItemLabelGenerator32, false);
        barRenderer3D21.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint41 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke43 = minMaxCategoryRenderer42.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint41, stroke43);
        barRenderer3D21.setSeriesStroke(15, stroke43);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape47, rectangleAnchor48, (double) (byte) 0, 0.0d);
        barRenderer3D21.setBaseShape(shape47, false);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.clone(shape47);
        boolean boolean55 = rectangleInsets17.equals((java.lang.Object) shape47);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str4.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D5.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean11 = size2D2.equals((java.lang.Object) barRenderer3D5);
        java.awt.Stroke stroke13 = null;
        barRenderer3D5.setSeriesOutlineStroke(0, stroke13);
        java.awt.Paint paint15 = null;
        try {
            barRenderer3D5.setBaseOutlinePaint(paint15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

