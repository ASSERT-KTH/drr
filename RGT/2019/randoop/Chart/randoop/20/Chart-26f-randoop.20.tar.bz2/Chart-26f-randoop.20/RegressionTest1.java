import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setItemMargin((double) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer8.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem13 = lineAndShapeRenderer8.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer8.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition(0, itemLabelPosition14);
        stackedBarRenderer3D3.setMinimumBarLength(0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        try {
            numberAxis0.setRange((double) (short) 0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getHeight();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        textTitle8.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle8.getMargin();
        boolean boolean12 = lineAndShapeRenderer6.equals((java.lang.Object) rectangleInsets11);
        textTitle1.setMargin(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        multiplePiePlot12.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        java.lang.String str17 = multiplePiePlot12.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset18 = multiplePiePlot12.getDataset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Multiple Pie Plot" + "'", str17.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.addCornerTextItem("First");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.getAutoRangeIncludesZero();
        numberAxis10.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis10.java2DToValue((double) (byte) -1, rectangle2D18, rectangleEdge19);
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D18);
        categoryPlot0.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo6, point2D21);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D21);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot1.removeChangeListener(plotChangeListener6);
        boolean boolean8 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean18 = piePlot1.equals((java.lang.Object) font17);
        piePlot1.setShadowXOffset((double) 0.0f);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isCircular();
        double double25 = piePlot23.getInteriorGap();
        java.awt.Font font26 = piePlot23.getNoDataMessageFont();
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font26, (org.jfree.chart.plot.Plot) multiplePiePlot33, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart35.createBufferedImage(5, 9, chartRenderingInfo38);
        java.lang.Number number45 = null;
        java.util.List list48 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem49 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number45, (java.lang.Number) 3, (java.lang.Number) 100.0d, list48);
        java.lang.Number number50 = boxAndWhiskerItem49.getMinRegularValue();
        boolean boolean51 = jFreeChart35.equals((java.lang.Object) number50);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator53 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator53);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.25d + "'", double25 == 0.25d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(bufferedImage39);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.0d + "'", number50.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str4 = dateTickUnit3.toString();
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Date date9 = dateTickUnit3.addToDate(date6);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone10);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker14.setStartValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = intervalMarker14.getLabelOffset();
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) date9, (java.lang.Object) rectangleInsets17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis20.setLowerMargin(0.0d);
        keyedObject18.setObject((java.lang.Object) categoryAxis20);
        categoryAxis20.setCategoryLabelPositionOffset(15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str4.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (double) ' ');
        java.lang.String str3 = rectangleConstraint2.toString();
        double double4 = rectangleConstraint2.getHeight();
        java.lang.String str5 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 2, stroke8);
        piePlot1.zoom((double) 9);
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(drawingSupplier14);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.lang.String str6 = textTitle1.getID();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isCircular();
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal(paint5, paint6);
        piePlot3.setBaseSectionPaint(paint5);
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setLabelPaint(paint9);
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) piePlot3);
        try {
            defaultCategoryDataset0.removeRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(100.0d, (double) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean7 = stackedBarRenderer3D6.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D6.setBaseSeriesVisible(false);
        java.awt.Paint paint10 = stackedBarRenderer3D6.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = stackedBarRenderer3D6.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range12, (double) 2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint2.toRangeHeight(range14);
        double double16 = range14.getLength();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list3 = categoryPlot2.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            lineRenderer3D0.drawDomainGridline(graphics2D1, categoryPlot2, rectangle2D5, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        int int3 = color2.getAlpha();
        java.awt.Color color4 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]", color2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer6 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint7 = waterfallBarRenderer6.getNegativeBarPaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer6.setLastBarPaint((java.awt.Paint) color8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        boolean boolean12 = piePlot11.isCircular();
        java.awt.Paint paint13 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal(paint13, paint14);
        piePlot11.setBaseSectionPaint(paint13);
        java.lang.Object obj17 = piePlot11.clone();
        org.jfree.chart.plot.Plot plot18 = piePlot11.getParent();
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot11.setLabelFont(font19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.trimHeight((double) 1L);
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, paint24);
        piePlot11.setBackgroundPaint(paint24);
        java.awt.Font font27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean28 = piePlot11.equals((java.lang.Object) font27);
        piePlot11.setExplodePercent((java.lang.Comparable) true, (double) 1L);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot11.setLabelOutlineStroke(stroke32);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 2.0f, (java.awt.Paint) color2, stroke5, (java.awt.Paint) color8, stroke32, (float) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) (byte) 100, 32.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getFixedAutoRange();
        boolean boolean7 = numberAxis5.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = numberAxis5.refreshTicks(graphics2D8, axisState9, rectangle2D13, rectangleEdge14);
        textTitle2.setBounds(rectangle2D13);
        java.lang.Object obj17 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        int int3 = taskSeriesCollection0.getRowCount();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = waterfallBarRenderer0.getItemLabelGenerator((-1), (int) (byte) -1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.setAntiAlias(false);
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart14.createBufferedImage(15, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (15) and height (-35) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-16777216", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(90.0d, 0.0d, true);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        barRenderer3D9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator12);
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint16);
        barRenderer3D9.setSeriesItemLabelPaint((int) (byte) 100, paint16, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer3D9.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        barRenderer3D9.setBaseOutlinePaint((java.awt.Paint) color23);
        float[] floatArray35 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray36 = color23.getRGBComponents(floatArray35);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("ThreadContext", font6, (java.awt.Paint) color23);
        org.jfree.chart.text.TextFragment textFragment38 = textLine37.getFirstTextFragment();
        java.awt.Font font39 = textFragment38.getFont();
        stackedBarRenderer3D4.setBaseItemLabelFont(font39, true);
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("PlotOrientation.HORIZONTAL", font39);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float45 = textFragment42.calculateBaselineOffset(graphics2D43, textAnchor44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(textFragment38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(textAnchor44);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean8 = stackedBarRenderer3D7.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D7.setBaseSeriesVisible(false);
        java.awt.Paint paint11 = stackedBarRenderer3D7.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range13 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range13, (double) 2);
        numberAxis0.setRangeWithMargins(range13);
        double double17 = numberAxis0.getLowerMargin();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        boolean boolean20 = piePlot19.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = null;
        piePlot19.setLegendLabelToolTipGenerator(pieSectionLabelGenerator21);
        java.awt.Font font23 = piePlot19.getLabelFont();
        java.awt.Paint paint24 = piePlot19.getNoDataMessagePaint();
        java.awt.Paint paint25 = piePlot19.getLabelOutlinePaint();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot19.setSectionOutlineStroke((java.lang.Comparable) Double.NaN, stroke27);
        boolean boolean29 = numberAxis0.hasListener((java.util.EventListener) piePlot19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getLicenceText();
        projectInfo7.setName("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        multiplePiePlot12.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        java.lang.String str17 = multiplePiePlot12.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot12);
        try {
            org.jfree.chart.title.Title title20 = jFreeChart18.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Multiple Pie Plot" + "'", str17.equals("Multiple Pie Plot"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot4.getSeparatorStroke();
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color1 = java.awt.Color.getColor("-16777216");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        boolean boolean43 = piePlot42.isCircular();
        java.awt.Paint paint44 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint45 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean46 = org.jfree.chart.util.PaintUtilities.equal(paint44, paint45);
        piePlot42.setBaseSectionPaint(paint44);
        java.lang.Object obj48 = piePlot42.clone();
        org.jfree.chart.plot.Plot plot49 = piePlot42.getParent();
        java.awt.Font font50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot42.setLabelFont(font50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets();
        double double54 = rectangleInsets52.trimHeight((double) 1L);
        java.awt.Paint paint55 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets52, paint55);
        piePlot42.setBackgroundPaint(paint55);
        java.awt.Font font58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean59 = piePlot42.equals((java.lang.Object) font58);
        java.awt.Paint paint60 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint61 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean62 = org.jfree.chart.util.PaintUtilities.equal(paint60, paint61);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset63 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list64 = defaultStatisticalCategoryDataset63.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset66 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset63, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint61, (org.jfree.data.general.Dataset) pieDataset66);
        textBlock0.addLine("", font58, paint61);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor72 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            textBlock0.draw(graphics2D69, (float) (-1L), (float) 12, textBlockAnchor72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-1.0d) + "'", double54 == (-1.0d));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNotNull(pieDataset66);
        org.junit.Assert.assertNotNull(textBlockAnchor72);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, (double) (byte) 0, 0.0d);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, 3.0d, (float) 1, (float) 3600000L);
        piePlot1.setLegendItemShape(shape8);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        textTitle5.draw(graphics2D6, rectangle2D7);
        textTitle5.setPadding((double) 10, (double) 1, (double) 0.0f, 0.0d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        rectangleInsets15.trim(rectangle2D21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        double double25 = rectangleInsets23.trimHeight((double) 1L);
        java.awt.Paint paint26 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, paint26);
        java.awt.Paint paint28 = blockBorder27.getPaint();
        boolean boolean30 = blockBorder27.equals((java.lang.Object) 10.0f);
        java.lang.Object obj31 = textTitle5.draw(graphics2D14, rectangle2D21, (java.lang.Object) boolean30);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer32 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke33 = minMaxCategoryRenderer32.getGroupStroke();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint35);
        minMaxCategoryRenderer32.setSeriesItemLabelPaint(0, paint35);
        java.awt.Paint paint38 = minMaxCategoryRenderer32.getGroupPaint();
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        boolean boolean41 = piePlot40.isCircular();
        double double42 = piePlot40.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator43 = piePlot40.getLegendLabelToolTipGenerator();
        java.awt.Font font44 = piePlot40.getLabelFont();
        piePlot40.setShadowXOffset(0.35d);
        org.jfree.chart.plot.Plot plot47 = null;
        piePlot40.setParent(plot47);
        java.awt.Stroke stroke49 = piePlot40.getLabelLinkStroke();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer50 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot piePlot52 = new org.jfree.chart.plot.PiePlot(pieDataset51);
        boolean boolean53 = piePlot52.isCircular();
        java.awt.Paint paint54 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint55 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean56 = org.jfree.chart.util.PaintUtilities.equal(paint54, paint55);
        piePlot52.setBaseSectionPaint(paint54);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        piePlot52.addChangeListener(plotChangeListener58);
        boolean boolean60 = ganttRenderer50.equals((java.lang.Object) plotChangeListener58);
        java.awt.Paint paint61 = ganttRenderer50.getIncompletePaint();
        try {
            org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem(attributedString0, "PlotOrientation.HORIZONTAL", "#00c000", "PlotOrientation.HORIZONTAL", (java.awt.Shape) rectangle2D21, paint38, stroke49, paint61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.25d + "'", double42 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        boolean boolean8 = polarPlot0.isDomainZoomable();
        java.awt.Paint paint9 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, (double) 12, 0.0d, 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 2, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        boolean boolean2 = outlierListCollection0.isHighFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable3 = keyToGroupMap1.getGroup((java.lang.Comparable) (byte) 1);
        int int5 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot8.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Font font12 = piePlot8.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint22);
        barRenderer3D15.setSeriesItemLabelPaint((int) (byte) 100, paint22, false);
        java.awt.Font font27 = barRenderer3D15.getSeriesItemLabelFont((-1));
        java.awt.Paint paint28 = barRenderer3D15.getWallPaint();
        piePlot8.setBaseSectionOutlinePaint(paint28);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color31 = java.awt.Color.pink;
        java.awt.Color color32 = color31.brighter();
        piePlot8.setSectionPaint((java.lang.Comparable) date30, (java.awt.Paint) color32);
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 100.0d, (java.lang.Comparable) date30);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (byte) 1 + "'", comparable3.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setMaximumLabelWidth(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        polarPlot5.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        double double8 = numberAxis7.getFixedAutoRange();
        boolean boolean9 = numberAxis7.isVerticalTickLabels();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis7.setTickMarkStroke(stroke10);
        polarPlot5.setAngleGridlineStroke(stroke10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis13.getMarkerBand();
        org.jfree.data.Range range16 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        boolean boolean17 = columnArrangement4.equals((java.lang.Object) polarPlot5);
        java.awt.Paint paint18 = polarPlot5.getRadiusGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer19.setBaseOutlinePaint(paint20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        boolean boolean23 = lineAndShapeRenderer19.equals((java.lang.Object) color22);
        polarPlot5.setRadiusGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = barRenderer3D2.getItemLabelGenerator(255, (int) 'a');
        java.lang.Boolean boolean24 = barRenderer3D2.getSeriesVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Paint paint26 = barRenderer3D11.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D31.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        barRenderer3D11.setSeriesPositiveItemLabelPosition(8, itemLabelPosition35, false);
        boolean boolean38 = sortOrder8.equals((java.lang.Object) 8);
        categoryPlot0.setColumnRenderingOrder(sortOrder8);
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        double double41 = axisSpace40.getBottom();
        double double42 = axisSpace40.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace40);
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list46 = categoryPlot45.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot45.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color49 = java.awt.Color.black;
        boolean boolean50 = layer48.equals((java.lang.Object) color49);
        java.util.Collection collection51 = categoryPlot45.getRangeMarkers(layer48);
        try {
            categoryPlot0.addDomainMarker(categoryMarker44, layer48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(collection51);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3600000L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        barRenderer3D2.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, true);
        java.awt.Paint paint22 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer23 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke24 = minMaxCategoryRenderer23.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint22, stroke24);
        barRenderer3D2.setSeriesStroke(15, stroke24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) (byte) 0, 0.0d);
        barRenderer3D2.setBaseShape(shape28, false);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.clone(shape28);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape35, "GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        int int3 = taskSeriesCollection0.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup4 = null;
        try {
            taskSeriesCollection0.setGroup(datasetGroup4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "", "", "");
        projectInfo7.addOptionalLibrary("DateTickMarkPosition.END");
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        int int17 = piePlot1.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Paint paint6 = ringPlot4.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset(0.05d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis0.setRangeWithMargins(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 15;
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor13, (double) (byte) 0, 0.0d);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, 3.0d, (float) 1, (float) 3600000L);
        numberAxis0.setDownArrow(shape16);
        boolean boolean22 = numberAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        double double10 = piePlot8.getInteriorGap();
        java.awt.Font font11 = piePlot8.getNoDataMessageFont();
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray14, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font11, (org.jfree.chart.plot.Plot) multiplePiePlot18, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart20.createBufferedImage(5, 9, chartRenderingInfo23);
        jFreeChart20.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart20.addProgressListener(chartProgressListener27);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) range5, jFreeChart20, (-16777216), (int) '#');
        int int32 = chartProgressEvent31.getPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        try {
            defaultIntervalCategoryDataset20.setEndValue((int) (short) 0, (java.lang.Comparable) year23, (java.lang.Number) 899998.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            int int4 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        java.util.List list23 = defaultIntervalCategoryDataset20.getColumnKeys();
        try {
            java.lang.Comparable comparable25 = defaultIntervalCategoryDataset20.getSeriesKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke18 = null;
        barRenderer3D2.setSeriesOutlineStroke(1, stroke18);
        int int20 = barRenderer3D2.getPassCount();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = barRenderer3D2.getGradientPaintTransformer();
        double double22 = barRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        java.awt.Paint paint7 = stackedBarRenderer3D3.getBasePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) (-1.0d), (java.lang.Number) (short) 10);
        java.lang.Object obj3 = defaultKeyedValue2.clone();
        java.lang.Comparable comparable4 = defaultKeyedValue2.getKey();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
        numberAxis3D1.resizeRange((double) 900000L, 1.0E-5d);
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        numberAxis3D1.setAxisLinePaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLabelAngle((double) 0L);
        java.lang.Object obj4 = numberAxis0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis0.getTickUnit();
        java.lang.String str7 = numberTickUnit5.valueToString((double) (short) 1);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getFixedAutoRange();
        numberAxis8.setLabelAngle((double) 0L);
        java.lang.Object obj12 = numberAxis8.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis8.getTickUnit();
        java.lang.String str15 = numberTickUnit13.valueToString((double) (short) 1);
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] { numberTickUnit5, (short) 1, 255, "First", "poly", "org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]" };
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths(false);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[][] doubleArray27 = new double[][] { doubleArray23, doubleArray24, doubleArray25, doubleArray26 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray20, (java.lang.Comparable[]) strArray22, doubleArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection7.getRowIndex((java.lang.Comparable) numberTickUnit14);
        defaultCategoryDataset4.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int15, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        java.lang.Comparable comparable22 = categoryItemEntity20.getRowKey();
        java.lang.Comparable comparable23 = categoryItemEntity20.getColumnKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable21.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable22.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (byte) 0 + "'", comparable23.equals((byte) 0));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        polarPlot11.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getFixedAutoRange();
        boolean boolean15 = numberAxis13.isVerticalTickLabels();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis13.setTickMarkStroke(stroke16);
        polarPlot11.setAngleGridlineStroke(stroke16);
        barRenderer3D2.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        int int20 = polarPlot11.getSeriesCount();
        polarPlot11.addCornerTextItem("DateTickUnit[HOUR, -457]");
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setSeriesVisibleInLegend(3, (java.lang.Boolean) false, true);
        java.lang.Object obj10 = null;
        boolean boolean11 = stackedBarRenderer3D3.equals(obj10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        int int1 = areaRenderer0.getPassCount();
        java.awt.Paint paint4 = areaRenderer0.getItemPaint((-457), (-457));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        barRenderer3D4.setBaseOutlinePaint((java.awt.Paint) color18);
        float[] floatArray30 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray31 = color18.getRGBComponents(floatArray30);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("ThreadContext", font1, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment33 = textLine32.getFirstTextFragment();
        java.awt.Paint paint34 = textFragment33.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(textFragment33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        float float11 = valueMarker4.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.lang.Comparable comparable9 = multiplePiePlot8.getAggregatedItemsKey();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Pie Plot", font1, (org.jfree.chart.plot.Plot) multiplePiePlot8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart11.getPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart11.createBufferedImage((int) (short) -1, 5, (double) 10L, (double) 100, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (5) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0d, shape3, "({0}, {1}) = {3} - {4}", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        java.lang.String str7 = categoryLabelEntity6.getShapeType();
        categoryLabelEntity6.setURLText("ItemLabelAnchor.OUTSIDE4");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        try {
            java.lang.String str12 = categoryLabelEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        textTitle2.draw(graphics2D3, rectangle2D7);
        java.awt.Paint paint9 = textTitle2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) numberTickUnit14);
        java.lang.Comparable comparable17 = null;
        try {
            java.lang.Number number18 = taskSeriesCollection0.getValue((java.lang.Comparable) 32.0d, comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        polarPlot11.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getFixedAutoRange();
        boolean boolean15 = numberAxis13.isVerticalTickLabels();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis13.setTickMarkStroke(stroke16);
        polarPlot11.setAngleGridlineStroke(stroke16);
        barRenderer3D2.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Stroke stroke20 = null;
        polarPlot11.setAngleGridlineStroke(stroke20);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = lineAndShapeRenderer0.getDrawingSupplier();
        lineAndShapeRenderer0.setSeriesShapesVisible(12, false);
        org.junit.Assert.assertNull(drawingSupplier3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setBaseSeriesVisible(false);
        java.awt.Paint paint7 = stackedBarRenderer3D3.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range9, (double) 2);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range9, (double) 3, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        try {
            java.lang.Number number12 = taskSeriesCollection0.getEndValue(2, (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 900000L, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) 0);
        java.util.List list6 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.String str1 = numberAxis3D0.getLabelToolTip();
        boolean boolean2 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        java.awt.Font font6 = stackedBarRenderer3D3.getSeriesItemLabelFont(3);
        stackedBarRenderer3D3.setBaseCreateEntities(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean18 = numberAxis17.getAutoRangeIncludesZero();
        numberAxis17.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState24 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo23.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis17.java2DToValue((double) (byte) -1, rectangle2D25, rectangleEdge26);
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D25);
        lineBorder13.draw(graphics2D14, rectangle2D25);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D25, (double) 0L, (float) 255, (float) (short) 1);
        try {
            stackedBarRenderer3D3.drawDomainGridline(graphics2D9, categoryPlot10, rectangle2D25, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(font6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        projectInfo0.setName("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot8.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Font font12 = piePlot8.getLabelFont();
        int int13 = piePlot8.getBackgroundImageAlignment();
        java.awt.Paint paint14 = piePlot8.getBaseSectionPaint();
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "9-April-1900", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]", "DateTickUnit[HOUR, -457]", shape4, (java.awt.Paint) color5, stroke6, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean46 = stackedBarRenderer3D45.getAutoPopulateSeriesStroke();
        boolean boolean47 = textFragment41.equals((java.lang.Object) boolean46);
        textLine38.addFragment(textFragment41);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setTickLabelFont(font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer0.getNegativeItemLabelPosition(255, (int) (byte) 100);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot1.addChangeListener(plotChangeListener7);
        piePlot1.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        barRenderer3D13.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint19, paint20);
        barRenderer3D13.setSeriesItemLabelPaint((int) (byte) 100, paint20, false);
        piePlot1.setBaseSectionOutlinePaint(paint20);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        boolean boolean28 = piePlot27.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = null;
        piePlot27.setLegendLabelToolTipGenerator(pieSectionLabelGenerator29);
        java.awt.Font font31 = piePlot27.getLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer33.setBaseOutlinePaint(paint34);
        piePlot27.setSectionPaint((java.lang.Comparable) 86400000L, paint34);
        piePlot1.setSectionPaint((java.lang.Comparable) (byte) 0, paint34);
        double double38 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0E-5d + "'", double38 == 1.0E-5d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        barRenderer3D2.setItemMargin((double) 10L);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator21, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean5 = unitType3.equals((java.lang.Object) lengthAdjustmentType4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean8 = piePlot7.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        piePlot7.setLegendLabelToolTipGenerator(pieSectionLabelGenerator9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot7.getLegendLabelGenerator();
        boolean boolean12 = unitType3.equals((java.lang.Object) pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean5 = stackedBarRenderer3D4.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D4.setBaseSeriesVisible(false);
        java.awt.Paint paint8 = stackedBarRenderer3D4.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = stackedBarRenderer3D4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range10, (double) 2);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (-1.0d), (double) (byte) 0);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(range15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) (-2208960000000L), (org.jfree.data.Range) dateRange16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean8 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, 9);
        java.lang.String str9 = spreadsheetDate3.getDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        size2D2.setWidth((double) 3600000L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis0.getLabelInsets();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray7, doubleArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray9);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getAggregatedItemsPaint();
        numberAxis0.setLabelPaint(paint12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.Object obj2 = null;
        boolean boolean3 = textFragment1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setLabelGap((double) 1L);
        piePlot1.setLabelLinksVisible(true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0d, shape3, "({0}, {1}) = {3} - {4}", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        java.lang.String str7 = categoryLabelEntity6.getShapeType();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean9 = categoryLabelEntity6.equals((java.lang.Object) color8);
        java.lang.String str10 = categoryLabelEntity6.getShapeType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.addValue((java.lang.Number) 100.0f, (java.lang.Comparable) "hi!", (java.lang.Comparable) "DateTickUnit[HOUR, -457]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ItemLabelAnchor.OUTSIDE4");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Paint paint19 = barRenderer3D4.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean25 = stackedBarRenderer3D24.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D24.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D24.getBaseNegativeItemLabelPosition();
        barRenderer3D4.setSeriesPositiveItemLabelPosition(8, itemLabelPosition28, false);
        boolean boolean31 = sortOrder1.equals((java.lang.Object) 8);
        defaultKeyedValues0.sortByValues(sortOrder1);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues33 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list34 = defaultKeyedValues33.getKeys();
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        defaultKeyedValues33.addValue((java.lang.Comparable) date35, (java.lang.Number) 90.0d);
        org.jfree.chart.util.SortOrder sortOrder38 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues33.sortByValues(sortOrder38);
        defaultKeyedValues0.sortByKeys(sortOrder38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        defaultKeyedValues0.setValue((java.lang.Comparable) year41, (double) 7);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(sortOrder38);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = rendererState14.getInfo();
        categoryPlot0.handleClick((int) '4', 2958465, plotRenderingInfo15);
        java.lang.Object obj17 = plotRenderingInfo15.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("", font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        textTitle18.draw(graphics2D19, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean36 = numberAxis35.getAutoRangeIncludesZero();
        numberAxis35.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo41.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis35.java2DToValue((double) (byte) -1, rectangle2D43, rectangleEdge44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D43);
        categoryPlot25.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo31, point2D46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        try {
            jFreeChart14.draw(graphics2D15, rectangle2D23, point2D46, chartRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + Double.NEGATIVE_INFINITY + "'", double45 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        double double10 = piePlot8.getInteriorGap();
        java.awt.Font font11 = piePlot8.getNoDataMessageFont();
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray14, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font11, (org.jfree.chart.plot.Plot) multiplePiePlot18, false);
        multiplePiePlot18.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        java.awt.Paint paint23 = multiplePiePlot18.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateBottomInset((double) 0L);
        double double28 = rectangleInsets24.trimHeight((double) 1);
        double double30 = rectangleInsets24.extendWidth((double) (byte) 1);
        multiplePiePlot18.setInsets(rectangleInsets24);
        valueMarker4.setLabelOffset(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.25d + "'", double10 == 0.25d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("1", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
        numberAxis3D1.resizeRange((double) 900000L, 1.0E-5d);
        double double5 = numberAxis3D1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.trimHeight((double) 1L);
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint8);
        java.awt.Color color10 = java.awt.Color.green;
        java.awt.Paint paint11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint12 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer13 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint8, (java.awt.Paint) color10, paint11, paint12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D24.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer3D24.getPositiveItemLabelPosition(0, (int) ' ');
        boolean boolean30 = size2D21.equals((java.lang.Object) barRenderer3D24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer3D24.getNegativeItemLabelPosition((int) (short) 0, (int) (byte) 10);
        stackedBarRenderer3D18.setPositiveItemLabelPositionFallback(itemLabelPosition33);
        waterfallBarRenderer13.setSeriesPositiveItemLabelPosition(15, itemLabelPosition33, false);
        org.jfree.chart.text.TextAnchor textAnchor37 = itemLabelPosition33.getRotationAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition33, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(textAnchor37);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator31 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D2.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator31);
        java.lang.Object obj33 = intervalCategoryToolTipGenerator31.clone();
        java.lang.String str34 = intervalCategoryToolTipGenerator31.getLabelFormat();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str34.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.lang.Number number24 = null;
        java.util.List list27 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem28 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number24, (java.lang.Number) 3, (java.lang.Number) 100.0d, list27);
        java.lang.Number number29 = boxAndWhiskerItem28.getMinRegularValue();
        boolean boolean30 = jFreeChart14.equals((java.lang.Object) number29);
        java.awt.Color color31 = java.awt.Color.darkGray;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.Plot plot33 = jFreeChart14.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(plot33);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer3D2.getBaseItemLabelGenerator();
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D2.setSeriesPaint((int) 'a', paint17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer3D2.getSeriesNegativeItemLabelPosition((-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D2.setSeriesURLGenerator((int) (byte) 0, categoryURLGenerator24, false);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = barRenderer3D2.getLegendItems();
        java.lang.Object obj28 = legendItemCollection27.clone();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer3D2.getURLGenerator((int) (byte) -1, (int) ' ');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = barRenderer3D2.getSeriesToolTipGenerator(2958465);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        boolean boolean4 = numberAxis0.isVisible();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        numberAxis0.setRange((org.jfree.data.Range) dateRange5, true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D2.setBaseFillPaint(paint19);
        barRenderer3D2.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D27 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D27.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer3D27.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D35.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = null;
        barRenderer3D35.setLegendItemToolTipGenerator(categorySeriesLabelGenerator38);
        java.awt.Paint paint41 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean43 = org.jfree.chart.util.PaintUtilities.equal(paint41, paint42);
        barRenderer3D35.setSeriesItemLabelPaint((int) (byte) 100, paint42, false);
        java.awt.Font font47 = barRenderer3D35.getSeriesItemLabelFont((-1));
        java.awt.Paint paint48 = barRenderer3D35.getWallPaint();
        boolean boolean49 = barRenderer3D27.equals((java.lang.Object) barRenderer3D35);
        java.awt.Stroke stroke51 = barRenderer3D27.getSeriesOutlineStroke(1);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D27.setBaseFillPaint((java.awt.Paint) color52, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator56 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D27.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator56);
        java.lang.Object obj58 = intervalCategoryToolTipGenerator56.clone();
        barRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator56, false);
        java.lang.String str61 = intervalCategoryToolTipGenerator56.getLabelFormat();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(font47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str61.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        boolean boolean4 = piePlot1.equals((java.lang.Object) 100L);
        boolean boolean5 = piePlot1.isSubplot();
        piePlot1.setExplodePercent((java.lang.Comparable) (byte) 100, (double) 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Paint paint19 = barRenderer3D4.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean25 = stackedBarRenderer3D24.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D24.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D24.getBaseNegativeItemLabelPosition();
        barRenderer3D4.setSeriesPositiveItemLabelPosition(8, itemLabelPosition28, false);
        boolean boolean31 = sortOrder1.equals((java.lang.Object) 8);
        defaultKeyedValues0.sortByValues(sortOrder1);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues33 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list34 = defaultKeyedValues33.getKeys();
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        defaultKeyedValues33.addValue((java.lang.Comparable) date35, (java.lang.Number) 90.0d);
        org.jfree.chart.util.SortOrder sortOrder38 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues33.sortByValues(sortOrder38);
        defaultKeyedValues0.sortByKeys(sortOrder38);
        int int41 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D2.setBaseFillPaint(paint19);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor21);
        barRenderer3D2.notifyListeners(rendererChangeEvent22);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textAnchor21);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) (short) 10, 3.0d);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        int int16 = defaultCategoryDataset15.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection18 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        double double21 = numberAxis20.getFixedAutoRange();
        numberAxis20.setLabelAngle((double) 0L);
        java.lang.Object obj24 = numberAxis20.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = numberAxis20.getTickUnit();
        int int26 = taskSeriesCollection18.getRowIndex((java.lang.Comparable) numberTickUnit25);
        defaultCategoryDataset15.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int26, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity31 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        numberAxis0.setLeftArrow(shape12);
        boolean boolean33 = numberAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        double double14 = piePlot12.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot12.getLegendLabelToolTipGenerator();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot12);
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke20 = minMaxCategoryRenderer19.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint18, stroke20);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer23 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean24 = valueMarker21.equals((java.lang.Object) minMaxCategoryRenderer23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker21);
        valueMarker4.notifyListeners(markerChangeEvent25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25d + "'", double14 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        java.lang.Comparable[] comparableArray24 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray27 = null;
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray34, numberArray41 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset43 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray24, (java.lang.Comparable[]) strArray26, numberArray27, numberArray42);
        try {
            defaultIntervalCategoryDataset20.setCategoryKeys(comparableArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(comparableArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        double double9 = numberAxis8.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis8.getMarkerBand();
        org.jfree.data.Range range11 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        java.lang.String str12 = numberAxis8.getLabelToolTip();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font16 = intervalMarker15.getLabelFont();
        numberAxis8.setTickLabelFont(font16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        barRenderer3D2.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getFixedAutoRange();
        boolean boolean7 = numberAxis5.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = numberAxis5.refreshTicks(graphics2D8, axisState9, rectangle2D13, rectangleEdge14);
        textTitle2.setBounds(rectangle2D13);
        java.awt.Paint paint17 = textTitle2.getBackgroundPaint();
        java.lang.Object obj18 = textTitle2.clone();
        boolean boolean19 = textTitle2.getNotify();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = ganttRenderer0.getIncompletePaint();
        ganttRenderer0.setEndPercent((double) (short) 0);
        java.lang.Boolean boolean15 = ganttRenderer0.getSeriesItemLabelsVisible((int) (short) 100);
        boolean boolean18 = ganttRenderer0.getItemVisible((-1), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isCircular();
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal(paint5, paint6);
        piePlot3.setBaseSectionPaint(paint5);
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setLabelPaint(paint9);
        boolean boolean11 = defaultCategoryDataset0.equals((java.lang.Object) piePlot3);
        java.util.List list12 = defaultCategoryDataset0.getColumnKeys();
        int int14 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-35));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = null;
        piePlot12.setLegendLabelToolTipGenerator(pieSectionLabelGenerator14);
        java.awt.Font font16 = piePlot12.getLabelFont();
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBaseSectionPaint();
        piePlot1.setBackgroundAlpha((float) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getStartValue((int) (short) 100, (int) (short) -1, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean8 = textLine6.equals((java.lang.Object) shape7);
        textBlock0.addLine(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = minMaxCategoryRenderer0.getSeriesToolTipGenerator(3);
        boolean boolean10 = minMaxCategoryRenderer0.getItemCreateEntity(3, (int) (byte) 10);
        javax.swing.Icon icon11 = minMaxCategoryRenderer0.getMinIcon();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        minMaxCategoryRenderer0.setBaseOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(icon11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        polarPlot1.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getFixedAutoRange();
        boolean boolean5 = numberAxis3.isVerticalTickLabels();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis3.setTickMarkStroke(stroke6);
        polarPlot1.setAngleGridlineStroke(stroke6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis9.getMarkerBand();
        org.jfree.data.Range range12 = polarPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer13);
        java.lang.Object obj15 = polarPlot14.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint3 = waterfallBarRenderer2.getNegativeBarPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        waterfallBarRenderer2.setLastBarPaint((java.awt.Paint) color4);
        boolean boolean6 = axisLocation0.equals((java.lang.Object) waterfallBarRenderer2);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        textTitle6.setURLText("JFreeChart");
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart14.addProgressListener(chartProgressListener21);
        jFreeChart14.setBackgroundImageAlpha((float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setRange((double) 7, (double) 100);
        boolean boolean5 = numberAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint4);
        barRenderer3D2.setSeriesOutlinePaint((int) '4', paint4);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot8.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Font font12 = piePlot8.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint22);
        barRenderer3D15.setSeriesItemLabelPaint((int) (byte) 100, paint22, false);
        java.awt.Font font27 = barRenderer3D15.getSeriesItemLabelFont((-1));
        java.awt.Paint paint28 = barRenderer3D15.getWallPaint();
        piePlot8.setBaseSectionOutlinePaint(paint28);
        barRenderer3D2.setBaseFillPaint(paint28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        barRenderer3D2.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator32);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 2, stroke8);
        piePlot1.zoom((double) 9);
        piePlot1.setOutlineVisible(false);
        java.awt.Paint paint14 = piePlot1.getOutlinePaint();
        boolean boolean15 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        java.awt.Stroke stroke6 = valueMarker4.getStroke();
        java.lang.Object obj7 = valueMarker4.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker4.getLabelAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        double double3 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Font font5 = piePlot1.getLabelFont();
        piePlot1.setShadowXOffset(0.35d);
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setToolTipText("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list6 = categoryPlot5.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color9 = java.awt.Color.black;
        boolean boolean10 = layer8.equals((java.lang.Object) color9);
        java.util.Collection collection11 = categoryPlot5.getRangeMarkers(layer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot5.getAxisOffset();
        textTitle2.setPadding(rectangleInsets12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot4.getSeparatorStroke();
        ringPlot4.setShadowXOffset(0.05d);
        double double9 = ringPlot4.getOuterSeparatorExtension();
        ringPlot4.setMaximumLabelWidth((double) (byte) 100);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.GENERAL");
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.lang.Object obj22 = blockContainer21.clone();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        java.lang.Class class28 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str32 = dateTickUnit31.toString();
        java.lang.Class class33 = null;
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        java.util.Date date37 = dateTickUnit31.addToDate(date34);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date37, timeZone38);
        try {
            java.lang.Object obj40 = blockContainer21.draw(graphics2D23, rectangle2D27, (java.lang.Object) regularTimePeriod39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str32.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (short) 100, 1.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean7 = stackedBarRenderer3D6.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D6.setBaseSeriesVisible(false);
        java.awt.Paint paint10 = stackedBarRenderer3D6.getBasePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = stackedBarRenderer3D6.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range12, (double) 2);
        boolean boolean15 = meanAndStandardDeviation2.equals((java.lang.Object) 2);
        boolean boolean17 = meanAndStandardDeviation2.equals((java.lang.Object) 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer3D2.getBaseItemLabelGenerator();
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D2.setSeriesPaint((int) 'a', paint17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer3D2.getSeriesNegativeItemLabelPosition((-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer3D2.setSeriesURLGenerator((int) (byte) 0, categoryURLGenerator24, false);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = barRenderer3D2.getLegendItems();
        int int28 = legendItemCollection27.getItemCount();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 12, (double) 3, (double) '#', (double) 100L);
        numberAxis0.setLabelInsets(rectangleInsets21);
        numberAxis0.setTickMarkOutsideLength((float) ' ');
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        textTitle28.draw(graphics2D29, rectangle2D30);
        textTitle28.setPadding((double) 10, (double) 1, (double) 0.0f, 0.0d);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        double double40 = rectangleInsets38.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        rectangleInsets38.trim(rectangle2D44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets();
        double double48 = rectangleInsets46.trimHeight((double) 1L);
        java.awt.Paint paint49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder(rectangleInsets46, paint49);
        java.awt.Paint paint51 = blockBorder50.getPaint();
        boolean boolean53 = blockBorder50.equals((java.lang.Object) 10.0f);
        java.lang.Object obj54 = textTitle28.draw(graphics2D37, rectangle2D44, (java.lang.Object) boolean53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list56 = numberAxis0.refreshTicks(graphics2D25, axisState26, rectangle2D44, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(obj54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        boolean boolean7 = minMaxCategoryRenderer0.getBaseCreateEntities();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        polarPlot9.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        double double12 = numberAxis11.getFixedAutoRange();
        boolean boolean13 = numberAxis11.isVerticalTickLabels();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis11.setTickMarkStroke(stroke14);
        polarPlot9.setAngleGridlineStroke(stroke14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        double double18 = numberAxis17.getFixedAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = numberAxis17.getMarkerBand();
        org.jfree.data.Range range20 = polarPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis17, polarItemRenderer21);
        org.jfree.data.xy.XYDataset xYDataset23 = polarPlot22.getDataset();
        minMaxCategoryRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot22);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        polarPlot22.setAngleGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart");
        textTitle1.setPadding((-1.0d), (double) 3600000L, (double) 7, (double) 60000L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        int int23 = defaultIntervalCategoryDataset20.getCategoryCount();
        try {
            org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        textTitle42.draw(graphics2D43, rectangle2D44);
        textTitle42.setExpandToFitSpace(true);
        java.awt.Paint paint48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        textTitle42.setPaint(paint48);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean54 = stackedBarRenderer3D53.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D53.setBaseSeriesVisible(false);
        blockContainer21.add((org.jfree.chart.block.Block) textTitle42, (java.lang.Object) stackedBarRenderer3D53);
        java.lang.Object obj58 = null;
        boolean boolean59 = blockContainer21.equals(obj58);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list2 = defaultStatisticalCategoryDataset1.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]", (org.jfree.chart.plot.Plot) ringPlot5);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        textTitle7.draw(graphics2D8, rectangle2D12);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle7, (java.lang.Object) "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.Arrangement arrangement22 = blockContainer21.getArrangement();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = blockContainer21.arrange(graphics2D23);
        double double25 = size2D24.getHeight();
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrangement22);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getAlpha();
        java.awt.Color color5 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]", color3);
        java.awt.Color color6 = color3.darker();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        piePlot8.setBaseSectionPaint(paint10);
        java.lang.Object obj14 = piePlot8.clone();
        piePlot8.setShadowYOffset(10.0d);
        java.awt.Stroke stroke17 = piePlot8.getLabelLinkStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean22 = stackedBarRenderer3D21.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D21.setBaseSeriesVisible(false);
        java.awt.Paint paint25 = stackedBarRenderer3D21.getBasePaint();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) year0, (java.awt.Paint) color3, stroke17, paint25, stroke26, (float) (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock1.draw(graphics2D2, (float) (short) -1, (float) 5, textBlockAnchor5);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        barRenderer3D11.setBaseOutlinePaint((java.awt.Paint) color25);
        float[] floatArray37 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray38 = color25.getRGBComponents(floatArray37);
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("ThreadContext", font8, (java.awt.Paint) color25);
        textBlock1.addLine(textLine39);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        boolean boolean44 = piePlot43.isCircular();
        java.awt.Paint paint45 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint46 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean47 = org.jfree.chart.util.PaintUtilities.equal(paint45, paint46);
        piePlot43.setBaseSectionPaint(paint45);
        java.lang.Object obj49 = piePlot43.clone();
        org.jfree.chart.plot.Plot plot50 = piePlot43.getParent();
        java.awt.Font font51 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot43.setLabelFont(font51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets();
        double double55 = rectangleInsets53.trimHeight((double) 1L);
        java.awt.Paint paint56 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder(rectangleInsets53, paint56);
        piePlot43.setBackgroundPaint(paint56);
        java.awt.Font font59 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean60 = piePlot43.equals((java.lang.Object) font59);
        java.awt.Paint paint61 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint62 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean63 = org.jfree.chart.util.PaintUtilities.equal(paint61, paint62);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset64 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list65 = defaultStatisticalCategoryDataset64.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset67 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset64, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent68 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint62, (org.jfree.data.general.Dataset) pieDataset67);
        textBlock1.addLine("", font59, paint62);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment70 = textBlock1.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment71 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement74 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment70, verticalAlignment71, (double) (short) 1, (double) 7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment75 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement78 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment70, verticalAlignment75, 0.0d, 3.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement81 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment75, 10.0d, (double) 100L);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNull(plot50);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-1.0d) + "'", double55 == (-1.0d));
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(pieDataset67);
        org.junit.Assert.assertNotNull(horizontalAlignment70);
        org.junit.Assert.assertNotNull(verticalAlignment75);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Paint paint19 = barRenderer3D4.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean25 = stackedBarRenderer3D24.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D24.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D24.getBaseNegativeItemLabelPosition();
        barRenderer3D4.setSeriesPositiveItemLabelPosition(8, itemLabelPosition28, false);
        boolean boolean31 = sortOrder1.equals((java.lang.Object) 8);
        defaultKeyedValues0.sortByValues(sortOrder1);
        boolean boolean34 = defaultKeyedValues0.equals((java.lang.Object) 100L);
        defaultKeyedValues0.setValue((java.lang.Comparable) Double.NaN, (java.lang.Number) 0L);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Class class2 = null;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        int int6 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) date3);
        taskSeriesCollection0.removeAll();
        java.lang.Comparable comparable9 = null;
        try {
            java.lang.Number number11 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 1.0f, comparable9, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getLabelInsets();
        numberAxis3D0.setTickLabelInsets(rectangleInsets4);
        java.awt.Paint paint6 = numberAxis3D0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        polarPlot0.setDataset(xYDataset8);
        try {
            polarPlot0.zoom((double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Paint paint26 = barRenderer3D11.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D31.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        barRenderer3D11.setSeriesPositiveItemLabelPosition(8, itemLabelPosition35, false);
        boolean boolean38 = sortOrder8.equals((java.lang.Object) 8);
        categoryPlot0.setColumnRenderingOrder(sortOrder8);
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        double double41 = axisSpace40.getBottom();
        double double42 = axisSpace40.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace40);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str47 = plotOrientation46.toString();
        categoryPlot0.setOrientation(plotOrientation46);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer49 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double50 = ganttRenderer49.getStartPercent();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer49.setSeriesOutlineStroke((int) (short) 1, stroke52);
        categoryPlot0.setRangeCrosshairStroke(stroke52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        textTitle57.draw(graphics2D58, rectangle2D59);
        org.jfree.chart.block.LineBorder lineBorder61 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean66 = numberAxis65.getAutoRangeIncludesZero();
        numberAxis65.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo70);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState72 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo71.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = null;
        double double75 = numberAxis65.java2DToValue((double) (byte) -1, rectangle2D73, rectangleEdge74);
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D73);
        lineBorder61.draw(graphics2D62, rectangle2D73);
        textTitle57.setFrame((org.jfree.chart.block.BlockFrame) lineBorder61);
        java.awt.Paint paint79 = lineBorder61.getPaint();
        boolean boolean80 = datasetRenderingOrder55.equals((java.lang.Object) lineBorder61);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str47.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.35d + "'", double50 == 0.35d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + Double.NEGATIVE_INFINITY + "'", double75 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D76);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType2 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        barRenderer3D5.setLegendItemToolTipGenerator(categorySeriesLabelGenerator8);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal(paint11, paint12);
        barRenderer3D5.setSeriesItemLabelPaint((int) (byte) 100, paint12, false);
        boolean boolean16 = areaRendererEndType2.equals((java.lang.Object) false);
        stackedAreaRenderer1.setEndType(areaRendererEndType2);
        org.junit.Assert.assertNotNull(areaRendererEndType2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Object obj0 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        java.lang.Class class3 = null;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        int int7 = taskSeriesCollection1.getRowIndex((java.lang.Comparable) date4);
        taskSeriesCollection1.removeAll();
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) taskSeriesCollection1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        multiplePiePlot12.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        java.lang.String str17 = multiplePiePlot12.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot12);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle21.draw(graphics2D22, rectangle2D23);
        textTitle21.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double30 = rectangleInsets28.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        rectangleInsets28.trim(rectangle2D34);
        textTitle21.draw(graphics2D27, rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo43.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean48 = numberAxis47.getAutoRangeIncludesZero();
        numberAxis47.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo52);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState54 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo53);
        java.awt.geom.Rectangle2D rectangle2D55 = plotRenderingInfo53.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = numberAxis47.java2DToValue((double) (byte) -1, rectangle2D55, rectangleEdge56);
        java.awt.geom.Point2D point2D58 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D55);
        categoryPlot37.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo43, point2D58);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = null;
        try {
            jFreeChart18.draw(graphics2D19, rectangle2D34, point2D58, chartRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Multiple Pie Plot" + "'", str17.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.NEGATIVE_INFINITY + "'", double57 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D58);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis0.getLabelInsets();
        numberAxis0.setRangeWithMargins((double) 9, 10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        double double8 = itemLabelPosition7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.data.Range range2 = rectangleConstraint0.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer3D10.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        barRenderer3D10.setBaseOutlinePaint((java.awt.Paint) color24);
        float[] floatArray36 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray37 = color24.getRGBComponents(floatArray36);
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("ThreadContext", font7, (java.awt.Paint) color24);
        textBlock0.addLine(textLine38);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        boolean boolean43 = piePlot42.isCircular();
        java.awt.Paint paint44 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint45 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean46 = org.jfree.chart.util.PaintUtilities.equal(paint44, paint45);
        piePlot42.setBaseSectionPaint(paint44);
        java.lang.Object obj48 = piePlot42.clone();
        org.jfree.chart.plot.Plot plot49 = piePlot42.getParent();
        java.awt.Font font50 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot42.setLabelFont(font50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets();
        double double54 = rectangleInsets52.trimHeight((double) 1L);
        java.awt.Paint paint55 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets52, paint55);
        piePlot42.setBackgroundPaint(paint55);
        java.awt.Font font58 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean59 = piePlot42.equals((java.lang.Object) font58);
        java.awt.Paint paint60 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint61 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean62 = org.jfree.chart.util.PaintUtilities.equal(paint60, paint61);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset63 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list64 = defaultStatisticalCategoryDataset63.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset66 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset63, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint61, (org.jfree.data.general.Dataset) pieDataset66);
        textBlock0.addLine("", font58, paint61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment69 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment70 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement73 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment69, verticalAlignment70, (double) (short) 1, (double) 7);
        org.jfree.chart.block.BlockContainer blockContainer74 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement73);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNull(plot49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-1.0d) + "'", double54 == (-1.0d));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNotNull(pieDataset66);
        org.junit.Assert.assertNotNull(horizontalAlignment69);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        java.awt.Font font20 = barRenderer3D8.getSeriesItemLabelFont((-1));
        java.awt.Paint paint21 = barRenderer3D8.getWallPaint();
        piePlot1.setBaseSectionOutlinePaint(paint21);
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer25 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke26 = minMaxCategoryRenderer25.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint24, stroke26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean30 = piePlot29.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = null;
        piePlot29.setLegendLabelToolTipGenerator(pieSectionLabelGenerator31);
        java.awt.Font font33 = piePlot29.getLabelFont();
        java.awt.Paint paint34 = piePlot29.getNoDataMessagePaint();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot29.setSectionOutlineStroke((java.lang.Comparable) 2, stroke36);
        valueMarker27.setOutlineStroke(stroke36);
        piePlot1.setLabelLinkStroke(stroke36);
        java.awt.Paint paint40 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        textTitle6.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle6.getMargin();
        boolean boolean10 = lineAndShapeRenderer4.equals((java.lang.Object) rectangleInsets9);
        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot1.removeChangeListener(plotChangeListener6);
        float float8 = piePlot1.getForegroundAlpha();
        java.lang.Class class9 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str13 = dateTickUnit12.toString();
        java.lang.Class class14 = null;
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        java.util.Date date18 = dateTickUnit12.addToDate(date15);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date18, timeZone19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker23.setStartValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = intervalMarker23.getLabelOffset();
        org.jfree.data.KeyedObject keyedObject27 = new org.jfree.data.KeyedObject((java.lang.Comparable) date18, (java.lang.Object) rectangleInsets26);
        piePlot1.setInsets(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str13.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("2019");
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj2 = dateAxis1.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis1.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str10 = dateTickUnit9.toString();
        java.lang.Class class11 = null;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        java.util.Date date15 = dateTickUnit9.addToDate(date12);
        dateAxis1.setTickUnit(dateTickUnit9);
        java.util.TimeZone timeZone17 = null;
        try {
            dateAxis1.setTimeZone(timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str10.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "", "", "");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.awt.Image image9 = null;
        projectInfo7.setLogo(image9);
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setName("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        int int23 = defaultIntervalCategoryDataset20.getCategoryCount();
        try {
            java.lang.Number number26 = defaultIntervalCategoryDataset20.getValue(0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean8 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, 9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean17 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14, 9);
        int int18 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        double double4 = numberAxis3.getFixedAutoRange();
        numberAxis3.setLabelAngle((double) 0L);
        java.lang.Object obj7 = numberAxis3.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis3.getTickUnit();
        int int9 = taskSeriesCollection1.getRowIndex((java.lang.Comparable) numberTickUnit8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        double double11 = numberAxis10.getFixedAutoRange();
        numberAxis10.setLabelAngle((double) 0L);
        java.lang.Object obj14 = numberAxis10.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis10.getTickUnit();
        int int16 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) numberTickUnit15);
        double double17 = numberTickUnit15.getSize();
        java.lang.String str19 = numberTickUnit15.valueToString((double) (-16777216));
        try {
            org.jfree.chart.axis.TickUnit tickUnit20 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-16777216" + "'", str19.equals("-16777216"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke18 = null;
        barRenderer3D2.setSeriesOutlineStroke(1, stroke18);
        int int20 = barRenderer3D2.getPassCount();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = barRenderer3D2.getGradientPaintTransformer();
        barRenderer3D2.setSeriesCreateEntities(0, (java.lang.Boolean) false, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean30 = stackedBarRenderer3D29.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D29.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = stackedBarRenderer3D29.getBaseNegativeItemLabelPosition();
        barRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition33);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean18 = piePlot1.equals((java.lang.Object) font17);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) 1L);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setLabelOutlineStroke(stroke22);
        piePlot1.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        java.awt.Paint paint3 = lineAndShapeRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        textTitle2.draw(graphics2D3, rectangle2D7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D7, paint9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list13 = categoryPlot12.getAnnotations();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        textTitle16.draw(graphics2D17, rectangle2D18);
        textTitle16.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        double double25 = rectangleInsets23.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo27.getDataArea();
        rectangleInsets23.trim(rectangle2D29);
        textTitle16.draw(graphics2D22, rectangle2D29);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.awt.geom.Rectangle2D rectangle2D40 = plotRenderingInfo39.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean44 = numberAxis43.getAutoRangeIncludesZero();
        numberAxis43.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState50 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo49);
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis43.java2DToValue((double) (byte) -1, rectangle2D51, rectangleEdge52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D51);
        categoryPlot33.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo39, point2D54);
        boolean boolean56 = categoryPlot12.render(graphics2D14, rectangle2D29, 7, plotRenderingInfo39);
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        boolean boolean59 = piePlot58.isCircular();
        java.awt.Paint paint60 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint61 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean62 = org.jfree.chart.util.PaintUtilities.equal(paint60, paint61);
        piePlot58.setBaseSectionPaint(paint60);
        java.lang.Object obj64 = piePlot58.clone();
        int int65 = piePlot58.getPieIndex();
        java.lang.Object obj66 = piePlot58.clone();
        try {
            java.lang.Object obj67 = legendGraphic10.draw(graphics2D11, rectangle2D29, (java.lang.Object) piePlot58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.NEGATIVE_INFINITY + "'", double53 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        ganttRenderer0.setIncompletePaint(paint11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = ganttRenderer0.getToolTipGenerator((int) (short) -1, 10);
        boolean boolean16 = ganttRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = ganttRenderer0.getToolTipGenerator((int) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Paint paint19 = barRenderer3D4.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean25 = stackedBarRenderer3D24.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D24.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D24.getBaseNegativeItemLabelPosition();
        barRenderer3D4.setSeriesPositiveItemLabelPosition(8, itemLabelPosition28, false);
        boolean boolean31 = sortOrder1.equals((java.lang.Object) 8);
        defaultKeyedValues0.sortByValues(sortOrder1);
        org.jfree.chart.util.SortOrder sortOrder33 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByValues(sortOrder33);
        int int35 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Class class2 = null;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        int int6 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) date3);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries8 = taskSeriesCollection0.getSeries((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        boolean boolean5 = lineAndShapeRenderer2.isItemLabelVisible((int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Paint paint26 = barRenderer3D11.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D31.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        barRenderer3D11.setSeriesPositiveItemLabelPosition(8, itemLabelPosition35, false);
        boolean boolean38 = sortOrder8.equals((java.lang.Object) 8);
        categoryPlot0.setColumnRenderingOrder(sortOrder8);
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        double double41 = axisSpace40.getBottom();
        double double42 = axisSpace40.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace40);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str47 = plotOrientation46.toString();
        categoryPlot0.setOrientation(plotOrientation46);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer49 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double50 = ganttRenderer49.getStartPercent();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer49.setSeriesOutlineStroke((int) (short) 1, stroke52);
        categoryPlot0.setRangeCrosshairStroke(stroke52);
        boolean boolean55 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str47.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.35d + "'", double50 == 0.35d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer3D2.getBaseItemLabelGenerator();
        java.awt.Paint paint17 = barRenderer3D2.getSeriesOutlinePaint((int) ' ');
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, (double) 86400000L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        boolean boolean4 = numberAxis2.isVerticalTickLabels();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis2.setTickMarkStroke(stroke5);
        polarPlot0.setAngleGridlineStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot0.getInsets();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) (-1.0d), (java.lang.Number) (short) 10);
        java.lang.Number number3 = defaultKeyedValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 10 + "'", number3.equals((short) 10));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray5, doubleArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.lang.Comparable comparable10 = multiplePiePlot9.getAggregatedItemsKey();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("Pie Plot", font2, (org.jfree.chart.plot.Plot) multiplePiePlot9, false);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]", font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        boolean boolean11 = numberAxis0.isVisible();
        java.awt.Shape shape12 = numberAxis0.getDownArrow();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Comparable comparable4 = defaultStatisticalCategoryDataset0.getRowKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        int int5 = color4.getAlpha();
        java.awt.Color color6 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]", color4);
        statisticalLineAndShapeRenderer2.setErrorIndicatorPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis0.java2DToValue((double) (byte) -1, rectangle2D8, rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo16.getDataArea();
        rectangleInsets12.trim(rectangle2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis0.valueToJava2D((double) 7, rectangle2D18, rectangleEdge20);
        numberAxis0.setUpperBound(0.2d);
        numberAxis0.setLabelAngle((double) (-457));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection7.getRowIndex((java.lang.Comparable) numberTickUnit14);
        defaultCategoryDataset4.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int15, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        int int21 = defaultCategoryDataset4.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup22 = defaultCategoryDataset4.getGroup();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(datasetGroup22);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setItemMargin((double) 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        try {
            java.lang.Number number11 = defaultStatisticalCategoryDataset7.getMeanValue(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, polarItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean6 = stackedBarRenderer3D5.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D5.setBaseSeriesVisible(false);
        java.awt.Paint paint9 = stackedBarRenderer3D5.getBasePaint();
        numberAxis3D1.setTickLabelPaint(paint9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        piePlot12.setBaseSectionPaint(paint14);
        java.lang.Object obj18 = piePlot12.clone();
        org.jfree.chart.plot.Plot plot19 = piePlot12.getParent();
        numberAxis3D1.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        piePlot12.setInteriorGap(0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        double double7 = numberAxis6.getFixedAutoRange();
        boolean boolean8 = numberAxis6.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis1.getCategoryEnd((int) (byte) -1, 0, rectangle2D14, rectangleEdge17);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D14);
        java.lang.String str20 = chartEntity19.getURLText();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean18 = piePlot1.equals((java.lang.Object) font17);
        piePlot1.setShadowXOffset((double) 0.0f);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isCircular();
        double double25 = piePlot23.getInteriorGap();
        java.awt.Font font26 = piePlot23.getNoDataMessageFont();
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font26, (org.jfree.chart.plot.Plot) multiplePiePlot33, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart35.createBufferedImage(5, 9, chartRenderingInfo38);
        java.lang.Number number45 = null;
        java.util.List list48 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem49 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number45, (java.lang.Number) 3, (java.lang.Number) 100.0d, list48);
        java.lang.Number number50 = boxAndWhiskerItem49.getMinRegularValue();
        boolean boolean51 = jFreeChart35.equals((java.lang.Object) number50);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        java.awt.Font font53 = piePlot1.getNoDataMessageFont();
        java.awt.Paint paint54 = piePlot1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.25d + "'", double25 == 0.25d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(bufferedImage39);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.0d + "'", number50.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        java.awt.Font font32 = barRenderer3D2.getItemLabelFont((int) (byte) 0, (int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list35 = categoryPlot34.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color38 = java.awt.Color.black;
        boolean boolean39 = layer37.equals((java.lang.Object) color38);
        java.util.Collection collection40 = categoryPlot34.getRangeMarkers(layer37);
        boolean boolean41 = categoryPlot34.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder42 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D45 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D45.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator48 = null;
        barRenderer3D45.setLegendItemToolTipGenerator(categorySeriesLabelGenerator48);
        java.awt.Paint paint51 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint52 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean53 = org.jfree.chart.util.PaintUtilities.equal(paint51, paint52);
        barRenderer3D45.setSeriesItemLabelPaint((int) (byte) 100, paint52, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator56 = null;
        barRenderer3D45.setBaseItemLabelGenerator(categoryItemLabelGenerator56, false);
        java.awt.Paint paint60 = barRenderer3D45.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean66 = stackedBarRenderer3D65.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D65.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = stackedBarRenderer3D65.getBaseNegativeItemLabelPosition();
        barRenderer3D45.setSeriesPositiveItemLabelPosition(8, itemLabelPosition69, false);
        boolean boolean72 = sortOrder42.equals((java.lang.Object) 8);
        categoryPlot34.setColumnRenderingOrder(sortOrder42);
        org.jfree.chart.axis.AxisSpace axisSpace74 = new org.jfree.chart.axis.AxisSpace();
        double double75 = axisSpace74.getBottom();
        double double76 = axisSpace74.getRight();
        categoryPlot34.setFixedDomainAxisSpace(axisSpace74);
        categoryPlot34.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace79 = categoryPlot34.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation80 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str81 = plotOrientation80.toString();
        categoryPlot34.setOrientation(plotOrientation80);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer83 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double84 = ganttRenderer83.getStartPercent();
        java.awt.Stroke stroke86 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer83.setSeriesOutlineStroke((int) (short) 1, stroke86);
        categoryPlot34.setRangeCrosshairStroke(stroke86);
        try {
            barRenderer3D2.setSeriesOutlineStroke((-12566273), stroke86, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNull(axisSpace79);
        org.junit.Assert.assertNotNull(plotOrientation80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str81.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.35d + "'", double84 == 0.35d);
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray4 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray5 = null;
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray12, numberArray19 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray2, (java.lang.Comparable[]) strArray4, numberArray5, numberArray20);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray24, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray26);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray2, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        double double2 = size2D0.getWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean2 = dataPackageResources0.containsKey("ItemLabelAnchor.OUTSIDE4");
        java.util.Locale locale3 = dataPackageResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration4 = dataPackageResources0.getKeys();
        java.lang.Object[][] objArray5 = dataPackageResources0.getContents();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strEnumeration4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer3D2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator18);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D22.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = null;
        barRenderer3D22.setLegendItemToolTipGenerator(categorySeriesLabelGenerator25);
        barRenderer3D22.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        polarPlot31.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        double double34 = numberAxis33.getFixedAutoRange();
        boolean boolean35 = numberAxis33.isVerticalTickLabels();
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis33.setTickMarkStroke(stroke36);
        polarPlot31.setAngleGridlineStroke(stroke36);
        barRenderer3D22.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot31);
        java.awt.Font font40 = polarPlot31.getAngleLabelFont();
        polarPlot31.clearCornerTextItems();
        boolean boolean42 = barRenderer3D2.equals((java.lang.Object) polarPlot31);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list46 = categoryPlot45.getAnnotations();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        textTitle49.draw(graphics2D50, rectangle2D51);
        textTitle49.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets();
        double double58 = rectangleInsets56.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo59);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState61 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo60);
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo60.getDataArea();
        rectangleInsets56.trim(rectangle2D62);
        textTitle49.draw(graphics2D55, rectangle2D62);
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot66.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo72.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean77 = numberAxis76.getAutoRangeIncludesZero();
        numberAxis76.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo81);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState83 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo82);
        java.awt.geom.Rectangle2D rectangle2D84 = plotRenderingInfo82.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        double double86 = numberAxis76.java2DToValue((double) (byte) -1, rectangle2D84, rectangleEdge85);
        java.awt.geom.Point2D point2D87 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D84);
        categoryPlot66.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo72, point2D87);
        boolean boolean89 = categoryPlot45.render(graphics2D47, rectangle2D62, 7, plotRenderingInfo72);
        try {
            java.awt.Point point90 = polarPlot31.translateValueThetaRadiusToJava2D((double) (byte) -1, (double) (-1), rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + Double.NEGATIVE_INFINITY + "'", double86 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = rendererState14.getInfo();
        categoryPlot0.handleClick((int) '4', 2958465, plotRenderingInfo15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis(9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        double double6 = numberAxis5.getFixedAutoRange();
        boolean boolean7 = numberAxis5.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = numberAxis5.refreshTicks(graphics2D8, axisState9, rectangle2D13, rectangleEdge14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray23 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray24 = null;
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray31, numberArray38 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset40 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray21, (java.lang.Comparable[]) strArray23, numberArray24, numberArray39);
        int int41 = defaultIntervalCategoryDataset40.getCategoryCount();
        java.util.List list42 = defaultIntervalCategoryDataset40.getRowKeys();
        java.util.List list43 = defaultIntervalCategoryDataset40.getColumnKeys();
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState4, rectangle2D13, categoryPlot16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset40, (-35), (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot1.addChangeListener(plotChangeListener7);
        piePlot1.setShadowXOffset((double) 100L);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        piePlot12.setBaseSectionPaint(paint14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot12.addChangeListener(plotChangeListener18);
        piePlot12.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D24.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator27 = null;
        barRenderer3D24.setLegendItemToolTipGenerator(categorySeriesLabelGenerator27);
        java.awt.Paint paint30 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint31 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean32 = org.jfree.chart.util.PaintUtilities.equal(paint30, paint31);
        barRenderer3D24.setSeriesItemLabelPaint((int) (byte) 100, paint31, false);
        piePlot12.setBaseSectionOutlinePaint(paint31);
        piePlot1.setShadowPaint(paint31);
        piePlot1.setLabelGap(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        double double7 = numberAxis6.getFixedAutoRange();
        boolean boolean8 = numberAxis6.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis1.getCategoryEnd((int) (byte) -1, 0, rectangle2D14, rectangleEdge17);
        boolean boolean19 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.text.TextBlock textBlock21 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock21.draw(graphics2D22, (float) (short) -1, (float) 5, textBlockAnchor25);
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D31 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D31.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = null;
        barRenderer3D31.setLegendItemToolTipGenerator(categorySeriesLabelGenerator34);
        java.awt.Paint paint37 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint38 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean39 = org.jfree.chart.util.PaintUtilities.equal(paint37, paint38);
        barRenderer3D31.setSeriesItemLabelPaint((int) (byte) 100, paint38, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = null;
        barRenderer3D31.setBaseItemLabelGenerator(categoryItemLabelGenerator42, false);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color45.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        barRenderer3D31.setBaseOutlinePaint((java.awt.Paint) color45);
        float[] floatArray57 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray58 = color45.getRGBComponents(floatArray57);
        org.jfree.chart.text.TextLine textLine59 = new org.jfree.chart.text.TextLine("ThreadContext", font28, (java.awt.Paint) color45);
        textBlock21.addLine(textLine59);
        org.jfree.data.general.PieDataset pieDataset62 = null;
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot(pieDataset62);
        boolean boolean64 = piePlot63.isCircular();
        java.awt.Paint paint65 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint66 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean67 = org.jfree.chart.util.PaintUtilities.equal(paint65, paint66);
        piePlot63.setBaseSectionPaint(paint65);
        java.lang.Object obj69 = piePlot63.clone();
        org.jfree.chart.plot.Plot plot70 = piePlot63.getParent();
        java.awt.Font font71 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot63.setLabelFont(font71);
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = new org.jfree.chart.util.RectangleInsets();
        double double75 = rectangleInsets73.trimHeight((double) 1L);
        java.awt.Paint paint76 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder77 = new org.jfree.chart.block.BlockBorder(rectangleInsets73, paint76);
        piePlot63.setBackgroundPaint(paint76);
        java.awt.Font font79 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean80 = piePlot63.equals((java.lang.Object) font79);
        java.awt.Paint paint81 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint82 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean83 = org.jfree.chart.util.PaintUtilities.equal(paint81, paint82);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset84 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list85 = defaultStatisticalCategoryDataset84.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset87 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset84, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent88 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint82, (org.jfree.data.general.Dataset) pieDataset87);
        textBlock21.addLine("", font79, paint82);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-12566273), font79);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNull(plot70);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + (-1.0d) + "'", double75 == (-1.0d));
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertNotNull(pieDataset87);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setRenderAsPercentages(false);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        boolean boolean6 = piePlot5.isCircular();
        java.awt.Paint paint7 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean9 = org.jfree.chart.util.PaintUtilities.equal(paint7, paint8);
        piePlot5.setBaseSectionPaint(paint7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot5.addChangeListener(plotChangeListener11);
        piePlot5.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D17.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = null;
        barRenderer3D17.setLegendItemToolTipGenerator(categorySeriesLabelGenerator20);
        java.awt.Paint paint23 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal(paint23, paint24);
        barRenderer3D17.setSeriesItemLabelPaint((int) (byte) 100, paint24, false);
        piePlot5.setBaseSectionOutlinePaint(paint24);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        boolean boolean32 = piePlot31.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator33 = null;
        piePlot31.setLegendLabelToolTipGenerator(pieSectionLabelGenerator33);
        java.awt.Font font35 = piePlot31.getLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer37.setBaseOutlinePaint(paint38);
        piePlot31.setSectionPaint((java.lang.Comparable) 86400000L, paint38);
        piePlot5.setSectionPaint((java.lang.Comparable) (byte) 0, paint38);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer42 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke43 = minMaxCategoryRenderer42.getGroupStroke();
        java.awt.Paint paint45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint45);
        minMaxCategoryRenderer42.setSeriesItemLabelPaint(0, paint45);
        java.awt.Paint paint48 = minMaxCategoryRenderer42.getGroupPaint();
        boolean boolean49 = org.jfree.chart.util.PaintUtilities.equal(paint38, paint48);
        stackedAreaRenderer1.setBaseOutlinePaint(paint38);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Paint paint6 = blockBorder4.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder4.getInsets();
        double double9 = rectangleInsets7.calculateTopInset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = numberAxis0.getLabelInsets();
        org.jfree.data.Range range4 = numberAxis0.getRange();
        numberAxis0.setLowerMargin((double) 'a');
        numberAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) textTitle6);
        intervalMarker2.setLabel("{0}");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        java.lang.Object obj5 = intervalMarker2.clone();
        java.lang.Object obj6 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj2 = dateAxis1.clone();
        double double3 = dateAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Paint paint17 = barRenderer3D2.lookupSeriesOutlinePaint((int) (short) 100);
        java.awt.Stroke stroke19 = barRenderer3D2.getSeriesStroke(10);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(stroke19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis2.setLowerMargin(0.0d);
        int int5 = categoryAxis2.getMaximumCategoryLabelLines();
        boolean boolean6 = rangeType0.equals((java.lang.Object) int5);
        java.lang.String str7 = rangeType0.toString();
        java.lang.String str8 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RangeType.FULL" + "'", str7.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RangeType.FULL" + "'", str8.equals("RangeType.FULL"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        boolean boolean2 = numberAxis3D1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        java.awt.Stroke stroke6 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16776961) + "'", int1 == (-16776961));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        barRenderer3D2.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer3D2.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        int int23 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list24 = defaultIntervalCategoryDataset20.getColumnKeys();
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke3);
        org.jfree.data.Range range5 = numberAxis0.getRange();
        boolean boolean8 = range5.intersects((double) (-2208960000000L), (double) 7);
        boolean boolean11 = range5.intersects((double) 2, 0.35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj2 = dateAxis1.clone();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        minMaxCategoryRenderer0.setDrawLines(true);
        minMaxCategoryRenderer0.setDrawLines(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        java.awt.Paint paint8 = minMaxCategoryRenderer0.getSeriesItemLabelPaint(1);
        java.awt.Paint paint9 = minMaxCategoryRenderer0.getGroupPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0d, shape3, "({0}, {1}) = {3} - {4}", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape3, "Aug", "PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        textTitle2.draw(graphics2D3, rectangle2D7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D7, paint9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic10.getShapeLocation();
        java.awt.Paint paint12 = legendGraphic10.getOutlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        double double5 = stackedBarRenderer3D3.getMaximumBarWidth();
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        java.awt.Color color9 = java.awt.Color.lightGray;
        stackedBarRenderer3D3.setSeriesFillPaint(5, (java.awt.Paint) color9, true);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D3.setSeriesStroke(10, stroke13, false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState19 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo18);
        categoryItemRendererState19.setBarWidth(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        double double24 = rectangleInsets22.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo26.getDataArea();
        rectangleInsets22.trim(rectangle2D28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis34.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        double double40 = numberAxis39.getFixedAutoRange();
        boolean boolean41 = numberAxis39.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.AxisState axisState43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState46 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo45);
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo45.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        java.util.List list49 = numberAxis39.refreshTicks(graphics2D42, axisState43, rectangle2D47, rectangleEdge48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = categoryAxis34.getCategoryEnd((int) (byte) -1, 0, rectangle2D47, rectangleEdge50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection53 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection53);
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        double double56 = numberAxis55.getFixedAutoRange();
        numberAxis55.setLabelAngle((double) 0L);
        java.lang.Object obj59 = numberAxis55.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = numberAxis55.getTickUnit();
        int int61 = taskSeriesCollection53.getRowIndex((java.lang.Comparable) numberTickUnit60);
        try {
            stackedBarRenderer3D3.drawItem(graphics2D16, categoryItemRendererState19, rectangle2D28, categoryPlot30, categoryAxis34, valueAxis52, (org.jfree.data.category.CategoryDataset) taskSeriesCollection53, 255, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot4.setSeparatorStroke(stroke6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        double double13 = stackedBarRenderer3D11.getMaximumBarWidth();
        stackedBarRenderer3D11.setRenderAsPercentages(true);
        java.awt.Color color17 = java.awt.Color.lightGray;
        stackedBarRenderer3D11.setSeriesFillPaint(5, (java.awt.Paint) color17, true);
        ringPlot4.setSeparatorPaint((java.awt.Paint) color17);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis29.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        double double35 = numberAxis34.getFixedAutoRange();
        boolean boolean36 = numberAxis34.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState41 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo40);
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo40.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        java.util.List list44 = numberAxis34.refreshTicks(graphics2D37, axisState38, rectangle2D42, rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis29.getCategoryEnd((int) (byte) -1, 0, rectangle2D42, rectangleEdge45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double48 = categoryAxis23.getCategoryMiddle((int) (byte) -1, (int) ' ', rectangle2D42, rectangleEdge47);
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        boolean boolean51 = piePlot50.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator52 = null;
        piePlot50.setLegendLabelToolTipGenerator(pieSectionLabelGenerator52);
        java.awt.Font font54 = piePlot50.getLabelFont();
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        piePlot50.removeChangeListener(plotChangeListener55);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list59 = categoryPlot58.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color62 = java.awt.Color.black;
        boolean boolean63 = layer61.equals((java.lang.Object) color62);
        java.util.Collection collection64 = categoryPlot58.getRangeMarkers(layer61);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryPlot58.getAxisOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo68);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState70 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo69);
        java.awt.geom.Rectangle2D rectangle2D71 = plotRenderingInfo69.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState72 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = rendererState72.getInfo();
        categoryPlot58.handleClick((int) '4', 2958465, plotRenderingInfo73);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState75 = ringPlot4.initialise(graphics2D21, rectangle2D42, piePlot50, (java.lang.Integer) (-35), plotRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(plotRenderingInfo73);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isCircular();
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        piePlot6.setBaseSectionPaint(paint8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot6.addChangeListener(plotChangeListener12);
        piePlot6.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D18.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = null;
        barRenderer3D18.setLegendItemToolTipGenerator(categorySeriesLabelGenerator21);
        java.awt.Paint paint24 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint25 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean26 = org.jfree.chart.util.PaintUtilities.equal(paint24, paint25);
        barRenderer3D18.setSeriesItemLabelPaint((int) (byte) 100, paint25, false);
        piePlot6.setBaseSectionOutlinePaint(paint25);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        boolean boolean33 = piePlot32.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = null;
        piePlot32.setLegendLabelToolTipGenerator(pieSectionLabelGenerator34);
        java.awt.Font font36 = piePlot32.getLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer38.setBaseOutlinePaint(paint39);
        piePlot32.setSectionPaint((java.lang.Comparable) 86400000L, paint39);
        piePlot6.setSectionPaint((java.lang.Comparable) (byte) 0, paint39);
        java.awt.Paint paint43 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint44 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean45 = org.jfree.chart.util.PaintUtilities.equal(paint43, paint44);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list47 = defaultStatisticalCategoryDataset46.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset46, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint44, (org.jfree.data.general.Dataset) pieDataset49);
        org.jfree.data.general.Dataset dataset51 = datasetChangeEvent50.getDataset();
        java.lang.Object obj52 = datasetChangeEvent50.getSource();
        piePlot6.datasetChanged(datasetChangeEvent50);
        piePlot1.datasetChanged(datasetChangeEvent50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(dataset51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) 1);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) numberTickUnit14);
        java.util.List list16 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean11 = piePlot10.isCircular();
        double double12 = piePlot10.getInteriorGap();
        java.awt.Font font13 = piePlot10.getNoDataMessageFont();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font13, (org.jfree.chart.plot.Plot) multiplePiePlot20, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart22.createBufferedImage(5, 9, chartRenderingInfo25);
        categoryPlot0.setBackgroundImage((java.awt.Image) bufferedImage26);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.25d + "'", double12 == 0.25d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection7.getRowIndex((java.lang.Comparable) numberTickUnit14);
        defaultCategoryDataset4.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int15, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        java.lang.Comparable comparable21 = categoryItemEntity20.getRowKey();
        java.lang.String str22 = categoryItemEntity20.getShapeCoords();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable21.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0,-35,35,0,0,35,-35,0,-35,0" + "'", str22.equals("0,-35,35,0,0,35,-35,0,-35,0"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        multiplePiePlot12.setNoDataMessage("ItemLabelAnchor.OUTSIDE4");
        java.awt.Paint paint17 = multiplePiePlot12.getAggregatedItemsPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateBottomInset((double) 0L);
        double double22 = rectangleInsets18.trimHeight((double) 1);
        double double24 = rectangleInsets18.extendWidth((double) (byte) 1);
        multiplePiePlot12.setInsets(rectangleInsets18);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26);
        java.lang.Number number30 = defaultStatisticalCategoryDataset26.getValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (short) 10);
        int int31 = defaultStatisticalCategoryDataset26.getRowCount();
        org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, 0);
        multiplePiePlot12.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(pieDataset33);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        java.lang.String str3 = projectInfo0.getCopyright();
        projectInfo0.setVersion("Pie Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str3.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType3);
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list7 = categoryPlot6.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color10 = java.awt.Color.black;
        boolean boolean11 = layer9.equals((java.lang.Object) color10);
        java.util.Collection collection12 = categoryPlot6.getRangeMarkers(layer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot6.getAxisOffset();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = rendererState20.getInfo();
        categoryPlot6.handleClick((int) '4', 2958465, plotRenderingInfo21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot6.getDomainAxis(9);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.setAntiAlias(false);
        java.awt.Paint paint21 = jFreeChart14.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (short) -1, (float) 5, textBlockAnchor4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = textBlock0.calculateDimensions(graphics2D6);
        org.jfree.chart.text.TextLine textLine8 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNull(textLine8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        double double2 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean11 = piePlot10.isCircular();
        double double12 = piePlot10.getInteriorGap();
        java.awt.Font font13 = piePlot10.getNoDataMessageFont();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font13, (org.jfree.chart.plot.Plot) multiplePiePlot20, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart22.createBufferedImage(5, 9, chartRenderingInfo25);
        categoryPlot0.setBackgroundImage((java.awt.Image) bufferedImage26);
        boolean boolean28 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.25d + "'", double12 == 0.25d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = null;
        piePlot6.setLegendLabelToolTipGenerator(pieSectionLabelGenerator8);
        java.awt.Font font10 = piePlot6.getLabelFont();
        java.awt.Paint paint11 = piePlot6.getNoDataMessagePaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot6.setSectionOutlineStroke((java.lang.Comparable) 2, stroke13);
        valueMarker4.setOutlineStroke(stroke13);
        java.awt.Stroke stroke16 = valueMarker4.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = valueMarker4.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer1 = new org.jfree.chart.renderer.category.AreaRenderer();
        int int2 = areaRenderer1.getPassCount();
        java.awt.Font font5 = areaRenderer1.getItemLabelFont((-35), (int) (short) 100);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("", font5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker9.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        boolean boolean14 = intervalMarker9.equals((java.lang.Object) textTitle13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle13.getHorizontalAlignment();
        textTitle6.setHorizontalAlignment(horizontalAlignment15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        textTitle2.draw(graphics2D3, rectangle2D7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D7, paint9);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = legendGraphic10.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list6 = categoryPlot5.getAnnotations();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        textTitle9.draw(graphics2D10, rectangle2D11);
        textTitle9.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets16.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        rectangleInsets16.trim(rectangle2D22);
        textTitle9.draw(graphics2D15, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean37 = numberAxis36.getAutoRangeIncludesZero();
        numberAxis36.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = numberAxis36.java2DToValue((double) (byte) -1, rectangle2D44, rectangleEdge45);
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D44);
        categoryPlot26.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo32, point2D47);
        boolean boolean49 = categoryPlot5.render(graphics2D7, rectangle2D22, 7, plotRenderingInfo32);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot50.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color57 = java.awt.Color.black;
        boolean boolean58 = layer56.equals((java.lang.Object) color57);
        categoryPlot50.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker55, layer56);
        categoryPlot50.setWeight(7);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis63.setLowerMargin(0.0d);
        categoryAxis63.setLowerMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj70 = dateAxis69.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit73 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis69.setTickUnit(dateTickUnit73);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset75 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list76 = defaultStatisticalCategoryDataset75.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset75, (java.lang.Comparable) 0.35d);
        defaultStatisticalCategoryDataset75.validateObject();
        try {
            statisticalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState4, rectangle2D22, categoryPlot50, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset75, (int) '4', 2, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.NEGATIVE_INFINITY + "'", double46 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNotNull(list76);
        org.junit.Assert.assertNotNull(pieDataset78);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        taskSeriesCollection1.removeAll();
        int int4 = taskSeriesCollection1.getRowCount();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj7 = dateAxis6.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis6.setTickUnit(dateTickUnit10);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection1, (java.lang.Comparable) dateTickUnit10);
        taskSeriesCollection1.removeAll();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Paint paint26 = barRenderer3D11.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D31.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = stackedBarRenderer3D31.getBaseNegativeItemLabelPosition();
        barRenderer3D11.setSeriesPositiveItemLabelPosition(8, itemLabelPosition35, false);
        boolean boolean38 = sortOrder8.equals((java.lang.Object) 8);
        categoryPlot0.setColumnRenderingOrder(sortOrder8);
        org.jfree.chart.axis.AxisSpace axisSpace40 = new org.jfree.chart.axis.AxisSpace();
        double double41 = axisSpace40.getBottom();
        double double42 = axisSpace40.getRight();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace40);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str47 = plotOrientation46.toString();
        categoryPlot0.setOrientation(plotOrientation46);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer49 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double50 = ganttRenderer49.getStartPercent();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer49.setSeriesOutlineStroke((int) (short) 1, stroke52);
        categoryPlot0.setRangeCrosshairStroke(stroke52);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis57.setLowerMargin(0.0d);
        java.awt.Font font62 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle("", font62);
        categoryAxis57.setTickLabelFont((java.lang.Comparable) 90.0d, font62);
        categoryPlot0.setDomainAxis(2958465, categoryAxis57, false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str47.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.35d + "'", double50 == 0.35d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(font62);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list21 = defaultStatisticalCategoryDataset20.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint18, (org.jfree.data.general.Dataset) pieDataset23);
        boolean boolean25 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset23);
        piePlot1.setDataset(pieDataset23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = areaRenderer0.getEndType();
        org.junit.Assert.assertNotNull(areaRendererEndType1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator31 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D2.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator31);
        java.awt.Shape shape33 = barRenderer3D2.getBaseShape();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        lineAndShapeRenderer0.setBaseFillPaint(paint6, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) (byte) 10, categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double8 = ganttRenderer7.getStartPercent();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        ganttRenderer7.setSeriesOutlineStroke((int) (short) 1, stroke10);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D14.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = null;
        barRenderer3D14.setLegendItemToolTipGenerator(categorySeriesLabelGenerator17);
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean22 = org.jfree.chart.util.PaintUtilities.equal(paint20, paint21);
        barRenderer3D14.setSeriesItemLabelPaint((int) (byte) 100, paint21, false);
        ganttRenderer7.setIncompletePaint(paint21);
        textTitle1.setBackgroundPaint(paint21);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.35d + "'", double8 == 0.35d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (-1), (java.lang.Number) 0.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1) + "'", number3.equals((-1)));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) textTitle6);
        java.lang.Object obj8 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        double double5 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        java.lang.Comparable comparable6 = null;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot8.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Font font12 = piePlot8.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint22);
        barRenderer3D15.setSeriesItemLabelPaint((int) (byte) 100, paint22, false);
        java.awt.Font font27 = barRenderer3D15.getSeriesItemLabelFont((-1));
        java.awt.Paint paint28 = barRenderer3D15.getWallPaint();
        piePlot8.setBaseSectionOutlinePaint(paint28);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color31 = java.awt.Color.pink;
        java.awt.Color color32 = color31.brighter();
        piePlot8.setSectionPaint((java.lang.Comparable) date30, (java.awt.Paint) color32);
        java.lang.Number number34 = defaultStatisticalCategoryDataset0.getStdDevValue(comparable6, (java.lang.Comparable) date30);
        java.util.TimeZone timeZone35 = null;
        try {
            org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date30, timeZone35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(number34);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer3D4.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Paint paint19 = barRenderer3D4.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean25 = stackedBarRenderer3D24.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D24.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedBarRenderer3D24.getBaseNegativeItemLabelPosition();
        barRenderer3D4.setSeriesPositiveItemLabelPosition(8, itemLabelPosition28, false);
        boolean boolean31 = sortOrder1.equals((java.lang.Object) 8);
        defaultKeyedValues0.sortByValues(sortOrder1);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues33 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list34 = defaultKeyedValues33.getKeys();
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        defaultKeyedValues33.addValue((java.lang.Comparable) date35, (java.lang.Number) 90.0d);
        org.jfree.chart.util.SortOrder sortOrder38 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues33.sortByValues(sortOrder38);
        defaultKeyedValues0.sortByKeys(sortOrder38);
        try {
            java.lang.Comparable comparable42 = defaultKeyedValues0.getKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(sortOrder38);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable3 = keyToGroupMap1.getGroup((java.lang.Comparable) (byte) 1);
        int int5 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) (short) 0);
        java.util.List list6 = keyToGroupMap1.getGroups();
        int int8 = keyToGroupMap1.getKeyCount((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (byte) 1 + "'", comparable3.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation10 = axisLocation9.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation9);
        java.lang.String str12 = axisLocation9.toString();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str12.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        textTitle12.draw(graphics2D13, rectangle2D14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer16.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem21 = lineAndShapeRenderer16.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer16.getBaseNegativeItemLabelPosition();
        columnArrangement10.add((org.jfree.chart.block.Block) textTitle12, (java.lang.Object) itemLabelPosition22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement5, (org.jfree.chart.block.Arrangement) columnArrangement10);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double27 = rectangleConstraint26.getWidth();
        org.jfree.data.Range range28 = rectangleConstraint26.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint26.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D30 = legendTitle24.arrange(graphics2D25, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
//        java.lang.Object obj2 = dateAxis1.clone();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
//        dateAxis1.setTickUnit(dateTickUnit5);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
//        java.lang.String str10 = dateTickUnit9.toString();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        java.util.Date date15 = dateTickUnit9.addToDate(date12);
//        dateAxis1.setTickUnit(dateTickUnit9);
//        java.awt.Font font17 = dateAxis1.getLabelFont();
//        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
//        boolean boolean22 = stackedBarRenderer3D21.getAutoPopulateSeriesStroke();
//        stackedBarRenderer3D21.setBaseSeriesVisible(false);
//        java.awt.Paint paint25 = stackedBarRenderer3D21.getBasePaint();
//        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//        org.jfree.data.Range range27 = stackedBarRenderer3D21.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26);
//        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range27, (double) 2);
//        org.jfree.data.resources.DataPackageResources dataPackageResources30 = new org.jfree.data.resources.DataPackageResources();
//        java.lang.Object[][] objArray31 = dataPackageResources30.getContents();
//        java.util.Locale locale32 = dataPackageResources30.getLocale();
//        boolean boolean33 = range29.equals((java.lang.Object) locale32);
//        dateAxis1.setRange(range29);
//        java.lang.Class class35 = null;
//        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
//        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
//        java.awt.Graphics2D graphics2D41 = null;
//        java.awt.geom.Rectangle2D rectangle2D42 = null;
//        textTitle40.draw(graphics2D41, rectangle2D42);
//        textTitle40.setPadding((double) 10, (double) 1, (double) 0.0f, 0.0d);
//        java.awt.Graphics2D graphics2D49 = null;
//        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
//        double double52 = rectangleInsets50.calculateBottomInset((double) 0L);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo53);
//        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo54);
//        java.awt.geom.Rectangle2D rectangle2D56 = plotRenderingInfo54.getDataArea();
//        rectangleInsets50.trim(rectangle2D56);
//        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets();
//        double double60 = rectangleInsets58.trimHeight((double) 1L);
//        java.awt.Paint paint61 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
//        org.jfree.chart.block.BlockBorder blockBorder62 = new org.jfree.chart.block.BlockBorder(rectangleInsets58, paint61);
//        java.awt.Paint paint63 = blockBorder62.getPaint();
//        boolean boolean65 = blockBorder62.equals((java.lang.Object) 10.0f);
//        java.lang.Object obj66 = textTitle40.draw(graphics2D49, rectangle2D56, (java.lang.Object) boolean65);
//        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.LEFT;
//        double double68 = dateAxis1.dateToJava2D(date36, rectangle2D56, rectangleEdge67);
//        dateAxis1.setLabel("");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit71 = dateAxis1.getTickUnit();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str10.equals("DateTickUnit[HOUR, -457]"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(font17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNotNull(range27);
//        org.junit.Assert.assertNotNull(range29);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNull(locale32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
//        org.junit.Assert.assertNotNull(rectangle2D56);
//        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
//        org.junit.Assert.assertNotNull(paint61);
//        org.junit.Assert.assertNotNull(paint63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNull(obj66);
//        org.junit.Assert.assertNotNull(rectangleEdge67);
//        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.120361937465E12d + "'", double68 == 3.120361937465E12d);
//        org.junit.Assert.assertNotNull(dateTickUnit71);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        java.awt.Font font20 = barRenderer3D8.getSeriesItemLabelFont((-1));
        java.awt.Paint paint21 = barRenderer3D8.getWallPaint();
        piePlot1.setBaseSectionOutlinePaint(paint21);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color24 = java.awt.Color.pink;
        java.awt.Color color25 = color24.brighter();
        piePlot1.setSectionPaint((java.lang.Comparable) date23, (java.awt.Paint) color25);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(pieSectionLabelGenerator27);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        double double2 = rectangleInsets0.getBottom();
        java.lang.String str3 = rectangleInsets0.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis1.setLowerMargin(0.0d);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean8 = piePlot7.isCircular();
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        piePlot7.setBaseSectionPaint(paint9);
        java.lang.Object obj13 = piePlot7.clone();
        org.jfree.chart.plot.Plot plot14 = piePlot7.getParent();
        java.awt.Font font15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot7.setLabelFont(font15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.trimHeight((double) 1L);
        java.awt.Paint paint20 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, paint20);
        piePlot7.setBackgroundPaint(paint20);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean24 = piePlot7.equals((java.lang.Object) font23);
        piePlot7.setShadowXOffset((double) 0.0f);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean30 = piePlot29.isCircular();
        double double31 = piePlot29.getInteriorGap();
        java.awt.Font font32 = piePlot29.getNoDataMessageFont();
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray35, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray37);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset38);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font32, (org.jfree.chart.plot.Plot) multiplePiePlot39, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart41.createBufferedImage(5, 9, chartRenderingInfo44);
        java.lang.Number number51 = null;
        java.util.List list54 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem55 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number51, (java.lang.Number) 3, (java.lang.Number) 100.0d, list54);
        java.lang.Number number56 = boxAndWhiskerItem55.getMinRegularValue();
        boolean boolean57 = jFreeChart41.equals((java.lang.Object) number56);
        piePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart41);
        java.awt.Font font59 = piePlot7.getNoDataMessageFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) "", font59);
        java.awt.Paint paint61 = categoryAxis1.getLabelPaint();
        categoryAxis1.setTickMarkOutsideLength((float) (-2208960000000L));
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.25d + "'", double31 == 0.25d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0.0d + "'", number56.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint4);
        barRenderer3D2.setSeriesOutlinePaint((int) '4', paint4);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot8.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Font font12 = piePlot8.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer3D15.setLegendItemToolTipGenerator(categorySeriesLabelGenerator18);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint22 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint21, paint22);
        barRenderer3D15.setSeriesItemLabelPaint((int) (byte) 100, paint22, false);
        java.awt.Font font27 = barRenderer3D15.getSeriesItemLabelFont((-1));
        java.awt.Paint paint28 = barRenderer3D15.getWallPaint();
        piePlot8.setBaseSectionOutlinePaint(paint28);
        barRenderer3D2.setBaseFillPaint(paint28);
        boolean boolean31 = barRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        double double14 = piePlot12.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot12.getLegendLabelToolTipGenerator();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot12);
        java.awt.Paint paint17 = valueMarker4.getLabelPaint();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        textTitle19.draw(graphics2D20, rectangle2D21);
        textTitle19.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        rectangleInsets26.trim(rectangle2D32);
        textTitle19.draw(graphics2D25, rectangle2D32);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape36, rectangleAnchor37, (double) (byte) 0, 0.0d);
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor37);
        valueMarker4.setLabelAnchor(rectangleAnchor37);
        java.lang.Object obj43 = null;
        boolean boolean44 = valueMarker4.equals(obj43);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25d + "'", double14 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Pie Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list7 = categoryPlot6.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color10 = java.awt.Color.black;
        boolean boolean11 = layer9.equals((java.lang.Object) color10);
        java.util.Collection collection12 = categoryPlot6.getRangeMarkers(layer9);
        int int13 = categoryPlot6.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getFixedAutoRange();
        boolean boolean16 = numberAxis14.isVerticalTickLabels();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis14.setTickMarkStroke(stroke17);
        org.jfree.data.Range range19 = numberAxis14.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets();
        double double22 = rectangleInsets20.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType23 = rectangleInsets20.getUnitType();
        numberAxis14.setLabelInsets(rectangleInsets20);
        java.lang.Object obj25 = numberAxis14.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState28 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo27.getDataArea();
        try {
            stackedBarRenderer3D3.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) numberAxis14, rectangle2D29, 0.35d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str4 = dateTickUnit3.toString();
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Date date9 = dateTickUnit3.addToDate(date6);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone10);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker14.setStartValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = intervalMarker14.getLabelOffset();
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) date9, (java.lang.Object) rectangleInsets17);
        java.lang.Object obj19 = keyedObject18.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str4.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.util.Date date1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        piePlot3.setLegendLabelToolTipGenerator(pieSectionLabelGenerator5);
        java.awt.Font font7 = piePlot3.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        piePlot3.setBaseSectionOutlinePaint(paint23);
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color26 = java.awt.Color.pink;
        java.awt.Color color27 = color26.brighter();
        piePlot3.setSectionPaint((java.lang.Comparable) date25, (java.awt.Paint) color27);
        try {
            org.jfree.data.gantt.Task task29 = new org.jfree.data.gantt.Task("JFreeChart", date1, date25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer7.setBaseOutlinePaint(paint8);
        piePlot1.setSectionPaint((java.lang.Comparable) 86400000L, paint8);
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke18 = null;
        barRenderer3D2.setSeriesOutlineStroke(1, stroke18);
        java.awt.Shape shape21 = barRenderer3D2.getSeriesShape(1);
        org.jfree.chart.LegendItem legendItem24 = barRenderer3D2.getLegendItem(9, (-16777216));
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list27 = categoryPlot26.getAnnotations();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        textTitle30.draw(graphics2D31, rectangle2D32);
        textTitle30.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets();
        double double39 = rectangleInsets37.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState42 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo41.getDataArea();
        rectangleInsets37.trim(rectangle2D43);
        textTitle30.draw(graphics2D36, rectangle2D43);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.setRangeGridlinesVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo52);
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo53.getPlotArea();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean58 = numberAxis57.getAutoRangeIncludesZero();
        numberAxis57.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo63);
        java.awt.geom.Rectangle2D rectangle2D65 = plotRenderingInfo63.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = numberAxis57.java2DToValue((double) (byte) -1, rectangle2D65, rectangleEdge66);
        java.awt.geom.Point2D point2D68 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D65);
        categoryPlot47.zoomDomainAxes(32.0d, (double) ' ', plotRenderingInfo53, point2D68);
        boolean boolean70 = categoryPlot26.render(graphics2D28, rectangle2D43, 7, plotRenderingInfo53);
        java.awt.Font font72 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("", font72);
        textTitle73.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis();
        double double77 = numberAxis76.getFixedAutoRange();
        boolean boolean78 = numberAxis76.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.axis.AxisState axisState80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo81);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState83 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo82);
        java.awt.geom.Rectangle2D rectangle2D84 = plotRenderingInfo82.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        java.util.List list86 = numberAxis76.refreshTicks(graphics2D79, axisState80, rectangle2D84, rectangleEdge85);
        textTitle73.setBounds(rectangle2D84);
        try {
            barRenderer3D2.drawOutline(graphics2D25, categoryPlot26, rectangle2D84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.NEGATIVE_INFINITY + "'", double67 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(list86);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setAutoPopulateSeriesFillPaint(true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        double double7 = piePlot1.getMinimumArcAngleToDraw();
        double double9 = piePlot1.getExplodePercent((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-5d + "'", double7 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13, false);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10.0d, shape19, "({0}, {1}) = {3} - {4}", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]");
        boolean boolean23 = barRenderer3D2.equals((java.lang.Object) shape19);
        java.awt.Paint paint24 = barRenderer3D2.getBaseFillPaint();
        double double25 = barRenderer3D2.getItemMargin();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        double double14 = piePlot12.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot12.getLegendLabelToolTipGenerator();
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot12);
        org.jfree.chart.util.Rotation rotation17 = null;
        try {
            piePlot12.setDirection(rotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25d + "'", double14 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        java.awt.Stroke stroke2 = polarPlot0.getAngleGridlineStroke();
        java.awt.Stroke stroke3 = polarPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        textTitle1.setWidth((double) 3);
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = ganttRenderer0.getIncompletePaint();
        ganttRenderer0.setEndPercent((double) (short) 0);
        ganttRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = defaultIntervalCategoryDataset20.getGroup();
        try {
            int int22 = defaultIntervalCategoryDataset20.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(datasetGroup21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftInset((double) (-35));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        int int4 = color3.getAlpha();
        java.awt.Color color5 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]", color3);
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        barRenderer3D9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator12);
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint16);
        barRenderer3D9.setSeriesItemLabelPaint((int) (byte) 100, paint16, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer3D9.setBaseItemLabelGenerator(categoryItemLabelGenerator20, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color23.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        barRenderer3D9.setBaseOutlinePaint((java.awt.Paint) color23);
        float[] floatArray35 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray36 = color23.getRGBComponents(floatArray35);
        float[] floatArray37 = color0.getColorComponents(colorSpace6, floatArray35);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#00c000" + "'", str1.equals("#00c000"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        java.util.List list3 = defaultKeyedValues2D1.getColumnKeys();
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D1.getRowKey((-35));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Stroke stroke6 = ringPlot4.getSeparatorStroke();
        ringPlot4.setShadowXOffset(0.05d);
        double double9 = ringPlot4.getOuterSeparatorExtension();
        java.awt.Color color10 = java.awt.Color.gray;
        ringPlot4.setSeparatorPaint((java.awt.Paint) color10);
        double double12 = ringPlot4.getInnerSeparatorExtension();
        java.awt.Paint paint13 = ringPlot4.getLabelPaint();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]");
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax(0.35d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getPaint();
        double double3 = textTitle1.getHeight();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        boolean boolean6 = piePlot5.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot5.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        java.awt.Font font9 = piePlot5.getLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer11.setBaseOutlinePaint(paint12);
        piePlot5.setSectionPaint((java.lang.Comparable) 86400000L, paint12);
        textTitle1.setBackgroundPaint(paint12);
        textTitle1.setWidth(Double.NEGATIVE_INFINITY);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        try {
            textTitle1.setVerticalAlignment(verticalAlignment18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D2.setBaseFillPaint((java.awt.Paint) color27, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator31 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D2.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator31);
        barRenderer3D2.setBaseCreateEntities(true);
        barRenderer3D2.setMinimumBarLength((double) 12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer3D2.getSeriesNegativeItemLabelPosition((int) (short) -1);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.Arrangement arrangement22 = blockContainer21.getArrangement();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection23 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection23);
        taskSeriesCollection23.removeAll();
        boolean boolean26 = blockContainer21.equals((java.lang.Object) taskSeriesCollection23);
        java.lang.Object obj27 = blockContainer21.clone();
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrangement22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Color color2 = java.awt.Color.getColor("poly", 7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer3D11.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        barRenderer3D11.setBaseOutlinePaint((java.awt.Paint) color25);
        float[] floatArray37 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray38 = color25.getRGBComponents(floatArray37);
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("ThreadContext", font8, (java.awt.Paint) color25);
        lineAndShapeRenderer5.setSeriesItemLabelPaint(255, (java.awt.Paint) color25, true);
        int int42 = color25.getRGB();
        java.awt.color.ColorSpace colorSpace43 = color25.getColorSpace();
        float[] floatArray46 = new float[] { ' ', '4' };
        try {
            float[] floatArray47 = color2.getComponents(colorSpace43, floatArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-12566273) + "'", int42 == (-12566273));
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertNotNull(floatArray46);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot1.removeChangeListener(plotChangeListener6);
        float float8 = piePlot1.getForegroundAlpha();
        java.awt.Paint paint10 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.2d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        piePlot1.notifyListeners(plotChangeEvent11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.getAutoRangeIncludesZero();
        numberAxis5.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis5.java2DToValue((double) (byte) -1, rectangle2D13, rectangleEdge14);
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D13);
        boolean boolean17 = categoryLabelPositions2.equals((java.lang.Object) 0);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.configure();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.NEGATIVE_INFINITY + "'", double15 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1577865599999L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) "DateTickUnit[HOUR, -457]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint3);
        minMaxCategoryRenderer0.setSeriesItemLabelPaint(0, paint3);
        javax.swing.Icon icon6 = minMaxCategoryRenderer0.getObjectIcon();
        minMaxCategoryRenderer0.setDrawLines(true);
        minMaxCategoryRenderer0.setBaseItemLabelsVisible(true, false);
        int int12 = minMaxCategoryRenderer0.getPassCount();
        minMaxCategoryRenderer0.setDrawLines(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(icon6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        boolean boolean2 = areaRenderer0.isSeriesItemLabelsVisible(0);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        areaRenderer0.setBasePaint(paint3, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-12566273), (float) 'a');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        java.lang.String str4 = dateTickUnit3.toString();
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Date date9 = dateTickUnit3.addToDate(date6);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone10);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker14.setStartValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = intervalMarker14.getLabelOffset();
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) date9, (java.lang.Object) rectangleInsets17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis20.setLowerMargin(0.0d);
        keyedObject18.setObject((java.lang.Object) categoryAxis20);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        boolean boolean27 = piePlot26.isCircular();
        double double28 = piePlot26.getInteriorGap();
        java.awt.Font font29 = piePlot26.getNoDataMessageFont();
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray32, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray34);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font29, (org.jfree.chart.plot.Plot) multiplePiePlot36, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        java.awt.image.BufferedImage bufferedImage42 = jFreeChart38.createBufferedImage(5, 9, chartRenderingInfo41);
        jFreeChart38.clearSubtitles();
        org.jfree.chart.plot.Plot plot44 = jFreeChart38.getPlot();
        boolean boolean45 = categoryAxis20.hasListener((java.util.EventListener) jFreeChart38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[HOUR, -457]" + "'", str4.equals("DateTickUnit[HOUR, -457]"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.25d + "'", double28 == 0.25d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNotNull(bufferedImage42);
        org.junit.Assert.assertNotNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("GradientPaintTransformType.HORIZONTAL", (org.jfree.data.time.TimePeriod) year1);
        int int4 = task3.getSubtaskCount();
        java.lang.Object obj5 = task3.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double[] doubleArray4 = new double[] { (short) 0, 1577865599999L };
        double[] doubleArray7 = new double[] { (short) 0, 1577865599999L };
        double[] doubleArray10 = new double[] { (short) 0, 1577865599999L };
        double[] doubleArray13 = new double[] { (short) 0, 1577865599999L };
        double[] doubleArray16 = new double[] { (short) 0, 1577865599999L };
        double[] doubleArray19 = new double[] { (short) 0, 1577865599999L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Pie Plot", doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.LegendItem legendItem17 = barRenderer3D2.getLegendItem(0, (int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list19 = categoryPlot18.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color22 = java.awt.Color.black;
        boolean boolean23 = layer21.equals((java.lang.Object) color22);
        java.util.Collection collection24 = categoryPlot18.getRangeMarkers(layer21);
        double double25 = categoryPlot18.getRangeCrosshairValue();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        boolean boolean29 = piePlot28.isCircular();
        double double30 = piePlot28.getInteriorGap();
        java.awt.Font font31 = piePlot28.getNoDataMessageFont();
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray34, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset37);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font31, (org.jfree.chart.plot.Plot) multiplePiePlot38, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        java.awt.image.BufferedImage bufferedImage44 = jFreeChart40.createBufferedImage(5, 9, chartRenderingInfo43);
        categoryPlot18.setBackgroundImage((java.awt.Image) bufferedImage44);
        categoryPlot18.setRangeCrosshairValue((double) 100L);
        barRenderer3D2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot18);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.25d + "'", double30 == 0.25d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(bufferedImage44);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        barRenderer3D5.setLegendItemToolTipGenerator(categorySeriesLabelGenerator8);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal(paint11, paint12);
        barRenderer3D5.setSeriesItemLabelPaint((int) (byte) 100, paint12, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer3D5.setBaseItemLabelGenerator(categoryItemLabelGenerator16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color19.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        barRenderer3D5.setBaseOutlinePaint((java.awt.Paint) color19);
        float[] floatArray31 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray32 = color19.getRGBComponents(floatArray31);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("ThreadContext", font2, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment34 = textLine33.getFirstTextFragment();
        java.awt.Font font35 = textFragment34.getFont();
        java.awt.Paint paint37 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer38 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke39 = minMaxCategoryRenderer38.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint37, stroke39);
        org.jfree.chart.text.TextAnchor textAnchor41 = valueMarker40.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font45 = intervalMarker44.getLabelFont();
        valueMarker40.setLabelFont(font45);
        org.jfree.data.general.PieDataset pieDataset47 = null;
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot(pieDataset47);
        boolean boolean49 = piePlot48.isCircular();
        double double50 = piePlot48.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator51 = piePlot48.getLegendLabelToolTipGenerator();
        valueMarker40.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot48);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]", font35, (org.jfree.chart.plot.Plot) piePlot48, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        try {
            jFreeChart54.plotChanged(plotChangeEvent55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(textFragment34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.25d + "'", double50 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator51);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = rendererChangeEvent1.getType();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.String str1 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Pie 3D Plot" + "'", str1.equals("Pie 3D Plot"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        int int1 = areaRenderer0.getPassCount();
        java.lang.Object obj2 = areaRenderer0.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        areaRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator4, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint9);
        java.lang.String str11 = seriesChangeEvent10.toString();
        taskSeriesCollection0.seriesChanged(seriesChangeEvent10);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=java.awt.Color[r=0,g=0,b=255]]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) classLoader1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertNull(classLoader1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(100);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke18 = null;
        barRenderer3D2.setSeriesOutlineStroke(1, stroke18);
        int int20 = barRenderer3D2.getPassCount();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = barRenderer3D2.getGradientPaintTransformer();
        int int22 = barRenderer3D2.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer3D2.getSeriesNegativeItemLabelPosition(15);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean26 = itemLabelPosition24.equals((java.lang.Object) stroke25);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer3D8.setBaseItemLabelGenerator(categoryItemLabelGenerator19, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = color22.createContext(colorModel23, rectangle24, rectangle2D25, affineTransform26, renderingHints27);
        barRenderer3D8.setBaseOutlinePaint((java.awt.Paint) color22);
        float[] floatArray34 = new float[] { (byte) 1, (-1L), '4', (-1L) };
        float[] floatArray35 = color22.getRGBComponents(floatArray34);
        org.jfree.chart.text.TextLine textLine36 = new org.jfree.chart.text.TextLine("ThreadContext", font5, (java.awt.Paint) color22);
        lineAndShapeRenderer2.setSeriesItemLabelPaint(255, (java.awt.Paint) color22, true);
        java.lang.Boolean boolean40 = lineAndShapeRenderer2.getSeriesShapesFilled((int) 'a');
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNull(boolean40);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint2 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean3 = org.jfree.chart.util.PaintUtilities.equal(paint1, paint2);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list5 = defaultStatisticalCategoryDataset4.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint2, (org.jfree.data.general.Dataset) pieDataset7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset7);
        boolean boolean10 = lengthConstraintType0.equals((java.lang.Object) pieDataset7);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        waterfallBarRenderer0.setLastBarPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color7 = java.awt.Color.black;
        boolean boolean8 = layer6.equals((java.lang.Object) color7);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer6);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("First");
        java.lang.Object obj10 = standardCategorySeriesLabelGenerator9.clone();
        lineAndShapeRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 12);
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.Object obj2 = numberAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.trimHeight((double) 1L);
        numberAxis0.setTickLabelInsets(rectangleInsets3);
        numberAxis0.setLabelToolTip("9-April-1900");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("DateTickUnit[HOUR, -457]", font1, paint2, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        barRenderer3D2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        polarPlot11.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        double double14 = numberAxis13.getFixedAutoRange();
        boolean boolean15 = numberAxis13.isVerticalTickLabels();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis13.setTickMarkStroke(stroke16);
        polarPlot11.setAngleGridlineStroke(stroke16);
        barRenderer3D2.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        int int20 = polarPlot11.getSeriesCount();
        java.awt.Stroke stroke21 = polarPlot11.getRadiusGridlineStroke();
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        textTitle21.draw(graphics2D22, rectangle2D23);
        textTitle21.setExpandToFitSpace(true);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets();
        double double30 = rectangleInsets28.calculateBottomInset((double) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        rectangleInsets28.trim(rectangle2D34);
        textTitle21.draw(graphics2D27, rectangle2D34);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape38, rectangleAnchor39, (double) (byte) 0, 0.0d);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor39);
        java.awt.geom.Point2D point2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        try {
            jFreeChart14.draw(graphics2D19, rectangle2D34, point2D44, chartRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke3);
        numberAxis0.setLowerBound((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis1.setTickUnit(dateTickUnit4, false, false);
        double double8 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint5 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        statisticalLineAndShapeRenderer2.setBaseShapesFilled(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getItemCreateEntity((int) (byte) 100, 9);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        java.awt.Stroke stroke26 = barRenderer3D2.getSeriesOutlineStroke(1);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray31);
        org.jfree.data.Range range33 = barRenderer3D2.findRangeBounds(categoryDataset32);
        java.awt.Paint paint35 = barRenderer3D2.lookupSeriesPaint(15);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer3D2.setBaseOutlineStroke(stroke36, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer3D2.getSeriesPositiveItemLabelPosition(12);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer3D2.setBaseStroke(stroke41);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean48 = stackedBarRenderer3D47.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D47.setItemMargin((double) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer52.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem57 = lineAndShapeRenderer52.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = lineAndShapeRenderer52.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D47.setSeriesPositiveItemLabelPosition(0, itemLabelPosition58);
        barRenderer3D2.setSeriesPositiveItemLabelPosition(2, itemLabelPosition58, true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(legendItem57);
        org.junit.Assert.assertNotNull(itemLabelPosition58);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getStartValue((int) ' ', 2958465, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setItemMargin((double) 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean14 = numberAxis13.getAutoRangeIncludesZero();
        numberAxis13.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis13.java2DToValue((double) (byte) -1, rectangle2D21, rectangleEdge22);
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D21);
        lineBorder9.draw(graphics2D10, rectangle2D21);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D21, (double) 0L, (float) 255, (float) (short) 1);
        stackedBarRenderer3D3.setBaseShape((java.awt.Shape) rectangle2D21, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.NEGATIVE_INFINITY + "'", double23 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        java.awt.Font font20 = barRenderer3D8.getSeriesItemLabelFont((-1));
        java.awt.Paint paint21 = barRenderer3D8.getWallPaint();
        piePlot1.setBaseSectionOutlinePaint(paint21);
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer25 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke26 = minMaxCategoryRenderer25.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint24, stroke26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean30 = piePlot29.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = null;
        piePlot29.setLegendLabelToolTipGenerator(pieSectionLabelGenerator31);
        java.awt.Font font33 = piePlot29.getLabelFont();
        java.awt.Paint paint34 = piePlot29.getNoDataMessagePaint();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot29.setSectionOutlineStroke((java.lang.Comparable) 2, stroke36);
        valueMarker27.setOutlineStroke(stroke36);
        piePlot1.setLabelLinkStroke(stroke36);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.trimHeight((double) 1L);
        java.awt.Paint paint43 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder44 = new org.jfree.chart.block.BlockBorder(rectangleInsets40, paint43);
        java.awt.Paint paint45 = blockBorder44.getPaint();
        piePlot1.setLabelShadowPaint(paint45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-1.0d) + "'", double42 == (-1.0d));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.35d);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-35), (java.lang.Number) 0.0f, (java.lang.Comparable) (-2208960000000L), (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
        java.lang.Number number12 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 100.0d, (java.lang.Comparable) "Other");
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 4, (java.lang.Comparable) 0L);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        int int7 = categoryPlot0.getWeight();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.util.List list3 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Object obj4 = defaultKeyedValues2D1.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean14 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11, 9);
        defaultKeyedValues2D1.setValue((java.lang.Number) 15, (java.lang.Comparable) spreadsheetDate7, (java.lang.Comparable) 0.05d);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        java.util.Date date18 = dateRange17.getUpperDate();
        try {
            defaultKeyedValues2D1.removeValue((java.lang.Comparable) date18, (java.lang.Comparable) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D3.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer3D3.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D11.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = null;
        barRenderer3D11.setLegendItemToolTipGenerator(categorySeriesLabelGenerator14);
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean19 = org.jfree.chart.util.PaintUtilities.equal(paint17, paint18);
        barRenderer3D11.setSeriesItemLabelPaint((int) (byte) 100, paint18, false);
        java.awt.Font font23 = barRenderer3D11.getSeriesItemLabelFont((-1));
        java.awt.Paint paint24 = barRenderer3D11.getWallPaint();
        boolean boolean25 = barRenderer3D3.equals((java.lang.Object) barRenderer3D11);
        barRenderer3D11.setDrawBarOutline(true);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        boolean boolean31 = piePlot30.isCircular();
        java.awt.Paint paint32 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint33 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal(paint32, paint33);
        piePlot30.setBaseSectionPaint(paint32);
        java.lang.Object obj36 = piePlot30.clone();
        org.jfree.chart.plot.Plot plot37 = piePlot30.getParent();
        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot30.setLabelFont(font38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.trimHeight((double) 1L);
        java.awt.Paint paint43 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder44 = new org.jfree.chart.block.BlockBorder(rectangleInsets40, paint43);
        piePlot30.setBackgroundPaint(paint43);
        java.awt.Font font46 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean47 = piePlot30.equals((java.lang.Object) font46);
        barRenderer3D11.setSeriesItemLabelFont((int) '4', font46);
        java.awt.Color color50 = java.awt.Color.BLACK;
        java.awt.Color color51 = java.awt.Color.getColor("Other", color50);
        org.jfree.chart.text.TextFragment textFragment52 = new org.jfree.chart.text.TextFragment("", font46, (java.awt.Paint) color50);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-1.0d) + "'", double42 == (-1.0d));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        taskSeriesCollection1.removeAll();
        int int4 = taskSeriesCollection1.getRowCount();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj7 = dateAxis6.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis6.setTickUnit(dateTickUnit10);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection1, (java.lang.Comparable) dateTickUnit10);
        java.lang.String str13 = legendItemBlockContainer12.getURLText();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.plot.Plot plot15 = jFreeChart14.getPlot();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("", font18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState23 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo22.getDataArea();
        textTitle19.draw(graphics2D20, rectangle2D24);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D24, paint26);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean31 = numberAxis30.getAutoRangeIncludesZero();
        numberAxis30.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState37 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo36.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis30.java2DToValue((double) (byte) -1, rectangle2D38, rectangleEdge39);
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        try {
            jFreeChart14.draw(graphics2D16, rectangle2D24, point2D41, chartRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.NEGATIVE_INFINITY + "'", double40 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean11 = piePlot10.isCircular();
        double double12 = piePlot10.getInteriorGap();
        java.awt.Font font13 = piePlot10.getNoDataMessageFont();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font13, (org.jfree.chart.plot.Plot) multiplePiePlot20, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart22.createBufferedImage(5, 9, chartRenderingInfo25);
        categoryPlot0.setBackgroundImage((java.awt.Image) bufferedImage26);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection29 = categoryPlot0.getRangeMarkers(layer28);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.25d + "'", double12 == 0.25d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean7 = valueMarker4.equals((java.lang.Object) minMaxCategoryRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.JFreeChart jFreeChart9 = markerChangeEvent8.getChart();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jFreeChart9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        piePlot1.setIgnoreNullValues(false);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isCircular();
        double double14 = piePlot12.getInteriorGap();
        java.awt.Font font15 = piePlot12.getNoDataMessageFont();
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray18, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font15, (org.jfree.chart.plot.Plot) multiplePiePlot22, false);
        piePlot1.setLabelFont(font15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25d + "'", double14 == 0.25d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        int int7 = categoryPlot0.getWeight();
        int int8 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.util.List list10 = boxAndWhiskerItem9.getOutliers();
        java.lang.Number number11 = boxAndWhiskerItem9.getMinOutlier();
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3 + "'", number11.equals(3));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isCircular();
        double double8 = piePlot6.getInteriorGap();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) horizontalAlignment0, (java.lang.Object) piePlot6);
        java.awt.Stroke stroke10 = piePlot6.getOutlineStroke();
        org.jfree.chart.util.Rotation rotation11 = null;
        try {
            piePlot6.setDirection(rotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.25d + "'", double8 == 0.25d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("poly");
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (-1.0d), true);
        boolean boolean4 = stackedBarRenderer3D3.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D3.setItemMargin((double) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = stackedBarRenderer3D3.getBaseNegativeItemLabelPosition();
        double double8 = stackedBarRenderer3D3.getBase();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer3D2.setLegendItemToolTipGenerator(categorySeriesLabelGenerator5);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint9);
        barRenderer3D2.setSeriesItemLabelPaint((int) (byte) 100, paint9, false);
        java.awt.Font font14 = barRenderer3D2.getSeriesItemLabelFont((-1));
        barRenderer3D2.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = barRenderer3D2.hasListener(eventListener17);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D2.setBaseFillPaint(paint19);
        barRenderer3D2.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D27 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D27.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer3D27.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D35 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D35.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = null;
        barRenderer3D35.setLegendItemToolTipGenerator(categorySeriesLabelGenerator38);
        java.awt.Paint paint41 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint42 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean43 = org.jfree.chart.util.PaintUtilities.equal(paint41, paint42);
        barRenderer3D35.setSeriesItemLabelPaint((int) (byte) 100, paint42, false);
        java.awt.Font font47 = barRenderer3D35.getSeriesItemLabelFont((-1));
        java.awt.Paint paint48 = barRenderer3D35.getWallPaint();
        boolean boolean49 = barRenderer3D27.equals((java.lang.Object) barRenderer3D35);
        java.awt.Stroke stroke51 = barRenderer3D27.getSeriesOutlineStroke(1);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D27.setBaseFillPaint((java.awt.Paint) color52, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator56 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D27.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator56);
        java.lang.Object obj58 = intervalCategoryToolTipGenerator56.clone();
        barRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator56, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D63 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D63.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = barRenderer3D63.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D71 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D71.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator74 = null;
        barRenderer3D71.setLegendItemToolTipGenerator(categorySeriesLabelGenerator74);
        java.awt.Paint paint77 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint78 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean79 = org.jfree.chart.util.PaintUtilities.equal(paint77, paint78);
        barRenderer3D71.setSeriesItemLabelPaint((int) (byte) 100, paint78, false);
        java.awt.Font font83 = barRenderer3D71.getSeriesItemLabelFont((-1));
        java.awt.Paint paint84 = barRenderer3D71.getWallPaint();
        boolean boolean85 = barRenderer3D63.equals((java.lang.Object) barRenderer3D71);
        java.awt.Stroke stroke87 = barRenderer3D63.getSeriesOutlineStroke(1);
        double[] doubleArray90 = new double[] {};
        double[] doubleArray91 = new double[] {};
        double[][] doubleArray92 = new double[][] { doubleArray90, doubleArray91 };
        org.jfree.data.category.CategoryDataset categoryDataset93 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray92);
        org.jfree.data.Range range94 = barRenderer3D63.findRangeBounds(categoryDataset93);
        try {
            java.lang.String str96 = intervalCategoryToolTipGenerator56.generateColumnLabel(categoryDataset93, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(font47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(itemLabelPosition68);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNull(font83);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNull(stroke87);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(categoryDataset93);
        org.junit.Assert.assertNull(range94);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.awt.Color color1 = java.awt.Color.getColor("First");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj2 = dateAxis1.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis1.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) (-35));
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        double double15 = numberAxis14.getFixedAutoRange();
        boolean boolean16 = numberAxis14.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = numberAxis14.refreshTicks(graphics2D17, axisState18, rectangle2D22, rectangleEdge23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis9.getCategoryEnd((int) (byte) -1, 0, rectangle2D22, rectangleEdge25);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double29 = dateAxis1.valueToJava2D((double) 0.5f, rectangle2D22, rectangleEdge28);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Other");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getFixedAutoRange();
        numberAxis2.setLabelAngle((double) 0L);
        java.lang.Object obj6 = numberAxis2.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis2.getTickUnit();
        int int8 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) numberTickUnit7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) numberTickUnit14);
        org.jfree.data.gantt.TaskSeries taskSeries16 = null;
        try {
            taskSeriesCollection0.remove(taskSeries16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number5, (java.lang.Number) 3, (java.lang.Number) 100.0d, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMaxRegularValue();
        java.lang.String str11 = boxAndWhiskerItem9.toString();
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        java.lang.String str11 = valueMarker4.getLabel();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        java.awt.Paint paint6 = valueMarker4.getPaint();
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke10 = minMaxCategoryRenderer9.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint8, stroke10);
        double double12 = valueMarker11.getValue();
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean14 = valueMarker11.equals((java.lang.Object) minMaxCategoryRenderer13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        boolean boolean17 = piePlot16.isCircular();
        double double18 = piePlot16.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot16.getLegendLabelToolTipGenerator();
        java.awt.Font font20 = piePlot16.getLabelFont();
        piePlot16.setShadowXOffset(0.35d);
        org.jfree.chart.plot.Plot plot23 = null;
        piePlot16.setParent(plot23);
        java.awt.Stroke stroke25 = piePlot16.getLabelLinkStroke();
        minMaxCategoryRenderer13.setGroupStroke(stroke25);
        valueMarker4.setOutlineStroke(stroke25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.25d + "'", double18 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.lang.Number number24 = null;
        java.util.List list27 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem28 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number24, (java.lang.Number) 3, (java.lang.Number) 100.0d, list27);
        java.lang.Number number29 = boxAndWhiskerItem28.getMinRegularValue();
        boolean boolean30 = jFreeChart14.equals((java.lang.Object) number29);
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart14.getLegend((int) ' ');
        org.jfree.chart.plot.Plot plot33 = jFreeChart14.getPlot();
        int int34 = jFreeChart14.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints35 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(legendTitle32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        numberAxis0.setLabelAngle((double) 0L);
        java.lang.Object obj4 = numberAxis0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis0.getTickUnit();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("", font8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        textTitle9.draw(graphics2D10, rectangle2D14);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) rectangle2D14, paint16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double19 = numberAxis0.lengthToJava2D((double) 2.0f, rectangle2D14, rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        int int2 = defaultKeyedValues2D0.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = ganttRenderer0.getIncompletePaint();
        double double12 = ganttRenderer0.getEndPercent();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = ganttRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.65d + "'", double12 == 0.65d);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        boolean boolean4 = lineAndShapeRenderer0.equals((java.lang.Object) color3);
        lineAndShapeRenderer0.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearRangeMarkers((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset((int) (short) 1);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.Number number6 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list9 = defaultStatisticalCategoryDataset8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 0.0f, (java.lang.Number) (-1), (java.lang.Number) (-16777216), (java.lang.Number) 32.0d, (java.lang.Number) 2958465, (java.lang.Number) 2.0d, number6, (java.lang.Number) 1.0d, list9);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D43 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D43.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = barRenderer3D43.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D51 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D51.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator54 = null;
        barRenderer3D51.setLegendItemToolTipGenerator(categorySeriesLabelGenerator54);
        java.awt.Paint paint57 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint58 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean59 = org.jfree.chart.util.PaintUtilities.equal(paint57, paint58);
        barRenderer3D51.setSeriesItemLabelPaint((int) (byte) 100, paint58, false);
        java.awt.Font font63 = barRenderer3D51.getSeriesItemLabelFont((-1));
        java.awt.Paint paint64 = barRenderer3D51.getWallPaint();
        boolean boolean65 = barRenderer3D43.equals((java.lang.Object) barRenderer3D51);
        barRenderer3D51.setDrawBarOutline(true);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot piePlot70 = new org.jfree.chart.plot.PiePlot(pieDataset69);
        boolean boolean71 = piePlot70.isCircular();
        java.awt.Paint paint72 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint73 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean74 = org.jfree.chart.util.PaintUtilities.equal(paint72, paint73);
        piePlot70.setBaseSectionPaint(paint72);
        java.lang.Object obj76 = piePlot70.clone();
        org.jfree.chart.plot.Plot plot77 = piePlot70.getParent();
        java.awt.Font font78 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot70.setLabelFont(font78);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = new org.jfree.chart.util.RectangleInsets();
        double double82 = rectangleInsets80.trimHeight((double) 1L);
        java.awt.Paint paint83 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder84 = new org.jfree.chart.block.BlockBorder(rectangleInsets80, paint83);
        piePlot70.setBackgroundPaint(paint83);
        java.awt.Font font86 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean87 = piePlot70.equals((java.lang.Object) font86);
        barRenderer3D51.setSeriesItemLabelFont((int) '4', font86);
        textTitle24.setFont(font86);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(font63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNull(plot77);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + (-1.0d) + "'", double82 == (-1.0d));
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.calculateTopOutset((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.lang.Number number24 = null;
        java.util.List list27 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem28 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number24, (java.lang.Number) 3, (java.lang.Number) 100.0d, list27);
        java.lang.Number number29 = boxAndWhiskerItem28.getMinRegularValue();
        boolean boolean30 = jFreeChart14.equals((java.lang.Object) number29);
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart14.getLegend((int) ' ');
        org.jfree.chart.plot.Plot plot33 = jFreeChart14.getPlot();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint36 = textTitle35.getPaint();
        double double37 = textTitle35.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent38 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle35);
        org.jfree.chart.title.Title title39 = titleChangeEvent38.getTitle();
        jFreeChart14.titleChanged(titleChangeEvent38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        try {
            jFreeChart14.handleClick((-1), (int) (byte) 100, chartRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(legendTitle32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(title39);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        double double5 = valueMarker4.getValue();
        java.awt.Stroke stroke6 = valueMarker4.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP;
        valueMarker4.setLabelAnchor(rectangleAnchor7);
        java.lang.String str9 = valueMarker4.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = plotRenderingInfo1.getSubplotInfo(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color7 = java.awt.Color.black;
        boolean boolean8 = layer6.equals((java.lang.Object) color7);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer6);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getFixedLegendItems();
        java.lang.Object obj11 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = rangeType0.equals(obj2);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 5 };
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Number[][] numberArray4 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 3600000L, (short) -1, 7, 1.0f, 0.25d, (short) 10 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray11, numberArray18 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray1, (java.lang.Comparable[]) strArray3, numberArray4, numberArray19);
        int int21 = defaultIntervalCategoryDataset20.getCategoryCount();
        java.util.List list22 = defaultIntervalCategoryDataset20.getRowKeys();
        try {
            java.lang.Object obj23 = defaultIntervalCategoryDataset20.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot1.addChangeListener(plotChangeListener7);
        piePlot1.setShadowXOffset((double) 100L);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        barRenderer3D13.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        java.awt.Paint paint19 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint20 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint19, paint20);
        barRenderer3D13.setSeriesItemLabelPaint((int) (byte) 100, paint20, false);
        piePlot1.setBaseSectionOutlinePaint(paint20);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator4);
        java.awt.Font font6 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isCircular();
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        piePlot8.setBaseSectionPaint(paint10);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setLabelPaint(paint14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker19.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        boolean boolean24 = intervalMarker19.equals((java.lang.Object) textTitle23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle23.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("GradientPaintTransformType.CENTER_HORIZONTAL", font6, paint14, rectangleEdge16, horizontalAlignment25, verticalAlignment26, rectangleInsets27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        double double31 = numberAxis30.getFixedAutoRange();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis30.setTickLabelFont(font32);
        boolean boolean34 = rectangleEdge16.equals((java.lang.Object) numberAxis30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer0.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        java.lang.String str8 = itemLabelAnchor7.toString();
        java.lang.String str9 = itemLabelAnchor7.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke14 = minMaxCategoryRenderer13.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint12, stroke14);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker15.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor16, textAnchor17, (double) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition20.getTextAnchor();
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition20, true);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ItemLabelAnchor.OUTSIDE4" + "'", str8.equals("ItemLabelAnchor.OUTSIDE4"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ItemLabelAnchor.OUTSIDE4" + "'", str9.equals("ItemLabelAnchor.OUTSIDE4"));
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor21);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color7 = java.awt.Color.black;
        boolean boolean8 = layer6.equals((java.lang.Object) color7);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer6);
        categoryPlot0.clearDomainMarkers(0);
        java.lang.Object obj12 = categoryPlot0.clone();
        categoryPlot0.setDomainGridlinesVisible(false);
        boolean boolean15 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("#00c000");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        java.util.List list4 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        double double10 = numberAxis9.getFixedAutoRange();
        numberAxis9.setLabelAngle((double) 0L);
        java.lang.Object obj13 = numberAxis9.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis9.getTickUnit();
        int int15 = taskSeriesCollection7.getRowIndex((java.lang.Comparable) numberTickUnit14);
        defaultCategoryDataset4.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) int15, (java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=3.0]");
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE4", "hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Comparable) (byte) 0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        boolean boolean25 = barRenderer3D24.getAutoPopulateSeriesStroke();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        boolean boolean29 = piePlot28.isCircular();
        double double30 = piePlot28.getInteriorGap();
        java.awt.Font font31 = piePlot28.getNoDataMessageFont();
        barRenderer3D24.setSeriesItemLabelFont((int) (short) 100, font31, false);
        java.awt.Font font36 = barRenderer3D24.getItemLabelFont((-1), (int) (byte) 100);
        boolean boolean37 = legendItemEntity21.equals((java.lang.Object) (byte) 100);
        org.jfree.data.general.Dataset dataset38 = legendItemEntity21.getDataset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.25d + "'", double30 == 0.25d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(dataset38);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D2.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D10.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        barRenderer3D10.setLegendItemToolTipGenerator(categorySeriesLabelGenerator13);
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean18 = org.jfree.chart.util.PaintUtilities.equal(paint16, paint17);
        barRenderer3D10.setSeriesItemLabelPaint((int) (byte) 100, paint17, false);
        java.awt.Font font22 = barRenderer3D10.getSeriesItemLabelFont((-1));
        java.awt.Paint paint23 = barRenderer3D10.getWallPaint();
        boolean boolean24 = barRenderer3D2.equals((java.lang.Object) barRenderer3D10);
        int int25 = barRenderer3D2.getPassCount();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getFixedAutoRange();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D8, rectangleEdge9);
        boolean boolean11 = numberAxis0.isVisible();
        float float12 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.getAutoRangeIncludesZero();
        numberAxis10.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis10.java2DToValue((double) (byte) -1, rectangle2D18, rectangleEdge19);
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D18);
        lineBorder6.draw(graphics2D7, rectangle2D18);
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder6);
        java.awt.Paint paint24 = lineBorder6.getPaint();
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        polarPlot25.clearCornerTextItems();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        numberAxis27.setTickMarkStroke(stroke30);
        polarPlot25.setAngleGridlineStroke(stroke30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        polarPlot25.setDataset(xYDataset33);
        java.awt.Stroke stroke35 = polarPlot25.getAngleGridlineStroke();
        java.awt.Color color36 = java.awt.Color.BLUE;
        int int37 = color36.getAlpha();
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint24, stroke35, (java.awt.Paint) color36, stroke38, 0.0f);
        java.io.ObjectOutputStream objectOutputStream41 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke38, objectOutputStream41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.NEGATIVE_INFINITY + "'", double20 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "hi!", (java.lang.Number) 100.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.String str1 = numberAxis3D0.getLabelToolTip();
        numberAxis3D0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        intervalMarker2.setStartValue((double) (-1.0f));
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) textTitle6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle6.getPadding();
        double double10 = rectangleInsets8.calculateTopInset(10.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-35));
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal(paint14, paint15);
        barRenderer3D8.setSeriesItemLabelPaint((int) (byte) 100, paint15, false);
        java.awt.Font font20 = barRenderer3D8.getSeriesItemLabelFont((-1));
        barRenderer3D8.setItemLabelAnchorOffset((double) (-1));
        java.awt.Stroke stroke24 = null;
        barRenderer3D8.setSeriesOutlineStroke(1, stroke24);
        boolean boolean26 = categoryAxis1.equals((java.lang.Object) stroke24);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis1.setTickMarkPaint(paint27);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(font20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("1");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setLabelPaint(paint7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        float float10 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean8 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, 9);
        java.lang.String str9 = spreadsheetDate1.toString();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate1.getFollowingDayOfWeek(3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color8 = java.awt.Color.black;
        boolean boolean9 = layer7.equals((java.lang.Object) color8);
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) boolean9);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 5);
        statisticalLineAndShapeRenderer2.setDrawOutlines(true);
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(0, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str5 = projectInfo4.getName();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=32.0]"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D4.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer3D4.setLegendItemToolTipGenerator(categorySeriesLabelGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean12 = org.jfree.chart.util.PaintUtilities.equal(paint10, paint11);
        barRenderer3D4.setSeriesItemLabelPaint((int) (byte) 100, paint11, false);
        java.awt.Font font16 = barRenderer3D4.getSeriesItemLabelFont((-1));
        barRenderer3D4.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = barRenderer3D4.hasListener(eventListener19);
        barRenderer3D4.setItemLabelAnchorOffset((double) 0L);
        java.awt.Paint paint25 = barRenderer3D4.getItemOutlinePaint(15, 0);
        categoryPlot0.setRangeCrosshairPaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean3 = numberAxis2.getAutoRangeIncludesZero();
        numberAxis2.resizeRange(100.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo8.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis2.java2DToValue((double) (byte) -1, rectangle2D10, rectangleEdge11);
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 0, (double) 0, rectangle2D10);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D13, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis(3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 0, 0.0d);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        boolean boolean5 = piePlot4.isCircular();
        double double6 = piePlot4.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot4.getLegendLabelToolTipGenerator();
        java.awt.Font font8 = piePlot4.getLabelFont();
        boolean boolean9 = size2D2.equals((java.lang.Object) piePlot4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextFillPaint();
        java.awt.Shape shape12 = defaultDrawingSupplier10.getNextShape();
        java.awt.Stroke stroke13 = defaultDrawingSupplier10.getNextStroke();
        piePlot4.setBaseSectionOutlineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.25d + "'", double6 == 0.25d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 255);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor6);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.CATEGORY", graphics2D1, 2.0f, (float) 1, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        outlierListCollection0.setHighFarOut(true);
        java.util.Iterator iterator5 = outlierListCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color4 = java.awt.Color.black;
        boolean boolean5 = layer3.equals((java.lang.Object) color4);
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke3 = minMaxCategoryRenderer2.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.0d);
        java.awt.Font font9 = intervalMarker8.getLabelFont();
        valueMarker4.setLabelFont(font9);
        java.lang.String str11 = valueMarker4.getLabel();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        valueMarker4.addChangeListener((org.jfree.chart.event.MarkerChangeListener) multiplePiePlot13);
        float float15 = valueMarker4.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot2.rendererChanged(rendererChangeEvent3);
        java.lang.String str5 = waferMapPlot2.getPlotType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.clear();
        int int2 = defaultKeyedValues2D0.getRowCount();
        defaultKeyedValues2D0.clear();
        defaultKeyedValues2D0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        java.lang.Number number24 = null;
        java.util.List list27 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem28 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number24, (java.lang.Number) 3, (java.lang.Number) 100.0d, list27);
        java.lang.Number number29 = boxAndWhiskerItem28.getMinRegularValue();
        boolean boolean30 = jFreeChart14.equals((java.lang.Object) number29);
        java.lang.Object obj31 = jFreeChart14.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        taskSeriesCollection1.removeAll();
        int int4 = taskSeriesCollection1.getRowCount();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DateTickUnit[HOUR, -457]");
        java.lang.Object obj7 = dateAxis6.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(3, (-457));
        dateAxis6.setTickUnit(dateTickUnit10);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection1, (java.lang.Comparable) dateTickUnit10);
        try {
            java.lang.Number number16 = taskSeriesCollection1.getEndValue((int) (byte) 1, 9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        boolean boolean4 = piePlot1.equals((java.lang.Object) 100L);
        boolean boolean5 = piePlot1.isSubplot();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        piePlot1.setOutlinePaint(paint6);
        float float8 = piePlot1.getBackgroundImageAlpha();
        java.awt.Paint paint9 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint9, paint10);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list13 = defaultStatisticalCategoryDataset12.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) 0.35d);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint10, (org.jfree.data.general.Dataset) pieDataset15);
        piePlot1.setDataset(pieDataset15);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset15, (java.lang.Comparable) "Multiple Pie Plot", (double) 3);
        double double21 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(pieDataset15);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.lang.Class<?> wildcardClass2 = font1.getClass();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("poly", font1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.clearCornerTextItems();
        java.awt.Stroke stroke2 = polarPlot0.getAngleGridlineStroke();
        java.awt.Stroke stroke3 = polarPlot0.getAngleGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = polarPlot0.getOrientation();
        java.awt.Paint paint5 = polarPlot0.getAngleGridlinePaint();
        java.awt.Paint paint6 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        boolean boolean6 = lineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D9.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        barRenderer3D9.setLegendItemToolTipGenerator(categorySeriesLabelGenerator12);
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint15, paint16);
        barRenderer3D9.setSeriesItemLabelPaint((int) (byte) 100, paint16, false);
        java.awt.Font font21 = barRenderer3D9.getSeriesItemLabelFont((-1));
        barRenderer3D9.setItemLabelAnchorOffset((double) (-1));
        java.util.EventListener eventListener24 = null;
        boolean boolean25 = barRenderer3D9.hasListener(eventListener24);
        java.awt.Paint paint26 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        barRenderer3D9.setBaseFillPaint(paint26);
        barRenderer3D9.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D34 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D34.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer3D34.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D42 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D42.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator45 = null;
        barRenderer3D42.setLegendItemToolTipGenerator(categorySeriesLabelGenerator45);
        java.awt.Paint paint48 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint49 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean50 = org.jfree.chart.util.PaintUtilities.equal(paint48, paint49);
        barRenderer3D42.setSeriesItemLabelPaint((int) (byte) 100, paint49, false);
        java.awt.Font font54 = barRenderer3D42.getSeriesItemLabelFont((-1));
        java.awt.Paint paint55 = barRenderer3D42.getWallPaint();
        boolean boolean56 = barRenderer3D34.equals((java.lang.Object) barRenderer3D42);
        java.awt.Stroke stroke58 = barRenderer3D34.getSeriesOutlineStroke(1);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D34.setBaseFillPaint((java.awt.Paint) color59, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator63 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D34.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator63);
        java.lang.Object obj65 = intervalCategoryToolTipGenerator63.clone();
        barRenderer3D9.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator63, false);
        lineAndShapeRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator63, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(font54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator3);
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        lineAndShapeRenderer0.setBaseFillPaint(paint6, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator10, true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D15.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer3D15.getPositiveItemLabelPosition(0, (int) ' ');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D23 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, (double) (short) 0);
        barRenderer3D23.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = null;
        barRenderer3D23.setLegendItemToolTipGenerator(categorySeriesLabelGenerator26);
        java.awt.Paint paint29 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint30 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean31 = org.jfree.chart.util.PaintUtilities.equal(paint29, paint30);
        barRenderer3D23.setSeriesItemLabelPaint((int) (byte) 100, paint30, false);
        java.awt.Font font35 = barRenderer3D23.getSeriesItemLabelFont((-1));
        java.awt.Paint paint36 = barRenderer3D23.getWallPaint();
        boolean boolean37 = barRenderer3D15.equals((java.lang.Object) barRenderer3D23);
        java.awt.Stroke stroke39 = barRenderer3D15.getSeriesOutlineStroke(1);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer3D15.setBaseFillPaint((java.awt.Paint) color40, true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator44 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        barRenderer3D15.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator44);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot(pieDataset46);
        boolean boolean48 = piePlot47.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator49 = null;
        piePlot47.setLegendLabelToolTipGenerator(pieSectionLabelGenerator49);
        java.awt.Font font51 = piePlot47.getLabelFont();
        java.awt.Paint paint52 = piePlot47.getNoDataMessagePaint();
        java.awt.Paint paint53 = piePlot47.getLabelOutlinePaint();
        barRenderer3D15.setBasePaint(paint53, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        lineAndShapeRenderer0.notifyListeners(rendererChangeEvent56);
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(font35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable3 = keyToGroupMap1.getGroup((java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable4 = null;
        int int5 = keyToGroupMap1.getGroupIndex(comparable4);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (byte) 1 + "'", comparable3.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean6 = org.jfree.chart.util.PaintUtilities.equal(paint4, paint5);
        piePlot2.setBaseSectionPaint(paint4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot2.addChangeListener(plotChangeListener8);
        boolean boolean10 = ganttRenderer0.equals((java.lang.Object) plotChangeListener8);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        ganttRenderer0.setIncompletePaint(paint11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = ganttRenderer0.getToolTipGenerator((int) (short) -1, 10);
        boolean boolean16 = ganttRenderer0.getAutoPopulateSeriesShape();
        double double17 = ganttRenderer0.getUpperClip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        textTitle6.draw(graphics2D7, rectangle2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setDrawOutlines(false);
        org.jfree.chart.LegendItem legendItem15 = lineAndShapeRenderer10.getLegendItem((int) (byte) 100, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer10.getBaseNegativeItemLabelPosition();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) itemLabelPosition16);
        java.lang.Class class18 = null;
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class18);
        boolean boolean20 = columnArrangement4.equals((java.lang.Object) class18);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("", font23);
        textTitle24.setToolTipText("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        double double28 = numberAxis27.getFixedAutoRange();
        boolean boolean29 = numberAxis27.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D30, axisState31, rectangle2D35, rectangleEdge36);
        textTitle24.setBounds(rectangle2D35);
        java.awt.Paint paint39 = textTitle24.getBackgroundPaint();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle24);
        java.lang.Object obj41 = blockContainer21.clone();
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        textTitle4.setWidth((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle4.getMargin();
        boolean boolean8 = lineAndShapeRenderer2.equals((java.lang.Object) rectangleInsets7);
        double double10 = rectangleInsets7.calculateBottomOutset((double) '4');
        double double12 = rectangleInsets7.calculateLeftOutset((double) (-35));
        java.lang.String str13 = rectangleInsets7.toString();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isCircular();
        double double4 = piePlot2.getInteriorGap();
        java.awt.Font font5 = piePlot2.getNoDataMessageFont();
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font5, (org.jfree.chart.plot.Plot) multiplePiePlot12, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage(5, 9, chartRenderingInfo17);
        jFreeChart14.setAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart14.addProgressListener(chartProgressListener21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        double double25 = rectangleInsets23.calculateBottomInset((double) 0L);
        org.jfree.chart.util.UnitType unitType26 = rectangleInsets23.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets(unitType26, (double) 12, (double) 3, (double) '#', (double) 100L);
        double double33 = rectangleInsets31.calculateLeftOutset((double) (short) 1);
        jFreeChart14.setPadding(rectangleInsets31);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot35 = jFreeChart14.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(bufferedImage18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(unitType26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        categoryItemRendererState2.setBarWidth((double) 500);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.lang.Object obj2 = numberAxis0.clone();
        numberAxis0.resizeRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getBottom();
        double double2 = axisSpace0.getRight();
        axisSpace0.setRight(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.lang.Class<?> wildcardClass2 = font1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isCircular();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        piePlot1.setBaseSectionPaint(paint3);
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimHeight((double) 1L);
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, paint14);
        piePlot1.setBackgroundPaint(paint14);
        java.awt.Font font17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        boolean boolean18 = piePlot1.equals((java.lang.Object) font17);
        piePlot1.setShadowXOffset((double) 0.0f);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isCircular();
        double double25 = piePlot23.getInteriorGap();
        java.awt.Font font26 = piePlot23.getNoDataMessageFont();
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray31);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font26, (org.jfree.chart.plot.Plot) multiplePiePlot33, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart35.createBufferedImage(5, 9, chartRenderingInfo38);
        java.lang.Number number45 = null;
        java.util.List list48 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem49 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, number45, (java.lang.Number) 3, (java.lang.Number) 100.0d, list48);
        java.lang.Number number50 = boxAndWhiskerItem49.getMinRegularValue();
        boolean boolean51 = jFreeChart35.equals((java.lang.Object) number50);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        boolean boolean53 = jFreeChart35.getAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = jFreeChart35.getPadding();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.25d + "'", double25 == 0.25d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(bufferedImage39);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.0d + "'", number50.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(rectangleInsets54);
    }
}

