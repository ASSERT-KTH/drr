import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) 'a', (int) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesException: ", "Value");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        int int10 = year5.compareTo((java.lang.Object) date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        long long16 = year12.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int21 = timePeriodValues20.getMinMiddleIndex();
        boolean boolean22 = year12.equals((java.lang.Object) int21);
        java.util.Date date23 = year12.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23, "hi!", "TimePeriodValue[2019,100.0]");
        int int27 = year11.compareTo((java.lang.Object) date23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year11.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod28, 1.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 10 + "'", comparable4.equals((byte) 10));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date4, "13-June-2019", "Value");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        int int14 = simpleTimePeriod10.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 1562097599999L);
        java.util.Date date17 = simpleTimePeriod10.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass22 = seriesChangeEvent21.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.lang.Object obj24 = null;
        boolean boolean25 = day23.equals(obj24);
        java.util.Date date26 = day23.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date11, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int39 = timePeriodValues38.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.Object obj42 = timePeriodValues38.clone();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year43, (double) 100.0f);
        timePeriodValue46.setValue((java.lang.Number) 12);
        timePeriodValue46.setValue((java.lang.Number) (short) 0);
        timePeriodValues38.add(timePeriodValue46);
        java.lang.Class class52 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date56 = simpleTimePeriod55.getEnd();
        java.util.Date date57 = simpleTimePeriod55.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date57, timeZone58);
        boolean boolean60 = timePeriodValue46.equals((java.lang.Object) date57);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date64 = simpleTimePeriod63.getEnd();
        java.util.Date date65 = simpleTimePeriod63.getStart();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 100.0f);
        long long70 = year66.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int75 = timePeriodValues74.getMinMiddleIndex();
        boolean boolean76 = year66.equals((java.lang.Object) int75);
        java.util.Date date77 = year66.getEnd();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getLastMillisecond();
        java.lang.String str80 = year78.toString();
        java.util.Date date81 = year78.getStart();
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81, timeZone82);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date77, timeZone82);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date65, timeZone82);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date57, timeZone82);
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date11, timeZone82);
        long long88 = day87.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1577865599999L + "'", long67 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2019" + "'", str80.equals("2019"));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        boolean boolean5 = timePeriodValues1.isEmpty();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 10 + "'", comparable4.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues3.getItemCount();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        int int11 = timePeriodValues3.getMinEndIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
        long long12 = day9.getSerialIndex();
        int int13 = day9.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day9, (double) 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562137199999L + "'", long10 == 1562137199999L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43648L + "'", long12 == 43648L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMinEndIndex();
        int int24 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) 100, (int) (short) 100);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        int int18 = day16.getYear();
//        int int19 = day16.getYear();
//        int int20 = day16.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues13.setKey((java.lang.Comparable) day22);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertNotNull(serialDate21);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getMiddleMillisecond();
        boolean boolean4 = year0.equals((java.lang.Object) long3);
        int int5 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int7 = timePeriodValues6.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues6.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues6.add(timePeriodValue14);
        java.lang.Class class20 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone26);
        boolean boolean28 = timePeriodValue14.equals((java.lang.Object) date25);
        boolean boolean29 = simpleTimePeriod2.equals((java.lang.Object) date25);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-1.0d));
        long long32 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        boolean boolean15 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        long long7 = year6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        long long16 = day9.getLastMillisecond();
//        long long17 = day9.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.util.Date date4 = simpleTimePeriod2.getStart();
//        long long5 = simpleTimePeriod2.getStartMillis();
//        long long6 = simpleTimePeriod2.getEndMillis();
//        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        int int11 = day9.getYear();
//        int int12 = day9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 5);
//        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) day9);
//        java.util.Date date16 = simpleTimePeriod2.getEnd();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        int int9 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        int int12 = year7.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year6.equals((java.lang.Object) year13);
        java.util.Date date15 = year13.getEnd();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int24 = timePeriodValues23.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
        java.lang.Number number31 = timePeriodValue30.getValue();
        timePeriodValues23.add(timePeriodValue30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 10);
        boolean boolean36 = timePeriodValue14.equals((java.lang.Object) day33);
        int int37 = day33.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0d + "'", number31.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        long long12 = simpleTimePeriod10.getStartMillis();
        long long13 = simpleTimePeriod10.getStartMillis();
        long long14 = simpleTimePeriod10.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        java.lang.Class<?> wildcardClass17 = serialDate16.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        java.util.Date date27 = simpleTimePeriod25.getStart();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date21, timeZone28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int34 = timePeriodValues33.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues33.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Object obj37 = timePeriodValues33.clone();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (double) 100.0f);
//        timePeriodValue41.setValue((java.lang.Number) 12);
//        timePeriodValue41.setValue((java.lang.Number) (short) 0);
//        timePeriodValues33.add(timePeriodValue41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date51 = simpleTimePeriod50.getEnd();
//        java.util.Date date52 = simpleTimePeriod50.getStart();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date52, timeZone53);
//        boolean boolean55 = timePeriodValue41.equals((java.lang.Object) date52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date59 = simpleTimePeriod58.getEnd();
//        java.util.Date date60 = simpleTimePeriod58.getStart();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (double) 100.0f);
//        long long65 = year61.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int70 = timePeriodValues69.getMinMiddleIndex();
//        boolean boolean71 = year61.equals((java.lang.Object) int70);
//        java.util.Date date72 = year61.getEnd();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
//        long long74 = year73.getLastMillisecond();
//        java.lang.String str75 = year73.toString();
//        java.util.Date date76 = year73.getStart();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date72, timeZone77);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date60, timeZone77);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date52, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone77);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent83 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass17);
//        java.lang.Class class84 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577865599999L + "'", long65 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1577865599999L + "'", long74 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2019" + "'", str75.equals("2019"));
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(class84);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        long long12 = simpleTimePeriod10.getStartMillis();
        long long13 = simpleTimePeriod10.getStartMillis();
        long long14 = simpleTimePeriod10.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        long long20 = day19.getLastMillisecond();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        long long23 = year21.getMiddleMillisecond();
        long long24 = year21.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.next();
        java.util.Date date26 = year21.getStart();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.lang.Object obj28 = null;
        boolean boolean29 = day27.equals(obj28);
        java.util.Date date30 = day27.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        java.lang.Class<?> wildcardClass32 = simpleTimePeriod31.getClass();
        int int33 = day19.compareTo((java.lang.Object) wildcardClass32);
        try {
            int int34 = simpleTimePeriod10.compareTo((java.lang.Object) int33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562137199999L + "'", long20 == 1562137199999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        int int19 = day13.getDayOfMonth();
//        int int20 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1.0f));
//        java.util.Calendar calendar23 = null;
//        try {
//            day13.peg(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.time.TimePeriod timePeriod15 = null;
        try {
            timePeriodValues1.add(timePeriod15, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues4.setDomainDescription("Time");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        timePeriodValues4.add(timePeriodValue10);
        java.lang.Number number12 = timePeriodValue10.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        int int8 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.delete((int) (byte) 10, 7);
        timePeriodValues1.setKey((java.lang.Comparable) "31-December-1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 10 + "'", comparable7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 1);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinMiddleIndex();
        int int7 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        java.lang.Class class15 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        java.util.Date date20 = simpleTimePeriod18.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone21);
        boolean boolean23 = timePeriodValue9.equals((java.lang.Object) date20);
        timePeriodValue9.setValue((java.lang.Number) 1.0f);
        java.lang.String str26 = timePeriodValue9.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str26.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        int int30 = timePeriodValues3.getMaxMiddleIndex();
        int int31 = timePeriodValues3.getItemCount();
        java.lang.Object obj32 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = year0.compareTo(obj7);
        long long9 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        int int19 = day13.getDayOfMonth();
//        int int20 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        java.lang.String str25 = year23.toString();
//        java.util.Date date26 = year23.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year23);
//        boolean boolean28 = day13.equals((java.lang.Object) year23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day13.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod29, (java.lang.Number) 9);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 100.0f);
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        long long14 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        boolean boolean18 = timePeriodValue14.equals((java.lang.Object) 1L);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues3.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getMiddleMillisecond();
        boolean boolean4 = year0.equals((java.lang.Object) long3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        boolean boolean8 = year5.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        boolean boolean12 = year0.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod11, (java.lang.Number) (-1L));
        java.util.Date date15 = regularTimePeriod11.getEnd();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        long long12 = simpleTimePeriod10.getStartMillis();
        long long13 = simpleTimePeriod10.getStartMillis();
        java.util.Date date14 = simpleTimePeriod10.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6, "", "");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date8 = simpleTimePeriod7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        long long11 = simpleTimePeriod10.getEndMillis();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        int int14 = simpleTimePeriod10.compareTo((java.lang.Object) day12);
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.previous();
//        java.lang.String str18 = day12.toString();
//        long long19 = day12.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        boolean boolean10 = year0.equals((java.lang.Object) int9);
//        java.util.Date date11 = year0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        int int18 = day15.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        int int21 = day15.compareTo((java.lang.Object) day19);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int31 = timePeriodValues30.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
//        java.lang.Object obj34 = timePeriodValues30.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (double) 100.0f);
//        timePeriodValue38.setValue((java.lang.Number) 12);
//        timePeriodValue38.setValue((java.lang.Number) (short) 0);
//        timePeriodValues30.add(timePeriodValue38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date48 = simpleTimePeriod47.getEnd();
//        java.util.Date date49 = simpleTimePeriod47.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone50);
//        boolean boolean52 = timePeriodValue38.equals((java.lang.Object) date49);
//        boolean boolean53 = simpleTimePeriod26.equals((java.lang.Object) date49);
//        int int54 = day15.compareTo((java.lang.Object) simpleTimePeriod26);
//        int int55 = day15.getDayOfMonth();
//        int int56 = day15.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 13 + "'", int55 == 13);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        boolean boolean11 = year8.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        long long14 = year12.getMiddleMillisecond();
        long long15 = year12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.next();
        int int17 = year8.compareTo((java.lang.Object) regularTimePeriod16);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1562097599999L);
        timePeriodValue19.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
//        java.lang.Object obj5 = timePeriodValues1.clone();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
//        timePeriodValue9.setValue((java.lang.Number) 12);
//        timePeriodValue9.setValue((java.lang.Number) (short) 0);
//        timePeriodValues1.add(timePeriodValue9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int19 = timePeriodValues18.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
//        java.lang.Number number26 = timePeriodValue25.getValue();
//        timePeriodValues18.add(timePeriodValue25);
//        timePeriodValues1.add(timePeriodValue25);
//        int int29 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDescription("");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        int int35 = day32.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
//        int int38 = day32.compareTo((java.lang.Object) day36);
//        int int39 = day32.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate40 = day32.getSerialDate();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 100.0f);
//        java.lang.Class<?> wildcardClass46 = year42.getClass();
//        boolean boolean47 = day41.equals((java.lang.Object) wildcardClass46);
//        int int48 = day41.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day41.previous();
//        boolean boolean50 = timePeriodValues1.equals((java.lang.Object) regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 100.0d + "'", number26.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 13 + "'", int39 == 13);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 13 + "'", int48 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues3.createCopy((int) (short) 1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getLastMillisecond();
//        long long3 = year1.getMiddleMillisecond();
//        boolean boolean4 = year0.equals((java.lang.Object) long3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        boolean boolean8 = year5.equals((java.lang.Object) '4');
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
//        boolean boolean12 = year0.equals((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        int int15 = day13.getYear();
//        int int16 = day13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = year0.compareTo((java.lang.Object) day13);
//        long long19 = day13.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean23 = year13.equals((java.lang.Object) int22);
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year13);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year13, (double) (byte) 0);
        java.util.Date date28 = year13.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        java.lang.Object obj13 = timePeriodValue10.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        boolean boolean10 = year7.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues6.setKey((java.lang.Comparable) regularTimePeriod14);
        java.util.Date date16 = regularTimePeriod14.getEnd();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        long long26 = day24.getSerialIndex();
        long long27 = day24.getSerialIndex();
        java.util.Date date28 = day24.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25568L + "'", long26 == 25568L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 25568L + "'", long27 == 25568L);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener24);
        int int26 = timePeriodValues3.getMinMiddleIndex();
        java.lang.String str27 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        int int11 = year6.compareTo((java.lang.Object) date10);
        long long12 = year6.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) 0.0f);
        java.lang.Object obj17 = timePeriodValue16.clone();
        boolean boolean18 = year6.equals((java.lang.Object) timePeriodValue16);
        boolean boolean19 = year0.equals((java.lang.Object) boolean18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "2019", "org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int28 = timePeriodValues27.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 100.0f);
        java.lang.Number number35 = timePeriodValue34.getValue();
        timePeriodValues27.add(timePeriodValue34);
        timePeriodValues27.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) regularTimePeriod43, (java.lang.Number) 0);
        long long46 = regularTimePeriod43.getMiddleMillisecond();
        boolean boolean47 = timePeriodValues23.equals((java.lang.Object) regularTimePeriod43);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100.0d + "'", number35.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1593676799999L + "'", long46 == 1593676799999L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 5);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=5]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=5]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=5]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=5]"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int8 = year0.compareTo((java.lang.Object) "");
        long long9 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100.0f);
        java.lang.Number number21 = timePeriodValue20.getValue();
        timePeriodValues13.add(timePeriodValue20);
        timePeriodValues13.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (double) (-1L));
        long long34 = simpleTimePeriod30.getEndMillis();
        int int35 = year0.compareTo((java.lang.Object) long34);
        long long36 = year0.getFirstMillisecond();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = year0.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 100.0d + "'", number21.equals(100.0d));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        int int7 = day4.compareTo((java.lang.Object) 4);
        int int8 = day4.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date6 = simpleTimePeriod5.getEnd();
        int int7 = year2.compareTo((java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        int int13 = year8.compareTo((java.lang.Object) date12);
        long long14 = year8.getLastMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0.0f);
        java.lang.Object obj19 = timePeriodValue18.clone();
        boolean boolean20 = year8.equals((java.lang.Object) timePeriodValue18);
        boolean boolean21 = year2.equals((java.lang.Object) boolean20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year2);
        int int23 = year0.compareTo((java.lang.Object) year2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date8 = simpleTimePeriod7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        long long11 = simpleTimePeriod10.getEndMillis();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        int int14 = simpleTimePeriod10.compareTo((java.lang.Object) day12);
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.previous();
//        java.lang.String str18 = day12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day12.previous();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        java.lang.String str7 = timePeriodValues4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str9 = seriesException8.toString();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str9.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6, "", "");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str5 = timePeriodValues4.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        int int11 = year6.compareTo((java.lang.Object) date10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date4, date10);
        long long13 = simpleTimePeriod12.getEndMillis();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        long long15 = year13.getMiddleMillisecond();
        long long16 = year13.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int19 = timePeriodValues18.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        int int22 = year13.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = year13.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 1.0f);
        long long26 = year13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        int int5 = timePeriodValues4.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timePeriodValues4.getKey();
        int int9 = timePeriodValues4.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        int int16 = day9.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day9.previous();
//        java.lang.String str18 = day9.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getDayOfMonth();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod13, (java.lang.Number) 0.0f);
//        boolean boolean16 = simpleTimePeriod11.equals((java.lang.Object) regularTimePeriod13);
//        long long17 = simpleTimePeriod11.getEndMillis();
//        boolean boolean18 = day0.equals((java.lang.Object) long17);
//        long long19 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.util.Date date9 = simpleTimePeriod7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9, "13-June-2019", "Value");
        boolean boolean13 = day4.equals((java.lang.Object) date9);
        java.lang.String str14 = day4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2-July-2019" + "'", str14.equals("2-July-2019"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        long long26 = year24.getMiddleMillisecond();
        long long27 = year24.getSerialIndex();
        boolean boolean28 = simpleTimePeriod22.equals((java.lang.Object) year24);
        java.util.Date date29 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        long long33 = year31.getMiddleMillisecond();
        boolean boolean34 = year30.equals((java.lang.Object) long33);
        java.util.Date date35 = year30.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date29, date35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date11, date35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date35);
        long long39 = day38.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577822399999L + "'", long39 == 1577822399999L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.String str15 = seriesChangeEvent14.toString();
        java.lang.String str16 = seriesChangeEvent14.toString();
        int int17 = year12.compareTo((java.lang.Object) str16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (double) 100.0f);
        java.lang.Number number29 = timePeriodValue28.getValue();
        timePeriodValues21.add(timePeriodValue28);
        boolean boolean31 = year12.equals((java.lang.Object) timePeriodValue28);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 100.0f);
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException15.getSuppressed();
        boolean boolean21 = timePeriodValues3.equals((java.lang.Object) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.delete(10, 1);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        timePeriodValues3.delete((int) (byte) 100, 13);
        timePeriodValues3.setNotify(true);
        int int25 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        timePeriodValues3.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        timePeriodValue3.setValue((java.lang.Number) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        boolean boolean11 = year0.equals((java.lang.Object) 5);
        int int12 = year0.getYear();
        java.lang.String str13 = year0.toString();
        long long14 = year0.getFirstMillisecond();
        java.lang.String str15 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        timePeriodValues3.setDescription("hi!");
        int int15 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        boolean boolean10 = year0.equals((java.lang.Object) int9);
//        java.util.Date date11 = year0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        int int18 = day15.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        int int21 = day15.compareTo((java.lang.Object) day19);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int31 = timePeriodValues30.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
//        java.lang.Object obj34 = timePeriodValues30.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (double) 100.0f);
//        timePeriodValue38.setValue((java.lang.Number) 12);
//        timePeriodValue38.setValue((java.lang.Number) (short) 0);
//        timePeriodValues30.add(timePeriodValue38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date48 = simpleTimePeriod47.getEnd();
//        java.util.Date date49 = simpleTimePeriod47.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone50);
//        boolean boolean52 = timePeriodValue38.equals((java.lang.Object) date49);
//        boolean boolean53 = simpleTimePeriod26.equals((java.lang.Object) date49);
//        int int54 = day15.compareTo((java.lang.Object) simpleTimePeriod26);
//        int int55 = day15.getDayOfMonth();
//        java.util.Date date56 = day15.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day15.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod57, (double) 10.0f);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 13 + "'", int55 == 13);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        int int18 = day17.getYear();
//        java.lang.String str19 = day17.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int10 = day4.compareTo((java.lang.Object) day8);
//        int int11 = day4.getDayOfMonth();
//        int int12 = day4.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day4.previous();
//        java.util.Date date14 = day4.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getLastMillisecond();
//        long long3 = year1.getMiddleMillisecond();
//        boolean boolean4 = year0.equals((java.lang.Object) long3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        boolean boolean8 = year5.equals((java.lang.Object) '4');
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
//        boolean boolean12 = year0.equals((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        int int15 = day13.getYear();
//        int int16 = day13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = year0.compareTo((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 0L);
//        java.util.Date date21 = year0.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year0.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        java.lang.String str4 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        boolean boolean11 = year0.equals((java.lang.Object) 5);
        int int12 = year0.getYear();
        java.lang.String str13 = year0.toString();
        java.util.Calendar calendar14 = null;
        try {
            year0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getMiddleMillisecond();
        boolean boolean4 = year0.equals((java.lang.Object) long3);
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        java.lang.String str10 = timePeriodValues8.getDescription();
        java.lang.String str11 = timePeriodValues8.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean23 = year13.equals((java.lang.Object) int22);
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year13);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year13, (double) (byte) 0);
        timePeriodValues12.delete((int) '4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=5]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.util.Date date9 = simpleTimePeriod7.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int16 = timePeriodValues15.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Object obj19 = timePeriodValues15.clone();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 100.0f);
        timePeriodValue23.setValue((java.lang.Number) 12);
        timePeriodValue23.setValue((java.lang.Number) (short) 0);
        timePeriodValues15.add(timePeriodValue23);
        java.lang.Class class29 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date33 = simpleTimePeriod32.getEnd();
        java.util.Date date34 = simpleTimePeriod32.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone35);
        boolean boolean37 = timePeriodValue23.equals((java.lang.Object) date34);
        java.lang.Object obj38 = timePeriodValue23.clone();
        boolean boolean39 = year13.equals(obj38);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        boolean boolean11 = year0.equals((java.lang.Object) 5);
        int int12 = year0.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date16 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        long long18 = day17.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        int int20 = year0.compareTo((java.lang.Object) day17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562137199999L + "'", long18 == 1562137199999L);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        java.lang.Object obj30 = timePeriodValues3.clone();
        int int31 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 2 + "'", comparable12.equals(2));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getMiddleMillisecond();
        long long18 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, 0.0d);
        java.lang.String str22 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 11);
        java.lang.Object obj6 = timePeriodValue5.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int10 = day4.compareTo((java.lang.Object) day8);
//        int int11 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day4.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100.0f);
//        java.lang.Class<?> wildcardClass18 = year14.getClass();
//        boolean boolean19 = day13.equals((java.lang.Object) wildcardClass18);
//        boolean boolean20 = timePeriodValue3.equals((java.lang.Object) day13);
//        java.util.Date date21 = day13.getStart();
//        long long22 = day13.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy((int) (byte) 100, (int) (byte) 1);
        timePeriodValues11.setDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int6 = timePeriodValues5.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        int int9 = year0.compareTo((java.lang.Object) propertyChangeListener7);
        long long10 = year0.getLastMillisecond();
        long long11 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        timePeriodValues3.setDescription("2019");
//        timePeriodValues3.setDomainDescription("");
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getMiddleMillisecond();
//        long long18 = year15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, 0.0d);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        long long24 = day22.getFirstMillisecond();
//        int int25 = day22.getDayOfMonth();
//        int int26 = year15.compareTo((java.lang.Object) day22);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = regularTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod25, "", "hi!");
        int int30 = timePeriodValues29.getMaxEndIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        java.util.Date date5 = simpleTimePeriod3.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        java.util.Date date13 = year8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date5, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) 100);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        timePeriodValue8.setValue((java.lang.Number) 12);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue14.getPeriod();
        boolean boolean17 = timePeriodValue8.equals((java.lang.Object) timePeriodValue14);
        timePeriodValues3.add(timePeriodValue14);
        java.lang.String str19 = timePeriodValues3.getRangeDescription();
        java.lang.String str20 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        boolean boolean24 = year21.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        long long27 = year25.getMiddleMillisecond();
        long long28 = year25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.next();
        int int30 = year21.compareTo((java.lang.Object) regularTimePeriod29);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod29, (double) 3);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        long long36 = year34.getMiddleMillisecond();
        boolean boolean37 = year33.equals((java.lang.Object) long36);
        int int38 = year33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year33.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod39, (double) 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1562097599999L + "'", long36 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        boolean boolean16 = year13.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year13.next();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day24);
        int int27 = timePeriodValues26.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues26.addPropertyChangeListener(propertyChangeListener28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues26.addPropertyChangeListener(propertyChangeListener30);
        timePeriodValues26.delete(13, 4);
        java.lang.String str35 = timePeriodValues26.getDomainDescription();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        timePeriodValue3.setValue((java.lang.Number) 1577822399999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        timePeriodValues1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 10 + "'", comparable4.equals((byte) 10));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        timePeriodValue16.setValue((java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue16.getPeriod();
        java.lang.Object obj20 = timePeriodValue16.clone();
        timePeriodValues3.add(timePeriodValue16);
        java.lang.Number number22 = timePeriodValue16.getValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 12 + "'", number22.equals(12));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
//        boolean boolean8 = timePeriodValues3.getNotify();
//        java.lang.String str9 = timePeriodValues3.getDescription();
//        int int10 = timePeriodValues3.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getLastMillisecond();
//        long long15 = year13.getMiddleMillisecond();
//        long long16 = year13.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int19 = timePeriodValues18.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
//        int int22 = year13.compareTo((java.lang.Object) propertyChangeListener20);
//        long long23 = year13.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 1.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int30 = timePeriodValues29.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        long long34 = year33.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 100.0f);
//        java.lang.Number number37 = timePeriodValue36.getValue();
//        timePeriodValues29.add(timePeriodValue36);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day39, (java.lang.Number) 10);
//        long long42 = day39.getSerialIndex();
//        long long43 = day39.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day39.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod44, (double) 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 100.0d + "'", number37.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43629L + "'", long42 == 43629L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43629L + "'", long43 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues1.createCopy((int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 31, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        boolean boolean6 = timePeriodValue3.equals((java.lang.Object) "Time");
        timePeriodValue3.setValue((java.lang.Number) (-1.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        long long16 = day9.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        int int20 = day17.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.next();
//        int int22 = day17.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17, "", "org.jfree.data.general.SeriesException: ");
//        int int26 = timePeriodValues25.getMinStartIndex();
//        int int27 = day9.compareTo((java.lang.Object) timePeriodValues25);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day9.getMiddleMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        java.lang.String str3 = timePeriodValues1.getDescription();
        try {
            timePeriodValues1.update(11, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        long long12 = simpleTimePeriod10.getStartMillis();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("13-June-2019");
        boolean boolean15 = simpleTimePeriod10.equals((java.lang.Object) "13-June-2019");
        java.util.Date date16 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setDomainDescription("");
        int int15 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getLastMillisecond();
//        long long3 = year1.getMiddleMillisecond();
//        boolean boolean4 = year0.equals((java.lang.Object) long3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        boolean boolean8 = year5.equals((java.lang.Object) '4');
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
//        boolean boolean12 = year0.equals((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        int int15 = day13.getYear();
//        int int16 = day13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = year0.compareTo((java.lang.Object) day13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day13.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.delete((int) ' ', 1);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues3.getMaxEndIndex();
        java.lang.Class<?> wildcardClass15 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        java.util.Date date11 = year0.getEnd();
        long long12 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long14 = year0.getFirstMillisecond();
        long long15 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str5 = year0.toString();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.previous();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (double) 100.0f);
        long long5 = year1.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int10 = timePeriodValues9.getMinMiddleIndex();
        boolean boolean11 = year1.equals((java.lang.Object) int10);
        java.util.Date date12 = year1.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean23 = year13.equals((java.lang.Object) int22);
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.lang.String str27 = year25.toString();
        java.util.Date date28 = year25.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass35 = seriesChangeEvent34.getClass();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.lang.Object obj37 = null;
        boolean boolean38 = day36.equals(obj37);
        java.util.Date date39 = day36.getStart();
        java.lang.Class class40 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        java.util.Date date45 = simpleTimePeriod43.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date24, timeZone46);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date12, timeZone46);
        try {
            org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date0, timeZone46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.util.Date date9 = year6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod10, (java.lang.Number) (short) -1);
        boolean boolean13 = simpleTimePeriod2.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        java.util.Date date15 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) 'a', (int) (byte) 100);
        int int9 = timePeriodValues8.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        java.util.Date date16 = null;
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        int int22 = year17.compareTo((java.lang.Object) date21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        java.util.Date date27 = simpleTimePeriod25.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 100.0f);
//        long long32 = year28.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int37 = timePeriodValues36.getMinMiddleIndex();
//        boolean boolean38 = year28.equals((java.lang.Object) int37);
//        java.util.Date date39 = year28.getEnd();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getLastMillisecond();
//        java.lang.String str42 = year40.toString();
//        java.util.Date date43 = year40.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date39, timeZone44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date27, timeZone44);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date21, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
        int int8 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        int int19 = day13.getDayOfMonth();
//        int int20 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        java.lang.String str25 = year23.toString();
//        java.util.Date date26 = year23.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year23);
//        boolean boolean28 = day13.equals((java.lang.Object) year23);
//        java.lang.String str29 = year23.toString();
//        long long30 = year23.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        long long24 = simpleTimePeriod20.getStartMillis();
        long long25 = simpleTimePeriod20.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long25, "org.jfree.data.general.SeriesException: ", "TimePeriodValue[2019,100.0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date6, "", "");
        java.lang.Comparable comparable10 = timePeriodValues9.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues9.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparable10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        int int26 = day24.getDayOfMonth();
        java.lang.String str27 = day24.toString();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day24.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-1969" + "'", str27.equals("31-December-1969"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) -1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        java.lang.String str7 = year5.toString();
        java.util.Date date8 = year5.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        java.util.Date date10 = year5.getStart();
        int int11 = year0.compareTo((java.lang.Object) year5);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int20 = year12.compareTo((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year12.next();
        int int22 = year5.compareTo((java.lang.Object) year12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValue21.getPeriod();
        boolean boolean24 = timePeriodValue21.equals((java.lang.Object) "Time");
        timePeriodValues3.add(timePeriodValue21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        int int28 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.String str2 = day0.toString();
//        java.util.Date date3 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day24);
        timePeriodValues26.setRangeDescription("TimePeriodValue[2019,100.0]");
        java.lang.Object obj29 = timePeriodValues26.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((-1), 3);
        java.lang.Comparable comparable14 = timePeriodValues13.getKey();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1L + "'", comparable14.equals(1L));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 1L + "'", comparable15.equals(1L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getMiddleMillisecond();
        boolean boolean4 = year0.equals((java.lang.Object) long3);
        int int5 = year0.getYear();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
//        boolean boolean8 = timePeriodValues3.getNotify();
//        timePeriodValues3.fireSeriesChanged();
//        int int10 = timePeriodValues3.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int15 = timePeriodValues14.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 100.0f);
//        java.lang.Number number22 = timePeriodValue21.getValue();
//        timePeriodValues14.add(timePeriodValue21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 10);
//        long long27 = day24.getSerialIndex();
//        long long28 = day24.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) (short) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 100.0d + "'", number22.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(43629L, 1562137199999L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date11);
        int int20 = day19.getYear();
        java.lang.Class<?> wildcardClass21 = day19.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        int int11 = year0.compareTo((java.lang.Object) int10);
        long long12 = year0.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            year0.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        int int18 = day15.compareTo((java.lang.Object) 4);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day15.compareTo((java.lang.Object) day19);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
        try {
            java.lang.Number number25 = timePeriodValues14.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        long long2 = year0.getMiddleMillisecond();
//        long long3 = year0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
//        java.util.Date date5 = year0.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day6.equals(obj7);
//        java.util.Date date9 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        long long12 = day11.getLastMillisecond();
//        long long13 = day11.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "", "TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValues8.add(timePeriodValue14);
        try {
            java.lang.Number number19 = timePeriodValues8.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) 100.0f);
        java.lang.Number number6 = timePeriodValue5.getValue();
        boolean boolean7 = year1.equals((java.lang.Object) timePeriodValue5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.previous();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1530561599999L + "'", long9 == 1530561599999L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
        java.lang.String str27 = day24.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-1969" + "'", str27.equals("31-December-1969"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass22 = seriesChangeEvent21.getClass();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.lang.Object obj24 = null;
        boolean boolean25 = day23.equals(obj24);
        java.util.Date date26 = day23.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date11, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int39 = timePeriodValues38.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.Object obj42 = timePeriodValues38.clone();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year43, (double) 100.0f);
        timePeriodValue46.setValue((java.lang.Number) 12);
        timePeriodValue46.setValue((java.lang.Number) (short) 0);
        timePeriodValues38.add(timePeriodValue46);
        java.lang.Class class52 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date56 = simpleTimePeriod55.getEnd();
        java.util.Date date57 = simpleTimePeriod55.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date57, timeZone58);
        boolean boolean60 = timePeriodValue46.equals((java.lang.Object) date57);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date64 = simpleTimePeriod63.getEnd();
        java.util.Date date65 = simpleTimePeriod63.getStart();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 100.0f);
        long long70 = year66.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int75 = timePeriodValues74.getMinMiddleIndex();
        boolean boolean76 = year66.equals((java.lang.Object) int75);
        java.util.Date date77 = year66.getEnd();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getLastMillisecond();
        java.lang.String str80 = year78.toString();
        java.util.Date date81 = year78.getStart();
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81, timeZone82);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date77, timeZone82);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date65, timeZone82);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date57, timeZone82);
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date11, timeZone82);
        java.lang.Object obj88 = null;
        int int89 = day87.compareTo(obj88);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1577865599999L + "'", long67 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2019" + "'", str80.equals("2019"));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        int int11 = year6.compareTo((java.lang.Object) date10);
        long long12 = year6.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) 0.0f);
        java.lang.Object obj17 = timePeriodValue16.clone();
        boolean boolean18 = year6.equals((java.lang.Object) timePeriodValue16);
        boolean boolean19 = year0.equals((java.lang.Object) boolean18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str21 = seriesChangeEvent20.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        long long2 = year0.getMiddleMillisecond();
//        long long3 = year0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        int int10 = timePeriodValues8.getMinMiddleIndex();
//        int int11 = year0.compareTo((java.lang.Object) int10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        int int15 = day12.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int18 = day12.compareTo((java.lang.Object) day16);
//        int int19 = day12.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day12.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
//        java.lang.Class<?> wildcardClass26 = year22.getClass();
//        boolean boolean27 = day21.equals((java.lang.Object) wildcardClass26);
//        org.jfree.data.time.SerialDate serialDate28 = day21.getSerialDate();
//        java.lang.Class<?> wildcardClass29 = serialDate28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        int int31 = year0.compareTo((java.lang.Object) class30);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj6 = null;
        boolean boolean7 = simpleTimePeriod2.equals(obj6);
        java.lang.Object obj8 = null;
        boolean boolean9 = simpleTimePeriod2.equals(obj8);
        java.util.Date date10 = simpleTimePeriod2.getEnd();
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int14 = timePeriodValues13.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Object obj17 = timePeriodValues13.clone();
        int int18 = timePeriodValues13.getMaxStartIndex();
        int int19 = timePeriodValues13.getMinEndIndex();
        java.lang.Object obj20 = timePeriodValues13.clone();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.lang.Object obj24 = null;
        boolean boolean25 = day23.equals(obj24);
        java.util.Date date26 = day23.getStart();
        timePeriodValues13.setKey((java.lang.Comparable) day23);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener28);
        try {
            int int30 = simpleTimePeriod2.compareTo((java.lang.Object) propertyChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timePeriodValues3.getDescription();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener24);
        int int26 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        java.util.Date date9 = simpleTimePeriod7.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int19 = timePeriodValues18.getMinMiddleIndex();
        boolean boolean20 = year10.equals((java.lang.Object) int19);
        java.util.Date date21 = year10.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        java.lang.String str24 = year22.toString();
        java.util.Date date25 = year22.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date21, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date9, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day29, 0.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (double) 2019);
        long long35 = day29.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 25568L + "'", long35 == 25568L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        timePeriodValues1.setDomainDescription("Value");
        int int10 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 10 + "'", comparable7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long5 = year0.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        boolean boolean11 = year0.equals((java.lang.Object) 5);
        int int12 = year0.getYear();
        java.lang.String str13 = year0.toString();
        long long14 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        java.lang.Class<?> wildcardClass17 = serialDate16.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date21 = simpleTimePeriod20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        java.util.Date date27 = simpleTimePeriod25.getStart();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date21, timeZone28);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int34 = timePeriodValues33.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues33.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Object obj37 = timePeriodValues33.clone();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (double) 100.0f);
//        timePeriodValue41.setValue((java.lang.Number) 12);
//        timePeriodValue41.setValue((java.lang.Number) (short) 0);
//        timePeriodValues33.add(timePeriodValue41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date51 = simpleTimePeriod50.getEnd();
//        java.util.Date date52 = simpleTimePeriod50.getStart();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date52, timeZone53);
//        boolean boolean55 = timePeriodValue41.equals((java.lang.Object) date52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date59 = simpleTimePeriod58.getEnd();
//        java.util.Date date60 = simpleTimePeriod58.getStart();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (double) 100.0f);
//        long long65 = year61.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int70 = timePeriodValues69.getMinMiddleIndex();
//        boolean boolean71 = year61.equals((java.lang.Object) int70);
//        java.util.Date date72 = year61.getEnd();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
//        long long74 = year73.getLastMillisecond();
//        java.lang.String str75 = year73.toString();
//        java.util.Date date76 = year73.getStart();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date72, timeZone77);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date60, timeZone77);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date52, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone77);
//        java.lang.Class class83 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577865599999L + "'", long65 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1577865599999L + "'", long74 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2019" + "'", str75.equals("2019"));
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(class83);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("31-December-1969");
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxStartIndex();
        int int14 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        long long19 = day13.getLastMillisecond();
//        int int20 = day13.getDayOfMonth();
//        int int21 = day13.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        int int11 = year6.compareTo((java.lang.Object) date10);
        long long12 = year6.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) 0.0f);
        java.lang.Object obj17 = timePeriodValue16.clone();
        boolean boolean18 = year6.equals((java.lang.Object) timePeriodValue16);
        boolean boolean19 = year0.equals((java.lang.Object) boolean18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year0.next();
        long long21 = year0.getSerialIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
        timePeriodValue25.setValue((java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue25.getPeriod();
        java.lang.Object obj29 = timePeriodValue25.clone();
        timePeriodValue25.setValue((java.lang.Number) 1560452399999L);
        timePeriodValue25.setValue((java.lang.Number) (short) 100);
        boolean boolean34 = year0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        timePeriodValue3.setValue((java.lang.Number) 12);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue9.getPeriod();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValue9);
        java.lang.Number number13 = null;
        timePeriodValue3.setValue(number13);
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue3.equals(obj15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod10);
        org.junit.Assert.assertNotNull(timePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod1, (java.lang.Number) 0.0f);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.Number number5 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10, "hi!", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int7 = timePeriodValues6.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues6.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues6.add(timePeriodValue14);
        java.lang.Class class20 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone26);
        boolean boolean28 = timePeriodValue14.equals((java.lang.Object) date25);
        timePeriodValue14.setValue((java.lang.Number) 1.0f);
        timePeriodValues3.add(timePeriodValue14);
        int int32 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener33);
        timePeriodValues3.setDescription("");
        java.lang.Object obj37 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass17 = seriesChangeEvent16.getClass();
        java.lang.Object obj18 = seriesChangeEvent16.getSource();
        boolean boolean19 = timePeriodValue9.equals(obj18);
        java.lang.String str20 = timePeriodValue9.toString();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue9.getPeriod();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + (-1) + "'", obj18.equals((-1)));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,0]" + "'", str20.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        long long11 = simpleTimePeriod10.getEndMillis();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        int int14 = simpleTimePeriod10.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 1562097599999L);
        long long17 = simpleTimePeriod10.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.lang.String str5 = year3.toString();
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year3);
        boolean boolean8 = day0.equals((java.lang.Object) year3);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12, "", "TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener18);
        boolean boolean20 = day0.equals((java.lang.Object) seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean20, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = timePeriodValues3.clone();
        int int8 = year0.compareTo(obj7);
        java.lang.Object obj9 = null;
        boolean boolean10 = year0.equals(obj9);
        long long11 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) 100.0f);
        java.lang.Number number6 = timePeriodValue5.getValue();
        boolean boolean7 = year1.equals((java.lang.Object) timePeriodValue5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year1.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate8);
//        int int12 = day11.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Object obj7 = null;
        boolean boolean8 = day6.equals(obj7);
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        int int12 = day11.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        long long16 = day13.getSerialIndex();
//        long long17 = day13.getSerialIndex();
//        java.util.Date date18 = day13.getStart();
//        java.util.TimeZone timeZone19 = null;
//        try {
//            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str19 = seriesException18.toString();
        seriesException13.addSuppressed((java.lang.Throwable) seriesException18);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException18);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str19.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,100.0]");
        boolean boolean11 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year4);
        int int11 = timePeriodValues10.getMinMiddleIndex();
        timePeriodValues10.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Object obj7 = null;
        boolean boolean8 = day6.equals(obj7);
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        boolean boolean10 = year0.equals((java.lang.Object) int9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int9, "", "2019");
//        boolean boolean14 = timePeriodValues13.getNotify();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = timePeriodValues13.equals(obj15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100.0f);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int24 = day21.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        int int27 = day21.compareTo((java.lang.Object) day25);
//        int int28 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day21.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 100.0f);
//        java.lang.Class<?> wildcardClass35 = year31.getClass();
//        boolean boolean36 = day30.equals((java.lang.Object) wildcardClass35);
//        boolean boolean37 = timePeriodValue20.equals((java.lang.Object) day30);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day30, (double) (short) 1);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date44 = simpleTimePeriod43.getEnd();
//        int int45 = year40.compareTo((java.lang.Object) date44);
//        long long46 = year40.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) 1560452399999L);
//        boolean boolean49 = day30.equals((java.lang.Object) timePeriodValue48);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int19 = timePeriodValues18.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
        java.lang.Number number26 = timePeriodValue25.getValue();
        timePeriodValues18.add(timePeriodValue25);
        timePeriodValues1.add(timePeriodValue25);
        java.lang.Number number30 = timePeriodValues1.getValue(0);
        timePeriodValues1.setNotify(false);
        int int33 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 100.0d + "'", number26.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 0 + "'", number30.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        int int6 = day0.compareTo((java.lang.Object) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Object obj7 = null;
        boolean boolean8 = day6.equals(obj7);
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod10.getClass();
        java.util.Date date12 = null;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean23 = year13.equals((java.lang.Object) int22);
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.lang.String str27 = year25.toString();
        java.util.Date date28 = year25.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone29);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        long long10 = day0.getFirstMillisecond();
//        int int11 = day0.getDayOfMonth();
//        long long12 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener9);
        timePeriodValues8.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        boolean boolean15 = year12.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        long long18 = year16.getMiddleMillisecond();
        long long19 = year16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.next();
        int int21 = year12.compareTo((java.lang.Object) regularTimePeriod20);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        long long26 = day24.getSerialIndex();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day24.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25568L + "'", long26 == 25568L);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
//        timePeriodValue14.setValue((java.lang.Number) 12);
//        timePeriodValue14.setValue((java.lang.Number) (short) 0);
//        timePeriodValues3.add(timePeriodValue14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int24 = timePeriodValues23.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
//        java.lang.Number number31 = timePeriodValue30.getValue();
//        timePeriodValues23.add(timePeriodValue30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 10);
//        boolean boolean36 = timePeriodValue14.equals((java.lang.Object) day33);
//        int int37 = day33.getDayOfMonth();
//        long long38 = day33.getLastMillisecond();
//        long long39 = day33.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0d + "'", number31.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 13 + "'", int37 == 13);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560495599999L + "'", long38 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        int int18 = day15.compareTo((java.lang.Object) 4);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day15.compareTo((java.lang.Object) day19);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
        org.jfree.data.time.SerialDate serialDate24 = day15.getSerialDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        long long21 = day19.getSerialIndex();
        int int22 = day19.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        boolean boolean10 = year7.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues6.setKey((java.lang.Comparable) regularTimePeriod14);
        java.lang.String str16 = timePeriodValues6.getRangeDescription();
        int int17 = timePeriodValues6.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.update((int) (short) 0, (java.lang.Number) 6);
        int int17 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) 0.0f);
        java.lang.Object obj11 = timePeriodValue10.clone();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValue10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year0.previous();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        long long16 = day13.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        java.util.Date date19 = day17.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) (byte) -1);
        timePeriodValues3.add(timePeriodValue15);
        timePeriodValue15.setValue((java.lang.Number) 1969L);
        java.lang.Number number19 = timePeriodValue15.getValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1969L + "'", number19.equals(1969L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        java.util.Date date5 = simpleTimePeriod3.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        java.util.Date date13 = year8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date5, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        boolean boolean19 = year16.equals((java.lang.Object) '4');
        java.util.Date date20 = year16.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 100.0f);
        long long25 = year21.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int30 = timePeriodValues29.getMinMiddleIndex();
        boolean boolean31 = year21.equals((java.lang.Object) int30);
        java.util.Date date32 = year21.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        java.lang.String str35 = year33.toString();
        java.util.Date date36 = year33.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date20, timeZone37);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date15, timeZone37);
        long long42 = day41.getSerialIndex();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43466L + "'", long42 == 43466L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,10]");
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        long long11 = year7.getSerialIndex();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) year7);
        long long13 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        int int6 = day0.compareTo((java.lang.Object) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]", "TimePeriodValue[2019,12]");
        timePeriodValues10.setDescription("");
        timePeriodValues10.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "TimePeriodValue[2019,12]");
        java.lang.Object obj2 = timePeriodValues1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        java.util.Date date5 = simpleTimePeriod3.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        java.util.Date date13 = year8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date5, date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues4.setDomainDescription("Time");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        timePeriodValues4.add(timePeriodValue10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        long long17 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod16, (java.lang.Number) 1.0d);
        timePeriodValues4.add(timePeriodValue19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        int int19 = day13.getDayOfMonth();
//        int int20 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1.0f));
//        timePeriodValue22.setValue((java.lang.Number) (short) -1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) 0.0f);
        java.lang.Object obj11 = timePeriodValue10.clone();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValue10);
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day24);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day24.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, 43466L);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 5);
//        timePeriodValue5.setValue((java.lang.Number) 1577779200000L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getMiddleMillisecond();
        long long18 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, 0.0d);
        int int22 = timePeriodValues3.getMinStartIndex();
        int int23 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener24);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) year4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date12, date17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date12);
        long long21 = year20.getLastMillisecond();
        long long22 = year20.getSerialIndex();
        boolean boolean23 = simpleTimePeriod2.equals((java.lang.Object) year20);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        int int16 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.next();
//        int int18 = day13.getMonth();
//        int int19 = day13.getDayOfMonth();
//        int int20 = day13.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        java.lang.String str25 = year23.toString();
//        java.util.Date date26 = year23.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year23);
//        boolean boolean28 = day13.equals((java.lang.Object) year23);
//        int int29 = year23.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int34 = timePeriodValues33.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = timePeriodValues33.createCopy((-1), (int) (byte) 1);
//        boolean boolean38 = timePeriodValues33.getNotify();
//        java.lang.String str39 = timePeriodValues33.getDescription();
//        int int40 = timePeriodValues33.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues33.addChangeListener(seriesChangeListener41);
//        java.lang.String str43 = timePeriodValues33.getDescription();
//        boolean boolean44 = year23.equals((java.lang.Object) str43);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
//        java.lang.Object obj5 = timePeriodValues1.clone();
//        int int6 = timePeriodValues1.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 100.0f);
//        long long13 = year9.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int18 = timePeriodValues17.getMinMiddleIndex();
//        boolean boolean19 = year9.equals((java.lang.Object) int18);
//        java.util.Date date20 = year9.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date20, "hi!", "TimePeriodValue[2019,100.0]");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.next();
//        int int27 = day24.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        int int30 = day24.compareTo((java.lang.Object) day28);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day24, (double) 100L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date36 = simpleTimePeriod35.getEnd();
//        java.util.Date date37 = simpleTimePeriod35.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int40 = timePeriodValues39.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues39.removePropertyChangeListener(propertyChangeListener41);
//        java.lang.Object obj43 = timePeriodValues39.clone();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, (double) 100.0f);
//        timePeriodValue47.setValue((java.lang.Number) 12);
//        timePeriodValue47.setValue((java.lang.Number) (short) 0);
//        timePeriodValues39.add(timePeriodValue47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date57 = simpleTimePeriod56.getEnd();
//        java.util.Date date58 = simpleTimePeriod56.getStart();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date58, timeZone59);
//        boolean boolean61 = timePeriodValue47.equals((java.lang.Object) date58);
//        boolean boolean62 = simpleTimePeriod35.equals((java.lang.Object) date58);
//        int int63 = day24.compareTo((java.lang.Object) simpleTimePeriod35);
//        int int64 = day24.getDayOfMonth();
//        java.util.Date date65 = day24.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day24, (double) 0);
//        int int68 = timePeriodValues1.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 13 + "'", int64 == 13);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        java.util.Date date11 = year0.getEnd();
        long long12 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100.0f);
        timePeriodValue17.setValue((java.lang.Number) 12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValue23.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue23.getPeriod();
        boolean boolean26 = timePeriodValue17.equals((java.lang.Object) timePeriodValue23);
        java.lang.Object obj27 = timePeriodValue17.clone();
        timePeriodValue17.setValue((java.lang.Number) 43648L);
        java.lang.Object obj30 = timePeriodValue17.clone();
        int int31 = year0.compareTo((java.lang.Object) timePeriodValue17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod24);
        org.junit.Assert.assertNotNull(timePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        int int16 = day9.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day9.previous();
//        java.util.Calendar calendar18 = null;
//        try {
//            day9.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int6 = timePeriodValues5.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        int int9 = year0.compareTo((java.lang.Object) propertyChangeListener7);
        long long10 = year0.getLastMillisecond();
        long long11 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,10]");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "", "TimePeriodValue[2019,100.0]");
        timePeriodValues8.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        int int18 = year13.compareTo((java.lang.Object) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        int int24 = year19.compareTo((java.lang.Object) date23);
        long long25 = year19.getLastMillisecond();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) 0.0f);
        java.lang.Object obj30 = timePeriodValue29.clone();
        boolean boolean31 = year19.equals((java.lang.Object) timePeriodValue29);
        boolean boolean32 = year13.equals((java.lang.Object) boolean31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year13);
        int int34 = year0.compareTo((java.lang.Object) seriesChangeEvent33);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year0.getMiddleMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        int int9 = timePeriodValues8.getMinStartIndex();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        long long16 = simpleTimePeriod13.getStartMillis();
        java.util.Date date17 = simpleTimePeriod13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "", "hi!", "Time");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getLastMillisecond();
        long long30 = year28.getMiddleMillisecond();
        long long31 = year28.getSerialIndex();
        boolean boolean32 = simpleTimePeriod26.equals((java.lang.Object) year28);
        java.util.Date date33 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        long long37 = year35.getMiddleMillisecond();
        boolean boolean38 = year34.equals((java.lang.Object) long37);
        java.util.Date date39 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date33, date39);
        boolean boolean41 = timePeriodValues23.equals((java.lang.Object) simpleTimePeriod40);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (java.lang.Number) 4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1562097599999L + "'", long30 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) 0.0f);
        java.lang.Object obj11 = timePeriodValue10.clone();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValue10);
        java.lang.Number number13 = timePeriodValue10.getValue();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0f + "'", number13.equals(0.0f));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues3.getMaxStartIndex();
        int int28 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str29 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day24);
        timePeriodValues26.setRangeDescription("TimePeriodValue[2019,100.0]");
        timePeriodValues26.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int16 = timePeriodValues15.getMinMiddleIndex();
        boolean boolean17 = year7.equals((java.lang.Object) int16);
        java.util.Date date18 = year7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date18, "hi!", "TimePeriodValue[2019,100.0]");
        int int22 = year6.compareTo((java.lang.Object) date18);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year6.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,12]");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener21);
        try {
            java.lang.Number number24 = timePeriodValues3.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date8 = simpleTimePeriod7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        long long11 = simpleTimePeriod10.getEndMillis();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        int int14 = simpleTimePeriod10.compareTo((java.lang.Object) day12);
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.previous();
//        java.lang.String str18 = day12.toString();
//        org.jfree.data.time.SerialDate serialDate19 = day12.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        long long21 = day20.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues25.createCopy(0, (int) (short) 1);
//        int int29 = day20.compareTo((java.lang.Object) timePeriodValues28);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(timePeriodValues28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        boolean boolean10 = year0.equals((java.lang.Object) int9);
//        java.util.Date date11 = year0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        int int18 = day15.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        int int21 = day15.compareTo((java.lang.Object) day19);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
//        int int24 = day15.getDayOfMonth();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
//        java.lang.Throwable[] throwableArray29 = seriesException28.getSuppressed();
//        timePeriodFormatException26.addSuppressed((java.lang.Throwable) seriesException28);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        seriesException28.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("13-June-2019");
//        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("");
//        seriesException36.addSuppressed((java.lang.Throwable) seriesException38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
//        org.jfree.data.general.SeriesException seriesException43 = new org.jfree.data.general.SeriesException("");
//        java.lang.Throwable[] throwableArray44 = seriesException43.getSuppressed();
//        timePeriodFormatException41.addSuppressed((java.lang.Throwable) seriesException43);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        seriesException43.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        org.jfree.data.general.SeriesException seriesException51 = new org.jfree.data.general.SeriesException("13-June-2019");
//        org.jfree.data.general.SeriesException seriesException53 = new org.jfree.data.general.SeriesException("");
//        seriesException51.addSuppressed((java.lang.Throwable) seriesException53);
//        org.jfree.data.general.SeriesException seriesException56 = new org.jfree.data.general.SeriesException("13-June-2019");
//        java.lang.String str57 = seriesException56.toString();
//        seriesException51.addSuppressed((java.lang.Throwable) seriesException56);
//        timePeriodFormatException47.addSuppressed((java.lang.Throwable) seriesException56);
//        seriesException36.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        java.lang.Throwable[] throwableArray61 = timePeriodFormatException47.getSuppressed();
//        seriesException28.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        int int63 = day15.compareTo((java.lang.Object) timePeriodFormatException47);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str57.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        java.lang.String str5 = day0.toString();
//        java.util.Date date6 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        int int25 = year20.compareTo((java.lang.Object) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date30 = simpleTimePeriod29.getEnd();
        int int31 = year26.compareTo((java.lang.Object) date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date24, date30);
        java.util.Date date33 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date38 = simpleTimePeriod37.getEnd();
        int int39 = year34.compareTo((java.lang.Object) date38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date43 = simpleTimePeriod42.getEnd();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year45, (double) 100.0f);
        long long49 = year45.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int54 = timePeriodValues53.getMinMiddleIndex();
        boolean boolean55 = year45.equals((java.lang.Object) int54);
        java.util.Date date56 = year45.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getLastMillisecond();
        java.lang.String str59 = year57.toString();
        java.util.Date date60 = year57.getStart();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date60, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date56, timeZone61);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date44, timeZone61);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date38, timeZone61);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date33, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date16, timeZone61);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date16);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.next();
        int int27 = day24.compareTo((java.lang.Object) 4);
        int int28 = day24.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 10L);
        java.lang.Object obj31 = timePeriodValue30.clone();
        boolean boolean33 = timePeriodValue30.equals((java.lang.Object) 100.0d);
        timePeriodValues3.add(timePeriodValue30);
        org.jfree.data.time.TimePeriod timePeriod35 = timePeriodValue30.getPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timePeriod35);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=5]");
        try {
            java.lang.Number number31 = timePeriodValues3.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int8 = timePeriodValues7.getMinMiddleIndex();
        int int9 = year0.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
//        boolean boolean8 = timePeriodValues3.getNotify();
//        timePeriodValues3.fireSeriesChanged();
//        int int10 = timePeriodValues3.getMaxEndIndex();
//        int int11 = timePeriodValues3.getMaxEndIndex();
//        java.lang.String str12 = timePeriodValues3.getRangeDescription();
//        java.lang.Object obj13 = timePeriodValues3.clone();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100.0f);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        int int21 = day18.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        int int24 = day18.compareTo((java.lang.Object) day22);
//        int int25 = day18.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day18.getSerialDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 100.0f);
//        java.lang.Class<?> wildcardClass32 = year28.getClass();
//        boolean boolean33 = day27.equals((java.lang.Object) wildcardClass32);
//        boolean boolean34 = timePeriodValue17.equals((java.lang.Object) day27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day27.next();
//        int int36 = day27.getYear();
//        org.jfree.data.time.SerialDate serialDate37 = day27.getSerialDate();
//        boolean boolean38 = timePeriodValues3.equals((java.lang.Object) day27);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        timePeriodValues12.setDescription("TimePeriodValue[2019,100.0]");
        int int15 = timePeriodValues12.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues12.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues12.getMinEndIndex();
        int int19 = timePeriodValues12.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getRangeDescription();
        java.lang.Object obj13 = timePeriodValues3.clone();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        long long19 = year15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int24 = timePeriodValues23.getMinMiddleIndex();
        boolean boolean25 = year15.equals((java.lang.Object) int24);
        java.util.Date date26 = year15.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.lang.String str29 = year27.toString();
        java.util.Date date30 = year27.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date26, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date11, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
        long long36 = day34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577779200000L + "'", long36 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        int int9 = year0.compareTo((java.lang.Object) regularTimePeriod8);
        int int10 = year0.getYear();
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "13-June-2019", "TimePeriodValue[2019,12]");
        try {
            timePeriodValues14.update((int) (byte) 10, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        java.lang.Class class15 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        java.util.Date date20 = simpleTimePeriod18.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone21);
        boolean boolean23 = timePeriodValue9.equals((java.lang.Object) date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        java.util.Date date28 = simpleTimePeriod26.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (double) 100.0f);
        long long33 = year29.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int38 = timePeriodValues37.getMinMiddleIndex();
        boolean boolean39 = year29.equals((java.lang.Object) int38);
        java.util.Date date40 = year29.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getLastMillisecond();
        java.lang.String str43 = year41.toString();
        java.util.Date date44 = year41.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44, timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date40, timeZone45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date28, timeZone45);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date20, timeZone45);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date53 = simpleTimePeriod52.getEnd();
        java.util.Date date54 = simpleTimePeriod52.getStart();
        long long55 = simpleTimePeriod52.getStartMillis();
        java.util.Date date56 = simpleTimePeriod52.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date56, "", "");
        java.lang.Comparable comparable60 = timePeriodValues59.getKey();
        int int61 = year49.compareTo((java.lang.Object) timePeriodValues59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019" + "'", str43.equals("2019"));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1L) + "'", long55 == (-1L));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(comparable60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        try {
            java.lang.Number number17 = timePeriodValues3.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        int int7 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj8 = timePeriodValues1.clone();
        int int9 = timePeriodValues1.getMinMiddleIndex();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        boolean boolean10 = year7.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues6.setKey((java.lang.Comparable) regularTimePeriod14);
        java.lang.String str16 = timePeriodValues6.getRangeDescription();
        java.lang.Object obj17 = timePeriodValues6.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues6.createCopy(0, 12);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 43629L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj6 = null;
        boolean boolean7 = simpleTimePeriod2.equals(obj6);
        java.lang.Object obj8 = null;
        boolean boolean9 = simpleTimePeriod2.equals(obj8);
        java.util.Date date10 = simpleTimePeriod2.getEnd();
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod2.getClass();
        long long12 = simpleTimePeriod2.getEndMillis();
        java.util.Date date13 = simpleTimePeriod2.getStart();
        java.util.Date date14 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((-1), 3);
        java.lang.Comparable comparable14 = timePeriodValues13.getKey();
        try {
            java.lang.Number number16 = timePeriodValues13.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1L + "'", comparable14.equals(1L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Object obj7 = null;
        boolean boolean8 = day6.equals(obj7);
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod10.getClass();
        java.util.Date date12 = simpleTimePeriod10.getEnd();
        java.lang.Class class13 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date12, timeZone19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10, "hi!", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int7 = timePeriodValues6.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues6.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues6.add(timePeriodValue14);
        java.lang.Class class20 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone26);
        boolean boolean28 = timePeriodValue14.equals((java.lang.Object) date25);
        timePeriodValue14.setValue((java.lang.Number) 1.0f);
        timePeriodValues3.add(timePeriodValue14);
        int int32 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener33);
        int int35 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1) + "'", obj2.equals((-1)));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1) + "'", obj4.equals((-1)));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.delete(2019, 2);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day24);
        int int27 = timePeriodValues26.getMaxEndIndex();
        int int28 = timePeriodValues26.getItemCount();
        java.lang.String str29 = timePeriodValues26.getDescription();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) -1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        java.lang.String str7 = year5.toString();
        java.util.Date date8 = year5.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        java.util.Date date10 = year5.getStart();
        int int11 = year0.compareTo((java.lang.Object) year5);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int14 = timePeriodValues13.getMinMiddleIndex();
        timePeriodValues13.setDomainDescription("hi!");
        int int17 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean18 = year5.equals((java.lang.Object) int17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year5.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        java.lang.Class<?> wildcardClass17 = serialDate16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date23 = simpleTimePeriod22.getEnd();
//        int int24 = year19.compareTo((java.lang.Object) date23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date29 = simpleTimePeriod28.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date34 = simpleTimePeriod33.getEnd();
//        java.util.Date date35 = simpleTimePeriod33.getStart();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date29, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str16 = timePeriodValues1.getDescription();
        java.lang.Object obj17 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Class<?> wildcardClass14 = year10.getClass();
//        boolean boolean15 = day9.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate16 = day9.getSerialDate();
//        java.lang.Class<?> wildcardClass17 = serialDate16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getLastMillisecond();
//        java.lang.String str21 = year19.toString();
//        java.util.Date date22 = year19.getStart();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 100.0f);
        long long9 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        boolean boolean15 = year5.equals((java.lang.Object) int14);
        java.util.Date date16 = year5.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date4, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        java.util.Date date26 = regularTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod25, "", "hi!");
        int int30 = timePeriodValues29.getItemCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) (byte) -1);
        timePeriodValues3.add(timePeriodValue15);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        boolean boolean6 = timePeriodValues1.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        java.util.Date date11 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int14 = timePeriodValues13.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Object obj17 = timePeriodValues13.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 100.0f);
        timePeriodValue21.setValue((java.lang.Number) 12);
        timePeriodValue21.setValue((java.lang.Number) (short) 0);
        timePeriodValues13.add(timePeriodValue21);
        java.lang.Class class27 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone33);
        boolean boolean35 = timePeriodValue21.equals((java.lang.Object) date32);
        boolean boolean36 = simpleTimePeriod9.equals((java.lang.Object) date32);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, 0.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int43 = timePeriodValues42.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (double) 100.0f);
        java.lang.Number number50 = timePeriodValue49.getValue();
        timePeriodValues42.add(timePeriodValue49);
        timePeriodValues42.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year57, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod61 = timePeriodValue60.getPeriod();
        boolean boolean63 = timePeriodValue60.equals((java.lang.Object) "Time");
        timePeriodValues42.add(timePeriodValue60);
        timePeriodValues1.add(timePeriodValue60);
        java.lang.String str66 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 100.0d + "'", number50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str66);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod11 = null;
        try {
            timePeriodValues10.add(timePeriod11, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = null;
        try {
            timePeriodValues1.add(timePeriodValue6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener18);
        try {
            timePeriodValues3.update(13, (java.lang.Number) 43648L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        int int15 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues1.createCopy(1, (int) (short) -1);
        boolean boolean19 = timePeriodValues18.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year4);
        int int11 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues10.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues10.getItemCount();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getEndMillis();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) (-1));
        long long9 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int14 = timePeriodValues13.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        timePeriodValues13.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 100.0f);
        timePeriodValue24.setValue((java.lang.Number) 12);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) 1L);
        timePeriodValues13.add(timePeriodValue24);
        boolean boolean30 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        int int9 = timePeriodValues8.getMinStartIndex();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        timePeriodValues8.delete((int) ' ', 3);
        java.lang.Object obj14 = timePeriodValues8.clone();
        boolean boolean15 = timePeriodValues8.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 1);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560538799999L + "'", long5 == 1560538799999L);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int6 = day0.compareTo((java.lang.Object) day4);
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        java.util.Date date10 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int15 = timePeriodValues14.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
//        timePeriodValues14.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues14.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
//        timePeriodValue25.setValue((java.lang.Number) 12);
//        timePeriodValue25.setValue((java.lang.Number) (short) 0);
//        timePeriodValues14.add(timePeriodValue25);
//        int int31 = timePeriodValues14.getMaxMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener32);
//        int int34 = timePeriodValues14.getMaxStartIndex();
//        java.lang.String str35 = timePeriodValues14.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener36);
//        int int38 = timePeriodValues14.getMaxStartIndex();
//        timePeriodValues14.setNotify(true);
//        java.lang.Object obj41 = timePeriodValues14.clone();
//        java.lang.Class<?> wildcardClass42 = obj41.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        int int44 = day0.compareTo((java.lang.Object) wildcardClass42);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
//        boolean boolean48 = year45.equals((java.lang.Object) '4');
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        long long50 = year49.getLastMillisecond();
//        long long51 = year49.getMiddleMillisecond();
//        long long52 = year49.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year49.next();
//        int int54 = year45.compareTo((java.lang.Object) regularTimePeriod53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod53, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "13-June-2019");
//        int int58 = timePeriodValues57.getMaxEndIndex();
//        int int59 = day0.compareTo((java.lang.Object) timePeriodValues57);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1562097599999L + "'", long51 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2019L + "'", long52 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int8 = year0.compareTo((java.lang.Object) "");
        long long9 = year0.getMiddleMillisecond();
        long long10 = year0.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        long long19 = year15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int24 = timePeriodValues23.getMinMiddleIndex();
        boolean boolean25 = year15.equals((java.lang.Object) int24);
        java.util.Date date26 = year15.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.lang.String str29 = year27.toString();
        java.util.Date date30 = year27.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date26, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date11, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod35);
        java.lang.Object obj37 = seriesChangeEvent36.getSource();
        java.lang.Object obj38 = seriesChangeEvent36.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        long long11 = year0.getLastMillisecond();
        int int13 = year0.compareTo((java.lang.Object) 0.0d);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year0.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        long long2 = year0.getMiddleMillisecond();
//        long long3 = year0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
//        java.util.Date date5 = year0.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day6.equals(obj7);
//        java.util.Date date9 = day6.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        long long13 = regularTimePeriod12.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560538799999L + "'", long13 == 1560538799999L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
        timePeriodValue9.setValue((java.lang.Number) 12);
        timePeriodValue9.setValue((java.lang.Number) (short) 0);
        timePeriodValues1.add(timePeriodValue9);
        java.lang.Class class15 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        java.util.Date date20 = simpleTimePeriod18.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone21);
        boolean boolean23 = timePeriodValue9.equals((java.lang.Object) date20);
        timePeriodValue9.setValue((java.lang.Number) 1.0f);
        java.lang.Number number26 = null;
        timePeriodValue9.setValue(number26);
        timePeriodValue9.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (double) 100.0f);
        timePeriodValue33.setValue((java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod36 = timePeriodValue33.getPeriod();
        timePeriodValue33.setValue((java.lang.Number) 2019);
        boolean boolean39 = timePeriodValue9.equals((java.lang.Object) 2019);
        java.lang.Number number40 = timePeriodValue9.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 100.0d + "'", number40.equals(100.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 100.0f);
        long long8 = year4.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int13 = timePeriodValues12.getMinMiddleIndex();
        boolean boolean14 = year4.equals((java.lang.Object) int13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int13, "", "2019");
        timePeriodValues17.setRangeDescription("2019");
        try {
            int int20 = simpleTimePeriod2.compareTo((java.lang.Object) "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getMiddleMillisecond();
        long long18 = year15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, 0.0d);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 100.0f);
        timePeriodValue25.setValue((java.lang.Number) 12);
        timePeriodValue25.setValue((java.lang.Number) (short) 0);
        boolean boolean31 = timePeriodValue25.equals((java.lang.Object) "2-July-2019");
        timePeriodValues3.add(timePeriodValue25);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        seriesException11.addSuppressed((java.lang.Throwable) seriesException13);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str17 = seriesException16.toString();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException7.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str17.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        boolean boolean16 = year13.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year13.next();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod19);
        timePeriodValues3.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        int int26 = simpleTimePeriod20.compareTo((java.lang.Object) year24);
        long long27 = year24.getFirstMillisecond();
        int int28 = year24.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        long long11 = year7.getSerialIndex();
        int int12 = simpleTimePeriod2.compareTo((java.lang.Object) year7);
        java.util.Date date13 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: ", "2-July-2019");
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        long long15 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int20 = timePeriodValues19.getMinMiddleIndex();
        boolean boolean21 = year11.equals((java.lang.Object) int20);
        java.util.Date date22 = year11.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        java.lang.String str25 = year23.toString();
        java.util.Date date26 = year23.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date10, timeZone27);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date4, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        int int26 = simpleTimePeriod20.compareTo((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.previous();
        long long28 = regularTimePeriod27.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1530561599999L + "'", long28 == 1530561599999L);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getLastMillisecond();
//        long long3 = year1.getMiddleMillisecond();
//        boolean boolean4 = year0.equals((java.lang.Object) long3);
//        long long5 = year0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "");
//        timePeriodValues8.setNotify(false);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        int int13 = day11.getYear();
//        int int14 = day11.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (double) 5);
//        boolean boolean17 = timePeriodValues8.equals((java.lang.Object) 5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj6 = null;
        boolean boolean7 = simpleTimePeriod2.equals(obj6);
        java.lang.Object obj8 = null;
        boolean boolean9 = simpleTimePeriod2.equals(obj8);
        java.util.Date date10 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Object obj12 = null;
        boolean boolean13 = day11.equals(obj12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.lang.String str16 = year14.toString();
        java.util.Date date17 = year14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year14);
        boolean boolean19 = day11.equals((java.lang.Object) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year14.previous();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) year14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int21);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, number7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Time" + "'", str2.equals("org.jfree.data.general.SeriesException: Time"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.String str10 = seriesException7.toString();
        java.lang.String str11 = seriesException7.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str10.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        int int5 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesException: ");
        int int9 = timePeriodValues8.getMinStartIndex();
        java.lang.Object obj10 = timePeriodValues8.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues8.createCopy(6, (int) (short) -1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.delete((int) ' ', 1);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1, "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("TimePeriodValue[2019,1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int11 = timePeriodValues10.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100.0f);
        java.lang.Number number18 = timePeriodValue17.getValue();
        timePeriodValues10.add(timePeriodValue17);
        timePeriodValues10.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date28 = simpleTimePeriod27.getEnd();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, (double) (-1L));
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        int int33 = simpleTimePeriod27.compareTo((java.lang.Object) year31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year31.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year31, 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0d + "'", number18.equals(100.0d));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        int int10 = year0.compareTo((java.lang.Object) seriesChangeEvent8);
        java.lang.Object obj11 = seriesChangeEvent8.getSource();
        java.lang.String str12 = seriesChangeEvent8.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + (-1) + "'", obj11.equals((-1)));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        boolean boolean6 = timePeriodValues1.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        java.util.Date date11 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int14 = timePeriodValues13.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Object obj17 = timePeriodValues13.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 100.0f);
        timePeriodValue21.setValue((java.lang.Number) 12);
        timePeriodValue21.setValue((java.lang.Number) (short) 0);
        timePeriodValues13.add(timePeriodValue21);
        java.lang.Class class27 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone33);
        boolean boolean35 = timePeriodValue21.equals((java.lang.Object) date32);
        boolean boolean36 = simpleTimePeriod9.equals((java.lang.Object) date32);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, 0.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int43 = timePeriodValues42.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (double) 100.0f);
        java.lang.Number number50 = timePeriodValue49.getValue();
        timePeriodValues42.add(timePeriodValue49);
        timePeriodValues42.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year57, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod61 = timePeriodValue60.getPeriod();
        boolean boolean63 = timePeriodValue60.equals((java.lang.Object) "Time");
        timePeriodValues42.add(timePeriodValue60);
        timePeriodValues1.add(timePeriodValue60);
        int int66 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 100.0d + "'", number50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriod61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date5 = simpleTimePeriod4.getEnd();
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        java.util.Date date11 = simpleTimePeriod9.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date5, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod17);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Object obj7 = null;
        boolean boolean8 = day6.equals(obj7);
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod10.getClass();
        java.util.Date date12 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        boolean boolean16 = year13.equals((java.lang.Object) '4');
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        long long19 = year17.getMiddleMillisecond();
        long long20 = year17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        int int22 = year13.compareTo((java.lang.Object) regularTimePeriod21);
        int int23 = year13.getYear();
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date12, date24);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        timePeriodValues3.setDescription("Value");
        timePeriodValues3.delete(1, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.delete((int) ' ', 1);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy(0, (int) (byte) 100);
        java.lang.String str17 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        boolean boolean3 = year0.equals((java.lang.Object) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int8 = year0.compareTo((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.next();
        java.lang.Object obj10 = null;
        boolean boolean11 = year0.equals(obj10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int16 = timePeriodValues15.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy((-1), (int) (byte) 1);
        boolean boolean20 = timePeriodValues15.getNotify();
        timePeriodValues15.fireSeriesChanged();
        int int22 = timePeriodValues15.getMaxEndIndex();
        int int23 = timePeriodValues15.getMaxEndIndex();
        java.lang.String str24 = timePeriodValues15.getRangeDescription();
        int int25 = year0.compareTo((java.lang.Object) str24);
        long long26 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Class class0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        java.util.Date date5 = simpleTimePeriod3.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone6);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int10 = timePeriodValues9.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues9.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 100.0f);
        timePeriodValue17.setValue((java.lang.Number) 12);
        timePeriodValue17.setValue((java.lang.Number) (short) 0);
        timePeriodValues9.add(timePeriodValue17);
        java.lang.Class class23 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date27 = simpleTimePeriod26.getEnd();
        java.util.Date date28 = simpleTimePeriod26.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone29);
        boolean boolean31 = timePeriodValue17.equals((java.lang.Object) date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date35 = simpleTimePeriod34.getEnd();
        java.util.Date date36 = simpleTimePeriod34.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year37, (double) 100.0f);
        long long41 = year37.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int46 = timePeriodValues45.getMinMiddleIndex();
        boolean boolean47 = year37.equals((java.lang.Object) int46);
        java.util.Date date48 = year37.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getLastMillisecond();
        java.lang.String str51 = year49.toString();
        java.util.Date date52 = year49.getStart();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date48, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date36, timeZone53);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date28, timeZone53);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date5, date28);
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        int int6 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date3);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        java.lang.String str14 = year11.toString();
        long long15 = year11.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
//        long long4 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int9 = timePeriodValues8.getMinMiddleIndex();
//        boolean boolean10 = year0.equals((java.lang.Object) int9);
//        java.util.Date date11 = year0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        int int18 = day15.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        int int21 = day15.compareTo((java.lang.Object) day19);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date27 = simpleTimePeriod26.getEnd();
//        java.util.Date date28 = simpleTimePeriod26.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int31 = timePeriodValues30.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
//        java.lang.Object obj34 = timePeriodValues30.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (double) 100.0f);
//        timePeriodValue38.setValue((java.lang.Number) 12);
//        timePeriodValue38.setValue((java.lang.Number) (short) 0);
//        timePeriodValues30.add(timePeriodValue38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date48 = simpleTimePeriod47.getEnd();
//        java.util.Date date49 = simpleTimePeriod47.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone50);
//        boolean boolean52 = timePeriodValue38.equals((java.lang.Object) date49);
//        boolean boolean53 = simpleTimePeriod26.equals((java.lang.Object) date49);
//        int int54 = day15.compareTo((java.lang.Object) simpleTimePeriod26);
//        int int55 = day15.getDayOfMonth();
//        java.util.Date date56 = day15.getEnd();
//        long long57 = day15.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 13 + "'", int55 == 13);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10, "hi!", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int7 = timePeriodValues6.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues6.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues6.add(timePeriodValue14);
        java.lang.Class class20 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone26);
        boolean boolean28 = timePeriodValue14.equals((java.lang.Object) date25);
        timePeriodValue14.setValue((java.lang.Number) 1.0f);
        timePeriodValues3.add(timePeriodValue14);
        int int32 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int39 = timePeriodValues38.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 100.0f);
        java.lang.Number number46 = timePeriodValue45.getValue();
        timePeriodValues38.add(timePeriodValue45);
        java.lang.String str48 = timePeriodValue45.toString();
        java.lang.Object obj49 = timePeriodValue45.clone();
        java.lang.Number number50 = timePeriodValue45.getValue();
        timePeriodValues3.add(timePeriodValue45);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 100.0d + "'", number46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str48.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 100.0d + "'", number50.equals(100.0d));
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        int int3 = day0.getYear();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date3);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod13, (java.lang.Number) 25568L);
        java.lang.Object obj17 = timePeriodValue16.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        int int7 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj8 = timePeriodValues1.clone();
        int int9 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getLastMillisecond();
//        java.lang.String str5 = year3.toString();
//        java.util.Date date6 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year3);
//        boolean boolean8 = day0.equals((java.lang.Object) year3);
//        int int9 = day0.getDayOfMonth();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((-1), 3);
        timePeriodValues13.setNotify(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date19, date24);
        long long27 = simpleTimePeriod26.getEndMillis();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        int int30 = simpleTimePeriod26.compareTo((java.lang.Object) day28);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (double) 1562097599999L);
        timePeriodValues13.setKey((java.lang.Comparable) simpleTimePeriod26);
        timePeriodValues13.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1562097599999L, (long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) 100.0f);
        java.lang.Number number6 = timePeriodValue5.getValue();
        boolean boolean7 = year1.equals((java.lang.Object) timePeriodValue5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.previous();
        java.util.Calendar calendar9 = null;
        try {
            year1.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int7 = timePeriodValues6.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        long long11 = year10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 100.0f);
//        java.lang.Number number14 = timePeriodValue13.getValue();
//        timePeriodValues6.add(timePeriodValue13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 10);
//        long long19 = day16.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("13-June-2019");
//        int int22 = day16.compareTo((java.lang.Object) seriesException21);
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException21);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100.0d + "'", number14.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 10);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 10 + "'", obj2.equals((byte) 10));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str24 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        int int30 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        long long7 = year4.getSerialIndex();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) year4);
        long long9 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (byte) -1);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (-1L));
        int int24 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (double) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int33 = year25.compareTo((java.lang.Object) "");
        long long34 = year25.getSerialIndex();
        boolean boolean35 = timePeriodValues3.equals((java.lang.Object) year25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
        java.lang.Number number11 = timePeriodValue10.getValue();
        timePeriodValues3.add(timePeriodValue10);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.update((int) (short) 0, (java.lang.Number) 6);
        boolean boolean17 = timePeriodValues3.getNotify();
        int int18 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        java.lang.String str3 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertNull(str3);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.lang.String str14 = year12.toString();
        java.util.Date date15 = year12.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 10 + "'", comparable7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100.0f);
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        boolean boolean10 = year0.equals((java.lang.Object) int9);
        java.util.Date date11 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11, "hi!", "TimePeriodValue[2019,100.0]");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        int int18 = day15.compareTo((java.lang.Object) 4);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day15.compareTo((java.lang.Object) day19);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
        java.lang.String str24 = timePeriodValues14.getRangeDescription();
        java.lang.Comparable comparable25 = timePeriodValues14.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        long long32 = year30.getMiddleMillisecond();
        long long33 = year30.getSerialIndex();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) (byte) 1);
        java.lang.Number number36 = null;
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year30, number36);
        long long38 = year30.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str24.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
//        timePeriodValue14.setValue((java.lang.Number) 12);
//        timePeriodValue14.setValue((java.lang.Number) (short) 0);
//        timePeriodValues3.add(timePeriodValue14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int24 = timePeriodValues23.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
//        java.lang.Number number31 = timePeriodValue30.getValue();
//        timePeriodValues23.add(timePeriodValue30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 10);
//        boolean boolean36 = timePeriodValue14.equals((java.lang.Object) day33);
//        java.lang.Object obj37 = timePeriodValue14.clone();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        int int41 = day38.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        int int44 = day38.compareTo((java.lang.Object) day42);
//        int int45 = day38.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day38.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        long long49 = year48.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (double) 100.0f);
//        java.lang.Class<?> wildcardClass52 = year48.getClass();
//        boolean boolean53 = day47.equals((java.lang.Object) wildcardClass52);
//        org.jfree.data.time.SerialDate serialDate54 = day47.getSerialDate();
//        java.lang.Class<?> wildcardClass55 = serialDate54.getClass();
//        boolean boolean56 = timePeriodValue14.equals((java.lang.Object) serialDate54);
//        java.lang.Number number57 = timePeriodValue14.getValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0d + "'", number31.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (short) 0 + "'", number57.equals((short) 0));
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinMiddleIndex();
        int int7 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 10 + "'", comparable8.equals((byte) 10));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        java.lang.String str8 = timePeriodValues1.getDomainDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int12 = timePeriodValues11.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues11.removePropertyChangeListener(propertyChangeListener13);
        java.lang.Object obj15 = timePeriodValues11.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) 100.0f);
        timePeriodValue19.setValue((java.lang.Number) 12);
        timePeriodValue19.setValue((java.lang.Number) (short) 0);
        timePeriodValues11.add(timePeriodValue19);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Class<?> wildcardClass27 = seriesChangeEvent26.getClass();
        java.lang.Object obj28 = seriesChangeEvent26.getSource();
        boolean boolean29 = timePeriodValue19.equals(obj28);
        java.lang.String str30 = timePeriodValue19.toString();
        timePeriodValues1.add(timePeriodValue19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 10 + "'", comparable7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + (-1) + "'", obj28.equals((-1)));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TimePeriodValue[2019,0]" + "'", str30.equals("TimePeriodValue[2019,0]"));
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener3);
//        java.lang.Object obj5 = timePeriodValues1.clone();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        long long7 = year6.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 100.0f);
//        timePeriodValue9.setValue((java.lang.Number) 12);
//        timePeriodValue9.setValue((java.lang.Number) (short) 0);
//        timePeriodValues1.add(timePeriodValue9);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) 100.0f);
//        timePeriodValues1.add(timePeriodValue19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        int int23 = day21.getYear();
//        int int24 = day21.getYear();
//        int int25 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day21.getSerialDate();
//        boolean boolean27 = timePeriodValue19.equals((java.lang.Object) day21);
//        int int28 = day21.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        boolean boolean4 = year0.equals((java.lang.Object) 100.0d);
        int int5 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "31-December-1969", "TimePeriodValue[2019,12]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date4, "13-June-2019", "Value");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4);
        java.lang.String str9 = year8.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date4, "13-June-2019", "Value");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        java.util.Date date13 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int16 = timePeriodValues15.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Object obj19 = timePeriodValues15.clone();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 100.0f);
        timePeriodValue23.setValue((java.lang.Number) 12);
        timePeriodValue23.setValue((java.lang.Number) (short) 0);
        timePeriodValues15.add(timePeriodValue23);
        java.lang.Class class29 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date33 = simpleTimePeriod32.getEnd();
        java.util.Date date34 = simpleTimePeriod32.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone35);
        boolean boolean37 = timePeriodValue23.equals((java.lang.Object) date34);
        boolean boolean38 = simpleTimePeriod11.equals((java.lang.Object) date34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date4, date34);
        long long40 = simpleTimePeriod39.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date49 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date44, date49);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date49, timeZone52);
        boolean boolean54 = simpleTimePeriod39.equals((java.lang.Object) timeZone52);
        long long55 = simpleTimePeriod39.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1L) + "'", long55 == (-1L));
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 100.0f);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        timePeriodValues3.add(timePeriodValue10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 10);
//        long long16 = day13.getSerialIndex();
//        long long17 = day13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = day0.equals(obj1);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getLastMillisecond();
//        java.lang.String str5 = year3.toString();
//        java.util.Date date6 = year3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year3);
//        boolean boolean8 = day0.equals((java.lang.Object) year3);
//        int int9 = day0.getDayOfMonth();
//        int int10 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int15 = timePeriodValues14.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues14.removePropertyChangeListener(propertyChangeListener18);
//        int int20 = timePeriodValues14.getItemCount();
//        java.lang.String str21 = timePeriodValues14.getRangeDescription();
//        int int22 = timePeriodValues14.getMinEndIndex();
//        boolean boolean23 = day0.equals((java.lang.Object) int22);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
//        java.util.Date date8 = simpleTimePeriod7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
//        long long11 = simpleTimePeriod10.getEndMillis();
//        long long12 = simpleTimePeriod10.getStartMillis();
//        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("13-June-2019");
//        boolean boolean15 = simpleTimePeriod10.equals((java.lang.Object) "13-June-2019");
//        java.util.Date date16 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        int int20 = day17.compareTo((java.lang.Object) 4);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int23 = day17.compareTo((java.lang.Object) day21);
//        int int24 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = day17.getSerialDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
//        java.lang.Class<?> wildcardClass31 = year27.getClass();
//        boolean boolean32 = day26.equals((java.lang.Object) wildcardClass31);
//        int int33 = day26.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day26.previous();
//        boolean boolean35 = simpleTimePeriod10.equals((java.lang.Object) day26);
//        java.util.Date date36 = simpleTimePeriod10.getStart();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 100.0f);
        long long17 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int22 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean23 = year13.equals((java.lang.Object) int22);
        java.util.Date date24 = year13.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.lang.String str27 = year25.toString();
        java.util.Date date28 = year25.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24, timeZone29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date24);
        long long33 = day32.getLastMillisecond();
        timePeriodValues3.setKey((java.lang.Comparable) long33);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
        timePeriodValue14.setValue((java.lang.Number) 12);
        timePeriodValue14.setValue((java.lang.Number) (short) 0);
        timePeriodValues3.add(timePeriodValue14);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue29 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 100.0f);
        long long16 = year12.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int21 = timePeriodValues20.getMinMiddleIndex();
        boolean boolean22 = year12.equals((java.lang.Object) int21);
        java.util.Date date23 = year12.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.lang.String str26 = year24.toString();
        java.util.Date date27 = year24.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date23, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date23);
        long long32 = day31.getMiddleMillisecond();
        int int33 = simpleTimePeriod10.compareTo((java.lang.Object) day31);
        java.util.Date date34 = simpleTimePeriod10.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577822399999L + "'", long32 == 1577822399999L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        timePeriodValues3.delete((int) ' ', 1);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues3.getMaxEndIndex();
        try {
            java.lang.Number number16 = timePeriodValues3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        int int5 = year0.compareTo((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, 1562097599999L);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        int int12 = year7.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year6.equals((java.lang.Object) year13);
        boolean boolean16 = year13.equals((java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy((-1), (int) (byte) 1);
        boolean boolean8 = timePeriodValues3.getNotify();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int4 = timePeriodValues3.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) 100.0f);
//        timePeriodValue14.setValue((java.lang.Number) 12);
//        timePeriodValue14.setValue((java.lang.Number) (short) 0);
//        timePeriodValues3.add(timePeriodValue14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int24 = timePeriodValues23.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) 100.0f);
//        java.lang.Number number31 = timePeriodValue30.getValue();
//        timePeriodValues23.add(timePeriodValue30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 10);
//        boolean boolean36 = timePeriodValue14.equals((java.lang.Object) day33);
//        int int37 = day33.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "");
//        int int42 = timePeriodValues41.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timePeriodValues41.removePropertyChangeListener(propertyChangeListener43);
//        timePeriodValues41.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        long long50 = year49.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (double) 100.0f);
//        timePeriodValue52.setValue((java.lang.Number) 12);
//        timePeriodValue52.setValue((java.lang.Number) (short) 0);
//        timePeriodValues41.add(timePeriodValue52);
//        timePeriodValues41.delete((int) (byte) 100, 13);
//        timePeriodValues41.setNotify(true);
//        int int63 = timePeriodValues41.getMaxEndIndex();
//        int int64 = day33.compareTo((java.lang.Object) int63);
//        java.util.Calendar calendar65 = null;
//        try {
//            long long66 = day33.getLastMillisecond(calendar65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0d + "'", number31.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 13 + "'", int37 == 13);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//    }
//}

