import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(regularTimePeriod3, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        try {
            timeSeries1.delete((int) (short) -1, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            timeSeries1.add(regularTimePeriod3, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) false, seriesChangeInfo1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number6 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, number6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((int) (short) 100, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184731632L + "'", long4 == 1560184731632L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        boolean boolean6 = month2.equals((java.lang.Object) (byte) 0);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Number number3 = null;
        try {
            timeSeries1.update(12, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries5.delete(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        try {
//            java.lang.Number number9 = timeSeries1.getValue(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184732322L + "'", long4 == 1560184732322L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries1.add(regularTimePeriod10, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int5 = month4.getYearValue();
        long long6 = month4.getSerialIndex();
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (double) 1577865599999L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184732898L + "'", long5 == 1560184732898L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        java.util.Calendar calendar3 = null;
//        long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184732919L + "'", long1 == 1560184732919L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184732918L + "'", long4 == 1560184732918L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int5 = month4.getYearValue();
        long long6 = month4.getSerialIndex();
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        try {
            timeSeries9.delete(10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            int int5 = timeSeries1.getIndex(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = null;
//        try {
//            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184734027L + "'", long1 == 1560184734027L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        try {
//            java.lang.Object obj21 = timeSeriesDataItem20.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184734722L + "'", long14 == 1560184734722L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.getDataItem(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184735202L + "'", long9 == 1560184735202L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        timeSeries1.setKey((java.lang.Comparable) date9);
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184735327L + "'", long8 == 1560184735327L);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(12, year1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        java.util.Calendar calendar18 = null;
//        try {
//            month9.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184735517L + "'", long4 == 1560184735517L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj4 = null;
        boolean boolean5 = month3.equals(obj4);
        boolean boolean7 = month3.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year8 = month3.getYear();
        int int9 = year8.getYear();
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) -1, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        timeSeries1.removeAgedItems((long) '#', true);
//        try {
//            timeSeries1.delete((int) 'a', (int) 'a', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184736519L + "'", long8 == 1560184736519L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (java.lang.Number) 100.0d);
//        timeSeriesDataItem11.setValue((java.lang.Number) 1201L);
//        timeSeries1.add(timeSeriesDataItem11, true);
//        int int16 = timeSeries1.getItemCount();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        long long20 = year18.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(12, year18);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184736936L + "'", long7 == 1560184736936L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.addOrUpdate(timeSeriesDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(12, year1);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month7.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = null;
//        try {
//            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184738173L + "'", long1 == 1560184738173L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            timeSeries9.update(12, (java.lang.Number) 1560184731518L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = month9.getFirstMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184738440L + "'", long4 == 1560184738440L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getTimePeriod(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184738914L + "'", long4 == 1560184738914L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560184734991L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        double double10 = timeSeries9.getMaxY();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        boolean boolean14 = year12.equals((java.lang.Object) Double.NaN);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560184734477L);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.createCopy(11, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getMonth();
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        int int6 = day4.getDayOfMonth();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 1560184738191L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) 9999);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj6 = null;
        boolean boolean7 = month5.equals(obj6);
        boolean boolean9 = month5.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year10 = month5.getYear();
        int int11 = year10.getYear();
        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) int11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        java.util.Date date27 = fixedMillisecond25.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560184731994L);
//        timeSeriesDataItem29.setSelected(true);
//        timeSeries1.add(timeSeriesDataItem29);
//        timeSeriesDataItem29.setValue((java.lang.Number) 1560184731570L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184740563L + "'", long8 == 1560184740563L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560184740565L + "'", long26 == 1560184740565L);
//        org.junit.Assert.assertNotNull(date27);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        java.lang.String str16 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184741431L + "'", long1 == 1560184741431L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Mon Jun 10 09:39:01 PDT 2019" + "'", str16.equals("Mon Jun 10 09:39:01 PDT 2019"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011603200000L) + "'", long3 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        try {
            timeSeries1.delete(10, (int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number19 = null;
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184741715L + "'", long4 == 1560184741715L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        boolean boolean10 = timeSeries1.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries1.update(regularTimePeriod11, (java.lang.Number) 1560184741632L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (double) 1577865599999L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass13 = timeSeries12.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
//        int int17 = timeSeries12.getIndex(regularTimePeriod16);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = month20.equals(obj21);
//        boolean boolean24 = month20.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year25 = month20.getYear();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 10, false);
//        int int29 = month20.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "org.jfree.data.event.SeriesChangeEvent[source=10.0]", "2019");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month20.previous();
//        try {
//            timeSeries1.setKey((java.lang.Comparable) regularTimePeriod33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184742365L + "'", long5 == 1560184742365L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560184742367L + "'", long15 == 1560184742367L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        try {
//            timeSeries1.delete(0, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184742423L + "'", long4 == 1560184742423L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone19 = null;
//        try {
//            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date14, timeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184742453L + "'", long13 == 1560184742453L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        java.util.TimeZone timeZone18 = null;
//        java.util.Locale locale19 = null;
//        try {
//            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date14, timeZone18, locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184742485L + "'", long13 == 1560184742485L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod3);
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184742511L + "'", long1 == 1560184742511L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
        boolean boolean3 = year1.equals((java.lang.Object) Double.NaN);
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean4 = timeSeries2.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries6.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        java.lang.String str13 = year11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year11.next();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(100, year11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        long long2 = year0.getSerialIndex();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
//        java.lang.Class<?> wildcardClass9 = seriesChangeEvent7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean13 = timeSeries12.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        timeSeries12.setKey((java.lang.Comparable) date20);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date20, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date20, timeZone25);
//        java.util.TimeZone timeZone27 = null;
//        try {
//            org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date20, timeZone27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184744344L + "'", long19 == 1560184744344L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.String str2 = regularTimePeriod1.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mon Jun 10 09:39:04 PDT 2019" + "'", str2.equals("Mon Jun 10 09:39:04 PDT 2019"));
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        java.util.Calendar calendar13 = null;
//        try {
//            day9.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184744515L + "'", long4 == 1560184744515L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        try {
            java.util.Date date5 = regularTimePeriod4.getStart();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        timeSeries1.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass14 = timeSeries13.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        int int18 = timeSeries13.getIndex(regularTimePeriod17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = month21.equals(obj22);
//        boolean boolean25 = month21.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year26 = month21.getYear();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month21.previous();
//        java.util.Date date31 = month21.getEnd();
//        int int32 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        java.lang.String str33 = timeSeries1.getDomainDescription();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184746245L + "'", long4 == 1560184746245L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560184746246L + "'", long16 == 1560184746246L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
        try {
            java.lang.Number number5 = timeSeries1.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemAge(1577865599999L);
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        int int11 = year10.getYear();
//        java.lang.String str12 = year10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 10);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass18 = timeSeries17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass21 = timeSeries20.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond22.previous();
//        int int25 = timeSeries20.getIndex(regularTimePeriod24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod24, (java.lang.Number) 100.0d);
//        timeSeriesDataItem27.setValue((java.lang.Number) 1201L);
//        timeSeries17.add(timeSeriesDataItem27, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getMiddleMillisecond(calendar34);
//        int int36 = timeSeriesDataItem27.compareTo((java.lang.Object) calendar34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem27.getPeriod();
//        try {
//            timeSeries5.add(timeSeriesDataItem27);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184746470L + "'", long23 == 1560184746470L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560184746472L + "'", long35 == 1560184746472L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184746731L + "'", long1 == 1560184746731L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184746731L + "'", long3 == 1560184746731L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemAge(1577865599999L);
        try {
            java.lang.Number number6 = timeSeries1.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        double double10 = timeSeries9.getMaxY();
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy((int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        java.lang.Comparable comparable9 = timeSeries1.getKey();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184747285L + "'", long4 == 1560184747285L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 100 + "'", comparable9.equals((short) 100));
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Date date19 = month9.getEnd();
//        java.util.TimeZone timeZone20 = null;
//        java.util.Locale locale21 = null;
//        try {
//            org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone20, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184747692L + "'", long4 == 1560184747692L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem13.getPeriod();
//        java.lang.Object obj16 = timeSeriesDataItem13.clone();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184747747L + "'", long9 == 1560184747747L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(obj16);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184747790L + "'", long1 == 1560184747790L);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        timeSeries14.setKey((java.lang.Comparable) 1560184740164L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries14.getDataItem(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184747799L + "'", long1 == 1560184747799L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.String str3 = timeSeries1.getDescription();
        timeSeries1.removeAgedItems(1560184743166L, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month2.getYear();
        long long6 = month2.getFirstMillisecond();
        int int7 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59011603200000L) + "'", long4 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59011603200000L) + "'", long6 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj15 = null;
        boolean boolean16 = month14.equals(obj15);
        boolean boolean18 = month14.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int20 = year19.getYear();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries9.fireSeriesChanged();
        timeSeries9.setDescription("Mon Jun 10 09:38:56 PDT 2019");
        try {
            timeSeries9.delete(100, 3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560184739172L, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560184739172]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=1560184739172]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
//        int int19 = timeSeries14.getIndex(regularTimePeriod18);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = month22.equals(obj23);
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year27 = month22.getYear();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 10, false);
//        timeSeries14.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.lang.Class<?> wildcardClass33 = timeSeries14.getClass();
//        boolean boolean34 = timeSeries14.isEmpty();
//        int int35 = day9.compareTo((java.lang.Object) timeSeries14);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int39 = month38.getYearValue();
//        long long40 = month38.getSerialIndex();
//        long long41 = month38.getLastMillisecond();
//        long long42 = month38.getSerialIndex();
//        try {
//            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 1560184734991L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period January 100 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184749140L + "'", long4 == 1560184749140L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560184749143L + "'", long17 == 1560184749143L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1201L + "'", long40 == 1201L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-59008924800001L) + "'", long41 == (-59008924800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1201L + "'", long42 == 1201L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        long long10 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries9.add(regularTimePeriod11, (java.lang.Number) 1560184740164L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1201L + "'", long4 == 1201L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
        boolean boolean6 = year0.equals((java.lang.Object) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(12, year1);
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = month4.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24240L + "'", long6 == 24240L);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        timeSeries5.fireSeriesChanged();
//        try {
//            timeSeries5.delete((int) (short) 10, (-9999));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184749674L + "'", long8 == 1560184749674L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        int int8 = timeSeries1.getItemCount();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int12 = month11.getYearValue();
        long long13 = month11.getSerialIndex();
        java.lang.Number number14 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.Comparable comparable15 = timeSeries1.getKey();
        try {
            timeSeries1.delete(0, (int) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1201L + "'", long13 == 1201L);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 100 + "'", comparable15.equals((short) 100));
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long30 = month29.getFirstMillisecond();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        boolean boolean32 = fixedMillisecond20.equals((java.lang.Object) year31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond20.previous();
//        long long34 = fixedMillisecond20.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184750113L + "'", long21 == 1560184750113L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184750113L + "'", long23 == 1560184750113L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560184750113L + "'", long25 == 1560184750113L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-59011603200000L) + "'", long30 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560184750113L + "'", long34 == 1560184750113L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 10.0d + "'", obj4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0d + "'", obj5.equals(10.0d));
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        int int6 = day5.getMonth();
//        int int7 = day5.getMonth();
//        int int8 = day5.getDayOfMonth();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) 1560184748302L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Date date12 = fixedMillisecond10.getTime();
//        long long13 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond14.peg(calendar15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries17.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184750305L + "'", long11 == 1560184750305L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184750305L + "'", long13 == 1560184750305L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        java.util.Date date28 = regularTimePeriod27.getStart();
//        try {
//            timeSeries5.add(regularTimePeriod27, (java.lang.Number) 1201L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184750452L + "'", long8 == 1560184750452L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        timeSeries1.removeAgedItems((long) '#', true);
//        timeSeries1.clear();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184750497L + "'", long8 == 1560184750497L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 09:38:56 PDT 2019");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        timeSeries1.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass14 = timeSeries13.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        int int18 = timeSeries13.getIndex(regularTimePeriod17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = month21.equals(obj22);
//        boolean boolean25 = month21.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year26 = month21.getYear();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month21.previous();
//        java.util.Date date31 = month21.getEnd();
//        int int32 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        org.jfree.data.time.Year year33 = month21.getYear();
//        java.util.Calendar calendar34 = null;
//        try {
//            month21.peg(calendar34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184750875L + "'", long4 == 1560184750875L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560184750890L + "'", long16 == 1560184750890L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(year33);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        int int8 = timeSeries1.getItemCount();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int12 = month11.getYearValue();
//        long long13 = month11.getSerialIndex();
//        java.lang.Number number14 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass17 = timeSeries16.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
//        int int21 = timeSeries16.getIndex(regularTimePeriod20);
//        boolean boolean22 = timeSeries16.isEmpty();
//        double double23 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass29 = timeSeries28.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        int int33 = timeSeries28.getIndex(regularTimePeriod32);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = month36.equals(obj37);
//        boolean boolean40 = month36.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year41 = month36.getYear();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month36.previous();
//        java.util.Date date46 = month36.getEnd();
//        int int47 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.Year year48 = month36.getYear();
//        int int49 = year48.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year48, (double) 1560184740563L, true);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass55 = timeSeries54.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        long long57 = fixedMillisecond56.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond56.previous();
//        int int59 = timeSeries54.getIndex(regularTimePeriod58);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj63 = null;
//        boolean boolean64 = month62.equals(obj63);
//        boolean boolean66 = month62.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year67 = month62.getYear();
//        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) month62, (java.lang.Number) 10, false);
//        int int71 = month62.getMonth();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month62, (java.lang.Number) 1560184746991L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1201L + "'", long13 == 1201L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184751448L + "'", long19 == 1560184751448L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560184751450L + "'", long31 == 1560184751450L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560184751453L + "'", long57 == 1560184751453L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Date date19 = month9.getEnd();
//        java.util.TimeZone timeZone20 = null;
//        try {
//            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19, timeZone20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184752096L + "'", long4 == 1560184752096L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getMonth();
//        long long4 = day2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        timeSeries1.add(regularTimePeriod5, (double) 1560184736072L, true);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        int int3 = day0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560184734991L);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.560184734991E12d + "'", number6.equals(1.560184734991E12d));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Date date12 = fixedMillisecond10.getTime();
//        long long13 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond14.peg(calendar15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
//        int int34 = timeSeries29.getIndex(regularTimePeriod33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 100.0d);
//        timeSeries24.add(timeSeriesDataItem36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries19.addOrUpdate(timeSeriesDataItem36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) fixedMillisecond39);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean44 = timeSeries42.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean47 = timeSeries46.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries46.addChangeListener(seriesChangeListener48);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries42.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int56 = month55.getYearValue();
//        long long57 = month55.getSerialIndex();
//        int int58 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) month55);
//        org.jfree.data.time.Year year59 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) month55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getMiddleMillisecond();
//        java.util.Date date63 = fixedMillisecond61.getTime();
//        long long64 = fixedMillisecond61.getSerialIndex();
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond61.getLastMillisecond(calendar65);
//        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        int int68 = timeSeriesDataItem36.compareTo((java.lang.Object) fixedMillisecond61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries5.addOrUpdate(timeSeriesDataItem36);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean73 = timeSeries71.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean76 = timeSeries75.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener77 = null;
//        timeSeries75.addChangeListener(seriesChangeListener77);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries71.addAndOrUpdate(timeSeries75);
//        timeSeries79.removeAgedItems(false);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj85 = null;
//        boolean boolean86 = month84.equals(obj85);
//        boolean boolean88 = month84.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year89 = month84.getYear();
//        int int90 = year89.getYear();
//        int int91 = timeSeries79.getIndex((org.jfree.data.time.RegularTimePeriod) year89);
//        timeSeries79.fireSeriesChanged();
//        timeSeries79.setDescription("Mon Jun 10 09:38:56 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries95 = timeSeries5.addAndOrUpdate(timeSeries79);
//        try {
//            timeSeries5.removeAgedItems((-1L), true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184753195L + "'", long11 == 1560184753195L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184753195L + "'", long13 == 1560184753195L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560184753198L + "'", long32 == 1560184753198L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1201L + "'", long57 == 1201L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560184753201L + "'", long62 == 1560184753201L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560184753201L + "'", long64 == 1560184753201L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560184753201L + "'", long66 == 1560184753201L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(year89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 100 + "'", int90 == 100);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries95);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        int int8 = timeSeries1.getItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184753252L + "'", long4 == 1560184753252L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560184747790L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) 1560184738652L, false);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries10.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate(regularTimePeriod15, (double) 1577865599999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, 0.0d);
//        java.lang.Number number23 = timeSeriesDataItem22.getValue();
//        timeSeriesDataItem22.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries10.addOrUpdate(timeSeriesDataItem22);
//        try {
//            timeSeries1.add(timeSeriesDataItem22);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184753842L + "'", long14 == 1560184753842L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184753843L + "'", long19 == 1560184753843L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        boolean boolean4 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        boolean boolean12 = timeSeries6.isEmpty();
//        double double13 = timeSeries6.getMaxY();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560184730581L, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries6);
//        long long24 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184753858L + "'", long9 == 1560184753858L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int11 = month10.getYearValue();
        long long12 = month10.getSerialIndex();
        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        int int14 = month10.getMonth();
        java.lang.Number number15 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1201L + "'", long12 == 1201L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener21);
//        int int23 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184755502L + "'", long14 == 1560184755502L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        timeSeries14.setKey((java.lang.Comparable) 1560184740164L);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int21 = month20.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.previous();
//        long long24 = month20.getLastMillisecond();
//        org.jfree.data.time.Year year25 = month20.getYear();
//        long long26 = month20.getLastMillisecond();
//        try {
//            timeSeries14.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560184733265L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184755650L + "'", long1 == 1560184755650L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59008924800001L) + "'", long24 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-59008924800001L) + "'", long26 == (-59008924800001L));
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        timeSeries1.removeAgedItems((long) '#', true);
//        org.jfree.data.time.TimeSeries timeSeries28 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.addAndOrUpdate(timeSeries28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184755828L + "'", long8 == 1560184755828L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        boolean boolean24 = day21.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) 1560184734991L);
//        long long27 = day21.getSerialIndex();
//        int int28 = timeSeriesDataItem18.compareTo((java.lang.Object) long27);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184755855L + "'", long14 == 1560184755855L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
//        try {
//            timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560184752187L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184756109L + "'", long8 == 1560184756109L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:39:02 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int7 = month6.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
//        long long10 = month6.getLastMillisecond();
//        int int11 = month6.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
//        java.lang.Number number18 = timeSeriesDataItem17.getValue();
//        int int19 = month6.compareTo((java.lang.Object) number18);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59008924800001L) + "'", long10 == (-59008924800001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184756655L + "'", long14 == 1560184756655L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond21);
//        long long23 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184756760L + "'", long14 == 1560184756760L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184756762L + "'", long23 == 1560184756762L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        java.lang.String str4 = fixedMillisecond0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184757126L + "'", long1 == 1560184757126L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184757126L + "'", long3 == 1560184757126L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 09:39:17 PDT 2019" + "'", str4.equals("Mon Jun 10 09:39:17 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        timeSeries1.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass14 = timeSeries13.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        int int18 = timeSeries13.getIndex(regularTimePeriod17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = month21.equals(obj22);
//        boolean boolean25 = month21.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year26 = month21.getYear();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month21.previous();
//        java.util.Date date31 = month21.getEnd();
//        int int32 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        try {
//            timeSeries1.delete(0, (-9999), false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184757138L + "'", long4 == 1560184757138L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560184757140L + "'", long16 == 1560184757140L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.lang.String str6 = timeSeries1.getDomainDescription();
        try {
            timeSeries1.update(0, (java.lang.Number) 1560184744756L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.delete((int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "10-June-2019", "Mon Jun 10 09:39:04 PDT 2019");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date1, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year4 = month2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011603200000L) + "'", long3 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
//        int int34 = timeSeries29.getIndex(regularTimePeriod33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 100.0d);
//        timeSeries24.add(timeSeriesDataItem36);
//        boolean boolean38 = timeSeriesDataItem18.equals((java.lang.Object) timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184757339L + "'", long14 == 1560184757339L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560184757341L + "'", long32 == 1560184757341L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        int int18 = month9.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "org.jfree.data.event.SeriesChangeEvent[source=10.0]", "2019");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month9.previous();
//        int int23 = month9.getMonth();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184757516L + "'", long4 == 1560184757516L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        timeSeries14.setKey((java.lang.Comparable) 1560184740164L);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries14.getTimePeriod((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184757569L + "'", long1 == 1560184757569L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        long long15 = timeSeries1.getMaximumItemAge();
//        try {
//            timeSeries1.delete(9, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184758038L + "'", long9 == 1560184758038L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        int int5 = timeSeries1.getItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        int int8 = year7.getYear();
//        java.lang.String str9 = year7.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560184734477L);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries13.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        int int23 = timeSeries18.getIndex(regularTimePeriod22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (java.lang.Number) 100.0d);
//        timeSeries13.add(timeSeriesDataItem25);
//        java.lang.String str27 = timeSeries13.getDescription();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 0L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getMonth();
//        long long36 = day34.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.next();
//        int int38 = day34.getYear();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries1.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
//        try {
//            java.lang.Number number42 = timeSeries13.getValue(regularTimePeriod41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184758131L + "'", long21 == 1560184758131L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries11.getKey();
//        int int18 = timeSeries11.getItemCount();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int22 = month21.getYearValue();
//        long long23 = month21.getSerialIndex();
//        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        long long25 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int30 = month29.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.previous();
//        long long33 = month29.getLastMillisecond();
//        org.jfree.data.time.Year year34 = month29.getYear();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass37 = timeSeries36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
//        int int41 = timeSeries36.getIndex(regularTimePeriod40);
//        boolean boolean42 = timeSeries36.isEmpty();
//        double double43 = timeSeries36.getMaxY();
//        int int44 = year34.compareTo((java.lang.Object) timeSeries36);
//        boolean boolean45 = timeSeries26.equals((java.lang.Object) timeSeries36);
//        java.util.Collection collection46 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(0);
//        long long49 = year48.getMiddleMillisecond();
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) year48);
//        java.util.Calendar calendar51 = null;
//        try {
//            long long52 = year48.getFirstMillisecond(calendar51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560184758751L + "'", long39 == 1560184758751L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-62135784000001L) + "'", long49 == (-62135784000001L));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries5.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560184732918L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        boolean boolean6 = month2.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year7 = month2.getYear();
        java.util.Date date8 = month2.getStart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long13 = month12.getFirstMillisecond();
//        java.lang.String str14 = month12.toString();
//        timeSeries5.setKey((java.lang.Comparable) month12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        java.util.Date date18 = fixedMillisecond16.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560184731994L);
//        timeSeriesDataItem20.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries5.addOrUpdate(timeSeriesDataItem20);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.createCopy(10, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January 100" + "'", str14.equals("January 100"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560184760331L + "'", long17 == 1560184760331L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (java.lang.Number) 100.0d);
//        timeSeriesDataItem11.setValue((java.lang.Number) 1201L);
//        timeSeries1.add(timeSeriesDataItem11, true);
//        int int16 = timeSeries1.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond17.previous();
//        java.lang.Number number21 = null;
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number21, false);
//        java.util.Calendar calendar24 = null;
//        fixedMillisecond17.peg(calendar24);
//        boolean boolean27 = fixedMillisecond17.equals((java.lang.Object) 1560184749591L);
//        int int29 = fixedMillisecond17.compareTo((java.lang.Object) 1560184752582L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184760386L + "'", long7 == 1560184760386L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560184760391L + "'", long18 == 1560184760391L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int3 = day0.compareTo((java.lang.Object) 1560184747246L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getLastMillisecond();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int5 = month4.getYearValue();
//        long long6 = month4.getSerialIndex();
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean15 = timeSeries14.getNotify();
//        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries14.addAndOrUpdate(timeSeries19);
//        int int23 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.addAndOrUpdate(timeSeries22);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries24.addChangeListener(seriesChangeListener25);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184760595L + "'", long9 == 1560184760595L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str4 = seriesException3.toString();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        int int6 = year0.compareTo((java.lang.Object) seriesException3);
        long long7 = year0.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        boolean boolean9 = timeSeries1.equals((java.lang.Object) 1560184741794L);
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184760835L + "'", long4 == 1560184760835L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries9.setRangeDescription("hi!");
        timeSeries9.removeAgedItems(1560184756845L, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries1.clear();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int16 = month15.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
        long long19 = month15.getLastMillisecond();
        org.jfree.data.time.Year year20 = month15.getYear();
        long long21 = month15.getLastMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560184735672L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-59008924800001L) + "'", long19 == (-59008924800001L));
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-59008924800001L) + "'", long21 == (-59008924800001L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.Comparable comparable5 = null;
        try {
            timeSeries1.setKey(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        double double10 = timeSeries9.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass13 = timeSeries12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass16 = timeSeries15.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.previous();
//        int int20 = timeSeries15.getIndex(regularTimePeriod19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (java.lang.Number) 100.0d);
//        timeSeriesDataItem22.setValue((java.lang.Number) 1201L);
//        timeSeries12.add(timeSeriesDataItem22, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getMiddleMillisecond(calendar29);
//        int int31 = timeSeriesDataItem22.compareTo((java.lang.Object) calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries9.addOrUpdate(timeSeriesDataItem22);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj36 = null;
//        boolean boolean37 = month35.equals(obj36);
//        boolean boolean39 = month35.equals((java.lang.Object) (byte) 0);
//        try {
//            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 1560184754573L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560184760996L + "'", long18 == 1560184760996L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560184760997L + "'", long30 == 1560184760997L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        boolean boolean9 = timeSeries1.equals((java.lang.Object) 1560184741794L);
//        int int10 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184761229L + "'", long4 == 1560184761229L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        timeSeries1.setKey((java.lang.Comparable) date9);
//        java.util.TimeZone timeZone11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184761265L + "'", long8 == 1560184761265L);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = month12.equals(obj13);
//        boolean boolean16 = month12.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year17 = month12.getYear();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month12.previous();
//        boolean boolean22 = day0.equals((java.lang.Object) month12);
//        long long23 = month12.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month12.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184761583L + "'", long7 == 1560184761583L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        try {
            java.lang.Number number13 = timeSeries9.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = month12.equals(obj13);
//        boolean boolean16 = month12.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year17 = month12.getYear();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month12.previous();
//        boolean boolean22 = day0.equals((java.lang.Object) month12);
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = day0.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184761810L + "'", long7 == 1560184761810L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj15 = null;
        boolean boolean16 = month14.equals(obj15);
        boolean boolean18 = month14.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int20 = year19.getYear();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries9.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = month14.compareTo((java.lang.Object) day21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day21.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean12 = timeSeries11.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.addChangeListener(seriesChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Comparable comparable17 = timeSeries11.getKey();
        int int18 = timeSeries11.getItemCount();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int22 = month21.getYearValue();
        long long23 = month21.getSerialIndex();
        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
        long long25 = timeSeries11.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
        try {
            timeSeries11.update(0, (java.lang.Number) 1560184752188L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "", "2019");
        timeSeries3.setDescription("10-June-2019");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560184734477L);
        long long12 = year7.getLastMillisecond();
        long long13 = year7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 43626L);
        try {
            timeSeries1.delete((int) (byte) 100, 9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int14 = month13.getYearValue();
//        long long15 = month13.getSerialIndex();
//        int int16 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.Year year17 = month13.getYear();
//        java.lang.String str18 = month13.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (-1.0d));
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = month13.getFirstMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184762217L + "'", long4 == 1560184762217L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1201L + "'", long15 == 1201L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January 100" + "'", str18.equals("January 100"));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:39:04 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        timeSeries9.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean15 = timeSeries13.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass18 = timeSeries17.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.previous();
//        int int22 = timeSeries17.getIndex(regularTimePeriod21);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = month25.equals(obj26);
//        boolean boolean29 = month25.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year30 = month25.getYear();
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 10, false);
//        timeSeries17.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection36 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        long long38 = fixedMillisecond37.getMiddleMillisecond();
//        java.util.Date date39 = fixedMillisecond37.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 1560184731994L);
//        timeSeriesDataItem41.setSelected(true);
//        timeSeries13.add(timeSeriesDataItem41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        long long46 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond45.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, 0.0d);
//        java.lang.Number number50 = timeSeriesDataItem49.getValue();
//        boolean boolean51 = timeSeriesDataItem49.isSelected();
//        int int52 = timeSeriesDataItem41.compareTo((java.lang.Object) timeSeriesDataItem49);
//        java.lang.Number number53 = timeSeriesDataItem49.getValue();
//        timeSeries9.add(timeSeriesDataItem49);
//        timeSeries9.setNotify(true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560184762313L + "'", long20 == 1560184762313L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560184762324L + "'", long38 == 1560184762324L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560184762325L + "'", long46 == 1560184762325L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.0d + "'", number50.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 0.0d + "'", number53.equals(0.0d));
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getYear();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getMonth();
//        java.lang.String str6 = day0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date14);
//        java.util.TimeZone timeZone20 = null;
//        java.util.Locale locale21 = null;
//        try {
//            org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date14, timeZone20, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184762718L + "'", long13 == 1560184762718L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        int int9 = day7.getMonth();
//        long long10 = day7.getLastMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560184750113L, false);
//        java.lang.String str14 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560184734991L);
//        long long6 = day0.getSerialIndex();
//        long long7 = day0.getFirstMillisecond();
//        long long8 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy(0, 10);
        timeSeries1.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=1560184739172]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        int int8 = year7.getYear();
//        java.lang.String str9 = year7.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560184734477L);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries13.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        int int23 = timeSeries18.getIndex(regularTimePeriod22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (java.lang.Number) 100.0d);
//        timeSeries13.add(timeSeriesDataItem25);
//        java.lang.String str27 = timeSeries13.getDescription();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 0L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getMonth();
//        long long36 = day34.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.next();
//        int int38 = day34.getYear();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries1.addAndOrUpdate(timeSeries13);
//        try {
//            timeSeries1.update((int) (short) -1, (java.lang.Number) 1560184755556L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184762956L + "'", long21 == 1560184762956L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:38:56 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        boolean boolean4 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        boolean boolean12 = timeSeries6.isEmpty();
//        double double13 = timeSeries6.getMaxY();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560184730581L, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        boolean boolean29 = day26.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) 1560184734991L);
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 1, true);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 1560184749825L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184763690L + "'", long9 == 1560184763690L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "10-June-2019", "Mon Jun 10 09:39:04 PDT 2019");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        long long12 = day10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
//        timeSeries9.add(regularTimePeriod13, (double) 1560184736072L, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy(regularTimePeriod13, regularTimePeriod17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184763805L + "'", long4 == 1560184763805L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        double double10 = timeSeries9.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass13 = timeSeries12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass16 = timeSeries15.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.previous();
//        int int20 = timeSeries15.getIndex(regularTimePeriod19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (java.lang.Number) 100.0d);
//        timeSeriesDataItem22.setValue((java.lang.Number) 1201L);
//        timeSeries12.add(timeSeriesDataItem22, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getMiddleMillisecond(calendar29);
//        int int31 = timeSeriesDataItem22.compareTo((java.lang.Object) calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries9.addOrUpdate(timeSeriesDataItem22);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries35 = timeSeries9.createCopy(5, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560184763861L + "'", long18 == 1560184763861L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560184763862L + "'", long30 == 1560184763862L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        boolean boolean6 = timeSeriesDataItem4.isSelected();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.util.Date date9 = year8.getEnd();
//        long long10 = year8.getSerialIndex();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(12, year8);
//        long long12 = month11.getLastMillisecond();
//        int int13 = timeSeriesDataItem4.compareTo((java.lang.Object) long12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184763958L + "'", long1 == 1560184763958L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass10 = timeSeries9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass13 = timeSeries12.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
//        int int17 = timeSeries12.getIndex(regularTimePeriod16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (java.lang.Number) 100.0d);
//        timeSeriesDataItem19.setValue((java.lang.Number) 1201L);
//        timeSeries9.add(timeSeriesDataItem19, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getMiddleMillisecond(calendar26);
//        int int28 = timeSeriesDataItem19.compareTo((java.lang.Object) calendar26);
//        timeSeries1.add(timeSeriesDataItem19);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        int int32 = timeSeriesDataItem19.compareTo((java.lang.Object) day30);
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184764541L + "'", long4 == 1560184764541L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560184764542L + "'", long15 == 1560184764542L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560184764544L + "'", long27 == 1560184764544L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(serialDate33);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.next();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getFirstMillisecond(calendar17);
//        long long19 = fixedMillisecond15.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond15.getLastMillisecond(calendar21);
//        long long23 = fixedMillisecond15.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184764693L + "'", long9 == 1560184764693L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560184764694L + "'", long18 == 1560184764694L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184764694L + "'", long19 == 1560184764694L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560184764694L + "'", long22 == 1560184764694L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184764694L + "'", long23 == 1560184764694L);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        timeSeries1.clear();
        java.lang.Object obj5 = timeSeries1.clone();
        timeSeries1.clear();
        try {
            java.lang.Number number8 = timeSeries1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184764959L + "'", long1 == 1560184764959L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184764959L + "'", long5 == 1560184764959L);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        int int18 = month9.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "org.jfree.data.event.SeriesChangeEvent[source=10.0]", "2019");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
//        int int34 = timeSeries29.getIndex(regularTimePeriod33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 100.0d);
//        timeSeries24.add(timeSeriesDataItem36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeriesDataItem36.getPeriod();
//        boolean boolean39 = month9.equals((java.lang.Object) regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184764993L + "'", long4 == 1560184764993L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560184764996L + "'", long32 == 1560184764996L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "10-June-2019", "Mon Jun 10 09:39:04 PDT 2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        java.util.Date date27 = fixedMillisecond25.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560184731994L);
//        timeSeriesDataItem29.setSelected(true);
//        timeSeries1.add(timeSeriesDataItem29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass35 = timeSeries34.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond36.previous();
//        int int39 = timeSeries34.getIndex(regularTimePeriod38);
//        boolean boolean40 = timeSeries34.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass46 = timeSeries45.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond47.previous();
//        int int50 = timeSeries45.getIndex(regularTimePeriod49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (java.lang.Number) 100.0d);
//        timeSeriesDataItem52.setValue((java.lang.Number) 1201L);
//        timeSeries42.add(timeSeriesDataItem52, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.next();
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond57.getMiddleMillisecond(calendar59);
//        int int61 = timeSeriesDataItem52.compareTo((java.lang.Object) calendar59);
//        timeSeries34.add(timeSeriesDataItem52);
//        timeSeriesDataItem52.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries1.addOrUpdate(timeSeriesDataItem52);
//        long long66 = timeSeries1.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184765241L + "'", long8 == 1560184765241L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560184765243L + "'", long26 == 1560184765243L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560184765251L + "'", long37 == 1560184765251L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560184765253L + "'", long48 == 1560184765253L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560184765254L + "'", long60 == 1560184765254L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9223372036854775807L + "'", long66 == 9223372036854775807L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = year21.getMiddleMillisecond();
        int int24 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(10);
        long long7 = year6.getLastMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 1560184750009L);
        long long10 = year6.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820208000001L) + "'", long7 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61820208000001L) + "'", long10 == (-61820208000001L));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries11.getKey();
//        int int18 = timeSeries11.getItemCount();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int22 = month21.getYearValue();
//        long long23 = month21.getSerialIndex();
//        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        long long25 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int30 = month29.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.previous();
//        long long33 = month29.getLastMillisecond();
//        org.jfree.data.time.Year year34 = month29.getYear();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass37 = timeSeries36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
//        int int41 = timeSeries36.getIndex(regularTimePeriod40);
//        boolean boolean42 = timeSeries36.isEmpty();
//        double double43 = timeSeries36.getMaxY();
//        int int44 = year34.compareTo((java.lang.Object) timeSeries36);
//        boolean boolean45 = timeSeries26.equals((java.lang.Object) timeSeries36);
//        java.util.Collection collection46 = timeSeries36.getTimePeriods();
//        timeSeries36.setMaximumItemAge(1560184742653L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560184765600L + "'", long39 == 1560184765600L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(collection46);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond21);
//        boolean boolean23 = timeSeriesDataItem18.isSelected();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184765711L + "'", long14 == 1560184765711L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.previous();
//        timeSeries1.add(regularTimePeriod6, (double) 1560184731443L);
//        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        timeSeries11.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = month17.equals(obj18);
//        java.lang.String str20 = month17.toString();
//        java.lang.Number number21 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Year year22 = month17.getYear();
//        int int23 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184765807L + "'", long4 == 1560184765807L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January 100" + "'", str20.equals("January 100"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        int int10 = timeSeries5.getIndex(regularTimePeriod9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = month13.equals(obj14);
//        boolean boolean17 = month13.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 10, false);
//        timeSeries5.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        java.util.Date date27 = fixedMillisecond25.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560184731994L);
//        timeSeriesDataItem29.setSelected(true);
//        timeSeries1.add(timeSeriesDataItem29);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener33);
//        try {
//            timeSeries1.removeAgedItems(1560184749874L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184765860L + "'", long8 == 1560184765860L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560184765871L + "'", long26 == 1560184765871L);
//        org.junit.Assert.assertNotNull(date27);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(10);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, year2);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (double) 1577865599999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        timeSeriesDataItem13.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate(timeSeriesDataItem13);
//        timeSeries1.setMaximumItemAge(1560184739170L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184765917L + "'", long5 == 1560184765917L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560184765917L + "'", long10 == 1560184765917L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "10-June-2019", "Mon Jun 10 09:39:04 PDT 2019");
        java.util.Collection collection7 = timeSeries6.getTimePeriods();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.addOrUpdate(timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(collection7);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        long long21 = timeSeries1.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184766066L + "'", long14 == 1560184766066L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Date date19 = month9.getEnd();
//        java.util.TimeZone timeZone20 = null;
//        try {
//            org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184766116L + "'", long4 == 1560184766116L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = month14.compareTo((java.lang.Object) day21);
        int int23 = day21.getMonth();
        int int24 = day21.getMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.previous();
//        timeSeries1.add(regularTimePeriod6, (double) 1560184731443L);
//        try {
//            timeSeries1.delete(2147483647, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184766190L + "'", long4 == 1560184766190L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = month9.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184766802L + "'", long4 == 1560184766802L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass10 = timeSeries9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass13 = timeSeries12.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
//        int int17 = timeSeries12.getIndex(regularTimePeriod16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (java.lang.Number) 100.0d);
//        timeSeriesDataItem19.setValue((java.lang.Number) 1201L);
//        timeSeries9.add(timeSeriesDataItem19, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getMiddleMillisecond(calendar26);
//        int int28 = timeSeriesDataItem19.compareTo((java.lang.Object) calendar26);
//        timeSeries1.add(timeSeriesDataItem19);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        int int32 = timeSeriesDataItem19.compareTo((java.lang.Object) day30);
//        boolean boolean33 = timeSeriesDataItem19.isSelected();
//        timeSeriesDataItem19.setValue((java.lang.Number) 1560184733384L);
//        java.lang.Number number36 = timeSeriesDataItem19.getValue();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184766910L + "'", long4 == 1560184766910L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560184766912L + "'", long15 == 1560184766912L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560184766913L + "'", long27 == 1560184766913L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1560184733384L + "'", number36.equals(1560184733384L));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.clear();
        java.lang.String str4 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("0");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean4 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass9 = timeSeries8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
//        int int13 = timeSeries8.getIndex(regularTimePeriod12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (java.lang.Number) 100.0d);
//        timeSeries3.add(timeSeriesDataItem15);
//        java.lang.String str17 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0L);
//        int int24 = fixedMillisecond1.compareTo((java.lang.Object) day21);
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond1.peg(calendar25);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184767118L + "'", long11 == 1560184767118L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560184731570L, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560184731570]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=1560184731570]"));
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184767206L + "'", long1 == 1560184767206L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184767206L + "'", long3 == 1560184767206L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (double) 1560184738652L, false);
        java.lang.String str9 = year5.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        boolean boolean5 = timeSeries1.getNotify();
        java.lang.String str6 = timeSeries1.getRangeDescription();
        try {
            java.lang.Number number8 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.event.SeriesChangeEvent[source=1560184739172]", "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        long long18 = month9.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184767529L + "'", long4 == 1560184767529L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-59008924800001L) + "'", long18 == (-59008924800001L));
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "", "2019");
        timeSeries3.setKey((java.lang.Comparable) 'a');
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNull(class6);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = regularTimePeriod1.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond4.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.String str5 = regularTimePeriod4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "February 100" + "'", str5.equals("February 100"));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184767765L + "'", long1 == 1560184767765L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560184767765L + "'", long2 == 1560184767765L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184767765L + "'", long3 == 1560184767765L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str6 = seriesException5.toString();
        java.lang.Throwable[] throwableArray7 = seriesException5.getSuppressed();
        java.lang.String str8 = seriesException5.toString();
        java.lang.String str9 = seriesException5.toString();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str12 = seriesException11.toString();
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        java.lang.String str14 = seriesException11.toString();
        java.lang.String str15 = seriesException11.toString();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str19 = seriesException18.toString();
        java.lang.Throwable[] throwableArray20 = seriesException18.getSuppressed();
        java.lang.String str21 = seriesException18.toString();
        java.lang.String str22 = seriesException18.toString();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException18);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str6.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str8.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str9.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str14.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str15.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str19.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str21.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str22.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        timeSeries1.setKey((java.lang.Comparable) date9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
//        int int13 = year11.compareTo((java.lang.Object) 1560184760465L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184767832L + "'", long8 == 1560184767832L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.String str3 = year1.toString();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1560184765711L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 100" + "'", str6.equals("January 100"));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560184735928L, false);
//        double double26 = timeSeries1.getMinY();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184768220L + "'", long9 == 1560184768220L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        timeSeries1.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        java.lang.String str12 = year10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 10);
        long long16 = year10.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int3 = month2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
//        long long6 = month2.getLastMillisecond();
//        org.jfree.data.time.Year year7 = month2.getYear();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass10 = timeSeries9.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        long long12 = fixedMillisecond11.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond11.previous();
//        int int14 = timeSeries9.getIndex(regularTimePeriod13);
//        boolean boolean15 = timeSeries9.isEmpty();
//        double double16 = timeSeries9.getMaxY();
//        int int17 = year7.compareTo((java.lang.Object) timeSeries9);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = year7.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59008924800001L) + "'", long6 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560184768332L + "'", long12 == 1560184768332L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("January 100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        org.jfree.data.time.Year year21 = month14.getYear();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year21.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(year21);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date14, timeZone19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184769246L + "'", long13 == 1560184769246L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getYear();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 09:39:01 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        int int18 = month9.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "org.jfree.data.event.SeriesChangeEvent[source=10.0]", "2019");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        java.lang.Class class26 = timeSeries24.getTimePeriodClass();
//        java.util.Collection collection27 = timeSeries24.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean30 = timeSeries29.getNotify();
//        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries24.addAndOrUpdate(timeSeries29);
//        boolean boolean33 = timeSeries24.isEmpty();
//        boolean boolean35 = timeSeries24.equals((java.lang.Object) 1560184730391L);
//        int int36 = month9.compareTo((java.lang.Object) boolean35);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184769424L + "'", long4 == 1560184769424L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNull(class26);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        java.util.Date date18 = regularTimePeriod17.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 0L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.next();
//        int int26 = day22.getYear();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass30 = seriesChangeEvent29.getClass();
//        java.lang.Class<?> wildcardClass31 = seriesChangeEvent29.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean35 = timeSeries34.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries34.addChangeListener(seriesChangeListener36);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries34.removePropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        long long41 = fixedMillisecond40.getMiddleMillisecond();
//        java.util.Date date42 = fixedMillisecond40.getTime();
//        timeSeries34.setKey((java.lang.Comparable) date42);
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date42, timeZone44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date42);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184769770L + "'", long9 == 1560184769770L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560184769774L + "'", long41 == 1560184769774L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str4 = seriesException3.toString();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        int int6 = year0.compareTo((java.lang.Object) seriesException3);
        long long7 = year0.getFirstMillisecond();
        boolean boolean9 = year0.equals((java.lang.Object) 1560184766912L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        timeSeries1.setKey((java.lang.Comparable) date9);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184770013L + "'", long8 == 1560184770013L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
//        int int19 = timeSeries14.getIndex(regularTimePeriod18);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = month22.equals(obj23);
//        boolean boolean26 = month22.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year27 = month22.getYear();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 10, false);
//        timeSeries14.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.lang.Class<?> wildcardClass33 = timeSeries14.getClass();
//        boolean boolean34 = timeSeries14.isEmpty();
//        int int35 = day9.compareTo((java.lang.Object) timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean39 = timeSeries37.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean42 = timeSeries41.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries41.addChangeListener(seriesChangeListener43);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries37.addAndOrUpdate(timeSeries41);
//        timeSeries45.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean51 = timeSeries49.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass54 = timeSeries53.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        long long56 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond55.previous();
//        int int58 = timeSeries53.getIndex(regularTimePeriod57);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj62 = null;
//        boolean boolean63 = month61.equals(obj62);
//        boolean boolean65 = month61.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year66 = month61.getYear();
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 10, false);
//        timeSeries53.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection72 = timeSeries49.getTimePeriodsUniqueToOtherSeries(timeSeries53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        long long74 = fixedMillisecond73.getMiddleMillisecond();
//        java.util.Date date75 = fixedMillisecond73.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (double) 1560184731994L);
//        timeSeriesDataItem77.setSelected(true);
//        timeSeries49.add(timeSeriesDataItem77);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        long long82 = fixedMillisecond81.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = fixedMillisecond81.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, 0.0d);
//        java.lang.Number number86 = timeSeriesDataItem85.getValue();
//        boolean boolean87 = timeSeriesDataItem85.isSelected();
//        int int88 = timeSeriesDataItem77.compareTo((java.lang.Object) timeSeriesDataItem85);
//        java.lang.Number number89 = timeSeriesDataItem85.getValue();
//        timeSeries45.add(timeSeriesDataItem85);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries14.addOrUpdate(timeSeriesDataItem85);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184770032L + "'", long4 == 1560184770032L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560184770034L + "'", long17 == 1560184770034L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560184770038L + "'", long56 == 1560184770038L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(collection72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560184770039L + "'", long74 == 1560184770039L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560184770044L + "'", long82 == 1560184770044L);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 0.0d + "'", number86.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
//        org.junit.Assert.assertTrue("'" + number89 + "' != '" + 0.0d + "'", number89.equals(0.0d));
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        java.util.TimeZone timeZone18 = null;
//        try {
//            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date14, timeZone18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184770065L + "'", long13 == 1560184770065L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int5 = month4.getYearValue();
        long long6 = month4.getSerialIndex();
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
        long long8 = month4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-59008924800001L) + "'", long8 == (-59008924800001L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries9.delete(5, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent5.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        boolean boolean9 = timeSeries1.equals((java.lang.Object) class8);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        timeSeries1.setKey((java.lang.Comparable) date9);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
//        java.util.TimeZone timeZone12 = null;
//        try {
//            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184770149L + "'", long8 == 1560184770149L);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean4 = timeSeries2.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries6.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        double double11 = timeSeries10.getMaxY();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(10);
        boolean boolean15 = year13.equals((java.lang.Object) Double.NaN);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 1560184734477L);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(1, year13);
        java.util.Calendar calendar19 = null;
        try {
            month18.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184770186L + "'", long3 == 1560184770186L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184770186L + "'", long4 == 1560184770186L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184770186L + "'", long5 == 1560184770186L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries14.getDataItem(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184770196L + "'", long1 == 1560184770196L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        int int22 = month14.compareTo((java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long3 = month2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1201L + "'", long3 == 1201L);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        int int9 = day7.getMonth();
//        long long10 = day7.getLastMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560184750113L, false);
//        int int14 = day7.getDayOfMonth();
//        int int15 = day7.getYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        boolean boolean5 = day2.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) 1560184734991L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (byte) 1, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.createCopy(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(12, year1);
        java.util.Date date5 = month4.getStart();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = month12.equals(obj13);
//        boolean boolean16 = month12.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year17 = month12.getYear();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month12.previous();
//        boolean boolean22 = day0.equals((java.lang.Object) month12);
//        long long23 = day0.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        try {
//            day0.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184770496L + "'", long7 == 1560184770496L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        boolean boolean6 = timeSeriesDataItem4.isSelected();
//        timeSeriesDataItem4.setSelected(true);
//        timeSeriesDataItem4.setValue((java.lang.Number) 1560184769521L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184771104L + "'", long1 == 1560184771104L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        int int9 = day7.getMonth();
//        long long10 = day7.getLastMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560184750113L, false);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day7.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.addChangeListener(seriesChangeListener8);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184771174L + "'", long4 == 1560184771174L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        boolean boolean4 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        boolean boolean12 = timeSeries6.isEmpty();
//        double double13 = timeSeries6.getMaxY();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560184730581L, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
//        java.lang.Class<?> wildcardClass27 = seriesChangeEvent25.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean31 = timeSeries30.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries30.addChangeListener(seriesChangeListener32);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getMiddleMillisecond();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        timeSeries30.setKey((java.lang.Comparable) date38);
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date38, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean46 = timeSeries45.getNotify();
//        java.lang.Class class47 = timeSeries45.getTimePeriodClass();
//        java.util.Collection collection48 = timeSeries45.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean51 = timeSeries50.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries50.addChangeListener(seriesChangeListener52);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass56 = timeSeries55.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        long long58 = fixedMillisecond57.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond57.previous();
//        int int60 = timeSeries55.getIndex(regularTimePeriod59);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod59, (java.lang.Number) 100.0d);
//        timeSeries50.add(timeSeriesDataItem62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries45.addOrUpdate(timeSeriesDataItem62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean66 = timeSeriesDataItem62.equals((java.lang.Object) fixedMillisecond65);
//        long long67 = fixedMillisecond65.getMiddleMillisecond();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 1560184765137L, false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184771191L + "'", long9 == 1560184771191L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560184771200L + "'", long37 == 1560184771200L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNull(class47);
//        org.junit.Assert.assertNotNull(collection48);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560184771203L + "'", long58 == 1560184771203L);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560184771204L + "'", long67 == 1560184771204L);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str5 = seriesException4.toString();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.String str7 = seriesException4.toString();
        java.lang.Throwable[] throwableArray8 = seriesException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str12 = seriesException11.toString();
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException11.getSuppressed();
        java.lang.Throwable[] throwableArray15 = seriesException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str7.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        long long6 = month2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-59008924800001L) + "'", long6 == (-59008924800001L));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        java.lang.Class class7 = timeSeries5.getTimePeriodClass();
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean11 = timeSeries10.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries10.addChangeListener(seriesChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass16 = timeSeries15.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.previous();
//        int int20 = timeSeries15.getIndex(regularTimePeriod19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (java.lang.Number) 100.0d);
//        timeSeries10.add(timeSeriesDataItem22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries5.addOrUpdate(timeSeriesDataItem22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean26 = timeSeriesDataItem22.equals((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean30 = timeSeries28.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean33 = timeSeries32.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries32.addChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int42 = month41.getYearValue();
//        long long43 = month41.getSerialIndex();
//        int int44 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.Year year45 = month41.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getMiddleMillisecond();
//        java.util.Date date49 = fixedMillisecond47.getTime();
//        long long50 = fixedMillisecond47.getSerialIndex();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond47.getLastMillisecond(calendar51);
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        int int54 = timeSeriesDataItem22.compareTo((java.lang.Object) fixedMillisecond47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem22.getPeriod();
//        timeSeries1.add(timeSeriesDataItem22);
//        try {
//            java.lang.Number number58 = timeSeries1.getValue((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560184771866L + "'", long18 == 1560184771866L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1201L + "'", long43 == 1201L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560184771875L + "'", long48 == 1560184771875L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560184771875L + "'", long50 == 1560184771875L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560184771875L + "'", long52 == 1560184771875L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.lang.String str27 = timeSeries9.getDomainDescription();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries9.addChangeListener(seriesChangeListener28);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184771938L + "'", long21 == 1560184771938L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184771938L + "'", long23 == 1560184771938L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560184771938L + "'", long25 == 1560184771938L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560184732918L);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int14 = month13.getYearValue();
//        long long15 = month13.getSerialIndex();
//        int int16 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.Year year17 = month13.getYear();
//        java.lang.String str18 = month13.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (-1.0d));
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener21);
//        timeSeries1.setMaximumItemAge((long) (short) 1);
//        timeSeries1.setDescription("Time");
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184772006L + "'", long4 == 1560184772006L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1201L + "'", long15 == 1201L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January 100" + "'", str18.equals("January 100"));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries11.getKey();
//        int int18 = timeSeries11.getItemCount();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int22 = month21.getYearValue();
//        long long23 = month21.getSerialIndex();
//        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        long long25 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean30 = timeSeries28.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean33 = timeSeries32.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries32.addChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int42 = month41.getYearValue();
//        long long43 = month41.getSerialIndex();
//        int int44 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.Year year45 = month41.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getMiddleMillisecond();
//        java.util.Date date49 = fixedMillisecond47.getTime();
//        long long50 = fixedMillisecond47.getSerialIndex();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond47.getLastMillisecond(calendar51);
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long57 = month56.getFirstMillisecond();
//        org.jfree.data.time.Year year58 = month56.getYear();
//        boolean boolean59 = fixedMillisecond47.equals((java.lang.Object) year58);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year58, (double) 1560184758157L, false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries26.getDataItem(6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1201L + "'", long43 == 1201L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560184772041L + "'", long48 == 1560184772041L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560184772041L + "'", long50 == 1560184772041L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560184772041L + "'", long52 == 1560184772041L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-59011603200000L) + "'", long57 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str10 = timeSeries1.getDescription();
        double double11 = timeSeries1.getMinY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) 9999);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184772134L + "'", long3 == 1560184772134L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        int int8 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(6, 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str10 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj15 = null;
        boolean boolean16 = month14.equals(obj15);
        boolean boolean18 = month14.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int20 = year19.getYear();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        boolean boolean22 = timeSeries9.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0d + "'", obj5.equals(10.0d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        boolean boolean6 = month2.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year7 = month2.getYear();
        java.util.Calendar calendar8 = null;
        try {
            month2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Date date19 = month9.getEnd();
//        int int20 = month9.getYearValue();
//        org.jfree.data.time.Year year21 = month9.getYear();
//        java.util.Calendar calendar22 = null;
//        try {
//            month9.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184773279L + "'", long4 == 1560184773279L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(year21);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Date date12 = fixedMillisecond10.getTime();
//        long long13 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond14.peg(calendar15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
//        int int34 = timeSeries29.getIndex(regularTimePeriod33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 100.0d);
//        timeSeries24.add(timeSeriesDataItem36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries19.addOrUpdate(timeSeriesDataItem36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) fixedMillisecond39);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean44 = timeSeries42.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean47 = timeSeries46.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries46.addChangeListener(seriesChangeListener48);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries42.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int56 = month55.getYearValue();
//        long long57 = month55.getSerialIndex();
//        int int58 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) month55);
//        org.jfree.data.time.Year year59 = month55.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) month55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getMiddleMillisecond();
//        java.util.Date date63 = fixedMillisecond61.getTime();
//        long long64 = fixedMillisecond61.getSerialIndex();
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond61.getLastMillisecond(calendar65);
//        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        int int68 = timeSeriesDataItem36.compareTo((java.lang.Object) fixedMillisecond61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries5.addOrUpdate(timeSeriesDataItem36);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean73 = timeSeries71.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean76 = timeSeries75.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener77 = null;
//        timeSeries75.addChangeListener(seriesChangeListener77);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries71.addAndOrUpdate(timeSeries75);
//        timeSeries79.removeAgedItems(false);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj85 = null;
//        boolean boolean86 = month84.equals(obj85);
//        boolean boolean88 = month84.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year89 = month84.getYear();
//        int int90 = year89.getYear();
//        int int91 = timeSeries79.getIndex((org.jfree.data.time.RegularTimePeriod) year89);
//        timeSeries79.fireSeriesChanged();
//        timeSeries79.setDescription("Mon Jun 10 09:38:56 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries95 = timeSeries5.addAndOrUpdate(timeSeries79);
//        try {
//            timeSeries95.update((int) (byte) 0, (java.lang.Number) 1560184738652L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184773307L + "'", long11 == 1560184773307L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184773307L + "'", long13 == 1560184773307L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560184773332L + "'", long32 == 1560184773332L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1201L + "'", long57 == 1201L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560184773336L + "'", long62 == 1560184773336L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560184773336L + "'", long64 == 1560184773336L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560184773336L + "'", long66 == 1560184773336L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(year89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 100 + "'", int90 == 100);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries95);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59011603200000L) + "'", long4 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, (java.lang.Number) 100.0d);
//        timeSeriesDataItem11.setValue((java.lang.Number) 1201L);
//        timeSeries1.add(timeSeriesDataItem11, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getMiddleMillisecond(calendar18);
//        int int20 = timeSeriesDataItem11.compareTo((java.lang.Object) calendar18);
//        timeSeriesDataItem11.setValue((java.lang.Number) 1560184738193L);
//        java.lang.Object obj23 = timeSeriesDataItem11.clone();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184773375L + "'", long7 == 1560184773375L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184773397L + "'", long19 == 1560184773397L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(obj23);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond0, seriesChangeInfo5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184773443L + "'", long1 == 1560184773443L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184773443L + "'", long3 == 1560184773443L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1201L + "'", long4 == 1201L);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = regularTimePeriod1.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
//        long long6 = fixedMillisecond5.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        java.util.TimeZone timeZone18 = null;
//        try {
//            org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184773585L + "'", long13 == 1560184773585L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560184767705L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getYear();
//        int int8 = day6.getDayOfMonth();
//        int int9 = day6.getDayOfMonth();
//        boolean boolean10 = fixedMillisecond0.equals((java.lang.Object) day6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184773659L + "'", long1 == 1560184773659L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184773659L + "'", long3 == 1560184773659L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184773659L + "'", long5 == 1560184773659L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        int int9 = day7.getMonth();
//        long long10 = day7.getLastMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560184750113L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean12 = timeSeries11.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.addChangeListener(seriesChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Comparable comparable17 = timeSeries11.getKey();
        int int18 = timeSeries11.getItemCount();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int22 = month21.getYearValue();
        long long23 = month21.getSerialIndex();
        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
        long long25 = timeSeries11.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
        double double27 = timeSeries5.getMinY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.next();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1560184746700L);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = month19.equals(obj20);
//        boolean boolean23 = month19.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year24 = month19.getYear();
//        int int25 = year24.getYear();
//        long long26 = year24.getLastMillisecond();
//        int int28 = year24.compareTo((java.lang.Object) 1560184748443L);
//        timeSeries1.setKey((java.lang.Comparable) int28);
//        try {
//            timeSeries1.setMaximumItemAge((-61820208000001L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184773767L + "'", long4 == 1560184773767L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184773768L + "'", long9 == 1560184773768L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184773768L + "'", long11 == 1560184773768L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184773768L + "'", long13 == 1560184773768L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58979980800001L) + "'", long26 == (-58979980800001L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 09:39:17 PDT 2019");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        long long3 = fixedMillisecond2.getFirstMillisecond();
        long long4 = fixedMillisecond2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj15 = null;
        boolean boolean16 = month14.equals(obj15);
        boolean boolean18 = month14.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int20 = year19.getYear();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries9.fireSeriesChanged();
        boolean boolean23 = timeSeries9.isEmpty();
        java.util.Collection collection24 = timeSeries9.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries25 = null;
        try {
            java.util.Collection collection26 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month2.getYear();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59011603200000L) + "'", long4 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58979980800001L) + "'", long7 == (-58979980800001L));
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        long long20 = timeSeries9.getMaximumItemAge();
//        double double21 = timeSeries9.getMinY();
//        boolean boolean22 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries9.addChangeListener(seriesChangeListener23);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass27 = timeSeries26.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
//        int int31 = timeSeries26.getIndex(regularTimePeriod30);
//        boolean boolean32 = timeSeries26.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass35 = timeSeries34.getClass();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass38 = timeSeries37.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        long long40 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond39.previous();
//        int int42 = timeSeries37.getIndex(regularTimePeriod41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod41, (java.lang.Number) 100.0d);
//        timeSeriesDataItem44.setValue((java.lang.Number) 1201L);
//        timeSeries34.add(timeSeriesDataItem44, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond49.next();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond49.getMiddleMillisecond(calendar51);
//        int int53 = timeSeriesDataItem44.compareTo((java.lang.Object) calendar51);
//        timeSeries26.add(timeSeriesDataItem44);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        int int57 = timeSeriesDataItem44.compareTo((java.lang.Object) day55);
//        boolean boolean58 = timeSeriesDataItem44.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries9.addOrUpdate(timeSeriesDataItem44);
//        boolean boolean60 = timeSeriesDataItem44.isSelected();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560184773955L + "'", long29 == 1560184773955L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560184773956L + "'", long40 == 1560184773956L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560184773958L + "'", long52 == 1560184773958L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date14);
//        java.util.TimeZone timeZone21 = null;
//        try {
//            org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date14, timeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184774114L + "'", long13 == 1560184774114L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date19, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date19);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184774130L + "'", long13 == 1560184774130L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        boolean boolean10 = timeSeries1.isEmpty();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) 1560184730391L);
        try {
            timeSeries1.update((int) (short) 10, (java.lang.Number) 1560184750910L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemAge(1577865599999L);
//        double double5 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass8 = timeSeries7.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
//        int int12 = timeSeries7.getIndex(regularTimePeriod11);
//        boolean boolean13 = timeSeries7.isEmpty();
//        double double14 = timeSeries7.getMaxY();
//        timeSeries7.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass20 = timeSeries19.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
//        int int24 = timeSeries19.getIndex(regularTimePeriod23);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = month27.equals(obj28);
//        boolean boolean31 = month27.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year32 = month27.getYear();
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month27.previous();
//        java.util.Date date37 = month27.getEnd();
//        int int38 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
//        int int39 = timeSeries7.getMaximumItemCount();
//        boolean boolean40 = timeSeries1.equals((java.lang.Object) timeSeries7);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560184774377L + "'", long10 == 1560184774377L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560184774378L + "'", long22 == 1560184774378L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
//        java.lang.Class<?> wildcardClass7 = seriesChangeEvent5.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
//        java.lang.Class<?> wildcardClass13 = seriesChangeEvent11.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean17 = timeSeries16.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries16.addChangeListener(seriesChangeListener18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getMiddleMillisecond();
//        java.util.Date date24 = fixedMillisecond22.getTime();
//        timeSeries16.setKey((java.lang.Comparable) date24);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date24, timeZone29);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date24, timeZone31);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184774476L + "'", long23 == 1560184774476L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        double double10 = timeSeries9.getMaxY();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        boolean boolean14 = year12.equals((java.lang.Object) Double.NaN);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560184734477L);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) month19);
        long long22 = month19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1201L + "'", long22 == 1201L);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.String str3 = timeSeries1.getDescription();
//        long long4 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        boolean boolean8 = day5.equals((java.lang.Object) (short) 0);
//        boolean boolean10 = day5.equals((java.lang.Object) 100.0f);
//        int int11 = day5.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        long long15 = fixedMillisecond12.getSerialIndex();
//        int int16 = day5.compareTo((java.lang.Object) fixedMillisecond12);
//        int int17 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184774570L + "'", long13 == 1560184774570L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560184774570L + "'", long15 == 1560184774570L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        try {
//            java.lang.Number number10 = timeSeries1.getValue((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184774614L + "'", long4 == 1560184774614L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.update((int) (short) -1, (java.lang.Number) 1560063600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, "", "Mon Jun 10 09:39:02 PDT 2019");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        timeSeries6.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        int int10 = timeSeries6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        timeSeries6.add(regularTimePeriod15, (java.lang.Number) 1560184760127L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.getDataItem(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        java.util.Date date18 = regularTimePeriod17.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener22);
//        java.lang.String str24 = timeSeries1.getDescription();
//        try {
//            timeSeries1.removeAgedItems(1560184735802L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184775083L + "'", long9 == 1560184775083L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(str24);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries11.getKey();
//        int int18 = timeSeries11.getItemCount();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int22 = month21.getYearValue();
//        long long23 = month21.getSerialIndex();
//        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        long long25 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int30 = month29.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.previous();
//        long long33 = month29.getLastMillisecond();
//        org.jfree.data.time.Year year34 = month29.getYear();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass37 = timeSeries36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
//        int int41 = timeSeries36.getIndex(regularTimePeriod40);
//        boolean boolean42 = timeSeries36.isEmpty();
//        double double43 = timeSeries36.getMaxY();
//        int int44 = year34.compareTo((java.lang.Object) timeSeries36);
//        boolean boolean45 = timeSeries26.equals((java.lang.Object) timeSeries36);
//        java.util.Collection collection46 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(0);
//        long long49 = year48.getMiddleMillisecond();
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) year48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.previous();
//        boolean boolean57 = day54.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) 1560184734991L);
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) (byte) 1, true);
//        java.util.Date date63 = day54.getStart();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries64 = timeSeries36.createCopy(regularTimePeriod51, (org.jfree.data.time.RegularTimePeriod) day54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560184775295L + "'", long39 == 1560184775295L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-62135784000001L) + "'", long49 == (-62135784000001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(date63);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184775577L + "'", long4 == 1560184775577L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long13 = month12.getFirstMillisecond();
        java.lang.String str14 = month12.toString();
        timeSeries5.setKey((java.lang.Comparable) month12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        boolean boolean19 = day16.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 1560184734991L);
        timeSeries5.add(timeSeriesDataItem21, true);
        timeSeriesDataItem21.setValue((java.lang.Number) 1560184744547L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January 100" + "'", str14.equals("January 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean4 = timeSeries3.getNotify();
        java.lang.Class class5 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection6 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean9 = timeSeries8.getNotify();
        java.lang.Class class10 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries1.equals((java.lang.Object) timeSeries3);
        timeSeries3.removeAgedItems(1560184747845L, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries14);
//        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184775681L + "'", long1 == 1560184775681L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNull(class16);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        timeSeries1.setRangeDescription("2019");
//        try {
//            java.lang.Number number11 = timeSeries1.getValue((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184775712L + "'", long4 == 1560184775712L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.String str4 = seriesException1.toString();
        java.lang.String str5 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str8 = seriesException7.toString();
        java.lang.Throwable[] throwableArray9 = seriesException7.getSuppressed();
        java.lang.String str10 = seriesException7.toString();
        java.lang.String str11 = seriesException7.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str15 = seriesException14.toString();
        java.lang.Throwable[] throwableArray16 = seriesException14.getSuppressed();
        java.lang.String str17 = seriesException14.toString();
        java.lang.String str18 = seriesException14.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.String str20 = seriesException14.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str5.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str8.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str10.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str11.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str15.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str17.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str18.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str20.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.String str3 = timeSeries1.getDescription();
        long long4 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean8 = timeSeries6.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries10.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries10);
        double double15 = timeSeries14.getMaxY();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(10);
        boolean boolean19 = year17.equals((java.lang.Object) Double.NaN);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 1560184734477L);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) month24);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond2);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond2.peg(calendar6);
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond2.getClass();
//        long long9 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184775926L + "'", long3 == 1560184775926L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184775926L + "'", long9 == 1560184775926L);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int14 = month13.getYearValue();
//        long long15 = month13.getSerialIndex();
//        int int16 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.Year year17 = month13.getYear();
//        java.lang.String str18 = month13.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (-1.0d));
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener21);
//        timeSeries1.setNotify(true);
//        int int25 = timeSeries1.getItemCount();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184775998L + "'", long4 == 1560184775998L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1201L + "'", long15 == 1201L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January 100" + "'", str18.equals("January 100"));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        int int8 = timeSeries1.getItemCount();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int12 = month11.getYearValue();
//        long long13 = month11.getSerialIndex();
//        java.lang.Number number14 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass17 = timeSeries16.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
//        int int21 = timeSeries16.getIndex(regularTimePeriod20);
//        boolean boolean22 = timeSeries16.isEmpty();
//        double double23 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass29 = timeSeries28.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        int int33 = timeSeries28.getIndex(regularTimePeriod32);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = month36.equals(obj37);
//        boolean boolean40 = month36.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year41 = month36.getYear();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month36.previous();
//        java.util.Date date46 = month36.getEnd();
//        int int47 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.Year year48 = month36.getYear();
//        int int49 = year48.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year48, (double) 1560184740563L, true);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        boolean boolean56 = day53.equals((java.lang.Object) (short) 0);
//        boolean boolean58 = day53.equals((java.lang.Object) 100.0f);
//        timeSeries1.setKey((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass62 = timeSeries61.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        long long64 = fixedMillisecond63.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.previous();
//        int int66 = timeSeries61.getIndex(regularTimePeriod65);
//        java.lang.String str67 = timeSeries61.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.previous();
//        long long71 = fixedMillisecond68.getLastMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond68.getFirstMillisecond(calendar72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = fixedMillisecond68.next();
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560184746700L);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560184750358L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener79 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener79);
//        int int81 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1201L + "'", long13 == 1201L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184776047L + "'", long19 == 1560184776047L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560184776049L + "'", long31 == 1560184776049L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560184776083L + "'", long64 == 1560184776083L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//        org.junit.Assert.assertNull(str67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560184776084L + "'", long69 == 1560184776084L);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560184776084L + "'", long71 == 1560184776084L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560184776084L + "'", long73 == 1560184776084L);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2147483647 + "'", int81 == 2147483647);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        timeSeries1.removeAgedItems(true);
        boolean boolean10 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy(regularTimePeriod8, (org.jfree.data.time.RegularTimePeriod) day9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int5 = month4.getYearValue();
//        long long6 = month4.getSerialIndex();
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean15 = timeSeries14.getNotify();
//        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries14.addAndOrUpdate(timeSeries19);
//        int int23 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.addAndOrUpdate(timeSeries22);
//        java.lang.Comparable comparable25 = timeSeries1.getKey();
//        timeSeries1.removeAgedItems(1560184740682L, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = null;
//        try {
//            java.lang.Number number30 = timeSeries1.getValue(regularTimePeriod29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184777072L + "'", long9 == 1560184777072L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (short) 100 + "'", comparable25.equals((short) 100));
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean9 = timeSeries7.equals((java.lang.Object) 9999);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int13 = month12.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.previous();
//        long long16 = month12.getLastMillisecond();
//        int int17 = month12.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        boolean boolean19 = fixedMillisecond0.equals((java.lang.Object) timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184777087L + "'", long3 == 1560184777087L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-59008924800001L) + "'", long16 == (-59008924800001L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 09:38:55 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int5 = month4.getYearValue();
//        long long6 = month4.getSerialIndex();
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560184731994L);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean15 = timeSeries14.getNotify();
//        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries14.addAndOrUpdate(timeSeries19);
//        int int23 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.addAndOrUpdate(timeSeries22);
//        java.lang.Comparable comparable25 = timeSeries1.getKey();
//        timeSeries1.removeAgedItems(1560184740682L, true);
//        java.lang.Class class29 = timeSeries1.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184777578L + "'", long9 == 1560184777578L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (short) 100 + "'", comparable25.equals((short) 100));
//        org.junit.Assert.assertNull(class29);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        int int18 = month9.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "org.jfree.data.event.SeriesChangeEvent[source=10.0]", "2019");
//        java.lang.String str22 = month9.toString();
//        long long23 = month9.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184777642L + "'", long4 == 1560184777642L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 100" + "'", str22.equals("January 100"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-59011603200000L) + "'", long23 == (-59011603200000L));
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemAge(1577865599999L);
//        double double5 = timeSeries1.getMinY();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date8);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getFirstMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond10.getLastMillisecond(calendar15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1560184754573L);
//        boolean boolean19 = timeSeries1.isEmpty();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        int int8 = timeSeries1.getItemCount();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int12 = month11.getYearValue();
//        long long13 = month11.getSerialIndex();
//        java.lang.Number number14 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass17 = timeSeries16.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.previous();
//        int int21 = timeSeries16.getIndex(regularTimePeriod20);
//        boolean boolean22 = timeSeries16.isEmpty();
//        double double23 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass29 = timeSeries28.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        int int33 = timeSeries28.getIndex(regularTimePeriod32);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj37 = null;
//        boolean boolean38 = month36.equals(obj37);
//        boolean boolean40 = month36.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year41 = month36.getYear();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month36.previous();
//        java.util.Date date46 = month36.getEnd();
//        int int47 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.Year year48 = month36.getYear();
//        int int49 = year48.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year48, (double) 1560184740563L, true);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        boolean boolean56 = day53.equals((java.lang.Object) (short) 0);
//        boolean boolean58 = day53.equals((java.lang.Object) 100.0f);
//        timeSeries1.setKey((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass62 = timeSeries61.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        long long64 = fixedMillisecond63.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.previous();
//        int int66 = timeSeries61.getIndex(regularTimePeriod65);
//        java.lang.String str67 = timeSeries61.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.previous();
//        long long71 = fixedMillisecond68.getLastMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond68.getFirstMillisecond(calendar72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = fixedMillisecond68.next();
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560184746700L);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560184750358L);
//        timeSeries1.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1201L + "'", long13 == 1201L);
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184777856L + "'", long19 == 1560184777856L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560184777858L + "'", long31 == 1560184777858L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560184777863L + "'", long64 == 1560184777863L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
//        org.junit.Assert.assertNull(str67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560184777864L + "'", long69 == 1560184777864L);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560184777864L + "'", long71 == 1560184777864L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560184777864L + "'", long73 == 1560184777864L);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getMonth();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        boolean boolean4 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        boolean boolean12 = timeSeries6.isEmpty();
//        double double13 = timeSeries6.getMaxY();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560184730581L, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
//        java.lang.Class<?> wildcardClass27 = seriesChangeEvent25.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean31 = timeSeries30.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries30.addChangeListener(seriesChangeListener32);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getMiddleMillisecond();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        timeSeries30.setKey((java.lang.Comparable) date38);
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date38, timeZone40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        long long44 = year42.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184778086L + "'", long9 == 1560184778086L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560184778089L + "'", long37 == 1560184778089L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1562097599999L + "'", long44 == 1562097599999L);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        double double10 = timeSeries9.getMaxY();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(10);
        boolean boolean14 = year12.equals((java.lang.Object) Double.NaN);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 1560184734477L);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj25 = null;
        boolean boolean26 = month24.equals(obj25);
        boolean boolean28 = month24.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 1560184752589L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        boolean boolean4 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        boolean boolean12 = timeSeries6.isEmpty();
//        double double13 = timeSeries6.getMaxY();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560184730581L, false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries6);
//        boolean boolean24 = timeSeries23.getNotify();
//        timeSeries23.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184778527L + "'", long9 == 1560184778527L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries1.clear();
        boolean boolean13 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries24.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass30 = timeSeries29.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
//        int int34 = timeSeries29.getIndex(regularTimePeriod33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, (java.lang.Number) 100.0d);
//        timeSeries24.add(timeSeriesDataItem36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries19.addOrUpdate(timeSeriesDataItem36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) fixedMillisecond39);
//        long long41 = fixedMillisecond39.getMiddleMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getFirstMillisecond(calendar42);
//        java.lang.Number number44 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class<?> wildcardClass45 = fixedMillisecond39.getClass();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond39.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond39.getStart();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184778691L + "'", long9 == 1560184778691L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560184778714L + "'", long32 == 1560184778714L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560184778716L + "'", long41 == 1560184778716L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560184778716L + "'", long43 == 1560184778716L);
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560184778716L + "'", long47 == 1560184778716L);
//        org.junit.Assert.assertNotNull(date48);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560184735928L, false);
//        timeSeries1.fireSeriesChanged();
//        double double27 = timeSeries1.getMinY();
//        timeSeries1.update((int) (byte) 1, (java.lang.Number) 1560184731994L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184778869L + "'", long9 == 1560184778869L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.setNotify(false);
        double double12 = timeSeries9.getMinY();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.String str3 = year1.toString();
        long long4 = year1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62135784000001L) + "'", long4 == (-62135784000001L));
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.lang.String str27 = timeSeries9.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond28.next();
//        long long30 = fixedMillisecond28.getLastMillisecond();
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond28.peg(calendar31);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1560184743536L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean38 = timeSeries36.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean41 = timeSeries40.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries40.addChangeListener(seriesChangeListener42);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries36.addAndOrUpdate(timeSeries40);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean47 = timeSeries46.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries46.addChangeListener(seriesChangeListener48);
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries46.removePropertyChangeListener(propertyChangeListener50);
//        java.lang.Comparable comparable52 = timeSeries46.getKey();
//        int int53 = timeSeries46.getItemCount();
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int57 = month56.getYearValue();
//        long long58 = month56.getSerialIndex();
//        java.lang.Number number59 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) month56);
//        long long60 = timeSeries46.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries40.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int65 = month64.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month64.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.previous();
//        long long68 = month64.getLastMillisecond();
//        org.jfree.data.time.Year year69 = month64.getYear();
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass72 = timeSeries71.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        long long74 = fixedMillisecond73.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond73.previous();
//        int int76 = timeSeries71.getIndex(regularTimePeriod75);
//        boolean boolean77 = timeSeries71.isEmpty();
//        double double78 = timeSeries71.getMaxY();
//        int int79 = year69.compareTo((java.lang.Object) timeSeries71);
//        boolean boolean80 = timeSeries61.equals((java.lang.Object) timeSeries71);
//        java.lang.String str81 = timeSeries61.getDomainDescription();
//        int int82 = fixedMillisecond28.compareTo((java.lang.Object) str81);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184779006L + "'", long21 == 1560184779006L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184779006L + "'", long23 == 1560184779006L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560184779006L + "'", long25 == 1560184779006L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560184779008L + "'", long30 == 1560184779008L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + (short) 100 + "'", comparable52.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1201L + "'", long58 == 1201L);
//        org.junit.Assert.assertNull(number59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-59008924800001L) + "'", long68 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560184779014L + "'", long74 == 1560184779014L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Time" + "'", str81.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        boolean boolean5 = day2.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) 1560184734991L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (byte) 1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond21);
//        java.util.Date date23 = fixedMillisecond21.getTime();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184779342L + "'", long14 == 1560184779342L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date23);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        int int5 = timeSeries1.getItemCount();
//        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass9 = timeSeries8.getClass();
//        int int10 = timeSeries8.getMaximumItemCount();
//        int int11 = timeSeries8.getMaximumItemCount();
//        java.lang.Class class12 = timeSeries8.getTimePeriodClass();
//        java.lang.String str13 = timeSeries8.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        int int17 = day15.getMonth();
//        int int18 = day15.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.next();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean23 = timeSeries21.equals((java.lang.Object) 9999);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
//        java.lang.Class<?> wildcardClass27 = seriesChangeEvent25.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        boolean boolean29 = timeSeries21.equals((java.lang.Object) class28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean32 = timeSeries31.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries31.addChangeListener(seriesChangeListener33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries31.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Comparable comparable37 = timeSeries31.getKey();
//        int int38 = timeSeries31.getItemCount();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int42 = month41.getYearValue();
//        long long43 = month41.getSerialIndex();
//        java.lang.Number number44 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass47 = timeSeries46.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        long long49 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond48.previous();
//        int int51 = timeSeries46.getIndex(regularTimePeriod50);
//        boolean boolean52 = timeSeries46.isEmpty();
//        double double53 = timeSeries46.getMaxY();
//        timeSeries46.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass59 = timeSeries58.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        long long61 = fixedMillisecond60.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond60.previous();
//        int int63 = timeSeries58.getIndex(regularTimePeriod62);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj67 = null;
//        boolean boolean68 = month66.equals(obj67);
//        boolean boolean70 = month66.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year71 = month66.getYear();
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month66.previous();
//        java.util.Date date76 = month66.getEnd();
//        int int77 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) month66);
//        org.jfree.data.time.Year year78 = month66.getYear();
//        int int79 = year78.getYear();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year78, (double) 1560184740563L, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (java.lang.Number) 2019);
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries1.createCopy(regularTimePeriod19, (org.jfree.data.time.RegularTimePeriod) year78);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = timeSeries1.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (short) 100 + "'", comparable37.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1201L + "'", long43 == 1201L);
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560184779436L + "'", long49 == 1560184779436L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560184779438L + "'", long61 == 1560184779438L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 100 + "'", int79 == 100);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//        org.junit.Assert.assertNotNull(timeSeries85);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "", "2019");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
//        java.lang.Class<?> wildcardClass9 = seriesChangeEvent7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean13 = timeSeries12.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        timeSeries12.setKey((java.lang.Comparable) date20);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date20, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        java.lang.Number number26 = null;
//        try {
//            timeSeries3.update(regularTimePeriod25, number26);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184779462L + "'", long19 == 1560184779462L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries11.getKey();
//        int int18 = timeSeries11.getItemCount();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int22 = month21.getYearValue();
//        long long23 = month21.getSerialIndex();
//        java.lang.Number number24 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month21);
//        long long25 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries5.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int30 = month29.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.previous();
//        long long33 = month29.getLastMillisecond();
//        org.jfree.data.time.Year year34 = month29.getYear();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass37 = timeSeries36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        long long39 = fixedMillisecond38.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
//        int int41 = timeSeries36.getIndex(regularTimePeriod40);
//        boolean boolean42 = timeSeries36.isEmpty();
//        double double43 = timeSeries36.getMaxY();
//        int int44 = year34.compareTo((java.lang.Object) timeSeries36);
//        boolean boolean45 = timeSeries26.equals((java.lang.Object) timeSeries36);
//        java.util.Collection collection46 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        java.util.Date date49 = year48.getEnd();
//        long long50 = year48.getSerialIndex();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(12, year48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.previous();
//        timeSeries36.add(regularTimePeriod52, (java.lang.Number) 1560184757972L, false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (short) 100 + "'", comparable17.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1201L + "'", long23 == 1201L);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-59008924800001L) + "'", long33 == (-59008924800001L));
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560184779501L + "'", long39 == 1560184779501L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184779677L + "'", long1 == 1560184779677L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184779677L + "'", long4 == 1560184779677L);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        int int9 = day7.getMonth();
//        long long10 = day7.getLastMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560184750113L, false);
//        int int14 = day7.getDayOfMonth();
//        long long15 = day7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        long long3 = year0.getSerialIndex();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        java.lang.String str9 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560184734477L);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((int) '#', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date14);
//        java.util.TimeZone timeZone21 = null;
//        try {
//            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date14, timeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184780215L + "'", long13 == 1560184780215L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        java.lang.String str4 = seriesException3.toString();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        int int6 = year0.compareTo((java.lang.Object) seriesException3);
        java.lang.String str7 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]" + "'", str7.equals("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]"));
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getYear();
//        long long4 = day0.getLastMillisecond();
//        int int5 = day0.getMonth();
//        java.lang.String str6 = day0.toString();
//        int int7 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getSerialIndex();
        org.jfree.data.time.Year year5 = month2.getYear();
        long long6 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1201L + "'", long4 == 1201L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1201L + "'", long6 == 1201L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = month14.compareTo((java.lang.Object) day21);
        int int23 = day21.getYear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184780869L + "'", long1 == 1560184780869L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184780869L + "'", long3 == 1560184780869L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        int int3 = year0.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj7 = null;
        boolean boolean8 = month6.equals(obj7);
        boolean boolean10 = month6.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year11 = month6.getYear();
        int int12 = year11.getYear();
        long long13 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        boolean boolean15 = year0.equals((java.lang.Object) year11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58979980800001L) + "'", long13 == (-58979980800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent1.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        timeSeries6.setKey((java.lang.Comparable) date14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date14, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        boolean boolean20 = year18.equals((java.lang.Object) 1560184762488L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184780919L + "'", long13 == 1560184780919L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        int int17 = day15.getDayOfMonth();
//        boolean boolean18 = timeSeriesDataItem13.equals((java.lang.Object) int17);
//        timeSeriesDataItem13.setSelected(false);
//        java.lang.Number number21 = null;
//        timeSeriesDataItem13.setValue(number21);
//        int int24 = timeSeriesDataItem13.compareTo((java.lang.Object) 1560184762048L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184781017L + "'", long9 == 1560184781017L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        int int5 = timeSeries1.getItemCount();
//        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass9 = timeSeries8.getClass();
//        int int10 = timeSeries8.getMaximumItemCount();
//        int int11 = timeSeries8.getMaximumItemCount();
//        java.lang.Class class12 = timeSeries8.getTimePeriodClass();
//        java.lang.String str13 = timeSeries8.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        int int17 = day15.getMonth();
//        int int18 = day15.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day15.next();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean23 = timeSeries21.equals((java.lang.Object) 9999);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
//        java.lang.Class<?> wildcardClass27 = seriesChangeEvent25.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        boolean boolean29 = timeSeries21.equals((java.lang.Object) class28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean32 = timeSeries31.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries31.addChangeListener(seriesChangeListener33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries31.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Comparable comparable37 = timeSeries31.getKey();
//        int int38 = timeSeries31.getItemCount();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int42 = month41.getYearValue();
//        long long43 = month41.getSerialIndex();
//        java.lang.Number number44 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass47 = timeSeries46.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        long long49 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond48.previous();
//        int int51 = timeSeries46.getIndex(regularTimePeriod50);
//        boolean boolean52 = timeSeries46.isEmpty();
//        double double53 = timeSeries46.getMaxY();
//        timeSeries46.removeAgedItems((long) 3, false);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass59 = timeSeries58.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        long long61 = fixedMillisecond60.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond60.previous();
//        int int63 = timeSeries58.getIndex(regularTimePeriod62);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj67 = null;
//        boolean boolean68 = month66.equals(obj67);
//        boolean boolean70 = month66.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year71 = month66.getYear();
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month66.previous();
//        java.util.Date date76 = month66.getEnd();
//        int int77 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) month66);
//        org.jfree.data.time.Year year78 = month66.getYear();
//        int int79 = year78.getYear();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year78, (double) 1560184740563L, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (java.lang.Number) 2019);
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries1.createCopy(regularTimePeriod19, (org.jfree.data.time.RegularTimePeriod) year78);
//        java.lang.Class class86 = timeSeries1.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (short) 100 + "'", comparable37.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1201L + "'", long43 == 1201L);
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560184781274L + "'", long49 == 1560184781274L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560184781282L + "'", long61 == 1560184781282L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 100 + "'", int79 == 100);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertNull(class86);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month9.previous();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = month9.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184781839L + "'", long4 == 1560184781839L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560184735928L, false);
//        timeSeries1.fireSeriesChanged();
//        java.lang.String str27 = timeSeries1.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184781857L + "'", long9 == 1560184781857L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-9999), 9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.next();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1560184746700L);
//        java.lang.String str17 = timeSeries1.getRangeDescription();
//        timeSeries1.setMaximumItemAge(1560184764959L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184782273L + "'", long4 == 1560184782273L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184782276L + "'", long9 == 1560184782276L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184782276L + "'", long11 == 1560184782276L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184782276L + "'", long13 == 1560184782276L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560184734991L);
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        java.util.Date date18 = regularTimePeriod17.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 0L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getMonth();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day22.next();
//        int int26 = day22.getYear();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.Class class28 = timeSeries1.getTimePeriodClass();
//        int int29 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184782403L + "'", long9 == 1560184782403L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011603200000L) + "'", long3 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setKey((java.lang.Comparable) 1560184765243L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        java.lang.Object obj12 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 09:38:56 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
//        boolean boolean5 = day2.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) 1560184734991L);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (byte) 1, true);
//        java.util.Date date11 = day2.getStart();
//        long long12 = day2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.Year year14 = month12.getYear();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year14, (double) 1560184743407L, false);
        int int18 = timeSeries5.getMaximumItemCount();
        try {
            java.lang.Number number20 = timeSeries5.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=1560184739172]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        boolean boolean8 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean13 = timeSeries12.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass18 = timeSeries17.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.previous();
//        int int22 = timeSeries17.getIndex(regularTimePeriod21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod21, (java.lang.Number) 100.0d);
//        timeSeries12.add(timeSeriesDataItem24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem24.getPeriod();
//        timeSeries1.add(timeSeriesDataItem24);
//        boolean boolean28 = timeSeriesDataItem24.isSelected();
//        java.lang.Number number29 = timeSeriesDataItem24.getValue();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184784136L + "'", long4 == 1560184784136L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560184784166L + "'", long20 == 1560184784166L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560184769487L);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        long long20 = timeSeries9.getMaximumItemAge();
//        double double21 = timeSeries9.getMinY();
//        boolean boolean22 = timeSeries9.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries9.addChangeListener(seriesChangeListener23);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass27 = timeSeries26.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
//        int int31 = timeSeries26.getIndex(regularTimePeriod30);
//        boolean boolean32 = timeSeries26.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass35 = timeSeries34.getClass();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass38 = timeSeries37.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        long long40 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond39.previous();
//        int int42 = timeSeries37.getIndex(regularTimePeriod41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod41, (java.lang.Number) 100.0d);
//        timeSeriesDataItem44.setValue((java.lang.Number) 1201L);
//        timeSeries34.add(timeSeriesDataItem44, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond49.next();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond49.getMiddleMillisecond(calendar51);
//        int int53 = timeSeriesDataItem44.compareTo((java.lang.Object) calendar51);
//        timeSeries26.add(timeSeriesDataItem44);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        int int57 = timeSeriesDataItem44.compareTo((java.lang.Object) day55);
//        boolean boolean58 = timeSeriesDataItem44.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries9.addOrUpdate(timeSeriesDataItem44);
//        try {
//            timeSeries9.removeAgedItems(1560184783945L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560184784355L + "'", long29 == 1560184784355L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560184784358L + "'", long40 == 1560184784358L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560184784388L + "'", long52 == 1560184784388L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59008924800001L) + "'", long4 == (-59008924800001L));
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        timeSeries1.setMaximumItemAge(1560184732113L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184784417L + "'", long4 == 1560184784417L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year18 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int20 = month14.getMonth();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = month14.compareTo((java.lang.Object) day21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day21.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        timeSeries1.removeAgedItems(1560184766910L, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        timeSeries1.setRangeDescription("2019");
//        java.util.Collection collection10 = timeSeries1.getTimePeriods();
//        java.util.List list11 = timeSeries1.getItems();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184786175L + "'", long4 == 1560184786175L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(list11);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        long long22 = fixedMillisecond18.getLastMillisecond();
//        timeSeries1.setKey((java.lang.Comparable) long22);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184786226L + "'", long4 == 1560184786226L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184786227L + "'", long21 == 1560184786227L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560184786227L + "'", long22 == 1560184786227L);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Date date12 = fixedMillisecond10.getTime();
//        long long13 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond14.peg(calendar15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        int int18 = timeSeries5.getItemCount();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560184786361L + "'", long11 == 1560184786361L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560184786361L + "'", long13 == 1560184786361L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        java.lang.String str7 = timeSeries1.getDescription();
//        boolean boolean9 = timeSeries1.equals((java.lang.Object) 1560184741794L);
//        timeSeries1.setRangeDescription("Mon Jun 10 09:38:55 PDT 2019");
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184786412L + "'", long4 == 1560184786412L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        double double8 = timeSeries1.getMaxY();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day9.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184786513L + "'", long4 == 1560184786513L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge(1560184747909L);
        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(regularTimePeriod3, (java.lang.Number) 1201L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        timeSeries1.setRangeDescription("Mon Jun 10 09:39:01 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int14 = month13.getYearValue();
//        long long15 = month13.getSerialIndex();
//        int int16 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        org.jfree.data.time.Year year17 = month13.getYear();
//        java.lang.String str18 = month13.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (-1.0d));
//        java.lang.String str21 = month13.toString();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184786816L + "'", long4 == 1560184786816L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1201L + "'", long15 == 1201L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January 100" + "'", str18.equals("January 100"));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "January 100" + "'", str21.equals("January 100"));
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (double) 1577865599999L);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
//        boolean boolean14 = day11.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 1560184734991L);
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) (byte) 1, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean24 = timeSeries23.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries23.addChangeListener(seriesChangeListener25);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass29 = timeSeries28.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        int int33 = timeSeries28.getIndex(regularTimePeriod32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod32, (java.lang.Number) 100.0d);
//        timeSeries23.add(timeSeriesDataItem35);
//        java.lang.String str37 = timeSeries23.getDescription();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        java.util.Date date40 = regularTimePeriod39.getStart();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
//        timeSeries23.update((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0L);
//        int int44 = fixedMillisecond21.compareTo((java.lang.Object) day41);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries45 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184786852L + "'", long5 == 1560184786852L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560184786881L + "'", long31 == 1560184786881L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        boolean boolean5 = day2.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (double) 1560184734991L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (byte) 1, true);
        java.util.Date date11 = day2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        timeSeries1.setNotify(false);
        java.lang.Object obj14 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "", "2019");
//        timeSeries3.setKey((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        int int11 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond8);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond8.peg(calendar12);
//        int int14 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries3.setDescription("0");
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184787039L + "'", long9 == 1560184787039L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.lang.Class<?> wildcardClass20 = timeSeries1.getClass();
//        boolean boolean21 = timeSeries1.isEmpty();
//        java.lang.Class<?> wildcardClass22 = timeSeries1.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184787335L + "'", long4 == 1560184787335L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560184735928L, false);
//        timeSeries1.fireSeriesChanged();
//        double double27 = timeSeries1.getMaxY();
//        java.lang.Class<?> wildcardClass28 = timeSeries1.getClass();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184787370L + "'", long9 == 1560184787370L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.560184735928E12d + "'", double27 == 1.560184735928E12d);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean7 = timeSeries6.getNotify();
        timeSeries6.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        java.lang.String str15 = month12.toString();
        java.lang.Number number16 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month12);
        boolean boolean17 = fixedMillisecond2.equals((java.lang.Object) month12);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month12.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January 100" + "'", str15.equals("January 100"));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long30 = month29.getFirstMillisecond();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        boolean boolean32 = fixedMillisecond20.equals((java.lang.Object) year31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond20.previous();
//        java.util.Date date34 = fixedMillisecond20.getTime();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond20.getMiddleMillisecond(calendar35);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184787524L + "'", long21 == 1560184787524L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184787524L + "'", long23 == 1560184787524L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560184787524L + "'", long25 == 1560184787524L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-59011603200000L) + "'", long30 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560184787524L + "'", long36 == 1560184787524L);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560184735928L, false);
//        timeSeries1.fireSeriesChanged();
//        double double27 = timeSeries1.getMaxY();
//        timeSeries1.setMaximumItemCount(9);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184787613L + "'", long9 == 1560184787613L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.560184735928E12d + "'", double27 == 1.560184735928E12d);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj15 = null;
        boolean boolean16 = month14.equals(obj15);
        boolean boolean18 = month14.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int20 = year19.getYear();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries9.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.createCopy((int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timeSeries25);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184787740L + "'", long3 == 1560184787740L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184787740L + "'", long4 == 1560184787740L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560184787740L + "'", long5 == 1560184787740L);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560184766222L, "February 100", "Mon Jun 10 09:39:02 PDT 2019");
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy((int) '4', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560184734991L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
//        java.lang.Class<?> wildcardClass9 = seriesChangeEvent7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean13 = timeSeries12.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        timeSeries12.setKey((java.lang.Comparable) date20);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date20, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date20);
//        int int26 = timeSeriesDataItem5.compareTo((java.lang.Object) month25);
//        long long27 = month25.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560184787883L + "'", long19 == 1560184787883L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        timeSeries1.clear();
//        double double8 = timeSeries1.getMinY();
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=10.0]]");
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184788250L + "'", long4 == 1560184788250L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond2);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184788265L + "'", long3 == 1560184788265L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184788264L + "'", long7 == 1560184788264L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560184788264L + "'", long8 == 1560184788264L);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.util.Date date2 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(7, year4);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean7 = timeSeries6.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        int int16 = timeSeries11.getIndex(regularTimePeriod15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 100.0d);
//        timeSeries6.add(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) fixedMillisecond21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem18.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560184788538L + "'", long14 == 1560184788538L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        java.lang.String str7 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
        int int9 = month2.compareTo((java.lang.Object) regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560184760595L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries1.addChangeListener(seriesChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        int int11 = timeSeries6.getIndex(regularTimePeriod10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 100.0d);
//        timeSeries1.add(timeSeriesDataItem13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem13.getPeriod();
//        timeSeriesDataItem13.setValue((java.lang.Number) 1560184765584L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560184788714L + "'", long9 == 1560184788714L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean6 = timeSeries5.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.Year year14 = month12.getYear();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year14, (double) 1560184743407L, false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean21 = timeSeries19.equals((java.lang.Object) 9999);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean24 = timeSeries23.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries23.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries19.addAndOrUpdate(timeSeries23);
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj33 = null;
        boolean boolean34 = month32.equals(obj33);
        boolean boolean36 = month32.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.Year year37 = month32.getYear();
        int int38 = year37.getYear();
        int int39 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year37);
        timeSeries27.fireSeriesChanged();
        boolean boolean41 = timeSeries27.isEmpty();
        java.util.Collection collection42 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(collection42);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long13 = month12.getFirstMillisecond();
//        org.jfree.data.time.Year year14 = month12.getYear();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year14, (double) 1560184743407L, false);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean21 = timeSeries19.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass24 = timeSeries23.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
//        int int28 = timeSeries23.getIndex(regularTimePeriod27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj32 = null;
//        boolean boolean33 = month31.equals(obj32);
//        boolean boolean35 = month31.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year36 = month31.getYear();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 10, false);
//        timeSeries23.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
//        java.util.Collection collection42 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        timeSeries23.fireSeriesChanged();
//        boolean boolean44 = year14.equals((java.lang.Object) timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59011603200000L) + "'", long13 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560184788829L + "'", long26 == 1560184788829L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = month9.equals(obj10);
//        boolean boolean13 = month9.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month9.previous();
//        java.util.Date date19 = month9.getEnd();
//        int int20 = month9.getYearValue();
//        org.jfree.data.time.Year year21 = month9.getYear();
//        java.util.Calendar calendar22 = null;
//        try {
//            year21.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184789039L + "'", long4 == 1560184789039L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(year21);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getMaximumItemCount();
        int int4 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(10);
        long long7 = year6.getLastMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 1560184750009L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820208000001L) + "'", long7 == (-61820208000001L));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        boolean boolean3 = day0.equals((java.lang.Object) (short) 0);
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean3 = timeSeries1.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries5.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        int int17 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        long long23 = fixedMillisecond20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getLastMillisecond(calendar24);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long30 = month29.getFirstMillisecond();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        boolean boolean32 = fixedMillisecond20.equals((java.lang.Object) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        long long36 = month35.getFirstMillisecond();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        int int38 = month35.getYearValue();
//        int int39 = year31.compareTo((java.lang.Object) int38);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1201L + "'", long16 == 1201L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560184789247L + "'", long21 == 1560184789247L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560184789247L + "'", long23 == 1560184789247L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560184789247L + "'", long25 == 1560184789247L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-59011603200000L) + "'", long30 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-59011603200000L) + "'", long36 == (-59011603200000L));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = month12.equals(obj13);
//        boolean boolean16 = month12.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Year year17 = month12.getYear();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month12.previous();
//        boolean boolean22 = day0.equals((java.lang.Object) month12);
//        long long23 = day0.getSerialIndex();
//        int int24 = day0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean28 = timeSeries26.equals((java.lang.Object) 9999);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean31 = timeSeries30.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries30.addChangeListener(seriesChangeListener32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        boolean boolean37 = timeSeries36.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries36.addChangeListener(seriesChangeListener38);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries36.removePropertyChangeListener(propertyChangeListener40);
//        java.lang.Comparable comparable42 = timeSeries36.getKey();
//        int int43 = timeSeries36.getItemCount();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
//        int int47 = month46.getYearValue();
//        long long48 = month46.getSerialIndex();
//        java.lang.Number number49 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) month46);
//        long long50 = timeSeries36.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries30.addAndOrUpdate(timeSeries36);
//        boolean boolean52 = day0.equals((java.lang.Object) timeSeries30);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560184789358L + "'", long7 == 1560184789358L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + (short) 100 + "'", comparable42.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1201L + "'", long48 == 1201L);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
//        int int6 = timeSeries1.getIndex(regularTimePeriod5);
//        boolean boolean7 = timeSeries1.isEmpty();
//        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
//        try {
//            timeSeries1.delete(0, 2, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560184789634L + "'", long4 == 1560184789634L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNull(class8);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        timeSeries1.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10.0]");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 100);
        java.lang.Object obj8 = null;
        boolean boolean9 = month7.equals(obj8);
        java.lang.String str10 = month7.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year12 = month7.getYear();
        java.util.Date date13 = month7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month7.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January 100" + "'", str10.equals("January 100"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getMonth();
        int int6 = day4.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 1560184743407L, true);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day4.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560184732750L, "org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=1560184739172]", "org.jfree.data.event.SeriesChangeEvent[source=10.0]");
    }
}

