import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException2.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.util.Date date8 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date0, timeZone14, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61756747200001L) + "'", long4 == (-61756747200001L));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 100, 12");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        java.util.Date date9 = regularTimePeriod7.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729531200001L) + "'", long8 == (-61729531200001L));
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date5, timeZone11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week13.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        java.util.Calendar calendar4 = null;
        try {
            week3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        boolean boolean4 = week0.equals((java.lang.Object) 1560365999999L);
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 53);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date17);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = week34.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        java.util.Date date7 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date13, timeZone19);
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone19, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        long long9 = week2.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException9.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date6, timeZone13, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61042780800000L) + "'", long3 == (-61042780800000L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        try {
            int int6 = week0.compareTo((java.lang.Object) regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        long long9 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year10 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
        int int7 = week5.compareTo((java.lang.Object) false);
        java.util.Date date8 = week5.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        java.util.Date date16 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException18.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date8, timeZone22);
        java.util.Locale locale26 = null;
        try {
            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date2, timeZone22, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException12.getClass();
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 12);
//        int int23 = week21.compareTo((java.lang.Object) false);
//        java.util.Date date24 = week21.getStart();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date24, timeZone27);
//        java.util.Locale locale30 = null;
//        try {
//            org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date5, timeZone27, locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            week3.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728926400001L) + "'", long8 == (-61728926400001L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        java.util.Date date17 = regularTimePeriod16.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        java.lang.Class<?> wildcardClass23 = date17.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(100, 12);
        int int28 = week26.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass29 = week26.getClass();
        java.util.Date date30 = week26.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        java.util.Date date40 = regularTimePeriod39.getStart();
        java.lang.Class class41 = null;
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date40, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone43);
        java.util.Locale locale47 = null;
        try {
            org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date6, timeZone43, locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 0, 0" + "'", str4.equals("Week 0, 0"));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        java.util.Date date8 = year6.getEnd();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year6.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2019);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1549180799999L + "'", long3 == 1549180799999L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        java.util.Date date6 = week2.getStart();
//        java.util.Date date7 = week2.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        java.util.Date date13 = week8.getEnd();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date13, timeZone16);
//        java.util.Locale locale19 = null;
//        try {
//            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date7, timeZone16, locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week10.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        java.util.Locale locale39 = null;
        try {
            org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date4, timeZone35, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61756747200001L) + "'", long4 == (-61756747200001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date6, timeZone15);
//        int int19 = week18.getYearValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
        int int17 = week15.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        java.util.Date date19 = week15.getStart();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(100, 12);
        int int25 = week24.getWeek();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
        int int30 = week28.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass31 = week28.getClass();
        java.util.Date date32 = week28.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        int int38 = week24.compareTo((java.lang.Object) timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date21, timeZone35);
        java.util.TimeZone timeZone40 = null;
        java.util.Locale locale41 = null;
        try {
            org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date21, timeZone40, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2019, year9);
//        long long11 = week10.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1528311599999L + "'", long11 == 1528311599999L);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        int int7 = week5.getYearValue();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        int int8 = week0.compareTo((java.lang.Object) "");
//        long long9 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = throwableArray3.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        java.util.Date date6 = week2.getStart();
//        java.lang.Class class7 = null;
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
//        java.lang.Class<?> wildcardClass12 = date6.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(100, 12);
//        int int25 = week24.getWeek();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
//        int int30 = week28.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        java.util.Date date32 = week28.getStart();
//        java.lang.Class class33 = null;
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
//        int int38 = week24.compareTo((java.lang.Object) timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date21, timeZone35);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        long long42 = week41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.previous();
//        java.lang.String str44 = week41.toString();
//        int int45 = week41.getYearValue();
//        org.jfree.data.time.Year year46 = week41.getYear();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, year46);
//        int int48 = week47.getYearValue();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(100, 12);
//        int int53 = week51.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass54 = week51.getClass();
//        java.util.Date date55 = week51.getStart();
//        java.lang.Class class56 = null;
//        java.util.Date date57 = null;
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date55, timeZone58);
//        int int61 = week47.compareTo((java.lang.Object) timeZone58);
//        java.util.Locale locale62 = null;
//        try {
//            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date21, timeZone58, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2019, year9);
//        java.util.Calendar calendar11 = null;
//        try {
//            week10.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        int int7 = week0.getWeek();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = year4.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale35 = null;
        try {
            org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date17, timeZone34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        int int7 = week0.getWeek();
//        java.util.Date date8 = week0.getStart();
//        java.util.TimeZone timeZone9 = null;
//        java.util.Locale locale10 = null;
//        try {
//            org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8, timeZone9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 24);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        java.util.Date date5 = week3.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Date date8 = week7.getStart();
        long long9 = week7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 736L + "'", long9 == 736L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 4);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        int int6 = week5.getWeek();
//        int int7 = week5.getWeek();
//        java.util.Calendar calendar8 = null;
//        try {
//            week5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date0, timeZone3, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Calendar calendar8 = null;
        try {
            week7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        java.util.Calendar calendar9 = null;
        try {
            week7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47 + "'", int8 == 47);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728624000001L) + "'", long8 == (-61728624000001L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getFirstMillisecond();
        long long9 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61728624000001L) + "'", long7 == (-61728624000001L));
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getStart();
//        java.util.Calendar calendar6 = null;
//        try {
//            week3.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 2019);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1548576000000L + "'", long3 == 1548576000000L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.util.Calendar calendar10 = null;
        try {
            week2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
//        int int32 = week30.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week30.next();
//        java.util.Date date34 = week30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        long long36 = week35.getLastMillisecond();
//        boolean boolean38 = week35.equals((java.lang.Object) 0.0d);
//        long long39 = week35.getMiddleMillisecond();
//        int int40 = week35.getWeek();
//        java.lang.String str41 = week35.toString();
//        java.lang.Class<?> wildcardClass42 = week35.getClass();
//        java.util.Date date43 = null;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(100, 12);
//        int int48 = week46.compareTo((java.lang.Object) false);
//        java.util.Date date49 = week46.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
//        java.lang.Class<?> wildcardClass53 = timePeriodFormatException51.getClass();
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
//        java.util.Date date57 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray60 = timePeriodFormatException59.getSuppressed();
//        java.lang.Class<?> wildcardClass61 = timePeriodFormatException59.getClass();
//        java.util.Date date62 = null;
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone63);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date49, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone63);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date34, timeZone63);
//        java.util.Locale locale69 = null;
//        try {
//            org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date11, timeZone63, locale69);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560365999999L + "'", long39 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 24, 2019" + "'", str41.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(throwableArray52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(throwableArray60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728926400001L) + "'", long8 == (-61728926400001L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
//        int int7 = week5.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.Date date11 = week10.getStart();
//        int int12 = week0.compareTo((java.lang.Object) date11);
//        org.jfree.data.time.Year year13 = week0.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(year13);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61728624000001L) + "'", long10 == (-61728624000001L));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        boolean boolean15 = week10.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week10.previous();
        boolean boolean17 = week2.equals((java.lang.Object) regularTimePeriod16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week2.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        boolean boolean10 = week7.equals((java.lang.Object) 0.0d);
//        long long11 = week7.getMiddleMillisecond();
//        int int12 = week7.getWeek();
//        java.lang.String str13 = week7.toString();
//        java.lang.Class<?> wildcardClass14 = week7.getClass();
//        java.util.Date date15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        java.util.Date date29 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException31.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date6, timeZone35);
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = week40.getLastMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        long long5 = week3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        boolean boolean10 = week7.equals((java.lang.Object) 0.0d);
//        long long11 = week7.getMiddleMillisecond();
//        int int12 = week7.getWeek();
//        java.lang.String str13 = week7.toString();
//        java.lang.Class<?> wildcardClass14 = week7.getClass();
//        java.util.Date date15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        java.util.Date date21 = week18.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        java.util.Date date29 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException31.getClass();
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone35);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date6, timeZone35);
//        java.lang.Class<?> wildcardClass41 = date6.getClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
        java.util.Date date38 = regularTimePeriod37.getStart();
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date38, timeZone41);
        java.lang.Class<?> wildcardClass44 = date38.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(100, 12);
        int int49 = week47.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass50 = week47.getClass();
        java.util.Date date51 = week47.getStart();
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date51, timeZone54);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        java.util.Date date61 = regularTimePeriod60.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date51, timeZone64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date17, timeZone64);
        java.util.TimeZone timeZone69 = null;
        java.util.Locale locale70 = null;
        try {
            org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date17, timeZone69, locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        int int8 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Calendar calendar10 = null;
        try {
            week7.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47 + "'", int8 == 47);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        int int8 = week0.getYearValue();
//        org.jfree.data.time.Year year9 = week0.getYear();
//        java.util.Date date10 = year9.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str11 = timePeriodFormatException5.toString();
        java.lang.String str12 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        int int7 = week3.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        int int20 = week6.getYearValue();
//        long long21 = week6.getFirstMillisecond();
//        long long22 = week6.getSerialIndex();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week6.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 107031L + "'", long22 == 107031L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException2.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException2.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
        int int13 = week11.compareTo((java.lang.Object) false);
        java.util.Date date14 = week11.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone17);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.util.Date date25 = regularTimePeriod24.getStart();
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date25, timeZone28);
        java.lang.Class<?> wildcardClass31 = date25.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException33.getSuppressed();
        java.lang.Class<?> wildcardClass35 = timePeriodFormatException33.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        java.util.Date date39 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
        java.lang.Class<?> wildcardClass43 = timePeriodFormatException41.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone45);
        try {
            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date0, timeZone45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException16.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Date date5 = regularTimePeriod4.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        boolean boolean2 = week0.equals((java.lang.Object) 1);
//        long long3 = week0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
//        int int8 = week6.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.util.Date date10 = week6.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.Date date12 = week11.getStart();
//        int int13 = week1.compareTo((java.lang.Object) date12);
//        org.jfree.data.time.Year year14 = week1.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, year14);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        int int20 = week6.getYearValue();
//        long long21 = week6.getFirstMillisecond();
//        java.util.Date date22 = week6.getStart();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week6.getFirstMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        java.util.Date date14 = week10.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14, timeZone17);
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date6, timeZone17, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        boolean boolean2 = week0.equals((java.lang.Object) 1);
        int int3 = week0.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            week0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        long long9 = week7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1606636799999L + "'", long9 == 1606636799999L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 100);
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        int int10 = week2.compareTo((java.lang.Object) 0);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        java.lang.Class<?> wildcardClass23 = date17.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(100, 12);
        int int28 = week26.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass29 = week26.getClass();
        java.util.Date date30 = week26.getStart();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        java.util.Date date32 = week31.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(100, 12);
        int int36 = week35.getWeek();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, 12);
        int int41 = week39.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass42 = week39.getClass();
        java.util.Date date43 = week39.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        int int49 = week35.compareTo((java.lang.Object) timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date32, timeZone46);
        boolean boolean51 = week2.equals((java.lang.Object) regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 12" + "'", str5.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        java.lang.Object obj6 = null;
        int int7 = week2.compareTo(obj6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        java.util.Calendar calendar4 = null;
        try {
            week3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (byte) 10);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        java.lang.Class<?> wildcardClass49 = date43.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, 12);
        int int54 = week52.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        java.util.Date date56 = week52.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.util.Date date66 = regularTimePeriod65.getStart();
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date56, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date22, timeZone69);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date4, timeZone69);
        java.util.Calendar calendar75 = null;
        try {
            long long76 = week74.getLastMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getFirstMillisecond();
        long long10 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61728926400001L) + "'", long10 == (-61728926400001L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        int int27 = week25.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass28 = week25.getClass();
        java.util.Date date29 = week25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date29, timeZone32);
        java.lang.Class<?> wildcardClass35 = timeZone32.getClass();
        java.util.Locale locale36 = null;
        try {
            org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date11, timeZone32, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
//        java.util.Date date4 = year2.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        java.util.Date date9 = week8.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
//        java.lang.Class<?> wildcardClass14 = timePeriodFormatException11.getClass();
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 12);
//        int int22 = week20.compareTo((java.lang.Object) false);
//        java.util.Date date23 = week20.getStart();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date23, timeZone26);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean30 = week8.equals((java.lang.Object) wildcardClass14);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
//        java.util.Date date35 = regularTimePeriod34.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        long long38 = week37.getLastMillisecond();
//        boolean boolean40 = week37.equals((java.lang.Object) 0.0d);
//        long long41 = week37.getMiddleMillisecond();
//        int int42 = week37.getWeek();
//        java.lang.String str43 = week37.toString();
//        java.lang.Class<?> wildcardClass44 = week37.getClass();
//        java.util.Date date45 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(100, 12);
//        int int50 = week48.compareTo((java.lang.Object) false);
//        java.util.Date date51 = week48.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray54 = timePeriodFormatException53.getSuppressed();
//        java.lang.Class<?> wildcardClass55 = timePeriodFormatException53.getClass();
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
//        java.util.Date date59 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException61 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray62 = timePeriodFormatException61.getSuppressed();
//        java.lang.Class<?> wildcardClass63 = timePeriodFormatException61.getClass();
//        java.util.Date date64 = null;
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date64, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone65);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date51, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date35, timeZone65);
//        java.util.Locale locale71 = null;
//        try {
//            org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date4, timeZone65, locale71);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560365999999L + "'", long41 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 24 + "'", int42 == 24);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(throwableArray54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(throwableArray62);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        int int5 = week3.getYearValue();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week3.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
//        int int7 = week5.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.Date date11 = week10.getStart();
//        int int12 = week0.compareTo((java.lang.Object) date11);
//        org.jfree.data.time.Year year13 = week0.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            week0.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(year13);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        long long9 = week2.getFirstMillisecond();
        long long10 = week2.getMiddleMillisecond();
        java.util.Date date11 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61728926400001L) + "'", long10 == (-61728926400001L));
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(6, year6);
//        boolean boolean9 = week7.equals((java.lang.Object) (short) 0);
//        java.lang.String str10 = week7.toString();
//        long long11 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 6, 2019" + "'", str10.equals("Week 6, 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1549483199999L + "'", long11 == 1549483199999L);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        int int5 = week3.getYearValue();
//        java.util.Calendar calendar6 = null;
//        try {
//            week3.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        java.util.Date date8 = year6.getEnd();
//        java.util.Date date9 = year6.getEnd();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(13, 3);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        int int10 = week2.compareTo((java.lang.Object) 0);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 12" + "'", str5.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        int int8 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = regularTimePeriod4.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = week8.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.lang.String str14 = week13.toString();
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.Year year16 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.next();
//        java.util.Date date18 = week13.getEnd();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date12, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone21);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(100, 12);
//        int int30 = week28.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        java.util.Date date32 = week28.getStart();
//        java.lang.Class class33 = null;
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
//        java.lang.Class<?> wildcardClass38 = timeZone35.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date5, timeZone35);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        long long42 = week41.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.previous();
//        java.lang.String str44 = week41.toString();
//        int int45 = week41.getYearValue();
//        org.jfree.data.time.Year year46 = week41.getYear();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(6, year46);
//        boolean boolean49 = week47.equals((java.lang.Object) (short) 0);
//        boolean boolean50 = week39.equals((java.lang.Object) boolean49);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        java.util.Date date16 = week11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week11.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week11.previous();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        boolean boolean20 = week7.equals((java.lang.Object) regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        java.lang.Object obj4 = null;
        boolean boolean5 = week3.equals(obj4);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone19);
        try {
            java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.lang.Object obj9 = null;
        int int10 = week2.compareTo(obj9);
        try {
            org.jfree.data.time.Year year11 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        java.lang.String str20 = timePeriodFormatException18.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone20);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.previous();
//        java.lang.String str27 = week24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week24.next();
//        long long29 = week24.getSerialIndex();
//        java.util.Date date30 = week24.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week33.next();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getLastMillisecond();
//        boolean boolean41 = week38.equals((java.lang.Object) 0.0d);
//        long long42 = week38.getMiddleMillisecond();
//        int int43 = week38.getWeek();
//        java.lang.String str44 = week38.toString();
//        java.lang.Class<?> wildcardClass45 = week38.getClass();
//        java.util.Date date46 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
//        int int51 = week49.compareTo((java.lang.Object) false);
//        java.util.Date date52 = week49.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException54.getClass();
//        java.util.Date date57 = null;
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date57, timeZone58);
//        java.util.Date date60 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray63 = timePeriodFormatException62.getSuppressed();
//        java.lang.Class<?> wildcardClass64 = timePeriodFormatException62.getClass();
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone66);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date52, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date37, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date30, timeZone66);
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize(class74);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560365999999L + "'", long42 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(throwableArray63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(class73);
//        org.junit.Assert.assertNotNull(class74);
//        org.junit.Assert.assertNotNull(class75);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone19);
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        try {
            org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date11, timeZone23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(9, year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', year7);
        boolean boolean10 = week2.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        long long5 = week3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getSerialIndex();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        int int8 = week5.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(100, 12);
//        int int7 = week5.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.lang.String str11 = week10.toString();
//        long long12 = week10.getFirstMillisecond();
//        org.jfree.data.time.Year year13 = week10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week10.next();
//        java.util.Date date15 = week10.getEnd();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9, timeZone18);
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date2, timeZone18, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 11);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 12, 11" + "'", str3.equals("Week 12, 11"));
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException8.getClass();
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 12);
//        int int19 = week17.compareTo((java.lang.Object) false);
//        java.util.Date date20 = week17.getStart();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date20, timeZone23);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
//        java.util.Date date31 = regularTimePeriod30.getStart();
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date31, timeZone34);
//        java.lang.Class<?> wildcardClass37 = date31.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException39.getClass();
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
//        java.util.Date date45 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        java.lang.Class<?> wildcardClass49 = timePeriodFormatException47.getClass();
//        java.util.Date date50 = null;
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date45, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date31, timeZone51);
//        java.util.Locale locale55 = null;
//        try {
//            org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date6, timeZone51, locale55);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(throwableArray40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        int int9 = week2.compareTo((java.lang.Object) class8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
        int int14 = week12.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass15 = week12.getClass();
        java.util.Date date16 = week12.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        java.lang.Class<?> wildcardClass22 = timeZone19.getClass();
        boolean boolean23 = week2.equals((java.lang.Object) wildcardClass22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = week2.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException16.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass25 = throwableArray24.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        java.util.Date date6 = regularTimePeriod4.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560970799999L + "'", long5 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 6, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        int int8 = week7.getYearValue();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
//        int int21 = week7.compareTo((java.lang.Object) timeZone18);
//        long long22 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1606334399999L + "'", long22 == 1606334399999L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729228800000L) + "'", long7 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, year2);
        java.util.Date date4 = year2.getEnd();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(13, 3);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62065195200001L) + "'", long3 == (-62065195200001L));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        java.util.Date date17 = week0.getStart();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week0.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 0);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-29) + "'", int3 == (-29));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
//        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
//        java.util.Date date5 = null;
//        java.util.TimeZone timeZone6 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
//        int int12 = week10.compareTo((java.lang.Object) false);
//        java.util.Date date13 = week10.getStart();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
//        java.util.Date date24 = regularTimePeriod23.getStart();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
//        java.lang.Class<?> wildcardClass30 = date24.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        java.util.Date date38 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date24, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.lang.String str49 = week48.toString();
//        java.util.Date date50 = week48.getEnd();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
//        int int52 = week51.getWeek();
//        java.util.Date date53 = week51.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date53, timeZone54);
//        java.util.Locale locale56 = null;
//        try {
//            org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date24, timeZone54, locale56);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(throwableArray3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 24, 2019" + "'", str49.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
//        long long8 = week2.getLastMillisecond();
//        java.util.Date date9 = week2.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException11.getClass();
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.lang.String str18 = week17.toString();
//        long long19 = week17.getFirstMillisecond();
//        org.jfree.data.time.Year year20 = week17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week17.next();
//        java.util.Date date22 = week17.getEnd();
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
//        java.lang.Class class28 = null;
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date22, timeZone30);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        long long35 = week34.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week34.previous();
//        java.lang.String str37 = week34.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week34.next();
//        long long39 = week34.getSerialIndex();
//        java.util.Date date40 = week34.getStart();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(100, 12);
//        int int45 = week43.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week43.next();
//        java.util.Date date47 = week43.getStart();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        long long49 = week48.getLastMillisecond();
//        boolean boolean51 = week48.equals((java.lang.Object) 0.0d);
//        long long52 = week48.getMiddleMillisecond();
//        int int53 = week48.getWeek();
//        java.lang.String str54 = week48.toString();
//        java.lang.Class<?> wildcardClass55 = week48.getClass();
//        java.util.Date date56 = null;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(100, 12);
//        int int61 = week59.compareTo((java.lang.Object) false);
//        java.util.Date date62 = week59.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException64 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray65 = timePeriodFormatException64.getSuppressed();
//        java.lang.Class<?> wildcardClass66 = timePeriodFormatException64.getClass();
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
//        java.util.Date date70 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray73 = timePeriodFormatException72.getSuppressed();
//        java.lang.Class<?> wildcardClass74 = timePeriodFormatException72.getClass();
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date75, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date70, timeZone76);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date62, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone76);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date47, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date40, timeZone76);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date9, timeZone76);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728624000001L) + "'", long8 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560668399999L + "'", long35 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 24, 2019" + "'", str37.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 107031L + "'", long39 == 107031L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560668399999L + "'", long49 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560365999999L + "'", long52 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 24 + "'", int53 == 24);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 24, 2019" + "'", str54.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(throwableArray65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(throwableArray73);
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 100);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59013072000000L) + "'", long3 == (-59013072000000L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = week0.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(100, 12);
//        int int5 = week3.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        java.util.Date date13 = week8.getEnd();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date13, timeZone16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date7, timeZone16);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
//        java.util.Date date24 = regularTimePeriod23.getStart();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
//        java.lang.Class<?> wildcardClass30 = date24.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        java.util.Date date37 = week33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date37, timeZone40);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
//        java.util.Date date47 = regularTimePeriod46.getStart();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date37, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
//        java.util.Date date58 = regularTimePeriod57.getStart();
//        java.lang.Class class59 = null;
//        java.util.Date date60 = null;
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date58, timeZone61);
//        java.lang.Class<?> wildcardClass64 = date58.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(100, 12);
//        int int69 = week67.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass70 = week67.getClass();
//        java.util.Date date71 = week67.getStart();
//        java.lang.Class class72 = null;
//        java.util.Date date73 = null;
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date71, timeZone74);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week79.previous();
//        java.util.Date date81 = regularTimePeriod80.getStart();
//        java.lang.Class class82 = null;
//        java.util.Date date83 = null;
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone84);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date81, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date71, timeZone84);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date37, timeZone84);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date7, timeZone84);
//        java.util.Locale locale90 = null;
//        try {
//            org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date0, timeZone84, locale90);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date4, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 736L + "'", long4 == 736L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date13);
        java.lang.Class<?> wildcardClass20 = week19.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year10 = week9.getYear();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', year10);
        boolean boolean13 = week2.equals((java.lang.Object) week12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61729228800000L) + "'", long6 == (-61729228800000L));
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        long long9 = week2.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61728624000001L) + "'", long9 == (-61728624000001L));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        long long9 = week7.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            week7.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1545249599999L + "'", long9 == 1545249599999L);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        int int3 = week0.getWeek();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        long long7 = week5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1545552000000L + "'", long7 == 1545552000000L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        long long14 = week13.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61728624000001L) + "'", long14 == (-61728624000001L));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException6.getClass();
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.util.Date date18 = week15.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean25 = week3.equals((java.lang.Object) wildcardClass9);
//        int int26 = week3.getWeek();
//        java.util.Calendar calendar27 = null;
//        try {
//            week3.peg(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
//        int int8 = week6.compareTo((java.lang.Object) false);
//        java.lang.String str9 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year12);
//        int int14 = week6.compareTo((java.lang.Object) 0);
//        long long15 = week6.getMiddleMillisecond();
//        boolean boolean16 = week0.equals((java.lang.Object) week6);
//        java.lang.String str17 = week6.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728926400001L) + "'", long15 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 100, 12" + "'", str17.equals("Week 100, 12"));
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        java.util.Date date7 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        java.util.Date date14 = week10.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week10.previous();
        int int16 = week10.getYearValue();
        try {
            int int17 = week2.compareTo((java.lang.Object) week10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        long long8 = week7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week3.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61728624000001L) + "'", long7 == (-61728624000001L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61729228800000L) + "'", long4 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        long long7 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week3.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        java.util.Date date9 = year7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(10, year7);
//        java.util.Calendar calendar11 = null;
//        try {
//            week10.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.lang.Object obj8 = null;
        int int9 = week2.compareTo(obj8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729228800000L) + "'", long7 == (-61729228800000L));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        try {
            org.jfree.data.time.Year year12 = week11.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
//        int int12 = week10.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        java.util.Date date14 = week10.getStart();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14, timeZone17);
//        java.lang.Class<?> wildcardClass20 = timeZone17.getClass();
//        java.util.Locale locale21 = null;
//        try {
//            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date7, timeZone17, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(9, year2);
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        java.lang.Class<?> wildcardClass5 = year2.getClass();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        java.util.Date date13 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone19);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week22.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getFirstMillisecond();
        java.lang.String str9 = week2.toString();
        java.util.Date date10 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.Year year16 = week0.getYear();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(year16);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        int int7 = week5.compareTo((java.lang.Object) (short) -1);
//        java.util.Calendar calendar8 = null;
//        try {
//            week5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-1), year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(3, year6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week9.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        java.lang.String str11 = week2.toString();
        java.util.Calendar calendar12 = null;
        try {
            week2.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 100, 12" + "'", str11.equals("Week 100, 12"));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.Date date6 = week5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        java.lang.String str10 = week7.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week15.next();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.lang.String str21 = week20.toString();
//        long long22 = week20.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = week20.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week20.next();
//        java.util.Date date25 = week20.getEnd();
//        java.lang.Class class26 = null;
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date25, timeZone28);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date19, timeZone28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date12, timeZone28);
//        java.util.Locale locale33 = null;
//        try {
//            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date6, timeZone28, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        long long10 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1545249599999L + "'", long10 == 1545249599999L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date5, timeZone11);
        int int14 = week13.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException6.getClass();
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.util.Date date18 = week15.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean25 = week3.equals((java.lang.Object) wildcardClass9);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.lang.String str27 = week26.toString();
//        java.util.Date date28 = week26.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        java.util.Date date30 = week29.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Throwable[] throwableArray34 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException32.getClass();
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
//        int int43 = week41.compareTo((java.lang.Object) false);
//        java.util.Date date44 = week41.getStart();
//        java.lang.Class class45 = null;
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date44, timeZone47);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        boolean boolean51 = week29.equals((java.lang.Object) wildcardClass35);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
//        java.util.Date date56 = regularTimePeriod55.getStart();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        long long59 = week58.getLastMillisecond();
//        boolean boolean61 = week58.equals((java.lang.Object) 0.0d);
//        long long62 = week58.getMiddleMillisecond();
//        int int63 = week58.getWeek();
//        java.lang.String str64 = week58.toString();
//        java.lang.Class<?> wildcardClass65 = week58.getClass();
//        java.util.Date date66 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(100, 12);
//        int int71 = week69.compareTo((java.lang.Object) false);
//        java.util.Date date72 = week69.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray75 = timePeriodFormatException74.getSuppressed();
//        java.lang.Class<?> wildcardClass76 = timePeriodFormatException74.getClass();
//        java.util.Date date77 = null;
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date77, timeZone78);
//        java.util.Date date80 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException82 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray83 = timePeriodFormatException82.getSuppressed();
//        java.lang.Class<?> wildcardClass84 = timePeriodFormatException82.getClass();
//        java.util.Date date85 = null;
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date85, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date80, timeZone86);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date72, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date66, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date56, timeZone86);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException93 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray94 = timePeriodFormatException93.getSuppressed();
//        java.lang.Class<?> wildcardClass95 = timePeriodFormatException93.getClass();
//        java.util.Date date96 = null;
//        java.util.TimeZone timeZone97 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass95, date96, timeZone97);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date56, timeZone97);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560668399999L + "'", long59 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560365999999L + "'", long62 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 24 + "'", int63 == 24);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Week 24, 2019" + "'", str64.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(throwableArray75);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(throwableArray83);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(throwableArray94);
//        org.junit.Assert.assertNotNull(wildcardClass95);
//        org.junit.Assert.assertNotNull(timeZone97);
//        org.junit.Assert.assertNull(regularTimePeriod98);
//        org.junit.Assert.assertNull(regularTimePeriod99);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        java.util.Date date4 = year2.getStart();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        java.util.Date date17 = week0.getStart();
//        int int18 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = week3.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        long long8 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 100, 12" + "'", str7.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 736L + "'", long8 == 736L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729531200001L) + "'", long7 == (-61729531200001L));
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        int int10 = week0.compareTo((java.lang.Object) str9);
//        java.lang.String str11 = week0.toString();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        long long17 = week14.getMiddleMillisecond();
//        boolean boolean19 = week14.equals((java.lang.Object) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week14.next();
//        try {
//            int int21 = week0.compareTo((java.lang.Object) week14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61728926400001L) + "'", long17 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        int int7 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week0.next();
//        java.util.Date date18 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.lang.String str16 = week14.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 47, 13" + "'", str16.equals("Week 47, 13"));
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        java.util.Date date9 = year7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone20);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.previous();
//        java.lang.String str27 = week24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week24.next();
//        long long29 = week24.getSerialIndex();
//        java.util.Date date30 = week24.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week33.next();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getLastMillisecond();
//        boolean boolean41 = week38.equals((java.lang.Object) 0.0d);
//        long long42 = week38.getMiddleMillisecond();
//        int int43 = week38.getWeek();
//        java.lang.String str44 = week38.toString();
//        java.lang.Class<?> wildcardClass45 = week38.getClass();
//        java.util.Date date46 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
//        int int51 = week49.compareTo((java.lang.Object) false);
//        java.util.Date date52 = week49.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException54.getClass();
//        java.util.Date date57 = null;
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date57, timeZone58);
//        java.util.Date date60 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray63 = timePeriodFormatException62.getSuppressed();
//        java.lang.Class<?> wildcardClass64 = timePeriodFormatException62.getClass();
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone66);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date52, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date37, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date30, timeZone66);
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize(class75);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560365999999L + "'", long42 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(throwableArray63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(class73);
//        org.junit.Assert.assertNotNull(class74);
//        org.junit.Assert.assertNotNull(class75);
//        org.junit.Assert.assertNotNull(class76);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getFirstMillisecond();
        int int10 = week2.compareTo((java.lang.Object) 1560970799999L);
        java.util.Calendar calendar11 = null;
        try {
            week2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException7.getSuppressed();
        java.lang.String str15 = timePeriodFormatException7.toString();
        boolean boolean16 = week2.equals((java.lang.Object) timePeriodFormatException7);
        java.util.Calendar calendar17 = null;
        try {
            week2.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Date date3 = year2.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException5.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, 0);
//        long long14 = week13.getLastMillisecond();
//        java.util.Date date15 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        java.util.Date date20 = regularTimePeriod19.getStart();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone23);
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date3, timeZone23, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62167708800001L) + "'", long14 == (-62167708800001L));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 2, -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        int int8 = week0.getYearValue();
//        org.jfree.data.time.Year year9 = week0.getYear();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week0.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        long long7 = week3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.lang.Object obj8 = null;
        int int9 = week2.compareTo(obj8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.String str8 = timePeriodFormatException4.toString();
        java.lang.String str9 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException4.getSuppressed();
        java.lang.String str12 = timePeriodFormatException4.toString();
        java.lang.String str13 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException15.getClass();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = week0.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
//        java.util.Date date10 = week9.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        long long13 = week12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.previous();
//        java.lang.String str15 = week12.toString();
//        int int16 = week12.getYearValue();
//        org.jfree.data.time.Year year17 = week12.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, year17);
//        int int19 = week18.getYearValue();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
//        int int24 = week22.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        java.util.Date date26 = week22.getStart();
//        java.lang.Class class27 = null;
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
//        int int32 = week18.compareTo((java.lang.Object) timeZone29);
//        java.util.Locale locale33 = null;
//        try {
//            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date10, timeZone29, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = regularTimePeriod4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        java.util.Date date9 = year7.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(10, year7);
//        java.util.Date date11 = year7.getStart();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(class11);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(8, year3);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.String str6 = week2.toString();
        long long7 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 12" + "'", str6.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61728926400001L) + "'", long7 == (-61728926400001L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        boolean boolean4 = week0.equals((java.lang.Object) 1560365999999L);
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        java.util.Date date10 = regularTimePeriod9.getStart();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
//        java.lang.Class<?> wildcardClass16 = date10.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 12);
//        int int21 = week19.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        java.util.Date date23 = week19.getStart();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
//        java.util.Date date33 = regularTimePeriod32.getStart();
//        java.lang.Class class34 = null;
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date33, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone36);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        java.util.Date date44 = regularTimePeriod43.getStart();
//        java.lang.Class class45 = null;
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date44, timeZone47);
//        java.lang.Class<?> wildcardClass50 = date44.getClass();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(100, 12);
//        int int55 = week53.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass56 = week53.getClass();
//        java.util.Date date57 = week53.getStart();
//        java.lang.Class class58 = null;
//        java.util.Date date59 = null;
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date57, timeZone60);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week65.previous();
//        java.util.Date date67 = regularTimePeriod66.getStart();
//        java.lang.Class class68 = null;
//        java.util.Date date69 = null;
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date69, timeZone70);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date67, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date57, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date23, timeZone70);
//        java.util.Locale locale75 = null;
//        try {
//            org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date5, timeZone70, locale75);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
//        long long4 = regularTimePeriod2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        long long8 = week7.getLastMillisecond();
//        java.lang.String str9 = week7.toString();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1552204799999L + "'", long8 == 1552204799999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 10, 2019" + "'", str9.equals("Week 10, 2019"));
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getLastMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        try {
//            org.jfree.data.time.Year year56 = week55.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(3, year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Year year4 = week3.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year4.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(13, (-1));
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        boolean boolean7 = week2.equals((java.lang.Object) 10);
//        java.util.Date date8 = week2.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.lang.String str17 = week16.toString();
//        long long18 = week16.getFirstMillisecond();
//        org.jfree.data.time.Year year19 = week16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week16.next();
//        java.util.Date date21 = week16.getEnd();
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date21, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date15, timeZone24);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        java.util.Date date32 = regularTimePeriod31.getStart();
//        java.lang.Class class33 = null;
//        java.util.Date date34 = null;
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
//        java.lang.Class<?> wildcardClass38 = date32.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
//        int int43 = week41.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass44 = week41.getClass();
//        java.util.Date date45 = week41.getStart();
//        java.lang.Class class46 = null;
//        java.util.Date date47 = null;
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date45, timeZone48);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
//        java.util.Date date55 = regularTimePeriod54.getStart();
//        java.lang.Class class56 = null;
//        java.util.Date date57 = null;
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date55, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date45, timeZone58);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
//        java.util.Date date66 = regularTimePeriod65.getStart();
//        java.lang.Class class67 = null;
//        java.util.Date date68 = null;
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
//        java.lang.Class<?> wildcardClass72 = date66.getClass();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(100, 12);
//        int int77 = week75.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass78 = week75.getClass();
//        java.util.Date date79 = week75.getStart();
//        java.lang.Class class80 = null;
//        java.util.Date date81 = null;
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date81, timeZone82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date79, timeZone82);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = week87.previous();
//        java.util.Date date89 = regularTimePeriod88.getStart();
//        java.lang.Class class90 = null;
//        java.util.Date date91 = null;
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class90, date91, timeZone92);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date89, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date79, timeZone92);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date45, timeZone92);
//        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date15, timeZone92);
//        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date8, timeZone92);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        java.lang.String str13 = timePeriodFormatException7.toString();
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
//        java.lang.String str16 = week0.toString();
//        java.util.Date date17 = week0.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        int int10 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        java.util.Date date13 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone19);
        long long23 = week22.getFirstMillisecond();
        java.util.Calendar calendar24 = null;
        try {
            long long25 = week22.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61729228800000L) + "'", long23 == (-61729228800000L));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.String str6 = week2.toString();
        long long7 = week2.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 12" + "'", str6.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61728926400001L) + "'", long7 == (-61728926400001L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 11);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        java.lang.String str10 = week2.toString();
        java.lang.String str11 = week2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 100, 12" + "'", str10.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 100, 12" + "'", str11.equals("Week 100, 12"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 0);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week13.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
//        long long10 = week9.getLastMillisecond();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        java.util.Date date16 = regularTimePeriod15.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
//        java.lang.Class<?> wildcardClass22 = date16.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
//        int int27 = week25.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        java.util.Date date29 = week25.getStart();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date29, timeZone32);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
//        java.util.Date date39 = regularTimePeriod38.getStart();
//        java.lang.Class class40 = null;
//        java.util.Date date41 = null;
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date39, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date29, timeZone42);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
//        java.util.Date date50 = regularTimePeriod49.getStart();
//        java.lang.Class class51 = null;
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date50, timeZone53);
//        java.lang.Class<?> wildcardClass56 = date50.getClass();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(100, 12);
//        int int61 = week59.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass62 = week59.getClass();
//        java.util.Date date63 = week59.getStart();
//        java.lang.Class class64 = null;
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date63, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.previous();
//        java.util.Date date73 = regularTimePeriod72.getStart();
//        java.lang.Class class74 = null;
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date73, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date63, timeZone76);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date29, timeZone76);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date11, timeZone76);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date6, timeZone76);
//        int int83 = week82.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 24 + "'", int83 == 24);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getStart();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        java.util.Locale locale10 = null;
//        try {
//            org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5, timeZone8, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        int int10 = week0.compareTo((java.lang.Object) str9);
//        int int11 = week0.getYearValue();
//        java.lang.String str12 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.String str15 = timePeriodFormatException14.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
//        java.lang.Throwable[] throwableArray22 = timePeriodFormatException20.getSuppressed();
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException20.getClass();
//        java.lang.String str24 = timePeriodFormatException20.toString();
//        java.lang.String str25 = timePeriodFormatException20.toString();
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException29.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
//        java.lang.String str35 = timePeriodFormatException29.toString();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        java.lang.Throwable[] throwableArray37 = timePeriodFormatException14.getSuppressed();
//        boolean boolean38 = week0.equals((java.lang.Object) throwableArray37);
//        long long39 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729228800000L) + "'", long7 == (-61729228800000L));
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.util.Date date12 = week9.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, 12);
//        int int17 = week15.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        java.util.Date date19 = week15.getStart();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date19, timeZone22);
//        java.lang.Class<?> wildcardClass25 = timeZone22.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone22);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        long long30 = week29.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week29.previous();
//        java.lang.String str32 = week29.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week29.next();
//        java.util.Date date34 = regularTimePeriod33.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(100, 12);
//        int int39 = week37.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week37.next();
//        java.util.Date date41 = week37.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.lang.String str43 = week42.toString();
//        long long44 = week42.getFirstMillisecond();
//        org.jfree.data.time.Year year45 = week42.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week42.next();
//        java.util.Date date47 = week42.getEnd();
//        java.lang.Class class48 = null;
//        java.util.Date date49 = null;
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date41, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date34, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date12, timeZone50);
//        java.util.Locale locale56 = null;
//        try {
//            org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date0, timeZone50, locale56);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560668399999L + "'", long30 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 24, 2019" + "'", str32.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560063600000L + "'", long44 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 157L + "'", long5 == 157L);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
//        java.lang.Class<?> wildcardClass4 = timePeriodFormatException2.getClass();
//        java.util.Date date5 = null;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        java.util.Date date13 = week8.getEnd();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date13, timeZone16);
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone21);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.lang.String str27 = week26.toString();
//        java.util.Date date28 = week26.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        int int30 = week29.getWeek();
//        java.util.Date date31 = week29.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date13, timeZone32);
//        org.junit.Assert.assertNotNull(throwableArray3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        boolean boolean18 = week0.equals((java.lang.Object) timePeriodFormatException17);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 7);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
        int int10 = week8.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.util.Date date12 = week8.getStart();
        boolean boolean13 = week2.equals((java.lang.Object) date12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 12);
        int int19 = week17.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass20 = week17.getClass();
        java.util.Date date21 = week17.getStart();
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date21, timeZone24);
        java.lang.Class<?> wildcardClass27 = timeZone24.getClass();
        java.util.Locale locale28 = null;
        try {
            org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date12, timeZone24, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.previous();
//        java.lang.String str8 = week5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
//        int int15 = week13.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        java.util.Date date17 = week13.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        long long20 = week18.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = week18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week18.next();
//        java.util.Date date23 = week18.getEnd();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date17, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date10, timeZone26);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        java.util.Date date37 = week33.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date37, timeZone40);
//        java.lang.Class<?> wildcardClass43 = timeZone40.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date10, timeZone40);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date2, timeZone40);
//        long long46 = week45.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560365999999L + "'", long46 == 1560365999999L);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(4, year5);
//        int int7 = week6.getYearValue();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        boolean boolean11 = week2.equals((java.lang.Object) str10);
        int int12 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getMiddleMillisecond();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728926400001L) + "'", long8 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 736L + "'", long9 == 736L);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.lang.String str3 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getSerialIndex();
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        int int10 = week7.getWeek();
        int int11 = week7.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47 + "'", int8 == 47);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 47 + "'", int10 == 47);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 53);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        long long9 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61729228800000L) + "'", long9 == (-61729228800000L));
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        java.util.Date date0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
//        java.lang.Class<?> wildcardClass4 = timePeriodFormatException2.getClass();
//        java.util.Date date5 = null;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        java.util.Date date13 = week8.getEnd();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date13, timeZone16);
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone21);
//        java.util.Locale locale24 = null;
//        try {
//            org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date0, timeZone21, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getSerialIndex();
//        int int6 = week3.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
//        java.lang.Class<?> wildcardClass4 = timePeriodFormatException2.getClass();
//        java.util.Date date5 = null;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        java.util.Date date13 = week8.getEnd();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date13, timeZone16);
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone21);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date13, timeZone24);
//        java.util.TimeZone timeZone26 = null;
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date13, timeZone26, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        int int9 = week2.compareTo((java.lang.Object) class8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.lang.String str11 = week10.toString();
//        java.util.Date date12 = week10.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        java.util.Date date14 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 12);
//        int int19 = week17.compareTo((java.lang.Object) false);
//        java.util.Date date20 = week17.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone26);
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        java.lang.Class class18 = null;
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone20);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.previous();
//        java.lang.String str27 = week24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week24.next();
//        long long29 = week24.getSerialIndex();
//        java.util.Date date30 = week24.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(100, 12);
//        int int35 = week33.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week33.next();
//        java.util.Date date37 = week33.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        long long39 = week38.getLastMillisecond();
//        boolean boolean41 = week38.equals((java.lang.Object) 0.0d);
//        long long42 = week38.getMiddleMillisecond();
//        int int43 = week38.getWeek();
//        java.lang.String str44 = week38.toString();
//        java.lang.Class<?> wildcardClass45 = week38.getClass();
//        java.util.Date date46 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
//        int int51 = week49.compareTo((java.lang.Object) false);
//        java.util.Date date52 = week49.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException54.getClass();
//        java.util.Date date57 = null;
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date57, timeZone58);
//        java.util.Date date60 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray63 = timePeriodFormatException62.getSuppressed();
//        java.lang.Class<?> wildcardClass64 = timePeriodFormatException62.getClass();
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone66);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date52, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date37, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date30, timeZone66);
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize(class73);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560668399999L + "'", long39 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560365999999L + "'", long42 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(throwableArray63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(class73);
//        org.junit.Assert.assertNotNull(class74);
//        org.junit.Assert.assertNotNull(class75);
//        org.junit.Assert.assertNotNull(class76);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        try {
            org.jfree.data.time.Year year8 = week7.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = regularTimePeriod4.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(9, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(3, year3);
        long long6 = week5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1547668799999L + "'", long6 == 1547668799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1548273599999L + "'", long8 == 1548273599999L);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        java.util.Date date17 = week0.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(100, 12);
//        int int22 = week20.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week20.next();
//        java.util.Date date24 = week20.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        long long26 = week25.getLastMillisecond();
//        boolean boolean28 = week25.equals((java.lang.Object) 0.0d);
//        long long29 = week25.getMiddleMillisecond();
//        int int30 = week25.getWeek();
//        java.lang.String str31 = week25.toString();
//        java.lang.Class<?> wildcardClass32 = week25.getClass();
//        java.util.Date date33 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        java.util.Date date39 = week36.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
//        java.lang.Class<?> wildcardClass43 = timePeriodFormatException41.getClass();
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
//        java.util.Date date47 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
//        java.lang.Class<?> wildcardClass51 = timePeriodFormatException49.getClass();
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date39, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date24, timeZone53);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date17, timeZone53);
//        org.jfree.data.time.Year year60 = week59.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(throwableArray42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(throwableArray50);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year60);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 736L + "'", long7 == 736L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 24);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        java.util.Date date8 = year6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getLastMillisecond();
//        boolean boolean19 = week16.equals((java.lang.Object) 0.0d);
//        long long20 = week16.getMiddleMillisecond();
//        int int21 = week16.getWeek();
//        java.lang.String str22 = week16.toString();
//        java.lang.Class<?> wildcardClass23 = week16.getClass();
//        java.util.Date date24 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(100, 12);
//        int int29 = week27.compareTo((java.lang.Object) false);
//        java.util.Date date30 = week27.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        java.util.Date date38 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date30, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone44);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date15, timeZone44);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        long long51 = week50.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week50.previous();
//        java.lang.String str53 = week50.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week50.next();
//        java.util.Date date55 = regularTimePeriod54.getEnd();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(100, 12);
//        int int60 = week58.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week58.next();
//        java.util.Date date62 = week58.getStart();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        java.lang.String str64 = week63.toString();
//        long long65 = week63.getFirstMillisecond();
//        org.jfree.data.time.Year year66 = week63.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week63.next();
//        java.util.Date date68 = week63.getEnd();
//        java.lang.Class class69 = null;
//        java.util.Date date70 = null;
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date68, timeZone71);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date62, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date55, timeZone71);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(100, 12);
//        int int80 = week78.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass81 = week78.getClass();
//        java.util.Date date82 = week78.getStart();
//        java.lang.Class class83 = null;
//        java.util.Date date84 = null;
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date82, timeZone85);
//        java.lang.Class<?> wildcardClass88 = timeZone85.getClass();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date55, timeZone85);
//        boolean boolean90 = week49.equals((java.lang.Object) timeZone85);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date8, timeZone85);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560365999999L + "'", long20 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 24, 2019" + "'", str22.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560668399999L + "'", long51 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Week 24, 2019" + "'", str53.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Week 24, 2019" + "'", str64.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560063600000L + "'", long65 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(wildcardClass88);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        int int5 = week4.getWeek();
//        java.util.Date date6 = week4.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
//        java.util.Locale locale9 = null;
//        try {
//            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date0, timeZone7, locale9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        java.util.Calendar calendar10 = null;
        try {
            week2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        int int16 = week5.getWeek();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
        int int38 = week36.compareTo((java.lang.Object) false);
        long long39 = week36.getMiddleMillisecond();
        long long40 = week36.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week36.next();
        java.util.Date date42 = week36.getEnd();
        java.lang.Class<?> wildcardClass43 = date42.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
        java.util.Date date46 = null;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, 12);
        int int51 = week49.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass52 = week49.getClass();
        java.util.Date date53 = week49.getStart();
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date53, timeZone56);
        java.lang.Class<?> wildcardClass59 = timeZone56.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone56);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date17, timeZone56);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61728926400001L) + "'", long39 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61728624000001L) + "'", long40 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNull(regularTimePeriod60);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        java.lang.String str5 = week2.toString();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 10);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61845350400001L) + "'", long3 == (-61845350400001L));
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
//        long long57 = regularTimePeriod56.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61728321600001L) + "'", long57 == (-61728321600001L));
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 10, year5);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        java.util.Date date13 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone19);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getStart();
        int int25 = week22.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61729228800000L) + "'", long23 == (-61729228800000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 47 + "'", int25 == 47);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.lang.String str6 = week5.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 0, 2019" + "'", str6.equals("Week 0, 2019"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getSerialIndex();
        long long11 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 736L + "'", long10 == 736L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61729228800000L) + "'", long11 == (-61729228800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 100, 12" + "'", str3.equals("Week 100, 12"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, 12);
        int int12 = week10.compareTo((java.lang.Object) false);
        java.util.Date date13 = week10.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date13, timeZone16);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.util.Date date24 = regularTimePeriod23.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
        java.lang.Class<?> wildcardClass30 = date24.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        java.util.Date date38 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date24, timeZone44);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
        java.lang.Class<?> wildcardClass51 = timePeriodFormatException49.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date24, timeZone53);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 100, 12" + "'", str7.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(6, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 0);
        long long10 = week9.getLastMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException24.getSuppressed();
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        java.util.Date date30 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone36);
        java.util.Calendar calendar40 = null;
        try {
            week39.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167708800001L) + "'", long10 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException19.getClass();
        java.lang.String str23 = timePeriodFormatException19.toString();
        java.lang.String str24 = timePeriodFormatException19.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str27 = timePeriodFormatException19.toString();
        java.lang.String str28 = timePeriodFormatException19.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        int int6 = week5.getWeek();
//        int int7 = week5.getWeek();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week5.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week3.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getFirstMillisecond();
        boolean boolean10 = week2.equals((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61729228800000L) + "'", long8 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 3, 4");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        long long8 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = date4.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(100, 12);
        int int15 = week13.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.util.Date date17 = week13.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date17);
        long long35 = week34.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61728624000001L) + "'", long35 == (-61728624000001L));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        int int20 = week6.getYearValue();
//        long long21 = week6.getFirstMillisecond();
//        java.util.Date date22 = week6.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date22);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
//        java.util.Calendar calendar57 = null;
//        try {
//            week55.peg(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 12, 11");
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        boolean boolean2 = week0.equals((java.lang.Object) 1);
//        long long3 = week0.getFirstMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        java.util.Date date9 = week2.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728624000001L) + "'", long8 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        try {
            org.jfree.data.time.Year year9 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException7.getClass();
        java.lang.String str11 = timePeriodFormatException7.toString();
        java.lang.String str12 = timePeriodFormatException7.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException19.getClass();
        java.lang.String str23 = timePeriodFormatException19.toString();
        java.lang.String str24 = timePeriodFormatException19.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException28.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException32.getSuppressed();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException32.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.String str37 = timePeriodFormatException32.toString();
        java.lang.String str38 = timePeriodFormatException32.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
        int int14 = week12.compareTo((java.lang.Object) false);
        long long15 = week12.getMiddleMillisecond();
        long long16 = week12.getLastMillisecond();
        java.util.Date date17 = week12.getEnd();
        int int19 = week12.compareTo((java.lang.Object) 8);
        int int20 = week2.compareTo((java.lang.Object) int19);
        try {
            org.jfree.data.time.Year year21 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728926400001L) + "'", long15 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61728624000001L) + "'", long16 == (-61728624000001L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException2.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException2.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
        int int13 = week11.compareTo((java.lang.Object) false);
        java.util.Date date14 = week11.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone17);
        try {
            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date0, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62073662400001L) + "'", long5 == (-62073662400001L));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.lang.Object obj5 = null;
        int int6 = week4.compareTo(obj5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getFirstMillisecond();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.String str12 = timePeriodFormatException6.toString();
//        int int13 = week3.compareTo((java.lang.Object) str12);
//        int int14 = week3.getYearValue();
//        java.lang.String str15 = week3.toString();
//        boolean boolean16 = week1.equals((java.lang.Object) week3);
//        org.jfree.data.time.Year year17 = week1.getYear();
//        java.util.Date date18 = week1.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(100, 12);
//        int int23 = week21.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week21.next();
//        java.util.Date date25 = week21.getStart();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getLastMillisecond();
//        boolean boolean29 = week26.equals((java.lang.Object) 0.0d);
//        long long30 = week26.getMiddleMillisecond();
//        int int31 = week26.getWeek();
//        java.lang.String str32 = week26.toString();
//        java.lang.Class<?> wildcardClass33 = week26.getClass();
//        java.util.Date date34 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(100, 12);
//        int int39 = week37.compareTo((java.lang.Object) false);
//        java.util.Date date40 = week37.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray43 = timePeriodFormatException42.getSuppressed();
//        java.lang.Class<?> wildcardClass44 = timePeriodFormatException42.getClass();
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
//        java.util.Date date48 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray51 = timePeriodFormatException50.getSuppressed();
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException50.getClass();
//        java.util.Date date53 = null;
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone54);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date40, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone54);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date25, timeZone54);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date18, timeZone54);
//        try {
//            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date0, timeZone54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560365999999L + "'", long30 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 24, 2019" + "'", str32.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(throwableArray43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(throwableArray51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
//        long long12 = week11.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        java.lang.Class<?> wildcardClass49 = date43.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, 12);
        int int54 = week52.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        java.util.Date date56 = week52.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.util.Date date66 = regularTimePeriod65.getStart();
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date56, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date22, timeZone69);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date4, timeZone69);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date4);
        java.util.Calendar calendar76 = null;
        try {
            long long77 = week75.getLastMillisecond(calendar76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        java.util.Date date10 = regularTimePeriod9.getStart();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
//        java.util.Locale locale16 = null;
//        try {
//            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date5, timeZone13, locale16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException3.getSuppressed();
        java.lang.String str12 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729228800000L) + "'", long7 == (-61729228800000L));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = regularTimePeriod9.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week5.equals((java.lang.Object) date13);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = week5.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545552000000L + "'", long6 == 1545552000000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 10, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Date date8 = regularTimePeriod7.getStart();
        java.util.Date date9 = regularTimePeriod7.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
//        int int8 = week6.compareTo((java.lang.Object) false);
//        java.lang.String str9 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year12);
//        int int14 = week6.compareTo((java.lang.Object) 0);
//        long long15 = week6.getMiddleMillisecond();
//        boolean boolean16 = week0.equals((java.lang.Object) week6);
//        org.jfree.data.time.Year year17 = week0.getYear();
//        long long18 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61728926400001L) + "'", long15 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
        java.lang.String str8 = timePeriodFormatException4.toString();
        java.lang.String str9 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str22 = timePeriodFormatException12.toString();
        java.lang.String str23 = timePeriodFormatException12.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.next();
//        java.util.Date date12 = week7.getEnd();
//        java.lang.Class class13 = null;
//        java.util.Date date14 = null;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date6, timeZone15);
//        int int19 = week18.getWeek();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 47 + "'", int19 == 47);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        int int12 = week2.compareTo((java.lang.Object) str11);
//        int int13 = week2.getYearValue();
//        java.lang.String str14 = week2.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) week2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, 12);
//        int int11 = week9.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        java.util.Date date13 = week9.getStart();
//        java.lang.String str14 = week9.toString();
//        java.util.Date date15 = week9.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
//        int int20 = week18.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.next();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getLastMillisecond();
//        boolean boolean26 = week23.equals((java.lang.Object) 0.0d);
//        long long27 = week23.getMiddleMillisecond();
//        int int28 = week23.getWeek();
//        java.lang.String str29 = week23.toString();
//        java.lang.Class<?> wildcardClass30 = week23.getClass();
//        java.util.Date date31 = null;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(100, 12);
//        int int36 = week34.compareTo((java.lang.Object) false);
//        java.util.Date date37 = week34.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray40 = timePeriodFormatException39.getSuppressed();
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException39.getClass();
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
//        java.util.Date date45 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray48 = timePeriodFormatException47.getSuppressed();
//        java.lang.Class<?> wildcardClass49 = timePeriodFormatException47.getClass();
//        java.util.Date date50 = null;
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date45, timeZone51);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date37, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone51);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date22, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date15, timeZone51);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 100, 12" + "'", str14.equals("Week 100, 12"));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 24, 2019" + "'", str29.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(throwableArray40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        int int9 = week7.getYearValue();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
//        int int14 = week12.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.next();
//        java.util.Date date16 = week12.getStart();
//        int int17 = week12.getWeek();
//        java.lang.Object obj18 = null;
//        int int19 = week12.compareTo(obj18);
//        boolean boolean20 = week7.equals((java.lang.Object) week12);
//        long long21 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1544947200000L + "'", long21 == 1544947200000L);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 100, year4);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getWeek();
        int int9 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(47, 47);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2538L + "'", long3 == 2538L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728624000001L) + "'", long8 == (-61728624000001L));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) '#');
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException4.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        int int9 = week2.compareTo((java.lang.Object) class8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.lang.String str11 = week10.toString();
//        java.util.Date date12 = week10.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        java.util.Date date14 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 12);
//        int int19 = week17.compareTo((java.lang.Object) false);
//        java.util.Date date20 = week17.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
//        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date20, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone26);
//        long long30 = regularTimePeriod29.getMiddleMillisecond();
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = regularTimePeriod29.getMiddleMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 0, year4);
//        long long6 = week5.getSerialIndex();
//        long long7 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107007L + "'", long6 == 107007L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107007L + "'", long7 == 107007L);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
//        long long12 = week11.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.next();
        long long12 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61729228800000L) + "'", long10 == (-61729228800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61728624000001L) + "'", long12 == (-61728624000001L));
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        long long11 = week8.getMiddleMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.lang.String str13 = week12.toString();
//        java.util.Date date14 = week12.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, 12);
//        int int19 = week17.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass20 = week17.getClass();
//        java.util.Date date21 = week17.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.Date date23 = week22.getStart();
//        int int24 = week12.compareTo((java.lang.Object) date23);
//        boolean boolean25 = week8.equals((java.lang.Object) week12);
//        int int26 = week12.getYearValue();
//        long long27 = week12.getFirstMillisecond();
//        java.util.Date date28 = week12.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date28, timeZone29);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        java.util.Date date38 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray41 = timePeriodFormatException40.getSuppressed();
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException40.getClass();
//        java.util.Date date43 = null;
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date28, timeZone44);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61728926400001L) + "'", long11 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560063600000L + "'", long27 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(throwableArray41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        long long6 = week2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
//        java.util.Date date8 = week2.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year14 = week11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
//        java.util.Date date16 = week11.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(100, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        java.util.Date date21 = regularTimePeriod20.getStart();
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date21, timeZone24);
//        java.lang.Class<?> wildcardClass27 = date21.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, 12);
//        int int34 = week32.compareTo((java.lang.Object) false);
//        long long35 = week32.getFirstMillisecond();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(100, 12);
//        int int40 = week38.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass41 = week38.getClass();
//        java.util.Date date42 = week38.getStart();
//        boolean boolean43 = week32.equals((java.lang.Object) date42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(100, 12);
//        int int48 = week46.compareTo((java.lang.Object) false);
//        java.util.Date date49 = week46.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray52 = timePeriodFormatException51.getSuppressed();
//        java.lang.Class<?> wildcardClass53 = timePeriodFormatException51.getClass();
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
//        java.util.Date date57 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray60 = timePeriodFormatException59.getSuppressed();
//        java.lang.Class<?> wildcardClass61 = timePeriodFormatException59.getClass();
//        java.util.Date date62 = null;
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone63);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date49, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date42, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone63);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61729228800000L) + "'", long35 == (-61729228800000L));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(throwableArray52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(throwableArray60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
        java.util.Date date16 = week0.getStart();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.Date date4 = week3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        int int7 = week5.compareTo((java.lang.Object) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        long long10 = week5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        java.util.Date date13 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date5, timeZone19);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(100, 12);
        int int27 = week25.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass28 = week25.getClass();
        java.util.Date date29 = week25.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date29, timeZone32);
        java.lang.Class<?> wildcardClass35 = timeZone32.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date5, timeZone32);
        int int37 = week36.getWeek();
        java.util.Date date38 = week36.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 47 + "'", int37 == 47);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        long long10 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year11 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 100, 12" + "'", str8.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61729228800000L) + "'", long10 == (-61729228800000L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        java.lang.String str9 = week2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        int int10 = week0.compareTo((java.lang.Object) str9);
//        int int11 = week0.getYearValue();
//        java.lang.String str12 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.String str15 = timePeriodFormatException14.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
//        java.lang.Throwable[] throwableArray22 = timePeriodFormatException20.getSuppressed();
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException20.getClass();
//        java.lang.String str24 = timePeriodFormatException20.toString();
//        java.lang.String str25 = timePeriodFormatException20.toString();
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException29.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
//        java.lang.String str35 = timePeriodFormatException29.toString();
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        java.lang.Throwable[] throwableArray37 = timePeriodFormatException14.getSuppressed();
//        boolean boolean38 = week0.equals((java.lang.Object) throwableArray37);
//        java.util.Calendar calendar39 = null;
//        try {
//            long long40 = week0.getLastMillisecond(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
//        org.junit.Assert.assertNotNull(throwableArray18);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (-2007));
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-2007) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.previous();
//        java.lang.String str4 = week1.toString();
//        int int5 = week1.getYearValue();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year6);
//        int int8 = week7.getYearValue();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
//        int int21 = week7.compareTo((java.lang.Object) timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week7.next();
//        long long23 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1606032000000L + "'", long23 == 1606032000000L);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException14.getClass();
        java.lang.String str18 = timePeriodFormatException14.toString();
        java.lang.String str19 = timePeriodFormatException14.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getStart();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61729228800000L) + "'", long7 == (-61729228800000L));
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getFirstMillisecond();
//        int int9 = week7.getYearValue();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(100, 12);
//        int int14 = week12.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.next();
//        java.util.Date date16 = week12.getStart();
//        int int17 = week12.getWeek();
//        java.lang.Object obj18 = null;
//        int int19 = week12.compareTo(obj18);
//        boolean boolean20 = week7.equals((java.lang.Object) week12);
//        long long21 = week7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1544947200000L + "'", long8 == 1544947200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1545249599999L + "'", long21 == 1545249599999L);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.util.Date date7 = week2.getEnd();
        int int8 = week2.getYearValue();
        long long9 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61728926400001L) + "'", long9 == (-61728926400001L));
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        boolean boolean3 = week0.equals((java.lang.Object) 0.0d);
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        org.jfree.data.time.Year year8 = week0.getYear();
//        long long9 = week0.getMiddleMillisecond();
//        long long10 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(100, 12);
//        int int8 = week6.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.util.Date date10 = week6.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.Date date12 = week11.getStart();
//        int int13 = week1.compareTo((java.lang.Object) date12);
//        org.jfree.data.time.Year year14 = week1.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) -1, year14);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        boolean boolean7 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = regularTimePeriod11.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 100, 12" + "'", str9.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (-2007));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException20.getSuppressed();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
        java.lang.String str28 = timePeriodFormatException26.toString();
        java.lang.String str29 = timePeriodFormatException26.toString();
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray30);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        long long6 = week3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.util.Date date9 = regularTimePeriod8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = date9.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, 12);
        int int20 = week18.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        java.util.Date date22 = week18.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = regularTimePeriod31.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date43, timeZone46);
        java.lang.Class<?> wildcardClass49 = date43.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, 12);
        int int54 = week52.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass55 = week52.getClass();
        java.util.Date date56 = week52.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week64.previous();
        java.util.Date date66 = regularTimePeriod65.getStart();
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date56, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date22, timeZone69);
        boolean boolean74 = week2.equals((java.lang.Object) timeZone69);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167708800001L) + "'", long3 == (-62167708800001L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
        int int10 = week8.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.util.Date date12 = week8.getStart();
        boolean boolean13 = week2.equals((java.lang.Object) date12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61729228800000L) + "'", long5 == (-61729228800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date6, timeZone9);
        java.lang.Class<?> wildcardClass12 = date6.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        long long16 = regularTimePeriod15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61728321600001L) + "'", long16 == (-61728321600001L));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728926400001L) + "'", long6 == (-61728926400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 12, 11");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
//        int int4 = week2.compareTo((java.lang.Object) false);
//        long long5 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, 12);
//        int int13 = week11.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.Date date17 = week16.getStart();
//        int int18 = week6.compareTo((java.lang.Object) date17);
//        boolean boolean19 = week2.equals((java.lang.Object) week6);
//        try {
//            org.jfree.data.time.Year year20 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str9 = timePeriodFormatException5.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
        int int10 = week2.compareTo((java.lang.Object) 0);
        java.lang.Class<?> wildcardClass11 = week2.getClass();
        long long12 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 100, 12" + "'", str5.equals("Week 100, 12"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61728624000001L) + "'", long12 == (-61728624000001L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        int int8 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        java.util.Date date10 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 12);
        int int4 = week2.compareTo((java.lang.Object) false);
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61728926400001L) + "'", long5 == (-61728926400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61728624000001L) + "'", long6 == (-61728624000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61728624000001L) + "'", long8 == (-61728624000001L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, (int) (byte) -1);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, 12);
//        int int10 = week8.compareTo((java.lang.Object) false);
//        java.util.Date date11 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, 12);
//        int int16 = week14.compareTo((java.lang.Object) false);
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        java.util.Date date18 = week14.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
//        java.lang.String str31 = week28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week28.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(100, 12);
//        int int38 = week36.compareTo((java.lang.Object) false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        java.util.Date date40 = week36.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week41.next();
//        java.util.Date date46 = week41.getEnd();
//        java.lang.Class class47 = null;
//        java.util.Date date48 = null;
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date40, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date33, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date11, timeZone49);
//        long long55 = week54.getLastMillisecond();
//        long long56 = week54.getMiddleMillisecond();
//        java.lang.String str57 = week54.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-61728624000001L) + "'", long55 == (-61728624000001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61728926400001L) + "'", long56 == (-61728926400001L));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Week 47, 13" + "'", str57.equals("Week 47, 13"));
//    }
//}

